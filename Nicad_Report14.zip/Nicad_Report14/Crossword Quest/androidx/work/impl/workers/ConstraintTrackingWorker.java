package androidx.work.impl.workers;

import android.content.Context;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.Logger;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.WorkManagerImpl;
import androidx.work.impl.constraints.WorkConstraintsCallback;
import androidx.work.impl.constraints.WorkConstraintsTracker;
import androidx.work.impl.model.WorkSpec;
import androidx.work.impl.utils.futures.SettableFuture;
import androidx.work.impl.utils.taskexecutor.TaskExecutor;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.Collections;
import java.util.List;

public class ConstraintTrackingWorker extends ListenableWorker implements WorkConstraintsCallback {
  public static final String ARGUMENT_CLASS_NAME = "androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME";
  
  private static final String TAG = Logger.tagWithPrefix("ConstraintTrkngWrkr");
  
  volatile boolean mAreConstraintsUnmet;
  
  private ListenableWorker mDelegate;
  
  SettableFuture<ListenableWorker.Result> mFuture;
  
  final Object mLock;
  
  private WorkerParameters mWorkerParameters;
  
  public ConstraintTrackingWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
    this.mWorkerParameters = paramWorkerParameters;
    this.mLock = new Object();
    this.mAreConstraintsUnmet = false;
    this.mFuture = SettableFuture.create();
  }
  
  public ListenableWorker getDelegate() {
    return this.mDelegate;
  }
  
  public TaskExecutor getTaskExecutor() {
    return WorkManagerImpl.getInstance(getApplicationContext()).getWorkTaskExecutor();
  }
  
  public WorkDatabase getWorkDatabase() {
    return WorkManagerImpl.getInstance(getApplicationContext()).getWorkDatabase();
  }
  
  public boolean isRunInForeground() {
    ListenableWorker listenableWorker = this.mDelegate;
    return (listenableWorker != null && listenableWorker.isRunInForeground());
  }
  
  public void onAllConstraintsMet(List<String> paramList) {}
  
  public void onAllConstraintsNotMet(List<String> paramList) {
    Logger.get().debug(TAG, String.format("Constraints changed for %s", new Object[] { paramList }), new Throwable[0]);
    synchronized (this.mLock) {
      this.mAreConstraintsUnmet = true;
      return;
    } 
  }
  
  public void onStopped() {
    super.onStopped();
    ListenableWorker listenableWorker = this.mDelegate;
    if (listenableWorker != null && !listenableWorker.isStopped())
      this.mDelegate.stop(); 
  }
  
  void setFutureFailed() {
    this.mFuture.set(ListenableWorker.Result.failure());
  }
  
  void setFutureRetry() {
    this.mFuture.set(ListenableWorker.Result.retry());
  }
  
  void setupAndRunConstraintTrackingWork() {
    String str = getInputData().getString("androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME");
    if (TextUtils.isEmpty(str)) {
      Logger.get().error(TAG, "No worker to delegate to.", new Throwable[0]);
      setFutureFailed();
      return;
    } 
    ListenableWorker listenableWorker = getWorkerFactory().createWorkerWithDefaultFallback(getApplicationContext(), str, this.mWorkerParameters);
    this.mDelegate = listenableWorker;
    if (listenableWorker == null) {
      Logger.get().debug(TAG, "No worker to delegate to.", new Throwable[0]);
      setFutureFailed();
      return;
    } 
    WorkSpec workSpec = getWorkDatabase().workSpecDao().getWorkSpec(getId().toString());
    if (workSpec == null) {
      setFutureFailed();
      return;
    } 
    WorkConstraintsTracker workConstraintsTracker = new WorkConstraintsTracker(getApplicationContext(), getTaskExecutor(), this);
    workConstraintsTracker.replace(Collections.singletonList(workSpec));
    if (workConstraintsTracker.areAllConstraintsMet(getId().toString())) {
      Logger.get().debug(TAG, String.format("Constraints met for delegate %s", new Object[] { str }), new Throwable[0]);
      try {
        return;
      } finally {
        workConstraintsTracker = null;
        Logger logger = Logger.get();
        null = TAG;
        logger.debug(null, String.format("Delegated worker %s threw exception in startWork.", new Object[] { str }), new Throwable[] { (Throwable)workConstraintsTracker });
      } 
    } 
    Logger.get().debug(TAG, String.format("Constraints not met for delegate %s. Requesting retry.", new Object[] { str }), new Throwable[0]);
    setFutureRetry();
  }
  
  public ListenableFuture<ListenableWorker.Result> startWork() {
    getBackgroundExecutor().execute(new Runnable() {
          public void run() {
            ConstraintTrackingWorker.this.setupAndRunConstraintTrackingWork();
          }
        });
    return (ListenableFuture<ListenableWorker.Result>)this.mFuture;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\androidx\work\impl\workers\ConstraintTrackingWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */