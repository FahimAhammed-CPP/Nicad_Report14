package androidx.fragment.app;

import android.os.Bundle;
import androidx.lifecycle.LifecycleOwner;

public interface FragmentResultOwner {
  void clearFragmentResult(String paramString);
  
  void clearFragmentResultListener(String paramString);
  
  void setFragmentResult(String paramString, Bundle paramBundle);
  
  void setFragmentResultListener(String paramString, LifecycleOwner paramLifecycleOwner, FragmentResultListener paramFragmentResultListener);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\androidx\fragment\app\FragmentResultOwner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */