package androidx.webkit.internal;

import android.os.Handler;
import android.webkit.WebMessage;
import android.webkit.WebMessagePort;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebMessagePortCompat;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import org.chromium.support_lib_boundary.WebMessagePortBoundaryInterface;
import org.chromium.support_lib_boundary.util.BoundaryInterfaceReflectionUtil;

public class WebMessagePortImpl extends WebMessagePortCompat {
  private WebMessagePortBoundaryInterface mBoundaryInterface;
  
  private WebMessagePort mFrameworksImpl;
  
  public WebMessagePortImpl(WebMessagePort paramWebMessagePort) {
    this.mFrameworksImpl = paramWebMessagePort;
  }
  
  public WebMessagePortImpl(InvocationHandler paramInvocationHandler) {
    this.mBoundaryInterface = (WebMessagePortBoundaryInterface)BoundaryInterfaceReflectionUtil.castToSuppLibClass(WebMessagePortBoundaryInterface.class, paramInvocationHandler);
  }
  
  public static WebMessage compatToFrameworkMessage(WebMessageCompat paramWebMessageCompat) {
    return new WebMessage(paramWebMessageCompat.getData(), compatToPorts(paramWebMessageCompat.getPorts()));
  }
  
  public static WebMessagePort[] compatToPorts(WebMessagePortCompat[] paramArrayOfWebMessagePortCompat) {
    if (paramArrayOfWebMessagePortCompat == null)
      return null; 
    int j = paramArrayOfWebMessagePortCompat.length;
    WebMessagePort[] arrayOfWebMessagePort = new WebMessagePort[j];
    for (int i = 0; i < j; i++)
      arrayOfWebMessagePort[i] = paramArrayOfWebMessagePortCompat[i].getFrameworkPort(); 
    return arrayOfWebMessagePort;
  }
  
  public static WebMessageCompat frameworkMessageToCompat(WebMessage paramWebMessage) {
    return new WebMessageCompat(paramWebMessage.getData(), portsToCompat(paramWebMessage.getPorts()));
  }
  
  private WebMessagePortBoundaryInterface getBoundaryInterface() {
    if (this.mBoundaryInterface == null)
      this.mBoundaryInterface = (WebMessagePortBoundaryInterface)BoundaryInterfaceReflectionUtil.castToSuppLibClass(WebMessagePortBoundaryInterface.class, WebViewGlueCommunicator.getCompatConverter().convertWebMessagePort(this.mFrameworksImpl)); 
    return this.mBoundaryInterface;
  }
  
  private WebMessagePort getFrameworksImpl() {
    if (this.mFrameworksImpl == null)
      this.mFrameworksImpl = WebViewGlueCommunicator.getCompatConverter().convertWebMessagePort(Proxy.getInvocationHandler(this.mBoundaryInterface)); 
    return this.mFrameworksImpl;
  }
  
  public static WebMessagePortCompat[] portsToCompat(WebMessagePort[] paramArrayOfWebMessagePort) {
    if (paramArrayOfWebMessagePort == null)
      return null; 
    WebMessagePortCompat[] arrayOfWebMessagePortCompat = new WebMessagePortCompat[paramArrayOfWebMessagePort.length];
    for (int i = 0; i < paramArrayOfWebMessagePort.length; i++)
      arrayOfWebMessagePortCompat[i] = new WebMessagePortImpl(paramArrayOfWebMessagePort[i]); 
    return arrayOfWebMessagePortCompat;
  }
  
  public void close() {
    WebViewFeatureInternal webViewFeatureInternal = WebViewFeatureInternal.WEB_MESSAGE_PORT_CLOSE;
    if (webViewFeatureInternal.isSupportedByFramework()) {
      getFrameworksImpl().close();
      return;
    } 
    if (webViewFeatureInternal.isSupportedByWebView()) {
      getBoundaryInterface().close();
      return;
    } 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
  
  public WebMessagePort getFrameworkPort() {
    return getFrameworksImpl();
  }
  
  public InvocationHandler getInvocationHandler() {
    return Proxy.getInvocationHandler(getBoundaryInterface());
  }
  
  public void postMessage(WebMessageCompat paramWebMessageCompat) {
    WebViewFeatureInternal webViewFeatureInternal = WebViewFeatureInternal.WEB_MESSAGE_PORT_POST_MESSAGE;
    if (webViewFeatureInternal.isSupportedByFramework()) {
      getFrameworksImpl().postMessage(compatToFrameworkMessage(paramWebMessageCompat));
      return;
    } 
    if (webViewFeatureInternal.isSupportedByWebView()) {
      getBoundaryInterface().postMessage(BoundaryInterfaceReflectionUtil.createInvocationHandlerFor(new WebMessageAdapter(paramWebMessageCompat)));
      return;
    } 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
  
  public void setWebMessageCallback(Handler paramHandler, final WebMessagePortCompat.WebMessageCallbackCompat callback) {
    WebViewFeatureInternal webViewFeatureInternal = WebViewFeatureInternal.CREATE_WEB_MESSAGE_CHANNEL;
    if (webViewFeatureInternal.isSupportedByFramework()) {
      getFrameworksImpl().setWebMessageCallback(new WebMessagePort.WebMessageCallback() {
            public void onMessage(WebMessagePort param1WebMessagePort, WebMessage param1WebMessage) {
              callback.onMessage(new WebMessagePortImpl(param1WebMessagePort), WebMessagePortImpl.frameworkMessageToCompat(param1WebMessage));
            }
          }paramHandler);
      return;
    } 
    if (webViewFeatureInternal.isSupportedByWebView()) {
      getBoundaryInterface().setWebMessageCallback(BoundaryInterfaceReflectionUtil.createInvocationHandlerFor(new WebMessageCallbackAdapter(callback)), paramHandler);
      return;
    } 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
  
  public void setWebMessageCallback(final WebMessagePortCompat.WebMessageCallbackCompat callback) {
    WebViewFeatureInternal webViewFeatureInternal = WebViewFeatureInternal.WEB_MESSAGE_PORT_SET_MESSAGE_CALLBACK;
    if (webViewFeatureInternal.isSupportedByFramework()) {
      getFrameworksImpl().setWebMessageCallback(new WebMessagePort.WebMessageCallback() {
            public void onMessage(WebMessagePort param1WebMessagePort, WebMessage param1WebMessage) {
              callback.onMessage(new WebMessagePortImpl(param1WebMessagePort), WebMessagePortImpl.frameworkMessageToCompat(param1WebMessage));
            }
          });
      return;
    } 
    if (webViewFeatureInternal.isSupportedByWebView()) {
      getBoundaryInterface().setWebMessageCallback(BoundaryInterfaceReflectionUtil.createInvocationHandlerFor(new WebMessageCallbackAdapter(callback)));
      return;
    } 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\androidx\webkit\internal\WebMessagePortImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */