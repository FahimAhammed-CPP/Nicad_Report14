package androidx.webkit;

import android.os.Build;
import android.webkit.SafeBrowsingResponse;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.internal.SafeBrowsingResponseImpl;
import androidx.webkit.internal.WebResourceErrorImpl;
import androidx.webkit.internal.WebViewFeatureInternal;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.InvocationHandler;
import org.chromium.support_lib_boundary.WebViewClientBoundaryInterface;

public class WebViewClientCompat extends WebViewClient implements WebViewClientBoundaryInterface {
  private static final String[] sSupportedFeatures = new String[] { "VISUAL_STATE_CALLBACK", "RECEIVE_WEB_RESOURCE_ERROR", "RECEIVE_HTTP_ERROR", "SHOULD_OVERRIDE_WITH_REDIRECTS", "SAFE_BROWSING_HIT" };
  
  public final String[] getSupportedFeatures() {
    return sSupportedFeatures;
  }
  
  public void onPageCommitVisible(WebView paramWebView, String paramString) {}
  
  public final void onReceivedError(WebView paramWebView, WebResourceRequest paramWebResourceRequest, WebResourceError paramWebResourceError) {
    if (Build.VERSION.SDK_INT < 23)
      return; 
    onReceivedError(paramWebView, paramWebResourceRequest, (WebResourceErrorCompat)new WebResourceErrorImpl(paramWebResourceError));
  }
  
  public void onReceivedError(WebView paramWebView, WebResourceRequest paramWebResourceRequest, WebResourceErrorCompat paramWebResourceErrorCompat) {
    if (Build.VERSION.SDK_INT < 21)
      return; 
    if (WebViewFeature.isFeatureSupported("WEB_RESOURCE_ERROR_GET_CODE")) {
      if (!WebViewFeature.isFeatureSupported("WEB_RESOURCE_ERROR_GET_DESCRIPTION"))
        return; 
      if (paramWebResourceRequest.isForMainFrame())
        onReceivedError(paramWebView, paramWebResourceErrorCompat.getErrorCode(), paramWebResourceErrorCompat.getDescription().toString(), paramWebResourceRequest.getUrl().toString()); 
    } 
  }
  
  public final void onReceivedError(WebView paramWebView, WebResourceRequest paramWebResourceRequest, InvocationHandler paramInvocationHandler) {
    onReceivedError(paramWebView, paramWebResourceRequest, (WebResourceErrorCompat)new WebResourceErrorImpl(paramInvocationHandler));
  }
  
  public void onReceivedHttpError(WebView paramWebView, WebResourceRequest paramWebResourceRequest, WebResourceResponse paramWebResourceResponse) {}
  
  public final void onSafeBrowsingHit(WebView paramWebView, WebResourceRequest paramWebResourceRequest, int paramInt, SafeBrowsingResponse paramSafeBrowsingResponse) {
    onSafeBrowsingHit(paramWebView, paramWebResourceRequest, paramInt, (SafeBrowsingResponseCompat)new SafeBrowsingResponseImpl(paramSafeBrowsingResponse));
  }
  
  public void onSafeBrowsingHit(WebView paramWebView, WebResourceRequest paramWebResourceRequest, int paramInt, SafeBrowsingResponseCompat paramSafeBrowsingResponseCompat) {
    if (WebViewFeature.isFeatureSupported("SAFE_BROWSING_RESPONSE_SHOW_INTERSTITIAL")) {
      paramSafeBrowsingResponseCompat.showInterstitial(true);
      return;
    } 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
  
  public final void onSafeBrowsingHit(WebView paramWebView, WebResourceRequest paramWebResourceRequest, int paramInt, InvocationHandler paramInvocationHandler) {
    onSafeBrowsingHit(paramWebView, paramWebResourceRequest, paramInt, (SafeBrowsingResponseCompat)new SafeBrowsingResponseImpl(paramInvocationHandler));
  }
  
  public boolean shouldOverrideUrlLoading(WebView paramWebView, WebResourceRequest paramWebResourceRequest) {
    return (Build.VERSION.SDK_INT < 21) ? false : shouldOverrideUrlLoading(paramWebView, paramWebResourceRequest.getUrl().toString());
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface SafeBrowsingThreat {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\androidx\webkit\WebViewClientCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */