package androidx.constraintlayout.core;

public class Cache {
  Pools.Pool<ArrayRow> arrayRowPool = (Pools.Pool<ArrayRow>)new Pools.SimplePool(256);
  
  SolverVariable[] mIndexedVariables = new SolverVariable[32];
  
  Pools.Pool<ArrayRow> optimizedArrayRowPool = (Pools.Pool<ArrayRow>)new Pools.SimplePool(256);
  
  Pools.Pool<SolverVariable> solverVariablePool = (Pools.Pool<SolverVariable>)new Pools.SimplePool(256);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\androidx\constraintlayout\core\Cache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */