package androidx.lifecycle;

import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlinx.coroutines.CancellableContinuation;
import kotlinx.coroutines.CancellableContinuationImpl;
import kotlinx.coroutines.CoroutineDispatcher;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.MainCoroutineDispatcher;

@Metadata(bv = {1, 0, 3}, d1 = {"\000,\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\b\032A\020\000\032\002H\001\"\004\b\000\020\001*\0020\0022\006\020\003\032\0020\0042\006\020\005\032\0020\0062\006\020\007\032\0020\b2\f\020\t\032\b\022\004\022\002H\0010\nH@ø\001\000¢\006\002\020\013\032+\020\f\032\002H\001\"\004\b\000\020\001*\0020\0022\016\b\004\020\t\032\b\022\004\022\002H\0010\nHHø\001\000¢\006\002\020\r\032+\020\f\032\002H\001\"\004\b\000\020\001*\0020\0162\016\b\004\020\t\032\b\022\004\022\002H\0010\nHHø\001\000¢\006\002\020\017\032+\020\020\032\002H\001\"\004\b\000\020\001*\0020\0022\016\b\004\020\t\032\b\022\004\022\002H\0010\nHHø\001\000¢\006\002\020\r\032+\020\020\032\002H\001\"\004\b\000\020\001*\0020\0162\016\b\004\020\t\032\b\022\004\022\002H\0010\nHHø\001\000¢\006\002\020\017\032+\020\021\032\002H\001\"\004\b\000\020\001*\0020\0022\016\b\004\020\t\032\b\022\004\022\002H\0010\nHHø\001\000¢\006\002\020\r\032+\020\021\032\002H\001\"\004\b\000\020\001*\0020\0162\016\b\004\020\t\032\b\022\004\022\002H\0010\nHHø\001\000¢\006\002\020\017\0323\020\022\032\002H\001\"\004\b\000\020\001*\0020\0022\006\020\003\032\0020\0042\016\b\004\020\t\032\b\022\004\022\002H\0010\nHHø\001\000¢\006\002\020\023\0323\020\022\032\002H\001\"\004\b\000\020\001*\0020\0162\006\020\003\032\0020\0042\016\b\004\020\t\032\b\022\004\022\002H\0010\nHHø\001\000¢\006\002\020\024\0323\020\025\032\002H\001\"\004\b\000\020\001*\0020\0022\006\020\003\032\0020\0042\016\b\004\020\t\032\b\022\004\022\002H\0010\nHHø\001\000¢\006\002\020\023\002\004\n\002\b\031¨\006\026"}, d2 = {"suspendWithStateAtLeastUnchecked", "R", "Landroidx/lifecycle/Lifecycle;", "state", "Landroidx/lifecycle/Lifecycle$State;", "dispatchNeeded", "", "lifecycleDispatcher", "Lkotlinx/coroutines/CoroutineDispatcher;", "block", "Lkotlin/Function0;", "(Landroidx/lifecycle/Lifecycle;Landroidx/lifecycle/Lifecycle$State;ZLkotlinx/coroutines/CoroutineDispatcher;Lkotlin/jvm/functions/Function0;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "withCreated", "(Landroidx/lifecycle/Lifecycle;Lkotlin/jvm/functions/Function0;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Landroidx/lifecycle/LifecycleOwner;", "(Landroidx/lifecycle/LifecycleOwner;Lkotlin/jvm/functions/Function0;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "withResumed", "withStarted", "withStateAtLeast", "(Landroidx/lifecycle/Lifecycle;Landroidx/lifecycle/Lifecycle$State;Lkotlin/jvm/functions/Function0;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$State;Lkotlin/jvm/functions/Function0;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "withStateAtLeastUnchecked", "lifecycle-runtime-ktx_release"}, k = 2, mv = {1, 4, 1})
public final class WithLifecycleStateKt {
  public static final <R> Object suspendWithStateAtLeastUnchecked(Lifecycle paramLifecycle, Lifecycle.State paramState, boolean paramBoolean, CoroutineDispatcher paramCoroutineDispatcher, Function0<? extends R> paramFunction0, Continuation<? super R> paramContinuation) {
    CancellableContinuationImpl cancellableContinuationImpl = new CancellableContinuationImpl(IntrinsicsKt.intercepted(paramContinuation), 1);
    cancellableContinuationImpl.initCancellability();
    CancellableContinuation cancellableContinuation = (CancellableContinuation)cancellableContinuationImpl;
    WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1 withLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1 = new WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1(cancellableContinuation, paramLifecycle, paramState, paramFunction0, paramBoolean, paramCoroutineDispatcher);
    if (paramBoolean) {
      paramCoroutineDispatcher.dispatch((CoroutineContext)EmptyCoroutineContext.INSTANCE, new WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$2(withLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1, paramLifecycle, paramState, paramFunction0, paramBoolean, paramCoroutineDispatcher));
    } else {
      paramLifecycle.addObserver((LifecycleObserver)withLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1);
    } 
    cancellableContinuation.invokeOnCancellation(new WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3(withLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1, paramLifecycle, paramState, paramFunction0, paramBoolean, paramCoroutineDispatcher));
    Object object = cancellableContinuationImpl.getResult();
    if (object == IntrinsicsKt.getCOROUTINE_SUSPENDED())
      DebugProbesKt.probeCoroutineSuspended(paramContinuation); 
    return object;
  }
  
  public static final <R> Object withCreated(Lifecycle paramLifecycle, Function0<? extends R> paramFunction0, Continuation<? super R> paramContinuation) {
    Lifecycle.State state = Lifecycle.State.CREATED;
    MainCoroutineDispatcher mainCoroutineDispatcher = Dispatchers.getMain().getImmediate();
    boolean bool = mainCoroutineDispatcher.isDispatchNeeded(paramContinuation.getContext());
    if (!bool)
      if (paramLifecycle.getCurrentState() != Lifecycle.State.DESTROYED) {
        if (paramLifecycle.getCurrentState().compareTo(state) >= 0)
          return paramFunction0.invoke(); 
      } else {
        throw (Throwable)new LifecycleDestroyedException();
      }  
    return suspendWithStateAtLeastUnchecked(paramLifecycle, state, bool, (CoroutineDispatcher)mainCoroutineDispatcher, new WithLifecycleStateKt$withStateAtLeastUnchecked$2(paramFunction0), paramContinuation);
  }
  
  public static final <R> Object withCreated(LifecycleOwner paramLifecycleOwner, Function0<? extends R> paramFunction0, Continuation<? super R> paramContinuation) {
    Lifecycle lifecycle = paramLifecycleOwner.getLifecycle();
    Intrinsics.checkNotNullExpressionValue(lifecycle, "lifecycle");
    Lifecycle.State state = Lifecycle.State.CREATED;
    MainCoroutineDispatcher mainCoroutineDispatcher = Dispatchers.getMain().getImmediate();
    boolean bool = mainCoroutineDispatcher.isDispatchNeeded(paramContinuation.getContext());
    if (!bool)
      if (lifecycle.getCurrentState() != Lifecycle.State.DESTROYED) {
        if (lifecycle.getCurrentState().compareTo(state) >= 0)
          return paramFunction0.invoke(); 
      } else {
        throw (Throwable)new LifecycleDestroyedException();
      }  
    return suspendWithStateAtLeastUnchecked(lifecycle, state, bool, (CoroutineDispatcher)mainCoroutineDispatcher, new WithLifecycleStateKt$withStateAtLeastUnchecked$2(paramFunction0), paramContinuation);
  }
  
  private static final Object withCreated$$forInline(Lifecycle paramLifecycle, Function0 paramFunction0, Continuation paramContinuation) {
    Lifecycle.State state = Lifecycle.State.CREATED;
    Dispatchers.getMain().getImmediate();
    InlineMarker.mark(3);
    throw new NullPointerException();
  }
  
  private static final Object withCreated$$forInline(LifecycleOwner paramLifecycleOwner, Function0 paramFunction0, Continuation paramContinuation) {
    Intrinsics.checkNotNullExpressionValue(paramLifecycleOwner.getLifecycle(), "lifecycle");
    Lifecycle.State state = Lifecycle.State.CREATED;
    Dispatchers.getMain().getImmediate();
    InlineMarker.mark(3);
    throw new NullPointerException();
  }
  
  public static final <R> Object withResumed(Lifecycle paramLifecycle, Function0<? extends R> paramFunction0, Continuation<? super R> paramContinuation) {
    Lifecycle.State state = Lifecycle.State.RESUMED;
    MainCoroutineDispatcher mainCoroutineDispatcher = Dispatchers.getMain().getImmediate();
    boolean bool = mainCoroutineDispatcher.isDispatchNeeded(paramContinuation.getContext());
    if (!bool)
      if (paramLifecycle.getCurrentState() != Lifecycle.State.DESTROYED) {
        if (paramLifecycle.getCurrentState().compareTo(state) >= 0)
          return paramFunction0.invoke(); 
      } else {
        throw (Throwable)new LifecycleDestroyedException();
      }  
    return suspendWithStateAtLeastUnchecked(paramLifecycle, state, bool, (CoroutineDispatcher)mainCoroutineDispatcher, new WithLifecycleStateKt$withStateAtLeastUnchecked$2(paramFunction0), paramContinuation);
  }
  
  public static final <R> Object withResumed(LifecycleOwner paramLifecycleOwner, Function0<? extends R> paramFunction0, Continuation<? super R> paramContinuation) {
    Lifecycle lifecycle = paramLifecycleOwner.getLifecycle();
    Intrinsics.checkNotNullExpressionValue(lifecycle, "lifecycle");
    Lifecycle.State state = Lifecycle.State.RESUMED;
    MainCoroutineDispatcher mainCoroutineDispatcher = Dispatchers.getMain().getImmediate();
    boolean bool = mainCoroutineDispatcher.isDispatchNeeded(paramContinuation.getContext());
    if (!bool)
      if (lifecycle.getCurrentState() != Lifecycle.State.DESTROYED) {
        if (lifecycle.getCurrentState().compareTo(state) >= 0)
          return paramFunction0.invoke(); 
      } else {
        throw (Throwable)new LifecycleDestroyedException();
      }  
    return suspendWithStateAtLeastUnchecked(lifecycle, state, bool, (CoroutineDispatcher)mainCoroutineDispatcher, new WithLifecycleStateKt$withStateAtLeastUnchecked$2(paramFunction0), paramContinuation);
  }
  
  private static final Object withResumed$$forInline(Lifecycle paramLifecycle, Function0 paramFunction0, Continuation paramContinuation) {
    Lifecycle.State state = Lifecycle.State.RESUMED;
    Dispatchers.getMain().getImmediate();
    InlineMarker.mark(3);
    throw new NullPointerException();
  }
  
  private static final Object withResumed$$forInline(LifecycleOwner paramLifecycleOwner, Function0 paramFunction0, Continuation paramContinuation) {
    Intrinsics.checkNotNullExpressionValue(paramLifecycleOwner.getLifecycle(), "lifecycle");
    Lifecycle.State state = Lifecycle.State.RESUMED;
    Dispatchers.getMain().getImmediate();
    InlineMarker.mark(3);
    throw new NullPointerException();
  }
  
  public static final <R> Object withStarted(Lifecycle paramLifecycle, Function0<? extends R> paramFunction0, Continuation<? super R> paramContinuation) {
    Lifecycle.State state = Lifecycle.State.STARTED;
    MainCoroutineDispatcher mainCoroutineDispatcher = Dispatchers.getMain().getImmediate();
    boolean bool = mainCoroutineDispatcher.isDispatchNeeded(paramContinuation.getContext());
    if (!bool)
      if (paramLifecycle.getCurrentState() != Lifecycle.State.DESTROYED) {
        if (paramLifecycle.getCurrentState().compareTo(state) >= 0)
          return paramFunction0.invoke(); 
      } else {
        throw (Throwable)new LifecycleDestroyedException();
      }  
    return suspendWithStateAtLeastUnchecked(paramLifecycle, state, bool, (CoroutineDispatcher)mainCoroutineDispatcher, new WithLifecycleStateKt$withStateAtLeastUnchecked$2(paramFunction0), paramContinuation);
  }
  
  public static final <R> Object withStarted(LifecycleOwner paramLifecycleOwner, Function0<? extends R> paramFunction0, Continuation<? super R> paramContinuation) {
    Lifecycle lifecycle = paramLifecycleOwner.getLifecycle();
    Intrinsics.checkNotNullExpressionValue(lifecycle, "lifecycle");
    Lifecycle.State state = Lifecycle.State.STARTED;
    MainCoroutineDispatcher mainCoroutineDispatcher = Dispatchers.getMain().getImmediate();
    boolean bool = mainCoroutineDispatcher.isDispatchNeeded(paramContinuation.getContext());
    if (!bool)
      if (lifecycle.getCurrentState() != Lifecycle.State.DESTROYED) {
        if (lifecycle.getCurrentState().compareTo(state) >= 0)
          return paramFunction0.invoke(); 
      } else {
        throw (Throwable)new LifecycleDestroyedException();
      }  
    return suspendWithStateAtLeastUnchecked(lifecycle, state, bool, (CoroutineDispatcher)mainCoroutineDispatcher, new WithLifecycleStateKt$withStateAtLeastUnchecked$2(paramFunction0), paramContinuation);
  }
  
  private static final Object withStarted$$forInline(Lifecycle paramLifecycle, Function0 paramFunction0, Continuation paramContinuation) {
    Lifecycle.State state = Lifecycle.State.STARTED;
    Dispatchers.getMain().getImmediate();
    InlineMarker.mark(3);
    throw new NullPointerException();
  }
  
  private static final Object withStarted$$forInline(LifecycleOwner paramLifecycleOwner, Function0 paramFunction0, Continuation paramContinuation) {
    Intrinsics.checkNotNullExpressionValue(paramLifecycleOwner.getLifecycle(), "lifecycle");
    Lifecycle.State state = Lifecycle.State.STARTED;
    Dispatchers.getMain().getImmediate();
    InlineMarker.mark(3);
    throw new NullPointerException();
  }
  
  public static final <R> Object withStateAtLeast(Lifecycle paramLifecycle, Lifecycle.State paramState, Function0<? extends R> paramFunction0, Continuation<? super R> paramContinuation) {
    boolean bool;
    if (paramState.compareTo(Lifecycle.State.CREATED) >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      MainCoroutineDispatcher mainCoroutineDispatcher = Dispatchers.getMain().getImmediate();
      boolean bool1 = mainCoroutineDispatcher.isDispatchNeeded(paramContinuation.getContext());
      if (!bool1)
        if (paramLifecycle.getCurrentState() != Lifecycle.State.DESTROYED) {
          if (paramLifecycle.getCurrentState().compareTo(paramState) >= 0)
            return paramFunction0.invoke(); 
        } else {
          throw (Throwable)new LifecycleDestroyedException();
        }  
      return suspendWithStateAtLeastUnchecked(paramLifecycle, paramState, bool1, (CoroutineDispatcher)mainCoroutineDispatcher, new WithLifecycleStateKt$withStateAtLeastUnchecked$2(paramFunction0), paramContinuation);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("target state must be CREATED or greater, found ");
    stringBuilder.append(paramState);
    throw new IllegalArgumentException(stringBuilder.toString().toString());
  }
  
  public static final <R> Object withStateAtLeast(LifecycleOwner paramLifecycleOwner, Lifecycle.State paramState, Function0<? extends R> paramFunction0, Continuation<? super R> paramContinuation) {
    boolean bool;
    Lifecycle lifecycle = paramLifecycleOwner.getLifecycle();
    Intrinsics.checkNotNullExpressionValue(lifecycle, "lifecycle");
    if (paramState.compareTo(Lifecycle.State.CREATED) >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      MainCoroutineDispatcher mainCoroutineDispatcher = Dispatchers.getMain().getImmediate();
      boolean bool1 = mainCoroutineDispatcher.isDispatchNeeded(paramContinuation.getContext());
      if (!bool1)
        if (lifecycle.getCurrentState() != Lifecycle.State.DESTROYED) {
          if (lifecycle.getCurrentState().compareTo(paramState) >= 0)
            return paramFunction0.invoke(); 
        } else {
          throw (Throwable)new LifecycleDestroyedException();
        }  
      return suspendWithStateAtLeastUnchecked(lifecycle, paramState, bool1, (CoroutineDispatcher)mainCoroutineDispatcher, new WithLifecycleStateKt$withStateAtLeastUnchecked$2(paramFunction0), paramContinuation);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("target state must be CREATED or greater, found ");
    stringBuilder.append(paramState);
    throw new IllegalArgumentException(stringBuilder.toString().toString());
  }
  
  private static final Object withStateAtLeast$$forInline(Lifecycle paramLifecycle, Lifecycle.State paramState, Function0 paramFunction0, Continuation paramContinuation) {
    boolean bool;
    if (paramState.compareTo(Lifecycle.State.CREATED) >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      Dispatchers.getMain().getImmediate();
      InlineMarker.mark(3);
      throw new NullPointerException();
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("target state must be CREATED or greater, found ");
    stringBuilder.append(paramState);
    throw new IllegalArgumentException(stringBuilder.toString().toString());
  }
  
  private static final Object withStateAtLeast$$forInline(LifecycleOwner paramLifecycleOwner, Lifecycle.State paramState, Function0 paramFunction0, Continuation paramContinuation) {
    boolean bool;
    Intrinsics.checkNotNullExpressionValue(paramLifecycleOwner.getLifecycle(), "lifecycle");
    if (paramState.compareTo(Lifecycle.State.CREATED) >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      Dispatchers.getMain().getImmediate();
      InlineMarker.mark(3);
      throw new NullPointerException();
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("target state must be CREATED or greater, found ");
    stringBuilder.append(paramState);
    throw new IllegalArgumentException(stringBuilder.toString().toString());
  }
  
  public static final <R> Object withStateAtLeastUnchecked(Lifecycle paramLifecycle, Lifecycle.State paramState, Function0<? extends R> paramFunction0, Continuation<? super R> paramContinuation) {
    MainCoroutineDispatcher mainCoroutineDispatcher = Dispatchers.getMain().getImmediate();
    boolean bool = mainCoroutineDispatcher.isDispatchNeeded(paramContinuation.getContext());
    if (!bool)
      if (paramLifecycle.getCurrentState() != Lifecycle.State.DESTROYED) {
        if (paramLifecycle.getCurrentState().compareTo(paramState) >= 0)
          return paramFunction0.invoke(); 
      } else {
        throw (Throwable)new LifecycleDestroyedException();
      }  
    return suspendWithStateAtLeastUnchecked(paramLifecycle, paramState, bool, (CoroutineDispatcher)mainCoroutineDispatcher, new WithLifecycleStateKt$withStateAtLeastUnchecked$2(paramFunction0), paramContinuation);
  }
  
  private static final Object withStateAtLeastUnchecked$$forInline(Lifecycle paramLifecycle, Lifecycle.State paramState, Function0 paramFunction0, Continuation paramContinuation) {
    Dispatchers.getMain().getImmediate();
    InlineMarker.mark(3);
    throw new NullPointerException();
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\035\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000*\001\000\b\n\030\0002\0020\001J\030\020\002\032\0020\0032\006\020\004\032\0020\0052\006\020\006\032\0020\007H\026¨\006\b¸\006\000"}, d2 = {"androidx/lifecycle/WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$2$observer$1", "Landroidx/lifecycle/LifecycleEventObserver;", "onStateChanged", "", "source", "Landroidx/lifecycle/LifecycleOwner;", "event", "Landroidx/lifecycle/Lifecycle$Event;", "lifecycle-runtime-ktx_release"}, k = 1, mv = {1, 4, 1})
  public static final class WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1 implements LifecycleEventObserver {
    WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1(CancellableContinuation param1CancellableContinuation, Lifecycle param1Lifecycle, Lifecycle.State param1State, Function0 param1Function0, boolean param1Boolean, CoroutineDispatcher param1CoroutineDispatcher) {}
    
    public void onStateChanged(LifecycleOwner param1LifecycleOwner, Lifecycle.Event param1Event) {
      CancellableContinuation cancellableContinuation;
      Intrinsics.checkNotNullParameter(param1LifecycleOwner, "source");
      Intrinsics.checkNotNullParameter(param1Event, "event");
      if (param1Event == Lifecycle.Event.upTo(this.$state$inlined)) {
        this.$this_suspendWithStateAtLeastUnchecked$inlined.removeObserver((LifecycleObserver)this);
        cancellableContinuation = this.$co;
        Object object = this.$block$inlined;
        try {
          Result.Companion companion = Result.Companion;
          Object object1 = Result.constructor-impl(object.invoke());
        } finally {
          object = null;
          Result.Companion companion = Result.Companion;
        } 
      } 
      if (cancellableContinuation == Lifecycle.Event.ON_DESTROY) {
        this.$this_suspendWithStateAtLeastUnchecked$inlined.removeObserver((LifecycleObserver)this);
        Continuation continuation = (Continuation)this.$co;
        Throwable throwable = (Throwable)new LifecycleDestroyedException();
        Result.Companion companion = Result.Companion;
        continuation.resumeWith(Result.constructor-impl(ResultKt.createFailure(throwable)));
      } 
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\n\n\000\n\002\020\002\n\002\b\003\020\000\032\0020\001\"\004\b\000\020\002H\n¢\006\002\b\003¨\006\004"}, d2 = {"<anonymous>", "", "R", "run", "androidx/lifecycle/WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$2$1"}, k = 3, mv = {1, 4, 1})
  static final class WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$2 implements Runnable {
    WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$2(WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1 param1WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1, Lifecycle param1Lifecycle, Lifecycle.State param1State, Function0 param1Function0, boolean param1Boolean, CoroutineDispatcher param1CoroutineDispatcher) {}
    
    public final void run() {
      this.$this_suspendWithStateAtLeastUnchecked$inlined.addObserver((LifecycleObserver)this.$observer);
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\022\n\000\n\002\020\002\n\002\b\002\n\002\020\003\n\002\b\002\020\000\032\0020\001\"\004\b\000\020\0022\b\020\003\032\004\030\0010\004H\n¢\006\002\b\005¨\006\006"}, d2 = {"<anonymous>", "", "R", "it", "", "invoke", "androidx/lifecycle/WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$2$2"}, k = 3, mv = {1, 4, 1})
  static final class WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3 extends Lambda implements Function1<Throwable, Unit> {
    WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3(WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1 param1WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1, Lifecycle param1Lifecycle, Lifecycle.State param1State, Function0 param1Function0, boolean param1Boolean, CoroutineDispatcher param1CoroutineDispatcher) {
      super(1);
    }
    
    public final void invoke(Throwable param1Throwable) {
      if (this.$lifecycleDispatcher$inlined.isDispatchNeeded((CoroutineContext)EmptyCoroutineContext.INSTANCE)) {
        this.$lifecycleDispatcher$inlined.dispatch((CoroutineContext)EmptyCoroutineContext.INSTANCE, new Runnable() {
              public final void run() {
                WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3.this.$this_suspendWithStateAtLeastUnchecked$inlined.removeObserver((LifecycleObserver)WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3.this.$observer);
              }
            });
        return;
      } 
      this.$this_suspendWithStateAtLeastUnchecked$inlined.removeObserver((LifecycleObserver)this.$observer);
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\n\n\000\n\002\020\002\n\002\b\003\020\000\032\0020\001\"\004\b\000\020\002H\n¢\006\002\b\003¨\006\004"}, d2 = {"<anonymous>", "", "R", "run", "androidx/lifecycle/WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$2$2$1"}, k = 3, mv = {1, 4, 1})
  static final class null implements Runnable {
    public final void run() {
      WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3.this.$this_suspendWithStateAtLeastUnchecked$inlined.removeObserver((LifecycleObserver)WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3.this.$observer);
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\004\n\002\b\004\020\000\032\002H\001\"\004\b\000\020\001H\n¢\006\004\b\002\020\003"}, d2 = {"<anonymous>", "R", "invoke", "()Ljava/lang/Object;"}, k = 3, mv = {1, 4, 1})
  public static final class WithLifecycleStateKt$withStateAtLeastUnchecked$2 extends Lambda implements Function0<R> {
    public WithLifecycleStateKt$withStateAtLeastUnchecked$2(Function0 param1Function0) {
      super(0);
    }
    
    public final R invoke() {
      return (R)this.$block.invoke();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\androidx\lifecycle\WithLifecycleStateKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */