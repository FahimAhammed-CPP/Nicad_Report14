package androidx.lifecycle;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.Job;

@Metadata(bv = {1, 0, 3}, d1 = {"\0002\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\b\001\030\0002\0020\001B%\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005\022\006\020\006\032\0020\007\022\006\020\b\032\0020\t¢\006\002\020\nJ\b\020\r\032\0020\016H\007J\021\020\017\032\0020\0162\006\020\b\032\0020\tH\bR\016\020\006\032\0020\007X\004¢\006\002\n\000R\016\020\002\032\0020\003X\004¢\006\002\n\000R\016\020\004\032\0020\005X\004¢\006\002\n\000R\016\020\013\032\0020\fX\004¢\006\002\n\000¨\006\020"}, d2 = {"Landroidx/lifecycle/LifecycleController;", "", "lifecycle", "Landroidx/lifecycle/Lifecycle;", "minState", "Landroidx/lifecycle/Lifecycle$State;", "dispatchQueue", "Landroidx/lifecycle/DispatchQueue;", "parentJob", "Lkotlinx/coroutines/Job;", "(Landroidx/lifecycle/Lifecycle;Landroidx/lifecycle/Lifecycle$State;Landroidx/lifecycle/DispatchQueue;Lkotlinx/coroutines/Job;)V", "observer", "Landroidx/lifecycle/LifecycleEventObserver;", "finish", "", "handleDestroy", "lifecycle-runtime-ktx_release"}, k = 1, mv = {1, 4, 1})
public final class LifecycleController {
  private final DispatchQueue dispatchQueue;
  
  private final Lifecycle lifecycle;
  
  private final Lifecycle.State minState;
  
  private final LifecycleEventObserver observer;
  
  public LifecycleController(Lifecycle paramLifecycle, Lifecycle.State paramState, DispatchQueue paramDispatchQueue, Job paramJob) {
    this.lifecycle = paramLifecycle;
    this.minState = paramState;
    this.dispatchQueue = paramDispatchQueue;
    LifecycleController$observer$1 lifecycleController$observer$1 = new LifecycleController$observer$1(paramJob);
    this.observer = lifecycleController$observer$1;
    if (paramLifecycle.getCurrentState() == Lifecycle.State.DESTROYED) {
      Job.DefaultImpls.cancel$default(paramJob, null, 1, null);
      finish();
      return;
    } 
    paramLifecycle.addObserver((LifecycleObserver)lifecycleController$observer$1);
  }
  
  private final void handleDestroy(Job paramJob) {
    Job.DefaultImpls.cancel$default(paramJob, null, 1, null);
    finish();
  }
  
  public final void finish() {
    this.lifecycle.removeObserver((LifecycleObserver)this.observer);
    this.dispatchQueue.finish();
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\024\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\0032\006\020\004\032\0020\005H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "source", "Landroidx/lifecycle/LifecycleOwner;", "<anonymous parameter 1>", "Landroidx/lifecycle/Lifecycle$Event;", "onStateChanged"}, k = 3, mv = {1, 4, 1})
  static final class LifecycleController$observer$1 implements LifecycleEventObserver {
    LifecycleController$observer$1(Job param1Job) {}
    
    public final void onStateChanged(LifecycleOwner param1LifecycleOwner, Lifecycle.Event param1Event) {
      LifecycleController lifecycleController;
      Intrinsics.checkNotNullParameter(param1LifecycleOwner, "source");
      Intrinsics.checkNotNullParameter(param1Event, "<anonymous parameter 1>");
      Lifecycle lifecycle2 = param1LifecycleOwner.getLifecycle();
      Intrinsics.checkNotNullExpressionValue(lifecycle2, "source.lifecycle");
      if (lifecycle2.getCurrentState() == Lifecycle.State.DESTROYED) {
        lifecycleController = LifecycleController.this;
        Job.DefaultImpls.cancel$default(this.$parentJob, null, 1, null);
        lifecycleController.finish();
        return;
      } 
      Lifecycle lifecycle1 = lifecycleController.getLifecycle();
      Intrinsics.checkNotNullExpressionValue(lifecycle1, "source.lifecycle");
      if (lifecycle1.getCurrentState().compareTo(LifecycleController.this.minState) < 0) {
        LifecycleController.this.dispatchQueue.pause();
        return;
      } 
      LifecycleController.this.dispatchQueue.resume();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\androidx\lifecycle\LifecycleController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */