package androidx.lifecycle;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv = {1, 0, 3}, d1 = {"\000\020\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\002\032\036\020\000\032\002H\001\"\n\b\000\020\001\030\001*\0020\002*\0020\003H\b¢\006\002\020\004¨\006\005"}, d2 = {"get", "VM", "Landroidx/lifecycle/ViewModel;", "Landroidx/lifecycle/ViewModelProvider;", "(Landroidx/lifecycle/ViewModelProvider;)Landroidx/lifecycle/ViewModel;", "lifecycle-viewmodel-ktx_release"}, k = 2, mv = {1, 1, 13})
public final class ViewModelProviderKt {
  private static final <VM extends ViewModel> VM get(ViewModelProvider paramViewModelProvider) {
    Intrinsics.reifiedOperationMarker(4, "VM");
    ViewModel viewModel = paramViewModelProvider.get(ViewModel.class);
    Intrinsics.checkExpressionValueIsNotNull(viewModel, "get(VM::class.java)");
    return (VM)viewModel;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\androidx\lifecycle\ViewModelProviderKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */