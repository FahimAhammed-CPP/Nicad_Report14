package androidx.core.transition;

import android.transition.Transition;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

@Metadata(bv = {1, 0, 3}, d1 = {"\000 \n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\013\032Æ\001\020\000\032\0020\001*\0020\0022#\b\006\020\003\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\0042#\b\006\020\t\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\0042#\b\006\020\n\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\0042#\b\006\020\013\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\0042#\b\006\020\f\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\004H\b\0322\020\r\032\0020\001*\0020\0022#\b\004\020\016\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\004H\b\0322\020\017\032\0020\001*\0020\0022#\b\004\020\016\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\004H\b\0322\020\020\032\0020\001*\0020\0022#\b\004\020\016\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\004H\b\0322\020\021\032\0020\001*\0020\0022#\b\004\020\016\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\004H\b\0322\020\022\032\0020\001*\0020\0022#\b\004\020\016\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\004H\b¨\006\023"}, d2 = {"addListener", "Landroid/transition/Transition$TransitionListener;", "Landroid/transition/Transition;", "onEnd", "Lkotlin/Function1;", "Lkotlin/ParameterName;", "name", "transition", "", "onStart", "onCancel", "onResume", "onPause", "doOnCancel", "action", "doOnEnd", "doOnPause", "doOnResume", "doOnStart", "core-ktx_release"}, k = 2, mv = {1, 1, 16})
public final class TransitionKt {
  public static final Transition.TransitionListener addListener(Transition paramTransition, Function1<? super Transition, Unit> paramFunction11, Function1<? super Transition, Unit> paramFunction12, Function1<? super Transition, Unit> paramFunction13, Function1<? super Transition, Unit> paramFunction14, Function1<? super Transition, Unit> paramFunction15) {
    Intrinsics.checkParameterIsNotNull(paramTransition, "$this$addListener");
    Intrinsics.checkParameterIsNotNull(paramFunction11, "onEnd");
    Intrinsics.checkParameterIsNotNull(paramFunction12, "onStart");
    Intrinsics.checkParameterIsNotNull(paramFunction13, "onCancel");
    Intrinsics.checkParameterIsNotNull(paramFunction14, "onResume");
    Intrinsics.checkParameterIsNotNull(paramFunction15, "onPause");
    TransitionKt$addListener$listener$1 transitionKt$addListener$listener$1 = new TransitionKt$addListener$listener$1(paramFunction11, paramFunction14, paramFunction15, paramFunction13, paramFunction12);
    paramTransition.addListener(transitionKt$addListener$listener$1);
    return transitionKt$addListener$listener$1;
  }
  
  public static final Transition.TransitionListener doOnCancel(Transition paramTransition, Function1<? super Transition, Unit> paramFunction1) {
    Intrinsics.checkParameterIsNotNull(paramTransition, "$this$doOnCancel");
    Intrinsics.checkParameterIsNotNull(paramFunction1, "action");
    TransitionKt$doOnCancel$$inlined$addListener$1 transitionKt$doOnCancel$$inlined$addListener$1 = new TransitionKt$doOnCancel$$inlined$addListener$1(paramFunction1);
    paramTransition.addListener(transitionKt$doOnCancel$$inlined$addListener$1);
    return transitionKt$doOnCancel$$inlined$addListener$1;
  }
  
  public static final Transition.TransitionListener doOnEnd(Transition paramTransition, Function1<? super Transition, Unit> paramFunction1) {
    Intrinsics.checkParameterIsNotNull(paramTransition, "$this$doOnEnd");
    Intrinsics.checkParameterIsNotNull(paramFunction1, "action");
    TransitionKt$doOnEnd$$inlined$addListener$1 transitionKt$doOnEnd$$inlined$addListener$1 = new TransitionKt$doOnEnd$$inlined$addListener$1(paramFunction1);
    paramTransition.addListener(transitionKt$doOnEnd$$inlined$addListener$1);
    return transitionKt$doOnEnd$$inlined$addListener$1;
  }
  
  public static final Transition.TransitionListener doOnPause(Transition paramTransition, Function1<? super Transition, Unit> paramFunction1) {
    Intrinsics.checkParameterIsNotNull(paramTransition, "$this$doOnPause");
    Intrinsics.checkParameterIsNotNull(paramFunction1, "action");
    TransitionKt$doOnPause$$inlined$addListener$1 transitionKt$doOnPause$$inlined$addListener$1 = new TransitionKt$doOnPause$$inlined$addListener$1(paramFunction1);
    paramTransition.addListener(transitionKt$doOnPause$$inlined$addListener$1);
    return transitionKt$doOnPause$$inlined$addListener$1;
  }
  
  public static final Transition.TransitionListener doOnResume(Transition paramTransition, Function1<? super Transition, Unit> paramFunction1) {
    Intrinsics.checkParameterIsNotNull(paramTransition, "$this$doOnResume");
    Intrinsics.checkParameterIsNotNull(paramFunction1, "action");
    TransitionKt$doOnResume$$inlined$addListener$1 transitionKt$doOnResume$$inlined$addListener$1 = new TransitionKt$doOnResume$$inlined$addListener$1(paramFunction1);
    paramTransition.addListener(transitionKt$doOnResume$$inlined$addListener$1);
    return transitionKt$doOnResume$$inlined$addListener$1;
  }
  
  public static final Transition.TransitionListener doOnStart(Transition paramTransition, Function1<? super Transition, Unit> paramFunction1) {
    Intrinsics.checkParameterIsNotNull(paramTransition, "$this$doOnStart");
    Intrinsics.checkParameterIsNotNull(paramFunction1, "action");
    TransitionKt$doOnStart$$inlined$addListener$1 transitionKt$doOnStart$$inlined$addListener$1 = new TransitionKt$doOnStart$$inlined$addListener$1(paramFunction1);
    paramTransition.addListener(transitionKt$doOnStart$$inlined$addListener$1);
    return transitionKt$doOnStart$$inlined$addListener$1;
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "Landroid/transition/Transition;", "invoke"}, k = 3, mv = {1, 1, 16})
  public static final class TransitionKt$addListener$1 extends Lambda implements Function1<Transition, Unit> {
    public static final TransitionKt$addListener$1 INSTANCE = new TransitionKt$addListener$1();
    
    public TransitionKt$addListener$1() {
      super(1);
    }
    
    public final void invoke(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "it");
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "Landroid/transition/Transition;", "invoke"}, k = 3, mv = {1, 1, 16})
  public static final class TransitionKt$addListener$2 extends Lambda implements Function1<Transition, Unit> {
    public static final TransitionKt$addListener$2 INSTANCE = new TransitionKt$addListener$2();
    
    public TransitionKt$addListener$2() {
      super(1);
    }
    
    public final void invoke(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "it");
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "Landroid/transition/Transition;", "invoke"}, k = 3, mv = {1, 1, 16})
  public static final class TransitionKt$addListener$3 extends Lambda implements Function1<Transition, Unit> {
    public static final TransitionKt$addListener$3 INSTANCE = new TransitionKt$addListener$3();
    
    public TransitionKt$addListener$3() {
      super(1);
    }
    
    public final void invoke(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "it");
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "Landroid/transition/Transition;", "invoke"}, k = 3, mv = {1, 1, 16})
  public static final class TransitionKt$addListener$4 extends Lambda implements Function1<Transition, Unit> {
    public static final TransitionKt$addListener$4 INSTANCE = new TransitionKt$addListener$4();
    
    public TransitionKt$addListener$4() {
      super(1);
    }
    
    public final void invoke(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "it");
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "Landroid/transition/Transition;", "invoke"}, k = 3, mv = {1, 1, 16})
  public static final class TransitionKt$addListener$5 extends Lambda implements Function1<Transition, Unit> {
    public static final TransitionKt$addListener$5 INSTANCE = new TransitionKt$addListener$5();
    
    public TransitionKt$addListener$5() {
      super(1);
    }
    
    public final void invoke(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "it");
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\031\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\005*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\007\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\b\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\t\032\0020\0032\006\020\004\032\0020\005H\026¨\006\n"}, d2 = {"androidx/core/transition/TransitionKt$addListener$listener$1", "Landroid/transition/Transition$TransitionListener;", "onTransitionCancel", "", "transition", "Landroid/transition/Transition;", "onTransitionEnd", "onTransitionPause", "onTransitionResume", "onTransitionStart", "core-ktx_release"}, k = 1, mv = {1, 1, 16})
  public static final class TransitionKt$addListener$listener$1 implements Transition.TransitionListener {
    public TransitionKt$addListener$listener$1(Function1 param1Function11, Function1 param1Function12, Function1 param1Function13, Function1 param1Function14, Function1 param1Function15) {}
    
    public void onTransitionCancel(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
      this.$onCancel.invoke(param1Transition);
    }
    
    public void onTransitionEnd(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
      this.$onEnd.invoke(param1Transition);
    }
    
    public void onTransitionPause(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
      this.$onPause.invoke(param1Transition);
    }
    
    public void onTransitionResume(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
      this.$onResume.invoke(param1Transition);
    }
    
    public void onTransitionStart(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
      this.$onStart.invoke(param1Transition);
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000)\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\005\n\002\b\005\n\002\b\005\n\002\b\005\n\002\b\005*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\007\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\b\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\t\032\0020\0032\006\020\004\032\0020\005H\026¨\006\n¸\006\000"}, d2 = {"androidx/core/transition/TransitionKt$addListener$listener$1", "Landroid/transition/Transition$TransitionListener;", "onTransitionCancel", "", "transition", "Landroid/transition/Transition;", "onTransitionEnd", "onTransitionPause", "onTransitionResume", "onTransitionStart", "core-ktx_release"}, k = 1, mv = {1, 1, 16})
  public static final class TransitionKt$doOnCancel$$inlined$addListener$1 implements Transition.TransitionListener {
    public TransitionKt$doOnCancel$$inlined$addListener$1(Function1 param1Function1) {}
    
    public void onTransitionCancel(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
      this.$onCancel.invoke(param1Transition);
    }
    
    public void onTransitionEnd(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
    
    public void onTransitionPause(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
    
    public void onTransitionResume(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
    
    public void onTransitionStart(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000)\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\005\n\002\b\005\n\002\b\005\n\002\b\005\n\002\b\005*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\007\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\b\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\t\032\0020\0032\006\020\004\032\0020\005H\026¨\006\n¸\006\000"}, d2 = {"androidx/core/transition/TransitionKt$addListener$listener$1", "Landroid/transition/Transition$TransitionListener;", "onTransitionCancel", "", "transition", "Landroid/transition/Transition;", "onTransitionEnd", "onTransitionPause", "onTransitionResume", "onTransitionStart", "core-ktx_release"}, k = 1, mv = {1, 1, 16})
  public static final class TransitionKt$doOnEnd$$inlined$addListener$1 implements Transition.TransitionListener {
    public TransitionKt$doOnEnd$$inlined$addListener$1(Function1 param1Function1) {}
    
    public void onTransitionCancel(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
    
    public void onTransitionEnd(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
      this.$onEnd.invoke(param1Transition);
    }
    
    public void onTransitionPause(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
    
    public void onTransitionResume(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
    
    public void onTransitionStart(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000)\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\005\n\002\b\005\n\002\b\005\n\002\b\005\n\002\b\005*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\007\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\b\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\t\032\0020\0032\006\020\004\032\0020\005H\026¨\006\n¸\006\000"}, d2 = {"androidx/core/transition/TransitionKt$addListener$listener$1", "Landroid/transition/Transition$TransitionListener;", "onTransitionCancel", "", "transition", "Landroid/transition/Transition;", "onTransitionEnd", "onTransitionPause", "onTransitionResume", "onTransitionStart", "core-ktx_release"}, k = 1, mv = {1, 1, 16})
  public static final class TransitionKt$doOnPause$$inlined$addListener$1 implements Transition.TransitionListener {
    public TransitionKt$doOnPause$$inlined$addListener$1(Function1 param1Function1) {}
    
    public void onTransitionCancel(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
    
    public void onTransitionEnd(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
    
    public void onTransitionPause(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
      this.$onPause.invoke(param1Transition);
    }
    
    public void onTransitionResume(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
    
    public void onTransitionStart(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000)\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\005\n\002\b\005\n\002\b\005\n\002\b\005\n\002\b\005*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\007\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\b\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\t\032\0020\0032\006\020\004\032\0020\005H\026¨\006\n¸\006\000"}, d2 = {"androidx/core/transition/TransitionKt$addListener$listener$1", "Landroid/transition/Transition$TransitionListener;", "onTransitionCancel", "", "transition", "Landroid/transition/Transition;", "onTransitionEnd", "onTransitionPause", "onTransitionResume", "onTransitionStart", "core-ktx_release"}, k = 1, mv = {1, 1, 16})
  public static final class TransitionKt$doOnResume$$inlined$addListener$1 implements Transition.TransitionListener {
    public TransitionKt$doOnResume$$inlined$addListener$1(Function1 param1Function1) {}
    
    public void onTransitionCancel(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
    
    public void onTransitionEnd(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
    
    public void onTransitionPause(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
    
    public void onTransitionResume(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
      this.$onResume.invoke(param1Transition);
    }
    
    public void onTransitionStart(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000)\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\005\n\002\b\005\n\002\b\005\n\002\b\005\n\002\b\005*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\007\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\b\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\t\032\0020\0032\006\020\004\032\0020\005H\026¨\006\n¸\006\000"}, d2 = {"androidx/core/transition/TransitionKt$addListener$listener$1", "Landroid/transition/Transition$TransitionListener;", "onTransitionCancel", "", "transition", "Landroid/transition/Transition;", "onTransitionEnd", "onTransitionPause", "onTransitionResume", "onTransitionStart", "core-ktx_release"}, k = 1, mv = {1, 1, 16})
  public static final class TransitionKt$doOnStart$$inlined$addListener$1 implements Transition.TransitionListener {
    public TransitionKt$doOnStart$$inlined$addListener$1(Function1 param1Function1) {}
    
    public void onTransitionCancel(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
    
    public void onTransitionEnd(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
    
    public void onTransitionPause(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
    
    public void onTransitionResume(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
    }
    
    public void onTransitionStart(Transition param1Transition) {
      Intrinsics.checkParameterIsNotNull(param1Transition, "transition");
      this.$onStart.invoke(param1Transition);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\androidx\core\transition\TransitionKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */