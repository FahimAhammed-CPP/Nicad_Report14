package com.facebook.appevents.iap;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import com.facebook.FacebookSdk;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000&\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\020\013\n\000\bÇ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\b\020\007\032\0020\bH\007J\b\020\t\032\0020\bH\007J\b\020\n\032\0020\013H\002R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\006X\004¢\006\002\n\000¨\006\f"}, d2 = {"Lcom/facebook/appevents/iap/InAppPurchaseManager;", "", "()V", "GOOGLE_BILLINGCLIENT_VERSION", "", "enabled", "Ljava/util/concurrent/atomic/AtomicBoolean;", "enableAutoLogging", "", "startTracking", "usingBillingLib2Plus", "", "facebook-core_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
public final class InAppPurchaseManager {
  private static final String GOOGLE_BILLINGCLIENT_VERSION = "com.google.android.play.billingclient.version";
  
  public static final InAppPurchaseManager INSTANCE = new InAppPurchaseManager();
  
  private static final AtomicBoolean enabled = new AtomicBoolean(false);
  
  @JvmStatic
  public static final void enableAutoLogging() {
    if (CrashShieldHandler.isObjectCrashing(InAppPurchaseManager.class))
      return; 
    try {
      return;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, InAppPurchaseManager.class);
    } 
  }
  
  @JvmStatic
  public static final void startTracking() {
    if (CrashShieldHandler.isObjectCrashing(InAppPurchaseManager.class))
      return; 
    try {
      return;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, InAppPurchaseManager.class);
    } 
  }
  
  private final boolean usingBillingLib2Plus() {
    boolean bool1 = CrashShieldHandler.isObjectCrashing(this);
    boolean bool = false;
    if (bool1)
      return false; 
    try {
      FacebookSdk facebookSdk = FacebookSdk.INSTANCE;
      Context context = FacebookSdk.getApplicationContext();
      ApplicationInfo applicationInfo = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128);
      Intrinsics.checkNotNullExpressionValue(applicationInfo, "context.packageManager.getApplicationInfo(\n              context.packageName, PackageManager.GET_META_DATA)");
      String str = applicationInfo.metaData.getString("com.google.android.play.billingclient.version");
      if (str == null)
        return false; 
      return bool;
    } catch (Exception exception) {
      return false;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\facebook\appevents\iap\InAppPurchaseManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */