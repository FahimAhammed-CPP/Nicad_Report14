package com.facebook.appevents.codeless;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import com.facebook.AccessToken;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.LoggingBehavior;
import com.facebook.appevents.codeless.internal.UnityReflection;
import com.facebook.appevents.codeless.internal.ViewHierarchy;
import com.facebook.appevents.internal.AppEventUtility;
import com.facebook.internal.InternalSettings;
import com.facebook.internal.Logger;
import com.facebook.internal.Utility;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import java.io.ByteArrayOutputStream;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Metadata(d1 = {"\0008\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\016\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\b\b\007\030\000 \0262\0020\001:\002\026\027B\r\022\006\020\002\032\0020\003¢\006\002\020\004J\032\020\r\032\0020\0162\b\020\017\032\004\030\0010\0202\b\020\021\032\004\030\0010\nJ\006\020\022\032\0020\016J\020\020\023\032\0020\0162\006\020\024\032\0020\nH\002J\006\020\025\032\0020\016R\024\020\005\032\b\022\004\022\0020\0030\006X\004¢\006\002\n\000R\020\020\007\032\004\030\0010\bX\016¢\006\002\n\000R\020\020\t\032\004\030\0010\nX\016¢\006\002\n\000R\016\020\013\032\0020\fX\004¢\006\002\n\000¨\006\030"}, d2 = {"Lcom/facebook/appevents/codeless/ViewIndexer;", "", "activity", "Landroid/app/Activity;", "(Landroid/app/Activity;)V", "activityReference", "Ljava/lang/ref/WeakReference;", "indexingTimer", "Ljava/util/Timer;", "previousDigest", "", "uiThreadHandler", "Landroid/os/Handler;", "processRequest", "", "request", "Lcom/facebook/GraphRequest;", "currentDigest", "schedule", "sendToServer", "tree", "unschedule", "Companion", "ScreenshotTaker", "facebook-core_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
public final class ViewIndexer {
  private static final String APP_VERSION_PARAM = "app_version";
  
  public static final Companion Companion = new Companion(null);
  
  private static final String PLATFORM_PARAM = "platform";
  
  private static final String REQUEST_TYPE = "request_type";
  
  private static final String SUCCESS = "success";
  
  private static final String TAG;
  
  private static final String TREE_PARAM = "tree";
  
  private static ViewIndexer instance;
  
  private final WeakReference<Activity> activityReference;
  
  private Timer indexingTimer;
  
  private String previousDigest;
  
  private final Handler uiThreadHandler;
  
  static {
    String str2 = ViewIndexer.class.getCanonicalName();
    String str1 = str2;
    if (str2 == null)
      str1 = ""; 
    TAG = str1;
  }
  
  public ViewIndexer(Activity paramActivity) {
    this.activityReference = new WeakReference<Activity>(paramActivity);
    this.previousDigest = null;
    this.uiThreadHandler = new Handler(Looper.getMainLooper());
    instance = this;
  }
  
  @JvmStatic
  public static final GraphRequest buildAppIndexingRequest(String paramString1, AccessToken paramAccessToken, String paramString2, String paramString3) {
    if (CrashShieldHandler.isObjectCrashing(ViewIndexer.class))
      return null; 
    try {
      return Companion.buildAppIndexingRequest(paramString1, paramAccessToken, paramString2, paramString3);
    } finally {
      paramString1 = null;
      CrashShieldHandler.handleThrowable((Throwable)paramString1, ViewIndexer.class);
    } 
  }
  
  private static final void schedule$lambda-0(ViewIndexer paramViewIndexer, TimerTask paramTimerTask) {
    if (CrashShieldHandler.isObjectCrashing(ViewIndexer.class))
      return; 
    try {
      Intrinsics.checkNotNullParameter(paramViewIndexer, "this$0");
    } finally {
      paramViewIndexer = null;
      CrashShieldHandler.handleThrowable((Throwable)paramViewIndexer, ViewIndexer.class);
    } 
  }
  
  private final void sendToServer(String paramString) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      return;
    } finally {
      paramString = null;
      CrashShieldHandler.handleThrowable((Throwable)paramString, this);
    } 
  }
  
  private static final void sendToServer$lambda-1(String paramString, ViewIndexer paramViewIndexer) {
    if (CrashShieldHandler.isObjectCrashing(ViewIndexer.class))
      return; 
    try {
      Intrinsics.checkNotNullParameter(paramString, "$tree");
      Intrinsics.checkNotNullParameter(paramViewIndexer, "this$0");
      Utility utility = Utility.INSTANCE;
      String str = Utility.md5hash(paramString);
      AccessToken accessToken = AccessToken.Companion.getCurrentAccessToken();
      if (str != null && Intrinsics.areEqual(str, paramViewIndexer.previousDigest))
        return; 
      Companion companion = Companion;
      return;
    } finally {
      paramString = null;
      CrashShieldHandler.handleThrowable((Throwable)paramString, ViewIndexer.class);
    } 
  }
  
  @JvmStatic
  public static final void sendToServerUnityInstance(String paramString) {
    if (CrashShieldHandler.isObjectCrashing(ViewIndexer.class))
      return; 
    try {
      return;
    } finally {
      paramString = null;
      CrashShieldHandler.handleThrowable((Throwable)paramString, ViewIndexer.class);
    } 
  }
  
  public final void processRequest(GraphRequest paramGraphRequest, String paramString) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    if (paramGraphRequest == null)
      return; 
    try {
      return;
    } finally {
      paramGraphRequest = null;
      CrashShieldHandler.handleThrowable((Throwable)paramGraphRequest, this);
    } 
  }
  
  public final void schedule() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
    
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  public final void unschedule() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      Activity activity = this.activityReference.get();
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  @Metadata(d1 = {"\0002\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\006\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020\002\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J0\020\f\032\004\030\0010\r2\b\020\016\032\004\030\0010\0042\b\020\017\032\004\030\0010\0202\b\020\021\032\004\030\0010\0042\006\020\022\032\0020\004H\007J\020\020\023\032\0020\0242\006\020\025\032\0020\004H\007R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000R\016\020\006\032\0020\004XT¢\006\002\n\000R\016\020\007\032\0020\004XT¢\006\002\n\000R\016\020\b\032\0020\004X\004¢\006\002\n\000R\016\020\t\032\0020\004XT¢\006\002\n\000R\020\020\n\032\004\030\0010\013X\016¢\006\002\n\000¨\006\026"}, d2 = {"Lcom/facebook/appevents/codeless/ViewIndexer$Companion;", "", "()V", "APP_VERSION_PARAM", "", "PLATFORM_PARAM", "REQUEST_TYPE", "SUCCESS", "TAG", "TREE_PARAM", "instance", "Lcom/facebook/appevents/codeless/ViewIndexer;", "buildAppIndexingRequest", "Lcom/facebook/GraphRequest;", "appIndex", "accessToken", "Lcom/facebook/AccessToken;", "appId", "requestType", "sendToServerUnityInstance", "", "tree", "facebook-core_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
    
    private static final void buildAppIndexingRequest$lambda-0(GraphResponse param1GraphResponse) {
      Intrinsics.checkNotNullParameter(param1GraphResponse, "it");
      Logger.Companion.log(LoggingBehavior.APP_EVENTS, ViewIndexer.access$getTAG$cp(), "App index sent to FB!");
    }
    
    @JvmStatic
    public final GraphRequest buildAppIndexingRequest(String param1String1, AccessToken param1AccessToken, String param1String2, String param1String3) {
      Intrinsics.checkNotNullParameter(param1String3, "requestType");
      if (param1String1 == null)
        return null; 
      GraphRequest.Companion companion = GraphRequest.Companion;
      StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
      param1String2 = String.format(Locale.US, "%s/app_indexing", Arrays.copyOf(new Object[] { param1String2 }, 1));
      Intrinsics.checkNotNullExpressionValue(param1String2, "java.lang.String.format(locale, format, *args)");
      GraphRequest graphRequest = companion.newPostRequest(param1AccessToken, param1String2, null, null);
      Bundle bundle2 = graphRequest.getParameters();
      Bundle bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle1.putString("tree", param1String1);
      AppEventUtility appEventUtility = AppEventUtility.INSTANCE;
      bundle1.putString("app_version", AppEventUtility.getAppVersion());
      bundle1.putString("platform", "android");
      bundle1.putString("request_type", param1String3);
      if (Intrinsics.areEqual(param1String3, "app_indexing")) {
        CodelessManager codelessManager = CodelessManager.INSTANCE;
        bundle1.putString("device_session_id", CodelessManager.getCurrentDeviceSessionID$facebook_core_release());
      } 
      graphRequest.setParameters(bundle1);
      graphRequest.setCallback((GraphRequest.Callback)ViewIndexer$Companion$.ExternalSyntheticLambda0.INSTANCE);
      return graphRequest;
    }
    
    @JvmStatic
    public final void sendToServerUnityInstance(String param1String) {
      Intrinsics.checkNotNullParameter(param1String, "tree");
      ViewIndexer viewIndexer = ViewIndexer.access$getInstance$cp();
      if (viewIndexer == null)
        return; 
      ViewIndexer.access$sendToServer(viewIndexer, param1String);
    }
  }
  
  @Metadata(d1 = {"\000\034\n\002\030\002\n\002\030\002\n\002\020\016\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\b\002\030\0002\b\022\004\022\0020\0020\001B\017\b\000\022\006\020\003\032\0020\004¢\006\002\020\005J\b\020\007\032\0020\002H\026R\024\020\003\032\b\022\004\022\0020\0040\006X\004¢\006\002\n\000¨\006\b"}, d2 = {"Lcom/facebook/appevents/codeless/ViewIndexer$ScreenshotTaker;", "Ljava/util/concurrent/Callable;", "", "rootView", "Landroid/view/View;", "(Landroid/view/View;)V", "Ljava/lang/ref/WeakReference;", "call", "facebook-core_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
  private static final class ScreenshotTaker implements Callable<String> {
    private final WeakReference<View> rootView;
    
    public ScreenshotTaker(View param1View) {
      this.rootView = new WeakReference<View>(param1View);
    }
    
    public String call() {
      View view = this.rootView.get();
      if (view == null || view.getWidth() == 0 || view.getHeight() == 0)
        return ""; 
      Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.RGB_565);
      view.draw(new Canvas(bitmap));
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      bitmap.compress(Bitmap.CompressFormat.JPEG, 10, byteArrayOutputStream);
      String str = Base64.encodeToString(byteArrayOutputStream.toByteArray(), 2);
      Intrinsics.checkNotNullExpressionValue(str, "encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)");
      return str;
    }
  }
  
  @Metadata(d1 = {"\000\021\n\000\n\002\030\002\n\000\n\002\020\002\n\000*\001\000\b\n\030\0002\0020\001J\b\020\002\032\0020\003H\026¨\006\004"}, d2 = {"com/facebook/appevents/codeless/ViewIndexer$schedule$indexingTask$1", "Ljava/util/TimerTask;", "run", "", "facebook-core_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public static final class ViewIndexer$schedule$indexingTask$1 extends TimerTask {
    public void run() {
      try {
        Activity activity = ViewIndexer.access$getActivityReference$p(ViewIndexer.this).get();
        AppEventUtility appEventUtility = AppEventUtility.INSTANCE;
        View view = AppEventUtility.getRootView(activity);
        if (activity != null) {
          if (view == null)
            return; 
          String str2 = activity.getClass().getSimpleName();
          CodelessManager codelessManager = CodelessManager.INSTANCE;
          if (!CodelessManager.getIsAppIndexingEnabled$facebook_core_release())
            return; 
          InternalSettings internalSettings = InternalSettings.INSTANCE;
          if (InternalSettings.isUnityApp()) {
            UnityReflection unityReflection = UnityReflection.INSTANCE;
            UnityReflection.captureViewHierarchy();
            return;
          } 
          FutureTask<String> futureTask = new FutureTask(new ViewIndexer.ScreenshotTaker(view));
          ViewIndexer.access$getUiThreadHandler$p(ViewIndexer.this).post(futureTask);
          String str1 = "";
          try {
            String str = futureTask.get(1L, TimeUnit.SECONDS);
            str1 = str;
          } catch (Exception exception) {
            Log.e(ViewIndexer.access$getTAG$cp(), "Failed to take screenshot.", exception);
          } 
          JSONObject jSONObject = new JSONObject();
          try {
            jSONObject.put("screenname", str2);
            jSONObject.put("screenshot", str1);
            JSONArray jSONArray = new JSONArray();
            ViewHierarchy viewHierarchy = ViewHierarchy.INSTANCE;
            jSONArray.put(ViewHierarchy.getDictionaryOfView(view));
            jSONObject.put("view", jSONArray);
          } catch (JSONException jSONException) {
            Log.e(ViewIndexer.access$getTAG$cp(), "Failed to create JSONObject");
          } 
          str1 = jSONObject.toString();
          Intrinsics.checkNotNullExpressionValue(str1, "viewTree.toString()");
          ViewIndexer.access$sendToServer(ViewIndexer.this, str1);
          return;
        } 
        return;
      } catch (Exception exception) {
        Log.e(ViewIndexer.access$getTAG$cp(), "UI Component tree indexing failure!", exception);
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\facebook\appevents\codeless\ViewIndexer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */