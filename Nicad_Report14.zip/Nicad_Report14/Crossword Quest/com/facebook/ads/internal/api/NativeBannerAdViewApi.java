package com.facebook.ads.internal.api;

import android.content.Context;
import android.view.View;
import com.facebook.ads.NativeAdViewAttributes;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;

public interface NativeBannerAdViewApi {
  View render(Context paramContext, NativeBannerAd paramNativeBannerAd, NativeBannerAdView.Type paramType);
  
  View render(Context paramContext, NativeBannerAd paramNativeBannerAd, NativeBannerAdView.Type paramType, NativeAdViewAttributes paramNativeAdViewAttributes);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\facebook\ads\internal\api\NativeBannerAdViewApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */