package com.facebook.ads;

@Deprecated
public enum VideoAutoplayBehavior {
  DEFAULT, OFF, ON;
  
  static {
    VideoAutoplayBehavior videoAutoplayBehavior1 = new VideoAutoplayBehavior("DEFAULT", 0);
    DEFAULT = videoAutoplayBehavior1;
    VideoAutoplayBehavior videoAutoplayBehavior2 = new VideoAutoplayBehavior("ON", 1);
    ON = videoAutoplayBehavior2;
    VideoAutoplayBehavior videoAutoplayBehavior3 = new VideoAutoplayBehavior("OFF", 2);
    OFF = videoAutoplayBehavior3;
    $VALUES = new VideoAutoplayBehavior[] { videoAutoplayBehavior1, videoAutoplayBehavior2, videoAutoplayBehavior3 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\facebook\ads\VideoAutoplayBehavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */