package com.adjust.sdk;

import android.content.Context;

public class AdjustConfig {
  public static final String AD_REVENUE_ADMOB = "admob_sdk";
  
  public static final String AD_REVENUE_ADMOST = "admost_sdk";
  
  public static final String AD_REVENUE_APPLOVIN_MAX = "applovin_max_sdk";
  
  public static final String AD_REVENUE_HELIUM_CHARTBOOST = "helium_chartboost_sdk";
  
  public static final String AD_REVENUE_IRONSOURCE = "ironsource_sdk";
  
  public static final String AD_REVENUE_MOPUB = "mopub";
  
  public static final String AD_REVENUE_SOURCE_PUBLISHER = "publisher_sdk";
  
  public static final String AD_REVENUE_UNITY = "unity_sdk";
  
  public static final String DATA_RESIDENCY_EU = "data_residency_eu";
  
  public static final String DATA_RESIDENCY_TR = "data_residency_tr";
  
  public static final String DATA_RESIDENCY_US = "data_residency_us";
  
  public static final String ENVIRONMENT_PRODUCTION = "production";
  
  public static final String ENVIRONMENT_SANDBOX = "sandbox";
  
  public static final String URL_STRATEGY_CHINA = "url_strategy_china";
  
  public static final String URL_STRATEGY_INDIA = "url_strategy_india";
  
  public String appSecret;
  
  public String appToken;
  
  public String basePath;
  
  public Context context;
  
  public boolean coppaCompliantEnabled;
  
  public Class deepLinkComponent;
  
  public String defaultTracker;
  
  public Double delayStart;
  
  public Boolean deviceKnown;
  
  public String environment;
  
  public boolean eventBufferingEnabled;
  
  public String externalDeviceId;
  
  public String gdprPath;
  
  public ILogger logger;
  
  public Boolean needsCost;
  
  public OnAttributionChangedListener onAttributionChangedListener;
  
  public OnDeeplinkResponseListener onDeeplinkResponseListener;
  
  public OnEventTrackingFailedListener onEventTrackingFailedListener;
  
  public OnEventTrackingSucceededListener onEventTrackingSucceededListener;
  
  public OnSessionTrackingFailedListener onSessionTrackingFailedListener;
  
  public OnSessionTrackingSucceededListener onSessionTrackingSucceededListener;
  
  public boolean playStoreKidsAppEnabled;
  
  public AdjustInstance.PreLaunchActions preLaunchActions;
  
  public String preinstallFilePath;
  
  public boolean preinstallTrackingEnabled;
  
  public String processName;
  
  public String pushToken;
  
  public String sdkPrefix;
  
  public String secretId;
  
  public boolean sendInBackground;
  
  public Boolean startEnabled;
  
  public boolean startOffline;
  
  public String subscriptionPath;
  
  public String urlStrategy;
  
  public String userAgent;
  
  public AdjustConfig(Context paramContext, String paramString1, String paramString2) {
    init(paramContext, paramString1, paramString2, false);
  }
  
  public AdjustConfig(Context paramContext, String paramString1, String paramString2, boolean paramBoolean) {
    init(paramContext, paramString1, paramString2, paramBoolean);
  }
  
  private boolean checkAppToken(String paramString) {
    if (paramString == null) {
      this.logger.error("Missing App Token", new Object[0]);
      return false;
    } 
    if (paramString.length() != 12) {
      this.logger.error("Malformed App Token '%s'", new Object[] { paramString });
      return false;
    } 
    return true;
  }
  
  private boolean checkContext(Context paramContext) {
    if (paramContext == null) {
      this.logger.error("Missing context", new Object[0]);
      return false;
    } 
    if (!Util.checkPermission(paramContext, "android.permission.INTERNET")) {
      this.logger.error("Missing permission: INTERNET", new Object[0]);
      return false;
    } 
    return true;
  }
  
  private boolean checkEnvironment(String paramString) {
    if (paramString == null) {
      this.logger.error("Missing environment", new Object[0]);
      return false;
    } 
    if (paramString.equals("sandbox")) {
      this.logger.warnInProduction("SANDBOX: Adjust is running in Sandbox mode. Use this setting for testing. Don't forget to set the environment to `production` before publishing!", new Object[0]);
      return true;
    } 
    if (paramString.equals("production")) {
      this.logger.warnInProduction("PRODUCTION: Adjust is running in Production mode. Use this setting only for the build that you want to publish. Set the environment to `sandbox` if you want to test your app!", new Object[0]);
      return true;
    } 
    this.logger.error("Unknown environment '%s'", new Object[] { paramString });
    return false;
  }
  
  private void init(Context paramContext, String paramString1, String paramString2, boolean paramBoolean) {
    LogLevel logLevel;
    this.logger = AdjustFactory.getLogger();
    if (paramBoolean && "production".equals(paramString2)) {
      logLevel = LogLevel.SUPRESS;
    } else {
      logLevel = LogLevel.INFO;
    } 
    setLogLevel(logLevel, paramString2);
    Context context = paramContext;
    if (paramContext != null)
      context = paramContext.getApplicationContext(); 
    this.context = context;
    this.appToken = paramString1;
    this.environment = paramString2;
    this.eventBufferingEnabled = false;
    this.sendInBackground = false;
    this.preinstallTrackingEnabled = false;
  }
  
  private void setLogLevel(LogLevel paramLogLevel, String paramString) {
    this.logger.setLogLevel(paramLogLevel, "production".equals(paramString));
  }
  
  public boolean isValid() {
    return !checkAppToken(this.appToken) ? false : (!checkEnvironment(this.environment) ? false : (!!checkContext(this.context)));
  }
  
  public void setAppSecret(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5) {
    this.secretId = Util.formatString("%d", new Object[] { Long.valueOf(paramLong1) });
    this.appSecret = Util.formatString("%d%d%d%d", new Object[] { Long.valueOf(paramLong2), Long.valueOf(paramLong3), Long.valueOf(paramLong4), Long.valueOf(paramLong5) });
  }
  
  public void setCoppaCompliantEnabled(boolean paramBoolean) {
    this.coppaCompliantEnabled = paramBoolean;
  }
  
  public void setDeepLinkComponent(Class paramClass) {
    this.deepLinkComponent = paramClass;
  }
  
  public void setDefaultTracker(String paramString) {
    this.defaultTracker = paramString;
  }
  
  public void setDelayStart(double paramDouble) {
    this.delayStart = Double.valueOf(paramDouble);
  }
  
  public void setDeviceKnown(boolean paramBoolean) {
    this.deviceKnown = Boolean.valueOf(paramBoolean);
  }
  
  public void setEventBufferingEnabled(Boolean paramBoolean) {
    boolean bool;
    if (paramBoolean == null) {
      bool = false;
    } else {
      bool = paramBoolean.booleanValue();
    } 
    this.eventBufferingEnabled = bool;
  }
  
  public void setExternalDeviceId(String paramString) {
    this.externalDeviceId = paramString;
  }
  
  public void setLogLevel(LogLevel paramLogLevel) {
    setLogLevel(paramLogLevel, this.environment);
  }
  
  public void setNeedsCost(boolean paramBoolean) {
    this.needsCost = Boolean.valueOf(paramBoolean);
  }
  
  public void setOnAttributionChangedListener(OnAttributionChangedListener paramOnAttributionChangedListener) {
    this.onAttributionChangedListener = paramOnAttributionChangedListener;
  }
  
  public void setOnDeeplinkResponseListener(OnDeeplinkResponseListener paramOnDeeplinkResponseListener) {
    this.onDeeplinkResponseListener = paramOnDeeplinkResponseListener;
  }
  
  public void setOnEventTrackingFailedListener(OnEventTrackingFailedListener paramOnEventTrackingFailedListener) {
    this.onEventTrackingFailedListener = paramOnEventTrackingFailedListener;
  }
  
  public void setOnEventTrackingSucceededListener(OnEventTrackingSucceededListener paramOnEventTrackingSucceededListener) {
    this.onEventTrackingSucceededListener = paramOnEventTrackingSucceededListener;
  }
  
  public void setOnSessionTrackingFailedListener(OnSessionTrackingFailedListener paramOnSessionTrackingFailedListener) {
    this.onSessionTrackingFailedListener = paramOnSessionTrackingFailedListener;
  }
  
  public void setOnSessionTrackingSucceededListener(OnSessionTrackingSucceededListener paramOnSessionTrackingSucceededListener) {
    this.onSessionTrackingSucceededListener = paramOnSessionTrackingSucceededListener;
  }
  
  public void setPlayStoreKidsAppEnabled(boolean paramBoolean) {
    this.playStoreKidsAppEnabled = paramBoolean;
  }
  
  public void setPreinstallFilePath(String paramString) {
    this.preinstallFilePath = paramString;
  }
  
  public void setPreinstallTrackingEnabled(boolean paramBoolean) {
    this.preinstallTrackingEnabled = paramBoolean;
  }
  
  public void setProcessName(String paramString) {
    this.processName = paramString;
  }
  
  @Deprecated
  public void setReadMobileEquipmentIdentity(boolean paramBoolean) {
    this.logger.warn("This method has been deprecated and shouldn't be used anymore", new Object[0]);
  }
  
  public void setSdkPrefix(String paramString) {
    this.sdkPrefix = paramString;
  }
  
  public void setSendInBackground(boolean paramBoolean) {
    this.sendInBackground = paramBoolean;
  }
  
  public void setUrlStrategy(String paramString) {
    if (paramString == null || paramString.isEmpty()) {
      this.logger.error("Invalid url strategy", new Object[0]);
      return;
    } 
    if (!paramString.equals("url_strategy_india") && !paramString.equals("url_strategy_china") && !paramString.equals("data_residency_eu") && !paramString.equals("data_residency_tr") && !paramString.equals("data_residency_us"))
      this.logger.warn("Unrecognised url strategy %s", new Object[] { paramString }); 
    this.urlStrategy = paramString;
  }
  
  public void setUserAgent(String paramString) {
    this.userAgent = paramString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\adjust\sdk\AdjustConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */