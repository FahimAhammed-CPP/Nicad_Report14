package com.adjust.sdk;

public enum LogLevel {
  ASSERT, DEBUG, ERROR, INFO, SUPRESS, VERBOSE, WARN;
  
  public final int androidLogLevel;
  
  static {
    LogLevel logLevel1 = new LogLevel("VERBOSE", 0, 2);
    VERBOSE = logLevel1;
    LogLevel logLevel2 = new LogLevel("DEBUG", 1, 3);
    DEBUG = logLevel2;
    LogLevel logLevel3 = new LogLevel("INFO", 2, 4);
    INFO = logLevel3;
    LogLevel logLevel4 = new LogLevel("WARN", 3, 5);
    WARN = logLevel4;
    LogLevel logLevel5 = new LogLevel("ERROR", 4, 6);
    ERROR = logLevel5;
    LogLevel logLevel6 = new LogLevel("ASSERT", 5, 7);
    ASSERT = logLevel6;
    LogLevel logLevel7 = new LogLevel("SUPRESS", 6, 8);
    SUPRESS = logLevel7;
    $VALUES = new LogLevel[] { logLevel1, logLevel2, logLevel3, logLevel4, logLevel5, logLevel6, logLevel7 };
  }
  
  LogLevel(int paramInt1) {
    this.androidLogLevel = paramInt1;
  }
  
  public int getAndroidLogLevel() {
    return this.androidLogLevel;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\adjust\sdk\LogLevel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */