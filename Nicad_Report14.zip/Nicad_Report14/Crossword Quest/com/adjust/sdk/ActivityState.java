package com.adjust.sdk;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamField;
import java.io.Serializable;
import java.util.Calendar;
import java.util.LinkedList;

public class ActivityState implements Serializable, Cloneable {
  private static final int ORDER_ID_MAXCOUNT = 10;
  
  private static final ObjectStreamField[] serialPersistentFields;
  
  private static final long serialVersionUID = 9039439291143138148L;
  
  public String adid = null;
  
  public boolean askingAttribution = false;
  
  public long clickTime = 0L;
  
  public long clickTimeHuawei = 0L;
  
  public long clickTimeSamsung = 0L;
  
  public long clickTimeServer = 0L;
  
  public long clickTimeServerXiaomi = 0L;
  
  public long clickTimeXiaomi = 0L;
  
  public boolean enabled = true;
  
  public int eventCount = 0;
  
  public Boolean googlePlayInstant = null;
  
  public long installBegin = 0L;
  
  public long installBeginHuawei = 0L;
  
  public long installBeginSamsung = 0L;
  
  public long installBeginServer = 0L;
  
  public long installBeginServerXiaomi = 0L;
  
  public long installBeginXiaomi = 0L;
  
  public String installReferrer = null;
  
  public String installReferrerHuawei = null;
  
  public String installReferrerHuaweiAppGallery = null;
  
  public String installReferrerSamsung = null;
  
  public String installReferrerXiaomi = null;
  
  public String installVersion = null;
  
  public String installVersionXiaomi = null;
  
  public boolean isGdprForgotten = false;
  
  public boolean isThirdPartySharingDisabled = false;
  
  public boolean isThirdPartySharingDisabledForCoppa = false;
  
  public long lastActivity = -1L;
  
  public long lastInterval = -1L;
  
  private transient ILogger logger = AdjustFactory.getLogger();
  
  public LinkedList<String> orderIds = null;
  
  public String pushToken = null;
  
  public int sessionCount = 0;
  
  public long sessionLength = -1L;
  
  public int subsessionCount = -1;
  
  public long timeSpent = -1L;
  
  public boolean updatePackages = false;
  
  public String uuid = Util.createUuid();
  
  static {
    ObjectStreamField objectStreamField1 = new ObjectStreamField("uuid", String.class);
    Class<boolean> clazz = boolean.class;
    ObjectStreamField objectStreamField2 = new ObjectStreamField("enabled", clazz);
    ObjectStreamField objectStreamField3 = new ObjectStreamField("isGdprForgotten", clazz);
    ObjectStreamField objectStreamField4 = new ObjectStreamField("isThirdPartySharingDisabled", clazz);
    ObjectStreamField objectStreamField5 = new ObjectStreamField("askingAttribution", clazz);
    Class<int> clazz1 = int.class;
    ObjectStreamField objectStreamField6 = new ObjectStreamField("eventCount", clazz1);
    ObjectStreamField objectStreamField7 = new ObjectStreamField("sessionCount", clazz1);
    ObjectStreamField objectStreamField8 = new ObjectStreamField("subsessionCount", clazz1);
    Class<long> clazz2 = long.class;
    serialPersistentFields = new ObjectStreamField[] { 
        objectStreamField1, objectStreamField2, objectStreamField3, objectStreamField4, objectStreamField5, objectStreamField6, objectStreamField7, objectStreamField8, new ObjectStreamField("sessionLength", clazz2), new ObjectStreamField("timeSpent", clazz2), 
        new ObjectStreamField("lastActivity", clazz2), new ObjectStreamField("lastInterval", clazz2), new ObjectStreamField("updatePackages", clazz), new ObjectStreamField("orderIds", LinkedList.class), new ObjectStreamField("pushToken", String.class), new ObjectStreamField("adid", String.class), new ObjectStreamField("clickTime", clazz2), new ObjectStreamField("installBegin", clazz2), new ObjectStreamField("installReferrer", String.class), new ObjectStreamField("googlePlayInstant", Boolean.class), 
        new ObjectStreamField("clickTimeServer", clazz2), new ObjectStreamField("installBeginServer", clazz2), new ObjectStreamField("installVersion", String.class), new ObjectStreamField("clickTimeHuawei", clazz2), new ObjectStreamField("installBeginHuawei", clazz2), new ObjectStreamField("installReferrerHuawei", String.class), new ObjectStreamField("installReferrerHuaweiAppGallery", String.class), new ObjectStreamField("isThirdPartySharingDisabledForCoppa", clazz), new ObjectStreamField("clickTimeXiaomi", clazz2), new ObjectStreamField("installBeginXiaomi", clazz2), 
        new ObjectStreamField("installReferrerXiaomi", String.class), new ObjectStreamField("clickTimeServerXiaomi", clazz2), new ObjectStreamField("installBeginServerXiaomi", clazz2), new ObjectStreamField("installVersionXiaomi", String.class), new ObjectStreamField("clickTimeSamsung", clazz2), new ObjectStreamField("installBeginSamsung", clazz2), new ObjectStreamField("installReferrerSamsung", String.class) };
  }
  
  private void readObject(ObjectInputStream paramObjectInputStream) {
    ObjectInputStream.GetField getField = paramObjectInputStream.readFields();
    this.eventCount = Util.readIntField(getField, "eventCount", 0);
    this.sessionCount = Util.readIntField(getField, "sessionCount", 0);
    this.subsessionCount = Util.readIntField(getField, "subsessionCount", -1);
    this.sessionLength = Util.readLongField(getField, "sessionLength", -1L);
    this.timeSpent = Util.readLongField(getField, "timeSpent", -1L);
    this.lastActivity = Util.readLongField(getField, "lastActivity", -1L);
    this.lastInterval = Util.readLongField(getField, "lastInterval", -1L);
    this.uuid = Util.readStringField(getField, "uuid", null);
    this.enabled = Util.readBooleanField(getField, "enabled", true);
    this.isGdprForgotten = Util.readBooleanField(getField, "isGdprForgotten", false);
    this.isThirdPartySharingDisabled = Util.readBooleanField(getField, "isThirdPartySharingDisabled", false);
    this.isThirdPartySharingDisabledForCoppa = Util.readBooleanField(getField, "isThirdPartySharingDisabledForCoppa", false);
    this.askingAttribution = Util.readBooleanField(getField, "askingAttribution", false);
    this.updatePackages = Util.readBooleanField(getField, "updatePackages", false);
    this.orderIds = (LinkedList<String>)Util.readObjectField(getField, "orderIds", null);
    this.pushToken = Util.readStringField(getField, "pushToken", null);
    this.adid = Util.readStringField(getField, "adid", null);
    this.clickTime = Util.readLongField(getField, "clickTime", -1L);
    this.installBegin = Util.readLongField(getField, "installBegin", -1L);
    this.installReferrer = Util.readStringField(getField, "installReferrer", null);
    this.googlePlayInstant = (Boolean)Util.readObjectField(getField, "googlePlayInstant", null);
    this.clickTimeServer = Util.readLongField(getField, "clickTimeServer", -1L);
    this.installBeginServer = Util.readLongField(getField, "installBeginServer", -1L);
    this.installVersion = Util.readStringField(getField, "installVersion", null);
    this.clickTimeHuawei = Util.readLongField(getField, "clickTimeHuawei", -1L);
    this.installBeginHuawei = Util.readLongField(getField, "installBeginHuawei", -1L);
    this.installReferrerHuawei = Util.readStringField(getField, "installReferrerHuawei", null);
    this.installReferrerHuaweiAppGallery = Util.readStringField(getField, "installReferrerHuaweiAppGallery", null);
    this.clickTimeXiaomi = Util.readLongField(getField, "clickTimeXiaomi", -1L);
    this.installBeginXiaomi = Util.readLongField(getField, "installBeginXiaomi", -1L);
    this.installReferrerXiaomi = Util.readStringField(getField, "installReferrerXiaomi", null);
    this.clickTimeServerXiaomi = Util.readLongField(getField, "clickTimeServerXiaomi", -1L);
    this.installBeginServerXiaomi = Util.readLongField(getField, "installBeginServerXiaomi", -1L);
    this.installVersionXiaomi = Util.readStringField(getField, "installVersionXiaomi", null);
    this.clickTimeSamsung = Util.readLongField(getField, "clickTimeSamsung", -1L);
    this.installBeginSamsung = Util.readLongField(getField, "installBeginSamsung", -1L);
    this.installReferrerSamsung = Util.readStringField(getField, "installReferrerSamsung", null);
    if (this.uuid == null)
      this.uuid = Util.createUuid(); 
  }
  
  private static String stamp(long paramLong) {
    Calendar.getInstance().setTimeInMillis(paramLong);
    return Util.formatString("%02d:%02d:%02d", new Object[] { Integer.valueOf(11), Integer.valueOf(12), Integer.valueOf(13) });
  }
  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) {
    paramObjectOutputStream.defaultWriteObject();
  }
  
  public void addOrderId(String paramString) {
    if (this.orderIds == null)
      this.orderIds = new LinkedList<String>(); 
    if (this.orderIds.size() >= 10)
      this.orderIds.removeLast(); 
    this.orderIds.addFirst(paramString);
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject == null)
      return false; 
    if (getClass() != paramObject.getClass())
      return false; 
    paramObject = paramObject;
    return !Util.equalString(this.uuid, ((ActivityState)paramObject).uuid) ? false : (!Util.equalBoolean(Boolean.valueOf(this.enabled), Boolean.valueOf(((ActivityState)paramObject).enabled)) ? false : (!Util.equalBoolean(Boolean.valueOf(this.isGdprForgotten), Boolean.valueOf(((ActivityState)paramObject).isGdprForgotten)) ? false : (!Util.equalBoolean(Boolean.valueOf(this.isThirdPartySharingDisabled), Boolean.valueOf(((ActivityState)paramObject).isThirdPartySharingDisabled)) ? false : (!Util.equalBoolean(Boolean.valueOf(this.isThirdPartySharingDisabledForCoppa), Boolean.valueOf(((ActivityState)paramObject).isThirdPartySharingDisabledForCoppa)) ? false : (!Util.equalBoolean(Boolean.valueOf(this.askingAttribution), Boolean.valueOf(((ActivityState)paramObject).askingAttribution)) ? false : (!Util.equalInt(Integer.valueOf(this.eventCount), Integer.valueOf(((ActivityState)paramObject).eventCount)) ? false : (!Util.equalInt(Integer.valueOf(this.sessionCount), Integer.valueOf(((ActivityState)paramObject).sessionCount)) ? false : (!Util.equalInt(Integer.valueOf(this.subsessionCount), Integer.valueOf(((ActivityState)paramObject).subsessionCount)) ? false : (!Util.equalLong(Long.valueOf(this.sessionLength), Long.valueOf(((ActivityState)paramObject).sessionLength)) ? false : (!Util.equalLong(Long.valueOf(this.timeSpent), Long.valueOf(((ActivityState)paramObject).timeSpent)) ? false : (!Util.equalLong(Long.valueOf(this.lastInterval), Long.valueOf(((ActivityState)paramObject).lastInterval)) ? false : (!Util.equalBoolean(Boolean.valueOf(this.updatePackages), Boolean.valueOf(((ActivityState)paramObject).updatePackages)) ? false : (!Util.equalObject(this.orderIds, ((ActivityState)paramObject).orderIds) ? false : (!Util.equalString(this.pushToken, ((ActivityState)paramObject).pushToken) ? false : (!Util.equalString(this.adid, ((ActivityState)paramObject).adid) ? false : (!Util.equalLong(Long.valueOf(this.clickTime), Long.valueOf(((ActivityState)paramObject).clickTime)) ? false : (!Util.equalLong(Long.valueOf(this.installBegin), Long.valueOf(((ActivityState)paramObject).installBegin)) ? false : (!Util.equalString(this.installReferrer, ((ActivityState)paramObject).installReferrer) ? false : (!Util.equalBoolean(this.googlePlayInstant, ((ActivityState)paramObject).googlePlayInstant) ? false : (!Util.equalLong(Long.valueOf(this.clickTimeServer), Long.valueOf(((ActivityState)paramObject).clickTimeServer)) ? false : (!Util.equalLong(Long.valueOf(this.installBeginServer), Long.valueOf(((ActivityState)paramObject).installBeginServer)) ? false : (!Util.equalString(this.installVersion, ((ActivityState)paramObject).installVersion) ? false : (!Util.equalLong(Long.valueOf(this.clickTimeHuawei), Long.valueOf(((ActivityState)paramObject).clickTimeHuawei)) ? false : (!Util.equalLong(Long.valueOf(this.installBeginHuawei), Long.valueOf(((ActivityState)paramObject).installBeginHuawei)) ? false : (!Util.equalString(this.installReferrerHuawei, ((ActivityState)paramObject).installReferrerHuawei) ? false : (!Util.equalString(this.installReferrerHuaweiAppGallery, ((ActivityState)paramObject).installReferrerHuaweiAppGallery) ? false : (!Util.equalLong(Long.valueOf(this.clickTimeXiaomi), Long.valueOf(((ActivityState)paramObject).clickTimeXiaomi)) ? false : (!Util.equalLong(Long.valueOf(this.installBeginXiaomi), Long.valueOf(((ActivityState)paramObject).installBeginXiaomi)) ? false : (!Util.equalString(this.installReferrerXiaomi, ((ActivityState)paramObject).installReferrerXiaomi) ? false : (!Util.equalLong(Long.valueOf(this.clickTimeServerXiaomi), Long.valueOf(((ActivityState)paramObject).clickTimeServerXiaomi)) ? false : (!Util.equalLong(Long.valueOf(this.installBeginServerXiaomi), Long.valueOf(((ActivityState)paramObject).installBeginServerXiaomi)) ? false : (!Util.equalString(this.installVersionXiaomi, ((ActivityState)paramObject).installVersionXiaomi) ? false : (!Util.equalLong(Long.valueOf(this.clickTimeSamsung), Long.valueOf(((ActivityState)paramObject).clickTimeSamsung)) ? false : (!Util.equalLong(Long.valueOf(this.installBeginSamsung), Long.valueOf(((ActivityState)paramObject).installBeginSamsung)) ? false : (!!Util.equalString(this.installReferrerSamsung, ((ActivityState)paramObject).installReferrerSamsung))))))))))))))))))))))))))))))))))));
  }
  
  public boolean findOrderId(String paramString) {
    LinkedList<String> linkedList = this.orderIds;
    return (linkedList == null) ? false : linkedList.contains(paramString);
  }
  
  public int hashCode() {
    int i = Util.hashString(this.uuid);
    int j = Util.hashBoolean(Boolean.valueOf(this.enabled));
    int k = Util.hashBoolean(Boolean.valueOf(this.isGdprForgotten));
    int m = Util.hashBoolean(Boolean.valueOf(this.isThirdPartySharingDisabled));
    int n = Util.hashBoolean(Boolean.valueOf(this.isThirdPartySharingDisabledForCoppa));
    int i1 = Util.hashBoolean(Boolean.valueOf(this.askingAttribution));
    int i2 = this.eventCount;
    int i3 = this.sessionCount;
    int i4 = this.subsessionCount;
    int i5 = Util.hashLong(Long.valueOf(this.sessionLength));
    int i6 = Util.hashLong(Long.valueOf(this.timeSpent));
    int i7 = Util.hashLong(Long.valueOf(this.lastInterval));
    int i8 = Util.hashBoolean(Boolean.valueOf(this.updatePackages));
    int i9 = Util.hashObject(this.orderIds);
    int i10 = Util.hashString(this.pushToken);
    int i11 = Util.hashString(this.adid);
    int i12 = Util.hashLong(Long.valueOf(this.clickTime));
    int i13 = Util.hashLong(Long.valueOf(this.installBegin));
    int i14 = Util.hashString(this.installReferrer);
    int i15 = Util.hashBoolean(this.googlePlayInstant);
    int i16 = Util.hashLong(Long.valueOf(this.clickTimeServer));
    int i17 = Util.hashLong(Long.valueOf(this.installBeginServer));
    int i18 = Util.hashString(this.installVersion);
    int i19 = Util.hashLong(Long.valueOf(this.clickTimeHuawei));
    int i20 = Util.hashLong(Long.valueOf(this.installBeginHuawei));
    int i21 = Util.hashString(this.installReferrerHuawei);
    int i22 = Util.hashString(this.installReferrerHuaweiAppGallery);
    int i23 = Util.hashLong(Long.valueOf(this.clickTimeXiaomi));
    int i24 = Util.hashLong(Long.valueOf(this.installBeginXiaomi));
    int i25 = Util.hashString(this.installReferrerXiaomi);
    int i26 = Util.hashLong(Long.valueOf(this.clickTimeServerXiaomi));
    int i27 = Util.hashLong(Long.valueOf(this.installBeginServerXiaomi));
    int i28 = Util.hashString(this.installVersionXiaomi);
    int i29 = Util.hashLong(Long.valueOf(this.clickTimeSamsung));
    int i30 = Util.hashLong(Long.valueOf(this.installBeginSamsung));
    return Util.hashString(this.installReferrerSamsung) + (i30 + (i29 + (i28 + (i27 + (i26 + (i25 + (i24 + (i23 + (i22 + (i21 + (i20 + (i19 + (i18 + (i17 + (i16 + (i15 + (i14 + (i13 + (i12 + (i11 + (i10 + (i9 + (i8 + (i7 + (i6 + (i5 + ((((i1 + (n + (m + (k + (j + (i + 629) * 37) * 37) * 37) * 37) * 37) * 37 + i2) * 37 + i3) * 37 + i4) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37) * 37;
  }
  
  public void resetSessionAttributes(long paramLong) {
    this.subsessionCount = 1;
    this.sessionLength = 0L;
    this.timeSpent = 0L;
    this.lastActivity = paramLong;
    this.lastInterval = -1L;
  }
  
  public String toString() {
    int i = this.eventCount;
    int j = this.sessionCount;
    int k = this.subsessionCount;
    double d1 = this.sessionLength;
    Double.isNaN(d1);
    d1 /= 1000.0D;
    double d2 = this.timeSpent;
    Double.isNaN(d2);
    return Util.formatString("ec:%d sc:%d ssc:%d sl:%.1f ts:%.1f la:%s uuid:%s", new Object[] { Integer.valueOf(i), Integer.valueOf(j), Integer.valueOf(k), Double.valueOf(d1), Double.valueOf(d2 / 1000.0D), stamp(this.lastActivity), this.uuid });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\adjust\sdk\ActivityState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */