package com.amazon.device.ads;

import android.content.Intent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.FrameLayout;
import java.util.Map;
import org.json.JSONException;

class DTBAdMRAIDExpandedController extends DTBAdMRAIDController {
  static final String LOG_TAG = "DTBAdMRAIDExpandedController";
  
  private DTBAdMRAIDBannerController masterController;
  
  DTBAdMRAIDExpandedController(DTBAdView paramDTBAdView) {
    super(paramDTBAdView);
  }
  
  void addCloseIndicator() {
    addCloseIndicator((View.OnTouchListener)new DTBAdMRAIDExpandedController$.ExternalSyntheticLambda0(this));
  }
  
  void addCloseIndicator(View.OnTouchListener paramOnTouchListener) {
    createContentIndicator();
    layoutCloseIndicator();
    setCloseIndicatorContent(paramOnTouchListener);
  }
  
  protected void closeExpandedPartTwo() {
    DTBAdActivity dTBAdActivity = (DTBAdActivity)DTBAdUtil.getActivity((View)getAdView());
    Intent intent = dTBAdActivity.getIntent();
    if (intent != null) {
      DTBAdMRAIDBannerController dTBAdMRAIDBannerController = DTBAdMRAIDBannerController.findControllerByIndex(intent.getIntExtra("cntrl_index", -1));
      if (dTBAdMRAIDBannerController != null)
        dTBAdMRAIDBannerController.closeExpandedPartTwo(); 
    } 
    dTBAdActivity.straightFinish();
  }
  
  protected void expand(Map<String, Object> paramMap) {
    fireErrorEvent("expand", "Expanded View does not allow expand");
    commandCompleted("expand");
  }
  
  protected MraidStateType getInitialStateType() {
    return MraidStateType.EXPANDED;
  }
  
  protected void layoutCloseIndicator() {
    ViewGroup viewGroup = DTBAdUtil.getRootView((View)getAdView());
    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(DTBAdUtil.sizeToDevicePixels(50), DTBAdUtil.sizeToDevicePixels(50));
    layoutParams.gravity = 8388661;
    layoutParams.topMargin = 0;
    layoutParams.rightMargin = 0;
    viewGroup.addView((View)this.closeIndicatorRegion, (ViewGroup.LayoutParams)layoutParams);
  }
  
  protected void onAdLeftApplication() {}
  
  protected void onMRAIDClose() {
    closeExpandedPartTwo();
  }
  
  protected void onPageLoad() {
    try {
      prepareMraid();
      if (getDtbOmSdkSessionManager() != null) {
        getDtbOmSdkSessionManager().registerAdView((WebView)getAdView());
        return;
      } 
    } catch (JSONException jSONException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Error:");
      stringBuilder.append(jSONException.getMessage());
      DtbLog.error(stringBuilder.toString());
    } 
  }
  
  protected void onResize(Map<String, Object> paramMap) {
    fireErrorEvent("resize", "Expanded View does not allow resize");
    commandCompleted("resize");
  }
  
  void passLoadError() {
    DTBAdMRAIDBannerController dTBAdMRAIDBannerController = this.masterController;
    if (dTBAdMRAIDBannerController != null)
      dTBAdMRAIDBannerController.passLoadError(); 
  }
  
  void setMasterController(DTBAdMRAIDBannerController paramDTBAdMRAIDBannerController) {
    this.masterController = paramDTBAdMRAIDBannerController;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\amazon\device\ads\DTBAdMRAIDExpandedController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */