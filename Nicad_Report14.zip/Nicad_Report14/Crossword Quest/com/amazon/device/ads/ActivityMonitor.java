package com.amazon.device.ads;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Bundle;
import java.lang.ref.WeakReference;

public class ActivityMonitor implements Application.ActivityLifecycleCallbacks {
  private static ActivityMonitor theInstance;
  
  private DTBActivityListener activityListener;
  
  private WeakReference<Activity> currentActivity;
  
  ActivityMonitor(Context paramContext) {
    if (paramContext != null) {
      Application application = (Application)paramContext.getApplicationContext();
      if (application != null) {
        setCurrentActivity(paramContext);
        application.registerActivityLifecycleCallbacks(this);
      } 
      theInstance = this;
    } 
  }
  
  static ActivityMonitor getInstance() {
    return theInstance;
  }
  
  Activity getCurrentActivity() {
    WeakReference<Activity> weakReference = this.currentActivity;
    return (weakReference != null) ? weakReference.get() : null;
  }
  
  public void onActivityCreated(Activity paramActivity, Bundle paramBundle) {
    this.currentActivity = new WeakReference<Activity>(paramActivity);
  }
  
  public void onActivityDestroyed(Activity paramActivity) {
    DTBActivityListener dTBActivityListener = this.activityListener;
    if (dTBActivityListener != null) {
      dTBActivityListener.onActivityDestroyed(paramActivity);
      if (getCurrentActivity() == paramActivity)
        this.currentActivity = null; 
    } 
  }
  
  public void onActivityPaused(Activity paramActivity) {
    DTBActivityListener dTBActivityListener = this.activityListener;
    if (dTBActivityListener != null)
      dTBActivityListener.onActivityPaused(paramActivity); 
  }
  
  public void onActivityResumed(Activity paramActivity) {
    this.currentActivity = new WeakReference<Activity>(paramActivity);
    DTBActivityListener dTBActivityListener = this.activityListener;
    if (dTBActivityListener != null)
      dTBActivityListener.onActivityResumed(paramActivity); 
  }
  
  public void onActivitySaveInstanceState(Activity paramActivity, Bundle paramBundle) {}
  
  public void onActivityStarted(Activity paramActivity) {}
  
  public void onActivityStopped(Activity paramActivity) {
    DTBActivityListener dTBActivityListener = this.activityListener;
    if (dTBActivityListener != null)
      dTBActivityListener.onActivityStopped(paramActivity); 
  }
  
  void setActivityListener(DTBActivityListener paramDTBActivityListener) {
    this.activityListener = paramDTBActivityListener;
  }
  
  void setCurrentActivity(Context paramContext) {
    if (paramContext instanceof ContextWrapper) {
      if (paramContext instanceof Activity) {
        this.currentActivity = new WeakReference<Activity>((Activity)paramContext);
        return;
      } 
      setCurrentActivity(((ContextWrapper)paramContext).getBaseContext());
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\amazon\device\ads\ActivityMonitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */