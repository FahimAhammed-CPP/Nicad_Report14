package com.chartboost.sdk.impl;

import com.chartboost.sdk.view.CBImpressionActivity;
import kotlin.Metadata;

@Metadata(bv = {}, d1 = {"\000\034\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\020\013\n\002\b\003\bf\030\0002\0020\001J\b\020\003\032\0020\002H&J\b\020\005\032\0020\004H&J\b\020\007\032\0020\006H&J\b\020\b\032\0020\004H&¨\006\t"}, d2 = {"Lcom/chartboost/sdk/impl/b3;", "", "Lcom/chartboost/sdk/view/CBImpressionActivity;", "a", "", "b", "", "d", "c", "Chartboost-9.1.1_productionRelease"}, k = 1, mv = {1, 6, 0})
public interface b3 {
  CBImpressionActivity a();
  
  void b();
  
  void c();
  
  boolean d();
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\b3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */