package com.chartboost.sdk.impl;

import java.util.NoSuchElementException;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(bv = {}, d1 = {"\000\020\n\002\030\002\n\002\020\020\n\002\020\b\n\002\b\021\b\001\030\0002\b\022\004\022\0020\0000\001:\001\tB\021\b\002\022\006\020\003\032\0020\002¢\006\004\b\007\020\bR\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\004\032\004\b\005\020\006j\002\b\nj\002\b\013j\002\b\fj\002\b\rj\002\b\016j\002\b\017j\002\b\020j\002\b\021j\002\b\022¨\006\023"}, d2 = {"Lcom/chartboost/sdk/impl/b0;", "", "", "value", "I", "b", "()I", "<init>", "(Ljava/lang/String;II)V", "a", "PERSPECTIVE_ROTATE", "BOUNCE", "PERSPECTIVE_ZOOM", "SLIDE_FROM_TOP", "SLIDE_FROM_BOTTOM", "FADE", "NONE", "SLIDE_FROM_LEFT", "SLIDE_FROM_RIGHT", "Chartboost-9.1.1_productionRelease"}, k = 1, mv = {1, 6, 0})
public enum b0 {
  c(1),
  d(2),
  e(3),
  f(4),
  g(5),
  h(6),
  i(7),
  j(8),
  k(9);
  
  public static final a b;
  
  public final int a;
  
  static {
    b = new a(null);
  }
  
  b0(int paramInt1) {
    this.a = paramInt1;
  }
  
  public final int b() {
    return this.a;
  }
  
  @Metadata(bv = {}, d1 = {"\000\026\n\002\030\002\n\002\020\000\n\002\020\b\n\000\n\002\030\002\n\002\b\004\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\006\020\007J\020\020\005\032\004\030\0010\0042\006\020\003\032\0020\002¨\006\b"}, d2 = {"Lcom/chartboost/sdk/impl/b0$a;", "", "", "value", "Lcom/chartboost/sdk/impl/b0;", "a", "<init>", "()V", "Chartboost-9.1.1_productionRelease"}, k = 1, mv = {1, 6, 0})
  public static final class a {
    public a() {}
    
    public final b0 a(int param1Int) {
      try {
        b0[] arrayOfB0 = b0.values();
        int j = arrayOfB0.length;
        for (int i = 0;; i++) {
          boolean bool;
          b0 b0;
          if (i < j) {
            b0 = arrayOfB0[i];
            if (b0.b() == param1Int) {
              bool = true;
            } else {
              bool = false;
            } 
          } else {
            throw new NoSuchElementException("Array contains no element matching the predicate.");
          } 
          if (bool)
            return b0; 
        } 
      } catch (NoSuchElementException noSuchElementException) {
        return null;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */