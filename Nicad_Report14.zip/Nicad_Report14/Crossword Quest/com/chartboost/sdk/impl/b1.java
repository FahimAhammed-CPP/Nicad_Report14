package com.chartboost.sdk.impl;

import android.content.Context;
import android.net.NetworkInfo;

public class b1 {
  public Context a;
  
  public final b2 b = new b2();
  
  public b1(Context paramContext) {
    this.a = paramContext;
  }
  
  public int a(Context paramContext) {
    b2 b21 = this.b;
    return (b21 != null) ? b21.b(paramContext) : 0;
  }
  
  public String a() {
    b2 b21 = this.b;
    if (b21 != null) {
      int i = a.a[b21.d(this.a).ordinal()];
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i != 4) {
              if (i != 5) {
                if (i == 7)
                  return "WIFI"; 
              } else {
                return "Ethernet";
              } 
            } else {
              return "Cellular_Unknown";
            } 
          } else {
            return "Cellular_4G";
          } 
        } else {
          return "Cellular_3G";
        } 
      } else {
        return "Cellular_2G";
      } 
    } 
    return "Unknown";
  }
  
  public a2 b() {
    Context context = this.a;
    if (context == null)
      return a2.c; 
    if (this.b.c(context) == null) {
      m3.a("CBReachability", "NETWORK TYPE: unknown");
      return a2.b;
    } 
    NetworkInfo networkInfo = this.b.a(this.a);
    if (networkInfo != null && networkInfo.isConnected()) {
      if (networkInfo.getType() == 1) {
        m3.a("CBReachability", "NETWORK TYPE: TYPE_WIFI");
        return a2.d;
      } 
      m3.a("CBReachability", "NETWORK TYPE: TYPE_MOBILE");
      return a2.e;
    } 
    m3.a("CBReachability", "NETWORK TYPE: NO Network");
    return a2.c;
  }
  
  public s3 c() {
    b2 b21 = this.b;
    return (b21 != null) ? b21.d(this.a) : s3.b;
  }
  
  public boolean d() {
    boolean bool = e();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (bool) {
      bool1 = bool2;
      if (b() == a2.e)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public boolean e() {
    return this.b.e(this.a);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\b1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */