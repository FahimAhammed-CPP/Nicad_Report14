package com.chartboost.sdk.impl;

public class c0 implements Comparable<c0> {
  public final int a;
  
  public final String b;
  
  public String c;
  
  public d0 d;
  
  public k e = null;
  
  public boolean f = false;
  
  public f4 g = f4.e;
  
  public Long h = null;
  
  public Long i = null;
  
  public Long j = null;
  
  public Integer k = null;
  
  public Integer l = null;
  
  public Integer m = null;
  
  public Integer n = null;
  
  public Integer o = null;
  
  public Integer p = null;
  
  public Integer q = null;
  
  public Integer r = null;
  
  public boolean s = false;
  
  public boolean t = false;
  
  public c0(int paramInt, String paramString, d0 paramd0) {
    this.a = paramInt;
    this.b = paramString;
    this.d = paramd0;
  }
  
  public c0(int paramInt, String paramString1, d0 paramd0, String paramString2) {
    this.a = paramInt;
    this.b = paramString1;
    this.c = paramString2;
    this.d = paramd0;
  }
  
  public int a(c0 paramc0) {
    return this.a - paramc0.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */