package com.chartboost.sdk.impl;

import com.chartboost.sdk.ChartboostDSP;
import com.chartboost.sdk.internal.Libraries.CBUtility;
import com.chartboost.sdk.internal.Model.CBError;
import com.chartboost.sdk.internal.Networking.NetworkHelper;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class c1 extends w0<JSONObject> {
  public final String j;
  
  public final String k;
  
  public JSONObject l = new JSONObject();
  
  public final a m;
  
  public boolean n = false;
  
  public final u4 o;
  
  public c1(String paramString1, String paramString2, u4 paramu4, f4 paramf4, a parama) {
    super("POST", NetworkHelper.a(paramString1, paramString2), paramf4, null);
    this.j = paramString2;
    this.o = paramu4;
    this.k = null;
    this.m = parama;
  }
  
  public c1(String paramString1, String paramString2, u4 paramu4, f4 paramf4, String paramString3, a parama) {
    super("POST", NetworkHelper.a(paramString1, paramString2), paramf4, null);
    this.j = paramString2;
    this.o = paramu4;
    this.m = parama;
    this.k = paramString3;
  }
  
  public x0 a() {
    c();
    String str1 = this.l.toString();
    u4 u41 = this.o;
    String str3 = u41.h;
    String str2 = u41.i;
    String str4 = t0.a(t0.b(String.format(Locale.US, "%s %s\n%s\n%s", new Object[] { this.a, f(), str2, str1 }).getBytes()));
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("Accept", "application/json");
    hashMap.put("X-Chartboost-Client", CBUtility.b());
    hashMap.put("X-Chartboost-API", "9.1.1");
    hashMap.put("X-Chartboost-App", str3);
    hashMap.put("X-Chartboost-Signature", str4);
    if (w4.a) {
      str3 = w4.b();
      if (str3.length() > 0)
        hashMap.put("X-Chartboost-Test", str3); 
      str3 = w4.a();
      if (str3 != null)
        hashMap.put("X-Chartboost-Test", str3); 
    } 
    if (ChartboostDSP.isDSP) {
      str3 = d();
      if (str3 != null && str3.length() > 0)
        hashMap.put("X-Chartboost-DspDemoApp", str3); 
    } 
    return new x0(hashMap, str1.getBytes(), "application/json");
  }
  
  public y0<JSONObject> a(z0 paramz0) {
    int i;
    StringBuilder stringBuilder;
    try {
      if (paramz0.b == null)
        return y0.a(new CBError(CBError.b.c, "Response is not a valid json object")); 
      JSONObject jSONObject = new JSONObject(new String(paramz0.b));
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Request ");
      stringBuilder1.append(e());
      stringBuilder1.append(" succeeded. Response code: ");
      stringBuilder1.append(paramz0.a);
      stringBuilder1.append(", body: ");
      stringBuilder1.append(jSONObject.toString(4));
      m3.d("CBRequest", stringBuilder1.toString());
      if (this.n) {
        i = jSONObject.optInt("status");
        if (i == 404)
          return y0.a(new CBError(CBError.b.g, "404 error from server")); 
      } else {
        return y0.a(jSONObject);
      } 
    } catch (Exception exception) {
      m2.d(new c2("response_json_serialization_error", exception.getMessage(), "", ""));
      stringBuilder = new StringBuilder();
      stringBuilder.append("parseServerResponse: ");
      stringBuilder.append(exception.toString());
      m3.b("CBRequest", stringBuilder.toString());
      return y0.a(new CBError(CBError.b.a, exception.getLocalizedMessage()));
    } 
    if (i < 200 || i > 299) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Request failed due to status code ");
      stringBuilder1.append(i);
      stringBuilder1.append(" in message");
      String str = stringBuilder1.toString();
      m3.b("CBRequest", str);
      return y0.a(new CBError(CBError.b.d, str));
    } 
    return y0.a(stringBuilder);
  }
  
  public final void a(z0 paramz0, CBError paramCBError) {
    String str2;
    Integer integer;
    String str1;
    v0.a a1 = v0.a("endpoint", e());
    String str3 = "None";
    if (paramz0 == null) {
      str2 = "None";
    } else {
      integer = Integer.valueOf(((z0)str2).a);
    } 
    v0.a a2 = v0.a("statuscode", integer);
    if (paramCBError == null) {
      str1 = "None";
    } else {
      str1 = paramCBError.getError().toString();
    } 
    v0.a a3 = v0.a("error", str1);
    if (paramCBError == null) {
      str1 = str3;
    } else {
      str1 = paramCBError.getErrorDesc();
    } 
    JSONObject jSONObject = v0.a(new v0.a[] { a1, a2, a3, v0.a("errorDescription", str1), v0.a("retryCount", Integer.valueOf(0)) });
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("sendToSessionLogs: ");
    stringBuilder.append(jSONObject.toString());
    m3.a("CBRequest", stringBuilder.toString());
  }
  
  public void a(CBError paramCBError, z0 paramz0) {
    if (paramCBError == null)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Request failure: ");
    stringBuilder.append(this.b);
    stringBuilder.append(" status: ");
    stringBuilder.append(paramCBError.getErrorDesc());
    m3.d("CBRequest", stringBuilder.toString());
    a a1 = this.m;
    if (a1 != null)
      a1.a(this, paramCBError); 
    a(paramz0, paramCBError);
  }
  
  public void a(String paramString, Object paramObject) {
    v0.a(this.l, paramString, paramObject);
  }
  
  public void a(JSONObject paramJSONObject, z0 paramz0) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Request success: ");
    stringBuilder.append(this.b);
    stringBuilder.append(" status: ");
    stringBuilder.append(paramz0.a);
    m3.d("CBRequest", stringBuilder.toString());
    a a1 = this.m;
    if (a1 != null && paramJSONObject != null)
      a1.a(this, paramJSONObject); 
    a(paramz0, (CBError)null);
  }
  
  public void c() {
    a("app", this.o.h);
    a("model", this.o.a);
    a("device_type", this.o.j);
    a("actual_device_type", this.o.k);
    a("os", this.o.b);
    a("country", this.o.c);
    a("language", this.o.d);
    a("sdk", this.o.g);
    a("user_agent", u5.a.a());
    a("timestamp", String.valueOf(TimeUnit.MILLISECONDS.toSeconds(this.o.j().a())));
    a("session", Integer.valueOf(this.o.i()));
    a("reachability", this.o.g().b());
    a("is_portrait", Boolean.valueOf(this.o.b().k()));
    a("scale", Float.valueOf(this.o.b().h()));
    a("bundle", this.o.e);
    a("bundle_id", this.o.f);
    a("carrier", this.o.l);
    n3 n3 = this.o.d();
    if (n3 != null) {
      a("mediation", n3.c());
      a("mediation_version", n3.b());
      a("adapter_version", n3.a());
    } 
    a("timezone", this.o.n);
    a("mobile_network", this.o.g().a());
    a("dw", Integer.valueOf(this.o.b().c()));
    a("dh", Integer.valueOf(this.o.b().a()));
    a("dpi", this.o.b().d());
    a("w", Integer.valueOf(this.o.b().j()));
    a("h", Integer.valueOf(this.o.b().e()));
    a("commit_hash", "c2d3d87c408e50466c4eeaa140f0fe2971e4b3d6");
    z2 z2 = this.o.c();
    if (z2 != null) {
      a("identity", z2.b());
      t5 t5 = z2.e();
      if (t5 != t5.b) {
        boolean bool;
        if (t5 == t5.d) {
          bool = true;
        } else {
          bool = false;
        } 
        a("limit_ad_tracking", Boolean.valueOf(bool));
      } 
      Integer integer = z2.d();
      if (integer != null)
        a("appsetidscope", integer); 
    } else {
      m3.e("CBRequest", "Missing identity in the CB SDK. This will affect ads performance.");
    } 
    a("pidatauseconsent", this.o.f().d());
    String str = this.o.a().a();
    if (!x.b().a(str))
      a("config_variant", str); 
    a("privacy", this.o.f().e());
  }
  
  public final String d() {
    t1 t1 = t1.a;
    String str = t1.a();
    int[] arrayOfInt = t1.b();
    JSONObject jSONObject = new JSONObject();
    if (str != null && str.length() > 0 && arrayOfInt != null && arrayOfInt.length > 0)
      try {
        JSONArray jSONArray = new JSONArray();
        for (int i = 0; i < arrayOfInt.length; i++)
          jSONArray.put(arrayOfInt[i]); 
        jSONObject.put("exchangeMode", 2);
        jSONObject.put("bidFloor", 0.01D);
        jSONObject.put("code", str);
        jSONObject.put("forceCreativeTypes", jSONArray);
        return jSONObject.toString();
      } catch (JSONException jSONException) {
        return null;
      }  
    return jSONObject.toString();
  }
  
  public String e() {
    String str2 = this.j;
    String str1 = "/";
    if (str2 == null)
      return "/"; 
    StringBuilder stringBuilder = new StringBuilder();
    if (this.j.startsWith("/"))
      str1 = ""; 
    stringBuilder.append(str1);
    stringBuilder.append(this.j);
    return stringBuilder.toString();
  }
  
  public String f() {
    return e();
  }
  
  public static interface a {
    void a(c1 param1c1, CBError param1CBError);
    
    void a(c1 param1c1, JSONObject param1JSONObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\c1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */