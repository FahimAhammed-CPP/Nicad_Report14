package com.chartboost.sdk.impl;

import com.chartboost.sdk.internal.Model.CBError;
import org.json.JSONObject;

public class c5 implements c1.a {
  public final m a;
  
  public final String b;
  
  public c5(m paramm, String paramString) {
    this.a = paramm;
    this.b = paramString;
  }
  
  public void a(c1 paramc1, CBError paramCBError) {
    m2.d((r5)new k2("show_request_error", paramCBError.getErrorDesc(), this.a.n.a.b(), this.b, this.a.b()));
  }
  
  public void a(c1 paramc1, JSONObject paramJSONObject) {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\c5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */