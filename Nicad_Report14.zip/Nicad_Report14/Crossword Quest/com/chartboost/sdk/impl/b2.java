package com.chartboost.sdk.impl;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;

public class b2 {
  public NetworkCapabilities a(Context paramContext, Network paramNetwork) {
    if (paramContext != null) {
      ConnectivityManager connectivityManager = c(paramContext);
      if (connectivityManager != null) {
        Network network = paramNetwork;
        if (paramNetwork == null) {
          try {
            network = connectivityManager.getActiveNetwork();
            return connectivityManager.getNetworkCapabilities(network);
          } catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot retrieve network capabilities: ");
            stringBuilder.append(exception.toString());
            m3.a("Chartboost", stringBuilder.toString());
          } 
        } else {
          return connectivityManager.getNetworkCapabilities((Network)exception);
        } 
      } 
    } 
    return null;
  }
  
  public NetworkInfo a(Context paramContext) {
    if (paramContext != null) {
      ConnectivityManager connectivityManager = c(paramContext);
      if (connectivityManager != null)
        try {
          return connectivityManager.getActiveNetworkInfo();
        } catch (Exception exception) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Cannot retrieve active network info: ");
          stringBuilder.append(exception.toString());
          m3.a("Chartboost", stringBuilder.toString());
        }  
    } 
    return null;
  }
  
  public final s3 a(int paramInt1, int paramInt2) {
    if (paramInt1 == 1)
      return s3.d; 
    if (paramInt1 == 0) {
      switch (paramInt2) {
        default:
          return s3.e;
        case 13:
          return s3.h;
        case 3:
        case 5:
        case 6:
        case 8:
        case 9:
        case 10:
        case 12:
        case 14:
        case 15:
          return s3.g;
        case 1:
        case 2:
        case 4:
        case 7:
        case 11:
          break;
      } 
      return s3.f;
    } 
    return s3.b;
  }
  
  public int b(Context paramContext) {
    NetworkInfo networkInfo = a(paramContext);
    return (networkInfo != null && networkInfo.isConnected()) ? networkInfo.getSubtype() : 0;
  }
  
  public ConnectivityManager c(Context paramContext) {
    if (paramContext != null)
      try {
        return (ConnectivityManager)paramContext.getSystemService("connectivity");
      } catch (Exception exception) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot retrieve connectivity manager: ");
        stringBuilder.append(exception.toString());
        m3.a("Chartboost", stringBuilder.toString());
      }  
    return null;
  }
  
  public s3 d(Context paramContext) {
    NetworkInfo networkInfo = a(paramContext);
    return (networkInfo != null && networkInfo.isConnected()) ? a(networkInfo.getType(), networkInfo.getSubtype()) : s3.b;
  }
  
  public boolean e(Context paramContext) {
    NetworkInfo networkInfo = a(paramContext);
    if (Build.VERSION.SDK_INT >= 23) {
      NetworkCapabilities networkCapabilities = a(paramContext, (Network)null);
      if (networkCapabilities != null)
        return networkCapabilities.hasCapability(16); 
    } 
    return (networkInfo != null && networkInfo.isConnected());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\b2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */