package com.chartboost.sdk.impl;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import com.chartboost.sdk.internal.Model.CBError;
import com.chartboost.sdk.view.CBImpressionActivity;
import com.safedk.android.analytics.brandsafety.BrandSafetyUtils;
import com.safedk.android.utils.Logger;

public class f1 {
  public final Handler a;
  
  public final i1 b;
  
  public CBImpressionActivity c = null;
  
  public com.chartboost.sdk.internal.Model.a d = null;
  
  public boolean e = false;
  
  public f6 f;
  
  public Context g;
  
  public f1(Context paramContext, Handler paramHandler, i1 parami1) {
    this.g = paramContext;
    this.a = paramHandler;
    this.b = parami1;
  }
  
  public static void safedk_Context_startActivity_97cb3195734cf5c9cc3418feeafa6dd6(Context paramContext, Intent paramIntent) {
    Logger.d("SafeDK-Special|SafeDK: Call> Landroid/content/Context;->startActivity(Landroid/content/Intent;)V");
    if (paramIntent == null)
      return; 
    BrandSafetyUtils.detectAdClick(paramIntent, "com.chartboost");
    paramContext.startActivity(paramIntent);
  }
  
  public f6 a(Activity paramActivity) {
    f6 f61 = this.f;
    if (f61 == null || f61.a != paramActivity.hashCode())
      this.f = new f6(paramActivity); 
    return this.f;
  }
  
  public void a() {
    l5.a("CBUIManager.clearImpressionActivity");
    this.c = null;
  }
  
  public void a(com.chartboost.sdk.internal.Model.a parama) {
    i1 i11;
    f3 f3 = parama.b;
    if (f3 == f3.d) {
      i11 = d();
      if (i11 != null) {
        i11.a(parama);
        return;
      } 
    } else if (i11 == f3.c) {
      i11 = d();
      if (i11 != null)
        i11.e(parama); 
      m2.d(new c2("show_close_before_template_show_error", "", parama.c.a.b(), parama.m));
    } 
  }
  
  public void a(CBImpressionActivity paramCBImpressionActivity) {
    l5.a("CBUIManager.setImpressionActivity", paramCBImpressionActivity);
    if (this.c == null)
      this.c = paramCBImpressionActivity; 
  }
  
  public boolean a(Activity paramActivity, com.chartboost.sdk.internal.Model.a parama) {
    if (parama != null) {
      int i = a.a[parama.b.ordinal()];
      if (i != 2 && i != 3) {
        if (i == 4 && !parama.E()) {
          i1 i11 = d();
          if (i11 != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Error onActivityStart ");
            stringBuilder.append(parama.b);
            m3.b("CBUIManager", stringBuilder.toString());
            i11.e(parama);
          } 
        } 
      } else {
        b(parama);
      } 
    } 
    return true;
  }
  
  public void b(Activity paramActivity) {
    l5.a("CBUIManager.onDestroyImpl", paramActivity);
    com.chartboost.sdk.internal.Model.a a2 = f();
    com.chartboost.sdk.internal.Model.a a1 = a2;
    if (a2 == null) {
      a1 = a2;
      if (paramActivity == this.c) {
        com.chartboost.sdk.internal.Model.a a3 = this.d;
        a1 = a2;
        if (a3 != null)
          a1 = a3; 
      } 
    } 
    i1 i11 = d();
    if (i11 != null && a1 != null)
      i11.e(a1); 
    this.d = null;
  }
  
  public void b(com.chartboost.sdk.internal.Model.a parama) {
    l5.a("CBUIManager.queueDisplayView", parama);
    if (parama.k().booleanValue()) {
      c(parama);
      return;
    } 
    d(parama);
  }
  
  public final boolean b() {
    l5.a("CBUIManager.closeImpressionImpl");
    com.chartboost.sdk.internal.Model.a a1 = f();
    if (a1 != null && a1.b == f3.d) {
      if (a1.r())
        return true; 
      this.a.post(new b(this, g1.b));
      return true;
    } 
    return false;
  }
  
  public void c(Activity paramActivity) {
    l5.a("CBUIManager.onStartImpl", paramActivity);
    boolean bool = paramActivity instanceof CBImpressionActivity;
    if (bool)
      a((CBImpressionActivity)paramActivity); 
    if (paramActivity == null)
      return; 
    if (bool)
      this.e = false; 
    if (a(paramActivity, this.d))
      this.d = null; 
    com.chartboost.sdk.internal.Model.a a1 = f();
    if (a1 != null)
      a1.y(); 
  }
  
  public final void c(com.chartboost.sdk.internal.Model.a parama) {
    this.b.d(parama);
  }
  
  public boolean c() {
    com.chartboost.sdk.internal.Model.a a1 = f();
    if (a1 == null)
      return false; 
    a1.I = true;
    a(a1);
    return true;
  }
  
  public i1 d() {
    return (e() == null) ? null : this.b;
  }
  
  public void d(Activity paramActivity) {
    l5.a("CBUIManager.onStopImpl", a(paramActivity));
  }
  
  public final void d(com.chartboost.sdk.internal.Model.a parama) {
    if (g()) {
      parama.a(CBError.CBImpressionError.IMPRESSION_ALREADY_VISIBLE);
      return;
    } 
    if (this.c != null) {
      this.b.b(parama);
      return;
    } 
    com.chartboost.sdk.internal.Model.a a1 = this.d;
    if (a1 != null && a1 != parama) {
      parama.a(CBError.CBImpressionError.IMPRESSION_ALREADY_VISIBLE);
      return;
    } 
    this.d = parama;
    e(parama);
  }
  
  public Activity e() {
    return (Activity)this.c;
  }
  
  public void e(com.chartboost.sdk.internal.Model.a parama) {
    Intent intent = new Intent(this.g, CBImpressionActivity.class);
    intent.putExtra("isChartboost", true);
    intent.addFlags(268435456);
    try {
      safedk_Context_startActivity_97cb3195734cf5c9cc3418feeafa6dd6(this.g, intent);
      this.e = true;
      return;
    } catch (ActivityNotFoundException activityNotFoundException) {
      m3.b("CBUIManager", "Please add CBImpressionActivity in AndroidManifest.xml following README.md instructions.");
      this.d = null;
      parama.a(CBError.CBImpressionError.ACTIVITY_MISSING_IN_MANIFEST);
      return;
    } 
  }
  
  public com.chartboost.sdk.internal.Model.a f() {
    d4 d4;
    i1 i11 = d();
    if (i11 == null) {
      i11 = null;
    } else {
      d4 = i11.a();
    } 
    return (d4 != null) ? (!d4.b() ? null : d4.getImpression()) : null;
  }
  
  public boolean g() {
    return (f() != null);
  }
  
  public boolean h() {
    l5.a("CBUIManager.onBackPressedImpl");
    return b();
  }
  
  public void i() {
    l5.a("CBUIManager.onCreateImpl");
    l();
  }
  
  public void j() {
    l5.a("CBUIManager.onPauseImpl", null);
    com.chartboost.sdk.internal.Model.a a1 = f();
    if (a1 != null)
      a1.v(); 
  }
  
  public void k() {
    l5.a("CBUIManager.onResumeImpl", null);
    com.chartboost.sdk.internal.Model.a a1 = f();
    if (a1 != null)
      a1.x(); 
  }
  
  public void l() {
    l5.a("CBUIManager.onStop");
  }
  
  public class b implements Runnable {
    public final g1 a;
    
    public Activity b = null;
    
    public boolean c = false;
    
    public com.chartboost.sdk.internal.Model.a d = null;
    
    public b(f1 this$0, g1 param1g1) {
      this.a = param1g1;
    }
    
    public void run() {
      try {
        i1 i1;
        com.chartboost.sdk.internal.Model.a a1;
        switch (f1.a.b[this.a.ordinal()]) {
          case 7:
            this.e.b.e(this.d);
            return;
          case 6:
            this.e.b.a(this.d, this.b);
            return;
          case 5:
            this.d.q();
            return;
          case 4:
            i1 = this.e.d();
            a1 = this.d;
            if (a1.b == f3.d && i1 != null) {
              i1.a(a1);
              return;
            } 
            return;
          case 3:
            if (this.d.z()) {
              this.d.m().J();
              return;
            } 
            return;
          case 2:
            this.e.e(this.d);
            return;
          case 1:
            this.e.c();
            return;
        } 
      } catch (Exception exception) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("run (");
        stringBuilder.append(this.a);
        stringBuilder.append("): ");
        stringBuilder.append(exception.toString());
        m3.b("CBUIManager", stringBuilder.toString());
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\f1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */