package com.chartboost.sdk.impl;

import kotlin.Metadata;

@Metadata(bv = {}, d1 = {"\000\020\n\002\030\002\n\002\020\020\n\002\020\b\n\002\b\b\b\001\030\0002\b\022\004\022\0020\0000\001B\021\b\002\022\006\020\003\032\0020\002¢\006\004\b\004\020\005j\002\b\006j\002\b\007j\002\b\bj\002\b\t¨\006\n"}, d2 = {"Lcom/chartboost/sdk/impl/c4;", "", "", "value", "<init>", "(Ljava/lang/String;II)V", "NONE", "IDLE", "PLAYING", "PAUSED", "Chartboost-9.1.1_productionRelease"}, k = 1, mv = {1, 6, 0})
public enum c4 {
  b(0),
  c(1),
  d(2),
  e(3);
  
  public final int a;
  
  c4(int paramInt1) {
    this.a = paramInt1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\c4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */