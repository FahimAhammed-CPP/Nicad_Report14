package com.chartboost.sdk.impl;

import android.app.Application;
import android.content.Context;
import android.util.Log;
import java.util.Objects;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

@Metadata(bv = {}, d1 = {"\000d\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\020\016\n\002\b\002\n\002\020\013\n\002\b\b\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\006\b\026\030\0002\0020\001B\007¢\006\004\b9\020:J\020\020\005\032\0020\0042\006\020\003\032\0020\002H\026J\030\020\005\032\0020\0042\006\020\007\032\0020\0062\006\020\b\032\0020\006H\026R\024\020\f\032\0020\t8VX\004¢\006\006\032\004\b\n\020\013R\024\020\016\032\0020\t8VX\004¢\006\006\032\004\b\r\020\013R\024\020\007\032\0020\0068VX\004¢\006\006\032\004\b\017\020\020R\024\020\b\032\0020\0068VX\004¢\006\006\032\004\b\021\020\020R\033\020\026\032\0020\0228VX\002¢\006\f\n\004\b\023\020\024\032\004\b\005\020\025R\033\020\033\032\0020\0278VX\002¢\006\f\n\004\b\030\020\024\032\004\b\031\020\032R\033\020 \032\0020\0348FX\002¢\006\f\n\004\b\035\020\024\032\004\b\036\020\037R\033\020%\032\0020!8FX\002¢\006\f\n\004\b\"\020\024\032\004\b#\020$R\033\020*\032\0020&8VX\002¢\006\f\n\004\b'\020\024\032\004\b(\020)R\033\020/\032\0020+8VX\002¢\006\f\n\004\b,\020\024\032\004\b-\020.R\033\0204\032\002008VX\002¢\006\f\n\004\b1\020\024\032\004\b2\0203R\024\0208\032\002058BX\004¢\006\006\032\004\b6\0207¨\006;"}, d2 = {"Lcom/chartboost/sdk/impl/f2;", "", "Landroid/content/Context;", "context", "", "a", "", "appId", "appSignature", "", "g", "()Z", "initialized", "k", "started", "b", "()Ljava/lang/String;", "c", "Lcom/chartboost/sdk/impl/y;", "androidComponent$delegate", "Lkotlin/Lazy;", "()Lcom/chartboost/sdk/impl/y;", "androidComponent", "Lcom/chartboost/sdk/impl/e0;", "applicationComponent$delegate", "e", "()Lcom/chartboost/sdk/impl/e0;", "applicationComponent", "Lcom/chartboost/sdk/impl/i4;", "privacyComponent$delegate", "h", "()Lcom/chartboost/sdk/impl/i4;", "privacyComponent", "Lcom/chartboost/sdk/impl/n2;", "executorComponent$delegate", "f", "()Lcom/chartboost/sdk/impl/n2;", "executorComponent", "Lcom/chartboost/sdk/impl/n5;", "trackerComponent$delegate", "l", "()Lcom/chartboost/sdk/impl/n5;", "trackerComponent", "Lcom/chartboost/sdk/impl/x4;", "sdkComponent$delegate", "j", "()Lcom/chartboost/sdk/impl/x4;", "sdkComponent", "Lcom/chartboost/sdk/impl/q4;", "renderComponent$delegate", "i", "()Lcom/chartboost/sdk/impl/q4;", "renderComponent", "Landroid/app/Application;", "d", "()Landroid/app/Application;", "application", "<init>", "()V", "Chartboost-9.1.1_productionRelease"}, k = 1, mv = {1, 6, 0})
public class f2 {
  public String a;
  
  public String b;
  
  public Application c;
  
  public final Lazy d = LazyKt.lazy(new a(this));
  
  public final Lazy e = LazyKt.lazy(new b(this));
  
  public final Lazy f = LazyKt.lazy(new d(this));
  
  public final Lazy g = LazyKt.lazy(c.a);
  
  public final Lazy h = LazyKt.lazy(new g(this));
  
  public final Lazy i = LazyKt.lazy(new f(this));
  
  public final Lazy j = LazyKt.lazy(new e(this));
  
  public y a() {
    return (y)this.d.getValue();
  }
  
  public void a(Context paramContext) {
    Intrinsics.checkNotNullParameter(paramContext, "context");
    paramContext = paramContext.getApplicationContext();
    Objects.requireNonNull(paramContext, "null cannot be cast to non-null type android.app.Application");
    this.c = (Application)paramContext;
  }
  
  public void a(String paramString1, String paramString2) {
    Intrinsics.checkNotNullParameter(paramString1, "appId");
    Intrinsics.checkNotNullParameter(paramString2, "appSignature");
    this.a = paramString1;
    this.b = paramString2;
    l().a();
  }
  
  public String b() {
    String str2 = this.a;
    String str1 = str2;
    if (str2 == null) {
      Intrinsics.throwUninitializedPropertyAccessException("_appId");
      str1 = null;
    } 
    return str1;
  }
  
  public String c() {
    String str2 = this.b;
    String str1 = str2;
    if (str2 == null) {
      Intrinsics.throwUninitializedPropertyAccessException("_appSignature");
      str1 = null;
    } 
    return str1;
  }
  
  public final Application d() {
    if (this.c == null)
      try {
        throw new v1();
      } catch (Exception exception) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Missing application. Cannot start Chartboost SDK: ");
        stringBuilder.append(exception);
        Log.e("Chartboost", stringBuilder.toString());
      }  
    Application application2 = this.c;
    Application application1 = application2;
    if (application2 == null) {
      Intrinsics.throwUninitializedPropertyAccessException("unsafeApplication");
      application1 = null;
    } 
    return application1;
  }
  
  public e0 e() {
    return (e0)this.e.getValue();
  }
  
  public final n2 f() {
    return (n2)this.g.getValue();
  }
  
  public boolean g() {
    return (this.c != null);
  }
  
  public final i4 h() {
    return (i4)this.f.getValue();
  }
  
  public q4 i() {
    return (q4)this.j.getValue();
  }
  
  public x4 j() {
    return (x4)this.i.getValue();
  }
  
  public boolean k() {
    return (this.a != null && this.b != null);
  }
  
  public n5 l() {
    return (n5)this.h.getValue();
  }
  
  @Metadata(bv = {}, d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Lcom/chartboost/sdk/impl/z;", "a", "()Lcom/chartboost/sdk/impl/z;"}, k = 3, mv = {1, 6, 0})
  public static final class a extends Lambda implements Function0<z> {
    public a(f2 param1f2) {
      super(0);
    }
    
    public final z a() {
      return new z((Context)f2.a(this.a));
    }
  }
  
  @Metadata(bv = {}, d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Lcom/chartboost/sdk/impl/f0;", "a", "()Lcom/chartboost/sdk/impl/f0;"}, k = 3, mv = {1, 6, 0})
  public static final class b extends Lambda implements Function0<f0> {
    public b(f2 param1f2) {
      super(0);
    }
    
    public final f0 a() {
      return new f0(this.a.b(), this.a.c(), this.a.a(), this.a.f(), this.a.h());
    }
  }
  
  @Metadata(bv = {}, d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Lcom/chartboost/sdk/impl/o2;", "a", "()Lcom/chartboost/sdk/impl/o2;"}, k = 3, mv = {1, 6, 0})
  public static final class c extends Lambda implements Function0<o2> {
    public static final c a = new c();
    
    public c() {
      super(0);
    }
    
    public final o2 a() {
      return new o2();
    }
  }
  
  @Metadata(bv = {}, d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Lcom/chartboost/sdk/impl/j4;", "a", "()Lcom/chartboost/sdk/impl/j4;"}, k = 3, mv = {1, 6, 0})
  public static final class d extends Lambda implements Function0<j4> {
    public d(f2 param1f2) {
      super(0);
    }
    
    public final j4 a() {
      return new j4(this.a.a());
    }
  }
  
  @Metadata(bv = {}, d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Lcom/chartboost/sdk/impl/r4;", "a", "()Lcom/chartboost/sdk/impl/r4;"}, k = 3, mv = {1, 6, 0})
  public static final class e extends Lambda implements Function0<r4> {
    public e(f2 param1f2) {
      super(0);
    }
    
    public final r4 a() {
      return new r4(this.a.a(), this.a.e());
    }
  }
  
  @Metadata(bv = {}, d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Lcom/chartboost/sdk/impl/a5;", "a", "()Lcom/chartboost/sdk/impl/a5;"}, k = 3, mv = {1, 6, 0})
  public static final class f extends Lambda implements Function0<a5> {
    public f(f2 param1f2) {
      super(0);
    }
    
    public final a5 a() {
      return new a5(this.a.a(), this.a.f(), this.a.e());
    }
  }
  
  @Metadata(bv = {}, d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Lcom/chartboost/sdk/impl/o5;", "a", "()Lcom/chartboost/sdk/impl/o5;"}, k = 3, mv = {1, 6, 0})
  public static final class g extends Lambda implements Function0<o5> {
    public g(f2 param1f2) {
      super(0);
    }
    
    public final o5 a() {
      return new o5(this.a.a(), this.a.e(), this.a.f(), this.a.h().a());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\f2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */