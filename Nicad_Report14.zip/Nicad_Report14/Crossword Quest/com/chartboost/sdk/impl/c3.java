package com.chartboost.sdk.impl;

import android.app.Activity;
import com.chartboost.sdk.internal.Model.CBError;
import com.chartboost.sdk.internal.Model.a;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv = {}, d1 = {"\000$\n\002\030\002\n\002\020\000\n\002\020\002\n\002\b\b\n\002\020\013\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\004\030\0002\0020\001B\027\022\006\020\016\032\0020\r\022\006\020\020\032\0020\017¢\006\004\b\021\020\022J\b\020\003\032\0020\002H\026J\b\020\004\032\0020\002H\026J\b\020\005\032\0020\002H\026J\b\020\006\032\0020\002H\026J\b\020\007\032\0020\002H\026J\b\020\b\032\0020\002H\026J\b\020\t\032\0020\002H\026J\b\020\n\032\0020\002H\026J\b\020\f\032\0020\013H\026¨\006\023"}, d2 = {"Lcom/chartboost/sdk/impl/c3;", "", "", "c", "g", "f", "e", "h", "d", "b", "i", "", "a", "Lcom/chartboost/sdk/impl/b3;", "view", "Lcom/chartboost/sdk/impl/f1;", "uiManager", "<init>", "(Lcom/chartboost/sdk/impl/b3;Lcom/chartboost/sdk/impl/f1;)V", "Chartboost-9.1.1_productionRelease"}, k = 1, mv = {1, 6, 0})
public final class c3 {
  public final b3 a;
  
  public final f1 b;
  
  public final String c;
  
  public c3(b3 paramb3, f1 paramf1) {
    this.a = paramb3;
    this.b = paramf1;
    this.c = "c3";
  }
  
  public boolean a() {
    try {
      return this.b.h();
    } catch (Exception exception) {
      String str = this.c;
      Intrinsics.checkNotNullExpressionValue(str, "TAG");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onBackPressed: ");
      stringBuilder.append(exception);
      m3.b(str, stringBuilder.toString());
      return false;
    } 
  }
  
  public void b() {
    try {
      a a = this.b.f();
      if (a != null) {
        j1 j1 = a.m();
        if (j1 != null) {
          j1.z();
          return;
        } 
      } 
    } catch (Exception exception) {
      String str = this.c;
      Intrinsics.checkNotNullExpressionValue(str, "TAG");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onConfigurationChange: ");
      stringBuilder.append(exception);
      m3.b(str, stringBuilder.toString());
    } 
  }
  
  public void c() {
    try {
      f1 f11 = this.b;
      f11.a(this.a.a());
      f11.i();
    } catch (Exception exception) {
      String str = this.c;
      Intrinsics.checkNotNullExpressionValue(str, "TAG");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onCreate: ");
      stringBuilder.append(exception);
      m3.b(str, stringBuilder.toString());
    } 
    this.a.b();
  }
  
  public void d() {
    try {
      this.b.b((Activity)this.a.a());
      return;
    } catch (Exception exception) {
      String str = this.c;
      Intrinsics.checkNotNullExpressionValue(str, "TAG");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onDestroy: ");
      stringBuilder.append(exception);
      m3.b(str, stringBuilder.toString());
      return;
    } 
  }
  
  public void e() {
    try {
      f1 f11 = this.b;
      f11.a((Activity)this.a.a());
      f11.j();
      return;
    } catch (Exception exception) {
      String str = this.c;
      Intrinsics.checkNotNullExpressionValue(str, "TAG");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onPause: ");
      stringBuilder.append(exception);
      m3.b(str, stringBuilder.toString());
      return;
    } 
  }
  
  public void f() {
    try {
      f1 f11 = this.b;
      f11.a((Activity)this.a.a());
      f11.k();
      return;
    } catch (Exception exception) {
      String str = this.c;
      Intrinsics.checkNotNullExpressionValue(str, "TAG");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onResume: ");
      stringBuilder.append(exception);
      m3.b(str, stringBuilder.toString());
      return;
    } 
  }
  
  public void g() {
    try {
      this.b.c((Activity)this.a.a());
      return;
    } catch (Exception exception) {
      String str = this.c;
      Intrinsics.checkNotNullExpressionValue(str, "TAG");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onStart: ");
      stringBuilder.append(exception);
      m3.b(str, stringBuilder.toString());
      return;
    } 
  }
  
  public void h() {
    try {
      this.b.d((Activity)this.a.a());
      return;
    } catch (Exception exception) {
      String str = this.c;
      Intrinsics.checkNotNullExpressionValue(str, "TAG");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onStop: ");
      stringBuilder.append(exception);
      m3.b(str, stringBuilder.toString());
      return;
    } 
  }
  
  public void i() {
    try {
      if (!this.a.d()) {
        String str = this.c;
        Intrinsics.checkNotNullExpressionValue(str, "TAG");
        m3.b(str, "The activity passed down is not hardware accelerated, so Chartboost cannot show ads");
        a a = this.b.f();
        if (a != null)
          a.a(CBError.CBImpressionError.HARDWARE_ACCELERATION_DISABLED); 
        this.a.c();
        return;
      } 
    } catch (Exception exception) {
      String str = this.c;
      Intrinsics.checkNotNullExpressionValue(str, "TAG");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onAttachedToWindow: ");
      stringBuilder.append(exception);
      m3.b(str, stringBuilder.toString());
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\c3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */