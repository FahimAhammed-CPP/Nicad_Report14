package com.chartboost.sdk.impl;

import java.util.ArrayList;
import java.util.Iterator;

public class b5 {
  public String a = "";
  
  public ArrayList<p0> b = new ArrayList<p0>();
  
  public b5() {}
  
  public b5(String paramString, ArrayList<p0> paramArrayList) {}
  
  public final String a() {
    Iterator<p0> iterator = this.b.iterator();
    String str = "";
    for (int i = 0; iterator.hasNext(); i++) {
      p0 p0 = iterator.next();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Bid ");
      stringBuilder.append(i);
      stringBuilder.append(" : ");
      stringBuilder.append(p0.toString());
      stringBuilder.append("\n");
      str = stringBuilder.toString();
    } 
    return str;
  }
  
  public ArrayList<p0> b() {
    return this.b;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("seat: ");
    stringBuilder.append(this.a);
    stringBuilder.append("\nbid: ");
    stringBuilder.append(a());
    stringBuilder.append("\n");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\b5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */