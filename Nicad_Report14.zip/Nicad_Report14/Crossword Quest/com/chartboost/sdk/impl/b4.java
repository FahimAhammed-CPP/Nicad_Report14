package com.chartboost.sdk.impl;

import android.os.Build;
import com.chartboost.sdk.internal.Model.CBError;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.json.JSONException;
import org.json.JSONObject;

@Metadata(bv = {}, d1 = {"\000H\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\020\013\n\002\b\003\030\0002\0020\001B\027\022\006\020\r\032\0020\f\022\006\020\022\032\0020\021¢\006\004\b\026\020\027J3\020\013\032\0020\t2\006\020\003\032\0020\0022!\020\n\032\035\022\023\022\0210\005¢\006\f\b\006\022\b\b\007\022\004\b\b(\b\022\004\022\0020\t0\004H\026J;\020\013\032\0020\t2\006\020\003\032\0020\0022\006\020\r\032\0020\f2!\020\n\032\035\022\023\022\0210\005¢\006\f\b\006\022\b\b\007\022\004\b\b(\b\022\004\022\0020\t0\004H\002J;\020\013\032\0020\t2\006\020\016\032\0020\0022\006\020\020\032\0020\0172!\020\n\032\035\022\023\022\0210\005¢\006\f\b\006\022\b\b\007\022\004\b\b(\b\022\004\022\0020\t0\004H\002J \020\013\032\0020\t2\006\020\022\032\0020\0212\006\020\023\032\0020\0172\006\020\n\032\0020\024H\002J\020\020\013\032\0020\0252\006\020\003\032\0020\002H\002¨\006\030"}, d2 = {"Lcom/chartboost/sdk/impl/b4;", "Lcom/chartboost/sdk/impl/g;", "Lcom/chartboost/sdk/impl/k3;", "params", "Lkotlin/Function1;", "Lcom/chartboost/sdk/impl/l3;", "Lkotlin/ParameterName;", "name", "result", "", "callback", "a", "Lcom/chartboost/sdk/impl/d3;", "impressionAdType", "loaderParams", "Lcom/chartboost/sdk/impl/w3;", "openRTBAdUnit", "Lcom/chartboost/sdk/impl/i2;", "downloader", "openRTB", "Lcom/chartboost/sdk/impl/h0;", "", "<init>", "(Lcom/chartboost/sdk/impl/d3;Lcom/chartboost/sdk/impl/i2;)V", "Chartboost-9.1.1_productionRelease"}, k = 1, mv = {1, 6, 0})
public final class b4 implements g {
  public final d3 a;
  
  public final i2 b;
  
  public b4(d3 paramd3, i2 parami2) {
    this.a = paramd3;
    this.b = parami2;
  }
  
  public static final void a(Function1 paramFunction1, k3 paramk3, w3 paramw3, b4 paramb4, boolean paramBoolean, int paramInt1, int paramInt2) {
    Intrinsics.checkNotNullParameter(paramFunction1, "$callback");
    Intrinsics.checkNotNullParameter(paramk3, "$loaderParams");
    Intrinsics.checkNotNullParameter(paramw3, "$openRTBAdUnit");
    Intrinsics.checkNotNullParameter(paramb4, "this$0");
    if (paramBoolean) {
      paramFunction1.invoke(new l3(paramk3.a(), paramw3, null, paramInt1, paramInt2));
      return;
    } 
    m2.d(new c2("cache_asset_download_error", CBError.CBImpressionError.ASSETS_DOWNLOAD_FAILURE.name(), paramb4.a.b(), (paramk3.a()).b));
    paramFunction1.invoke(new l3(paramk3.a(), null, new CBError(CBError.b.c, "Error parsing response"), 0L, 0L, 26, null));
  }
  
  public final void a(i2 parami2, w3 paramw3, h0 paramh0) {
    HashMap hashMap = paramw3.d().b();
    AtomicInteger atomicInteger = new AtomicInteger();
    parami2.a(f4.c, hashMap, atomicInteger, paramh0, this.a.b());
  }
  
  public final void a(k3 paramk3, d3 paramd3, Function1<? super l3, Unit> paramFunction1) {
    if (Build.VERSION.SDK_INT < 21) {
      paramFunction1.invoke(new l3(paramk3.a(), null, new CBError(CBError.b.d, "No ad found"), 0L, 0L, 26, null));
      return;
    } 
    if (!a(paramk3)) {
      m2.d(new c2("cache_bid_response_parsing_error", "Invalid bid response", paramd3.b(), (paramk3.a()).b));
      paramFunction1.invoke(new l3(paramk3.a(), null, new CBError(CBError.b.d, "Error parsing response"), 0L, 0L, 26, null));
      return;
    } 
    try {
      JSONObject jSONObject = new JSONObject((paramk3.a()).c);
      try {
        w3 w3 = new w3(paramd3, jSONObject);
        a(paramk3, w3, paramFunction1);
        return;
      } catch (JSONException null) {}
    } catch (JSONException jSONException) {}
    m2.d(new c2("cache_bid_response_parsing_error", jSONException.toString(), paramd3.b(), (paramk3.a()).b));
    paramFunction1.invoke(new l3(paramk3.a(), null, new CBError(CBError.b.c, "Error parsing response"), 0L, 0L, 26, null));
  }
  
  public final void a(k3 paramk3, w3 paramw3, Function1<? super l3, Unit> paramFunction1) {
    a(this.b, paramw3, (h0)new b4$.ExternalSyntheticLambda0(paramFunction1, paramk3, paramw3, this));
  }
  
  public void a(k3 paramk3, Function1<? super l3, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramk3, "params");
    Intrinsics.checkNotNullParameter(paramFunction1, "callback");
    a(paramk3, this.a, paramFunction1);
  }
  
  public final boolean a(k3 paramk3) {
    boolean bool;
    String str = (paramk3.a()).b;
    Intrinsics.checkNotNullExpressionValue(str, "params.appRequest.location");
    if (str.length() > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      String str1 = (paramk3.a()).c;
      Intrinsics.checkNotNullExpressionValue(str1, "params.appRequest.bidResponse");
      if (str1.length() > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        return true; 
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\b4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */