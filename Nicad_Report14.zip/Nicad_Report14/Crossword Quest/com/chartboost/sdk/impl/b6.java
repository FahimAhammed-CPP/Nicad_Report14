package com.chartboost.sdk.impl;

import com.chartboost.sdk.internal.Model.CBError;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

@Metadata(bv = {}, d1 = {"\000\001\n\002\030\002\n\002\030\002\n\002\020\016\n\000\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\002\b\007\n\002\020 \n\002\b\003\n\002\030\002\n\000\n\002\020\b\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\t\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\004\030\0002\0020\001:\001\016B=\022\006\020(\032\0020'\022\006\020,\032\0020+\022\b\020.\032\004\030\0010-\022\b\0200\032\004\030\0010/\022\b\b\002\0202\032\00201\022\006\0204\032\00203¢\006\004\b5\0206J\024\020\005\032\004\030\0010\0042\b\020\003\032\004\030\0010\002H\002J\020\020\b\032\0020\0072\006\020\006\032\0020\004H\002J\020\020\013\032\0020\n2\006\020\t\032\0020\004H\002J\022\020\r\032\004\030\0010\f2\006\020\t\032\0020\004H\002J\b\020\016\032\0020\007H\002J\b\020\r\032\0020\nH\002J,\020\016\032\0020\0072\006\020\017\032\0020\0022\006\020\003\032\0020\0022\b\020\020\032\004\030\0010\f2\b\020\021\032\004\030\0010\fH\002J\020\020\016\032\0020\0072\006\020\006\032\0020\004H\002J\020\020\022\032\0020\0072\006\020\006\032\0020\004H\002J\022\020\023\032\0020\n2\b\020\t\032\004\030\0010\004H\002J\016\020\023\032\b\022\004\022\0020\0040\024H\002J\024\020\023\032\004\030\0010\f2\b\020\003\032\004\030\0010\002H\002J\030\020\022\032\0020\n2\006\020\025\032\0020\0022\006\020\026\032\0020\002H\002J\020\020\022\032\0020\0072\006\020\017\032\0020\002H\002J\006\020\005\032\0020\007J(\020\016\032\0020\0072\006\020\017\032\0020\0022\006\020\003\032\0020\0022\006\020\027\032\0020\n2\b\020\031\032\004\030\0010\030J \020\016\032\0020\0072\b\020\003\032\004\030\0010\0022\006\020\033\032\0020\0322\006\020\034\032\0020\nJ\022\020\016\032\004\030\0010\0362\b\020\035\032\004\030\0010\002J\020\020\013\032\0020\n2\b\b\001\020\035\032\0020\002J\020\020\r\032\004\030\0010\0042\006\020\003\032\0020\002J\020\020\005\032\0020\0322\b\020\t\032\004\030\0010\004J\020\020\037\032\0020\n2\b\020\006\032\004\030\0010\004J*\020\016\032\0020\0072\006\020\017\032\0020\0022\006\020 \032\0020\0022\006\020\"\032\0020!2\b\020#\032\004\030\0010\030H\026J\030\020\016\032\0020\0072\006\020$\032\0020\0022\006\020 \032\0020\002H\026J\"\020\016\032\0020\0072\006\020$\032\0020\0022\006\020 \032\0020\0022\b\020&\032\004\030\0010%H\026R\027\020(\032\0020'8\006¢\006\f\n\004\b(\020)\032\004\b\022\020*¨\0067"}, d2 = {"Lcom/chartboost/sdk/impl/b6;", "Lcom/chartboost/sdk/impl/c6$a;", "", "filename", "Lcom/chartboost/sdk/impl/v5;", "d", "videoAsset", "", "h", "asset", "", "f", "Ljava/io/File;", "c", "a", "url", "dest", "destDir", "b", "e", "", "nextUrl", "nextFilename", "showImmediately", "Lcom/chartboost/sdk/impl/b6$a;", "callback", "", "repeat", "forceDownload", "videoFilename", "Ljava/io/RandomAccessFile;", "g", "videoFileName", "", "expectedContentSize", "adUnitVideoPrecacheTempCallback", "uri", "Lcom/chartboost/sdk/internal/Model/CBError;", "error", "Lcom/chartboost/sdk/impl/a1;", "networkRequestService", "Lcom/chartboost/sdk/impl/a1;", "()Lcom/chartboost/sdk/impl/a1;", "Lcom/chartboost/sdk/impl/x5;", "policy", "Lcom/chartboost/sdk/impl/b1;", "reachability", "Lcom/chartboost/sdk/impl/t2;", "fileCache", "Lcom/chartboost/sdk/impl/h5;", "tempHelper", "Ljava/util/concurrent/ScheduledExecutorService;", "backgroundExecutor", "<init>", "(Lcom/chartboost/sdk/impl/a1;Lcom/chartboost/sdk/impl/x5;Lcom/chartboost/sdk/impl/b1;Lcom/chartboost/sdk/impl/t2;Lcom/chartboost/sdk/impl/h5;Ljava/util/concurrent/ScheduledExecutorService;)V", "Chartboost-9.1.1_productionRelease"}, k = 1, mv = {1, 6, 0})
public final class b6 implements c6.a {
  public final a1 a;
  
  public final x5 b;
  
  public final b1 c;
  
  public final t2 d;
  
  public final h5 e;
  
  public final ScheduledExecutorService f;
  
  public final Queue<v5> g;
  
  public final ConcurrentLinkedQueue<String> h;
  
  public final ConcurrentHashMap<String, a> i;
  
  public final ConcurrentHashMap<String, v5> j;
  
  public AtomicInteger k;
  
  public final Runnable l;
  
  public b6(a1 parama1, x5 paramx5, b1 paramb1, t2 paramt2, h5 paramh5, ScheduledExecutorService paramScheduledExecutorService) {
    this.a = parama1;
    this.b = paramx5;
    this.c = paramb1;
    this.d = paramt2;
    this.e = paramh5;
    this.f = paramScheduledExecutorService;
    this.g = new ConcurrentLinkedQueue<v5>();
    this.h = new ConcurrentLinkedQueue<String>();
    this.i = new ConcurrentHashMap<String, a>();
    this.j = new ConcurrentHashMap<String, v5>();
    this.k = new AtomicInteger(1);
    d();
    this.l = (Runnable)new b6$.ExternalSyntheticLambda0(this);
  }
  
  public static final void a(b6 paramb6) {
    Intrinsics.checkNotNullParameter(paramb6, "this$0");
    paramb6.a((String)null, paramb6.k.incrementAndGet(), false);
  }
  
  public final RandomAccessFile a(String paramString) {
    if (paramString != null)
      try {
        File file = e(paramString);
        if (file != null && file.exists())
          return this.e.a(file); 
      } catch (Exception exception) {
        m3.b("VideoRepository", exception.toString());
      }  
    return null;
  }
  
  public final void a() {
    if (c()) {
      Iterator<v5> iterator = e().iterator();
      while (iterator.hasNext()) {
        g(iterator.next());
        if (!c())
          break; 
      } 
    } 
  }
  
  public final void a(v5 paramv5) {
    if (w4.a) {
      File file = new File(paramv5.f());
      try {
        file.createNewFile();
        file.setLastModified(System.currentTimeMillis());
        return;
      } catch (IOException iOException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Error while creating queue empty file: ");
        stringBuilder.append(iOException);
        m3.e("VideoRepository", stringBuilder.toString());
      } 
    } 
  }
  
  public final void a(String paramString, int paramInt, boolean paramBoolean) {
    if (this.g.size() > 0) {
      int i = this.h.size();
      boolean bool = false;
      if (i > 0) {
        i = 1;
      } else {
        i = 0;
      } 
      b1 b11 = this.c;
      if (b11 != null)
        bool = b11.e(); 
      if (paramBoolean || (bool && this.b.b() && i == 0)) {
        v5 v5 = d(paramString);
        if (v5 != null)
          h(v5); 
        return;
      } 
      w4.a("Can't cache next video at the moment");
      long l = paramInt;
      this.f.schedule(this.l, l * 5000L, TimeUnit.MILLISECONDS);
      return;
    } 
  }
  
  public void a(String paramString1, String paramString2) {
    Intrinsics.checkNotNullParameter(paramString1, "uri");
    Intrinsics.checkNotNullParameter(paramString2, "videoFileName");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Video downloaded success ");
    stringBuilder.append(paramString1);
    w4.a(stringBuilder.toString());
    a();
    this.h.remove(paramString1);
    this.i.remove(paramString1);
    this.k = new AtomicInteger(1);
    b(paramString1);
    a((String)null, this.k.get(), false);
  }
  
  public void a(String paramString1, String paramString2, long paramLong, a parama) {
    Intrinsics.checkNotNullParameter(paramString1, "url");
    Intrinsics.checkNotNullParameter(paramString2, "videoFileName");
    v5 v5 = c(paramString2);
    if (v5 != null)
      v5.a(paramLong); 
    a a2 = parama;
    if (parama == null)
      a2 = this.i.get(paramString1); 
    if (a2 != null)
      a2.a(paramString1); 
  }
  
  public void a(String paramString1, String paramString2, CBError paramCBError) {
    String str1;
    Intrinsics.checkNotNullParameter(paramString1, "uri");
    Intrinsics.checkNotNullParameter(paramString2, "videoFileName");
    if (paramCBError != null) {
      str1 = paramCBError.getErrorDesc();
    } else {
      str1 = null;
    } 
    String str2 = str1;
    if (str1 == null)
      str2 = "Unknown error"; 
    v5 v5 = c(paramString2);
    if (v5 != null) {
      File file = v5.e();
      if (file != null)
        file.delete(); 
    } 
    if (paramCBError != null && paramCBError.getError() == CBError.b.b) {
      if (v5 != null) {
        this.g.add(v5);
        a(v5);
      } 
    } else {
      b(paramString1);
      a a2 = this.i.get(paramString1);
      if (a2 != null) {
        a2.a(paramString1);
        Unit unit = Unit.INSTANCE;
      } else {
        a2 = null;
      } 
      if (a2 == null)
        m3.b("VideoRepository", "Missing callback on error"); 
    } 
    this.i.remove(paramString1);
    this.j.remove(paramString2);
    a((String)null, this.k.get(), false);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Video download failed: ");
    stringBuilder.append(paramString1);
    stringBuilder.append(" with error ");
    stringBuilder.append(str2);
    m3.c("VideoRepository", stringBuilder.toString());
    stringBuilder = new StringBuilder();
    stringBuilder.append("Video downloaded failed ");
    stringBuilder.append(paramString1);
    stringBuilder.append(" with error ");
    stringBuilder.append(str2);
    w4.a(stringBuilder.toString());
    this.h.remove(paramString1);
  }
  
  public final void a(String paramString1, String paramString2, File paramFile1, File paramFile2) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #6
    //   9: aload_0
    //   10: getfield d : Lcom/chartboost/sdk/impl/t2;
    //   13: astore #5
    //   15: aload #5
    //   17: ifnull -> 42
    //   20: aload #5
    //   22: invokevirtual e : ()Ljava/io/File;
    //   25: astore #5
    //   27: aload #5
    //   29: ifnull -> 42
    //   32: aload #5
    //   34: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   37: astore #5
    //   39: goto -> 45
    //   42: aconst_null
    //   43: astore #5
    //   45: aload #6
    //   47: aload #5
    //   49: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   52: pop
    //   53: aload #6
    //   55: getstatic java/io/File.separator : Ljava/lang/String;
    //   58: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   61: pop
    //   62: aload #6
    //   64: aload_2
    //   65: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   68: pop
    //   69: new com/chartboost/sdk/impl/v5
    //   72: dup
    //   73: aload_1
    //   74: aload_2
    //   75: aload_3
    //   76: aload #4
    //   78: lconst_0
    //   79: aload #6
    //   81: invokevirtual toString : ()Ljava/lang/String;
    //   84: lconst_0
    //   85: bipush #80
    //   87: aconst_null
    //   88: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/io/File;Ljava/io/File;JLjava/lang/String;JILkotlin/jvm/internal/DefaultConstructorMarker;)V
    //   91: astore_1
    //   92: aload_3
    //   93: ifnull -> 105
    //   96: aload_3
    //   97: aload_1
    //   98: invokevirtual a : ()J
    //   101: invokevirtual setLastModified : (J)Z
    //   104: pop
    //   105: aload_0
    //   106: aload_1
    //   107: invokevirtual a : (Lcom/chartboost/sdk/impl/v5;)V
    //   110: aload_0
    //   111: getfield j : Ljava/util/concurrent/ConcurrentHashMap;
    //   114: aload_2
    //   115: aload_1
    //   116: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   121: pop
    //   122: aload_0
    //   123: getfield g : Ljava/util/Queue;
    //   126: aload_1
    //   127: invokeinterface offer : (Ljava/lang/Object;)Z
    //   132: pop
    //   133: return
  }
  
  public final void a(String paramString1, String paramString2, boolean paramBoolean, a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ldc_w 'url'
    //   6: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   9: aload_2
    //   10: ldc_w 'filename'
    //   13: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   16: aload_0
    //   17: getfield d : Lcom/chartboost/sdk/impl/t2;
    //   20: astore #8
    //   22: aload #8
    //   24: ifnull -> 354
    //   27: aload #8
    //   29: invokevirtual c : ()Ljava/io/File;
    //   32: astore #8
    //   34: goto -> 37
    //   37: aload_0
    //   38: getfield d : Lcom/chartboost/sdk/impl/t2;
    //   41: astore #9
    //   43: aload #9
    //   45: ifnull -> 360
    //   48: aload #9
    //   50: aload #8
    //   52: aload_2
    //   53: invokevirtual a : (Ljava/io/File;Ljava/lang/String;)Ljava/io/File;
    //   56: astore #9
    //   58: goto -> 61
    //   61: aload_0
    //   62: aload_2
    //   63: invokevirtual f : (Ljava/lang/String;)Z
    //   66: istore #5
    //   68: iload_3
    //   69: ifeq -> 109
    //   72: aload_0
    //   73: getfield i : Ljava/util/concurrent/ConcurrentHashMap;
    //   76: aload_1
    //   77: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   80: ifeq -> 109
    //   83: iload #5
    //   85: ifne -> 109
    //   88: aload #4
    //   90: ifnull -> 109
    //   93: aload_0
    //   94: getfield i : Ljava/util/concurrent/ConcurrentHashMap;
    //   97: aload_1
    //   98: aload #4
    //   100: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   105: pop
    //   106: aload_0
    //   107: monitorexit
    //   108: return
    //   109: iload_3
    //   110: ifeq -> 190
    //   113: iload #5
    //   115: ifeq -> 190
    //   118: aload_0
    //   119: getfield i : Ljava/util/concurrent/ConcurrentHashMap;
    //   122: aload_1
    //   123: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   126: ifeq -> 190
    //   129: new java/lang/StringBuilder
    //   132: dup
    //   133: invokespecial <init> : ()V
    //   136: astore #8
    //   138: aload #8
    //   140: ldc_w 'Already downloading for show operation: '
    //   143: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   146: pop
    //   147: aload #8
    //   149: aload_2
    //   150: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   153: pop
    //   154: aload #8
    //   156: invokevirtual toString : ()Ljava/lang/String;
    //   159: invokestatic a : (Ljava/lang/String;)V
    //   162: aload #9
    //   164: ifnull -> 366
    //   167: aload #9
    //   169: invokevirtual length : ()J
    //   172: lstore #6
    //   174: goto -> 177
    //   177: aload_0
    //   178: aload_1
    //   179: aload_2
    //   180: lload #6
    //   182: aload #4
    //   184: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;JLcom/chartboost/sdk/impl/b6$a;)V
    //   187: aload_0
    //   188: monitorexit
    //   189: return
    //   190: iload_3
    //   191: ifne -> 240
    //   194: aload_0
    //   195: aload_1
    //   196: aload_2
    //   197: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)Z
    //   200: ifne -> 208
    //   203: iload #5
    //   205: ifeq -> 240
    //   208: new java/lang/StringBuilder
    //   211: dup
    //   212: invokespecial <init> : ()V
    //   215: astore_1
    //   216: aload_1
    //   217: ldc_w 'Already queued or downloading for cache operation: '
    //   220: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   223: pop
    //   224: aload_1
    //   225: aload_2
    //   226: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   229: pop
    //   230: aload_1
    //   231: invokevirtual toString : ()Ljava/lang/String;
    //   234: invokestatic a : (Ljava/lang/String;)V
    //   237: aload_0
    //   238: monitorexit
    //   239: return
    //   240: iload_3
    //   241: ifeq -> 295
    //   244: aload #4
    //   246: ifnull -> 295
    //   249: new java/lang/StringBuilder
    //   252: dup
    //   253: invokespecial <init> : ()V
    //   256: astore #9
    //   258: aload #9
    //   260: ldc_w 'Register callback for show operation: '
    //   263: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   266: pop
    //   267: aload #9
    //   269: aload_2
    //   270: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   273: pop
    //   274: aload #9
    //   276: invokevirtual toString : ()Ljava/lang/String;
    //   279: invokestatic a : (Ljava/lang/String;)V
    //   282: aload_0
    //   283: getfield i : Ljava/util/concurrent/ConcurrentHashMap;
    //   286: aload_1
    //   287: aload #4
    //   289: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   294: pop
    //   295: aload_0
    //   296: aload_1
    //   297: aload_2
    //   298: new java/io/File
    //   301: dup
    //   302: aload #8
    //   304: aload_2
    //   305: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   308: aload #8
    //   310: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;Ljava/io/File;Ljava/io/File;)V
    //   313: iload_3
    //   314: ifeq -> 333
    //   317: aload_0
    //   318: aload_2
    //   319: aload_0
    //   320: getfield k : Ljava/util/concurrent/atomic/AtomicInteger;
    //   323: invokevirtual get : ()I
    //   326: iload_3
    //   327: invokevirtual a : (Ljava/lang/String;IZ)V
    //   330: goto -> 346
    //   333: aload_0
    //   334: aconst_null
    //   335: aload_0
    //   336: getfield k : Ljava/util/concurrent/atomic/AtomicInteger;
    //   339: invokevirtual get : ()I
    //   342: iload_3
    //   343: invokevirtual a : (Ljava/lang/String;IZ)V
    //   346: aload_0
    //   347: monitorexit
    //   348: return
    //   349: astore_1
    //   350: aload_0
    //   351: monitorexit
    //   352: aload_1
    //   353: athrow
    //   354: aconst_null
    //   355: astore #8
    //   357: goto -> 37
    //   360: aconst_null
    //   361: astore #9
    //   363: goto -> 61
    //   366: lconst_0
    //   367: lstore #6
    //   369: goto -> 177
    // Exception table:
    //   from	to	target	type
    //   2	22	349	finally
    //   27	34	349	finally
    //   37	43	349	finally
    //   48	58	349	finally
    //   61	68	349	finally
    //   72	83	349	finally
    //   93	106	349	finally
    //   118	162	349	finally
    //   167	174	349	finally
    //   177	187	349	finally
    //   194	203	349	finally
    //   208	237	349	finally
    //   249	295	349	finally
    //   295	313	349	finally
    //   317	330	349	finally
    //   333	346	349	finally
  }
  
  public final a1 b() {
    return this.a;
  }
  
  public final void b(v5 paramv5) {
    if (w4.a) {
      File file = new File(paramv5.f());
      if (file.exists())
        file.delete(); 
    } 
  }
  
  public final void b(String paramString) {
    for (v5 v5 : new LinkedList(this.g)) {
      if (v5 != null && Intrinsics.areEqual(v5.g(), paramString))
        this.g.remove(v5); 
    } 
  }
  
  public final boolean b(String paramString1, String paramString2) {
    if (this.g.size() > 0)
      for (v5 v5 : this.g) {
        if (Intrinsics.areEqual(v5.g(), paramString1) && Intrinsics.areEqual(v5.d(), paramString2))
          return true; 
      }  
    return false;
  }
  
  public final v5 c(String paramString) {
    Intrinsics.checkNotNullParameter(paramString, "filename");
    return this.j.get(paramString);
  }
  
  public final File c(v5 paramv5) {
    return this.e.a(paramv5.b(), paramv5.d());
  }
  
  public final boolean c() {
    t2 t21 = this.d;
    if (t21 != null) {
      long l = t21.b(t21.c());
      return this.b.a(l);
    } 
    return false;
  }
  
  public final int d(v5 paramv5) {
    byte b = 0;
    if (paramv5 != null) {
      long l;
      if (e(paramv5))
        return 5; 
      File file = c(paramv5);
      if (file != null) {
        l = file.length();
      } else {
        l = 0L;
      } 
      if (paramv5.c() == 0L)
        return 0; 
      float f = (float)l / (float)paramv5.c();
      if (f == 0.0F) {
        b = 1;
      } else {
        b = 0;
      } 
      if (b)
        return 0; 
      double d = f;
      if (d < 0.25D)
        return 1; 
      if (d < 0.5D)
        return 2; 
      if (d < 0.75D)
        return 3; 
      if (f < 1.0F)
        return 4; 
      b = 5;
    } 
    return b;
  }
  
  public final v5 d(String paramString) {
    v5 v52;
    if (paramString == null) {
      v52 = (v5)this.g.poll();
    } else {
      Iterator<v5> iterator = this.g.iterator();
      v52 = null;
      while (iterator.hasNext()) {
        v5 v5 = iterator.next();
        if (Intrinsics.areEqual(v5.d(), paramString))
          v52 = v5; 
      } 
    } 
    v5 v51 = v52;
    if (v51 != null)
      b(v51); 
    return v51;
  }
  
  public final void d() {
    t2 t21 = this.d;
    if (t21 != null) {
      File[] arrayOfFile = t21.d();
      if (arrayOfFile != null) {
        Intrinsics.checkNotNullExpressionValue(arrayOfFile, "files");
        int j = arrayOfFile.length;
        for (int i = 0; i < j; i++) {
          File file = arrayOfFile[i];
          if (file.exists()) {
            String str = file.getName();
            Intrinsics.checkNotNullExpressionValue(str, "file.name");
            if (StringsKt.contains$default(str, ".tmp", false, 2, null)) {
              t21.a(file);
              return;
            } 
          } 
          x5 x51 = this.b;
          Intrinsics.checkNotNullExpressionValue(file, "file");
          if (x51.a(file)) {
            t21.a(file);
          } else {
            String str2 = file.getName();
            Intrinsics.checkNotNullExpressionValue(str2, "file.name");
            v5 v5 = new v5("", str2, file, t21.c(), file.lastModified(), null, file.length(), 32, null);
            ConcurrentHashMap<String, v5> concurrentHashMap = this.j;
            String str1 = file.getName();
            Intrinsics.checkNotNullExpressionValue(str1, "file.name");
            concurrentHashMap.put(str1, v5);
          } 
        } 
      } 
    } 
  }
  
  public final File e(String paramString) {
    t2 t21 = this.d;
    if (t21 != null) {
      File file1 = t21.c();
      File file2 = t21.a(file1, paramString);
      return (file2 != null && file2.exists()) ? file2 : this.e.a(file1, paramString);
    } 
    return null;
  }
  
  public final List<v5> e() {
    Collection<v5> collection = this.j.values();
    Intrinsics.checkNotNullExpressionValue(collection, "videoMap.values");
    return CollectionsKt.sortedWith(collection, new b());
  }
  
  public final boolean e(v5 paramv5) {
    if (paramv5 == null)
      return false; 
    if (paramv5.e() == null)
      return false; 
    t2 t21 = this.d;
    return (t21 != null) ? t21.c(paramv5.e()) : false;
  }
  
  public final boolean f(v5 paramv5) {
    return this.e.b(paramv5.b(), paramv5.d());
  }
  
  public final boolean f(String paramString) {
    boolean bool1;
    boolean bool2;
    Intrinsics.checkNotNullParameter(paramString, "videoFilename");
    v5 v5 = c(paramString);
    boolean bool3 = true;
    if (v5 != null && f(v5)) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (v5 != null && e(v5)) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (!bool1) {
      if (bool2)
        return true; 
      bool3 = false;
    } 
    return bool3;
  }
  
  public final boolean g(v5 paramv5) {
    if (paramv5 != null && e(paramv5)) {
      File file = paramv5.e();
      String str = paramv5.d();
      t2 t21 = this.d;
      if (t21 != null && t21.a(file)) {
        this.j.remove(str);
        return true;
      } 
    } 
    return false;
  }
  
  public final void h(v5 paramv5) {
    c6 c6;
    if (!f(paramv5.d())) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Start downloading ");
      stringBuilder1.append(paramv5.g());
      w4.a(stringBuilder1.toString());
      if (this.b.c() == 0L)
        this.b.b(System.currentTimeMillis()); 
      this.b.a();
      this.h.add(paramv5.g());
      b1 b11 = this.c;
      File file = paramv5.e();
      String str1 = paramv5.g();
      f4 f4 = f4.d;
      String str2 = this.a.a();
      Intrinsics.checkNotNullExpressionValue(str2, "networkRequestService.appId");
      c6 = new c6(b11, file, str1, this, f4, str2);
      this.a.a(c6);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("File already downloaded or downloading: ");
    stringBuilder.append(c6.d());
    w4.a(stringBuilder.toString());
    String str = c6.g();
    a a2 = this.i.remove(str);
    if (a2 != null)
      a2.a(str); 
  }
  
  @Metadata(bv = {}, d1 = {"\000\026\n\002\030\002\n\002\020\000\n\002\020\016\n\000\n\002\020\002\n\002\b\002\bæ\001\030\0002\0020\001J\020\020\005\032\0020\0042\006\020\003\032\0020\002H&¨\006\006"}, d2 = {"Lcom/chartboost/sdk/impl/b6$a;", "", "", "url", "", "a", "Chartboost-9.1.1_productionRelease"}, k = 1, mv = {1, 6, 0})
  public static interface a {
    void a(String param1String);
  }
  
  @Metadata(d1 = {"\000\n\n\000\n\002\020\b\n\002\b\007\020\000\032\0020\001\"\004\b\000\020\0022\016\020\003\032\n \004*\004\030\001H\002H\0022\016\020\005\032\n \004*\004\030\001H\002H\002H\n¢\006\004\b\006\020\007¨\006\b"}, d2 = {"<anonymous>", "", "T", "a", "kotlin.jvm.PlatformType", "b", "compare", "(Ljava/lang/Object;Ljava/lang/Object;)I", "kotlin/comparisons/ComparisonsKt__ComparisonsKt$compareBy$2"}, k = 3, mv = {1, 6, 0}, xi = 48)
  public static final class b<T> implements Comparator {
    public final int compare(T param1T1, T param1T2) {
      return ComparisonsKt.compareValues(Long.valueOf(((v5)param1T1).a()), Long.valueOf(((v5)param1T2).a()));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\b6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */