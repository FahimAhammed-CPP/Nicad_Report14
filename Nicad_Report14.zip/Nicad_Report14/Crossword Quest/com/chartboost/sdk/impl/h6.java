package com.chartboost.sdk.impl;

import org.json.JSONException;
import org.json.JSONObject;

public class h6 {
  public void a(String paramString, a parama) {
    if (a(paramString)) {
      m3.b("Chartboost", "CORS policy: No 'Access-Control-Allow-Origin' header is present on the requested resource");
      JSONObject jSONObject = new JSONObject();
      try {
        jSONObject.put("message", "CORS policy: No 'Access-Control-Allow-Origin' header is present on the requested resource");
      } catch (JSONException jSONException) {
        jSONException.printStackTrace();
      } 
      if (parama != null)
        parama.a(jSONObject); 
    } 
  }
  
  public final boolean a(String paramString) {
    return (paramString != null && !paramString.isEmpty() && paramString.contains("Access-Control-Allow-Origin") && paramString.contains("'null'"));
  }
  
  public static interface a {
    void a(JSONObject param1JSONObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\h6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */