package com.chartboost.sdk.impl;

import java.util.ArrayList;
import org.json.JSONException;
import org.json.JSONObject;

public class w3 extends k {
  public d3 w;
  
  public w3(d3 paramd3, JSONObject paramJSONObject) throws JSONException {
    this.w = paramd3;
    x3 x3 = y3.b(paramJSONObject);
    this.v = x3;
    p0 p0 = b(c(x3.d()).b());
    p2 p2 = p0.b();
    a(this.v.a());
    this.b.put("body", this.u);
    this.h = this.v.c();
    this.g = "";
    this.r = p2.c();
    this.e = p2.a();
    this.f = p2.b();
    this.i = p2.f();
    this.p.put("imptrackers", p2.d());
    a(p0);
    this.j = b();
  }
  
  public final void a(p0 paramp0) {
    String str1;
    String str2 = c();
    if (this.w.equals(d3.c)) {
      str1 = "true";
    } else {
      str1 = "false";
    } 
    this.c.put("{% encoding %}", "base64");
    this.c.put("{% adm %}", paramp0.a());
    this.c.put("{{ ad_type }}", str2);
    this.c.put("{{ show_close_button }}", str1);
    this.c.put("{{ preroll_popup }}", "false");
    this.c.put("{{ post_video_reward_toaster_enabled }}", "false");
    if (this.w.equals(d3.e))
      this.c.put("{% is_banner %}", "true"); 
  }
  
  public final void a(ArrayList<g0> paramArrayList) {
    if (!paramArrayList.isEmpty()) {
      this.u = paramArrayList.get(0);
      return;
    } 
    this.u = new g0("", "", "");
  }
  
  public final p0 b(ArrayList<p0> paramArrayList) {
    p0 p0 = new p0();
    if (!paramArrayList.isEmpty())
      p0 = paramArrayList.get(0); 
    return p0;
  }
  
  public final b5 c(ArrayList<b5> paramArrayList) {
    b5 b5 = new b5();
    if (!paramArrayList.isEmpty())
      b5 = paramArrayList.get(0); 
    return b5;
  }
  
  public final String c() {
    int i = a.a[this.w.ordinal()];
    return (i != 1) ? ((i != 2) ? ((i != 3) ? "" : "9") : "8") : "10";
  }
  
  public x3 d() {
    return this.v;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\w3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */