package com.chartboost.sdk.ads;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import androidx.core.os.HandlerCompat;
import com.chartboost.sdk.Chartboost;
import com.chartboost.sdk.Mediation;
import com.chartboost.sdk.callbacks.InterstitialCallback;
import com.chartboost.sdk.events.CacheError;
import com.chartboost.sdk.events.CacheEvent;
import com.chartboost.sdk.events.ShowError;
import com.chartboost.sdk.events.ShowEvent;
import com.chartboost.sdk.impl.e;
import com.chartboost.sdk.impl.j3;
import com.chartboost.sdk.internal.Model.CBError;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

@Metadata(bv = {}, d1 = {"\000>\n\002\030\002\n\002\030\002\n\002\020\013\n\000\n\002\020\002\n\002\b\002\n\002\020\016\n\002\b\b\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\030\0002\0020\001B#\022\006\020\f\032\0020\007\022\006\020\021\032\0020\020\022\n\b\002\020\024\032\004\030\0010\023¢\006\004\b\037\020 J\020\020\005\032\0020\0042\006\020\003\032\0020\002H\002J\b\020\006\032\0020\004H\026J\022\020\006\032\0020\0042\b\020\b\032\004\030\0010\007H\026J\b\020\t\032\0020\004H\026J\b\020\n\032\0020\004H\026J\b\020\013\032\0020\002H\026R\032\020\f\032\0020\0078\026X\004¢\006\f\n\004\b\f\020\r\032\004\b\016\020\017R\024\020\021\032\0020\0208\002X\004¢\006\006\n\004\b\021\020\022R\026\020\024\032\004\030\0010\0238\002X\004¢\006\006\n\004\b\024\020\025R\033\020\033\032\0020\0268BX\002¢\006\f\n\004\b\027\020\030\032\004\b\031\020\032R\024\020\035\032\0020\0348\002X\004¢\006\006\n\004\b\035\020\036¨\006!"}, d2 = {"Lcom/chartboost/sdk/ads/Interstitial;", "Lcom/chartboost/sdk/ads/Ad;", "", "isCache", "", "postSessionNotStartedInMainThread", "cache", "", "bidResponse", "show", "clearCache", "isCached", "location", "Ljava/lang/String;", "getLocation", "()Ljava/lang/String;", "Lcom/chartboost/sdk/callbacks/InterstitialCallback;", "callback", "Lcom/chartboost/sdk/callbacks/InterstitialCallback;", "Lcom/chartboost/sdk/Mediation;", "mediation", "Lcom/chartboost/sdk/Mediation;", "Lcom/chartboost/sdk/impl/j3;", "api$delegate", "Lkotlin/Lazy;", "getApi", "()Lcom/chartboost/sdk/impl/j3;", "api", "Landroid/os/Handler;", "mainThreadHandler", "Landroid/os/Handler;", "<init>", "(Ljava/lang/String;Lcom/chartboost/sdk/callbacks/InterstitialCallback;Lcom/chartboost/sdk/Mediation;)V", "Chartboost-9.1.1_productionRelease"}, k = 1, mv = {1, 6, 0})
public final class Interstitial implements Ad {
  private final Lazy api$delegate;
  
  private final InterstitialCallback callback;
  
  private final String location;
  
  private final Handler mainThreadHandler;
  
  private final Mediation mediation;
  
  public Interstitial(String paramString, InterstitialCallback paramInterstitialCallback, Mediation paramMediation) {
    this.location = paramString;
    this.callback = paramInterstitialCallback;
    this.mediation = paramMediation;
    this.api$delegate = LazyKt.lazy(new a(this));
    Handler handler = HandlerCompat.createAsync(Looper.getMainLooper());
    Intrinsics.checkNotNullExpressionValue(handler, "createAsync(Looper.getMainLooper())");
    this.mainThreadHandler = handler;
  }
  
  private final j3 getApi() {
    return (j3)this.api$delegate.getValue();
  }
  
  private final void postSessionNotStartedInMainThread(boolean paramBoolean) {
    try {
      this.mainThreadHandler.post((Runnable)new Interstitial$.ExternalSyntheticLambda0(paramBoolean, this));
      return;
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad cannot post session not started callback ");
      stringBuilder.append(exception);
      Log.e("Chartboost", stringBuilder.toString());
      return;
    } 
  }
  
  private static final void postSessionNotStartedInMainThread$lambda-0(boolean paramBoolean, Interstitial paramInterstitial) {
    Intrinsics.checkNotNullParameter(paramInterstitial, "this$0");
    if (paramBoolean) {
      paramInterstitial.callback.onAdLoaded(new CacheEvent(null, paramInterstitial), new CacheError(CacheError.Code.SESSION_NOT_STARTED, null, 2, null));
      return;
    } 
    paramInterstitial.callback.onAdShown(new ShowEvent(null, paramInterstitial), new ShowError(ShowError.Code.SESSION_NOT_STARTED, null, 2, null));
  }
  
  public void cache() {
    if (!Chartboost.isSdkStarted()) {
      postSessionNotStartedInMainThread(true);
      return;
    } 
    getApi().a(this, this.callback);
  }
  
  public void cache(String paramString) {
    boolean bool1 = Chartboost.isSdkStarted();
    boolean bool = true;
    if (!bool1) {
      postSessionNotStartedInMainThread(true);
      return;
    } 
    if (paramString != null) {
      if (paramString.length() != 0)
        bool = false; 
      if (!bool) {
        getApi().a(this, this.callback, paramString);
        return;
      } 
    } 
    getApi().b("", CBError.CBImpressionError.INVALID_RESPONSE);
  }
  
  public void clearCache() {
    if (Chartboost.isSdkStarted())
      getApi().g(getLocation()); 
  }
  
  public String getLocation() {
    return this.location;
  }
  
  public boolean isCached() {
    return Chartboost.isSdkStarted() ? getApi().h(getLocation()) : false;
  }
  
  public void show() {
    if (!Chartboost.isSdkStarted()) {
      postSessionNotStartedInMainThread(false);
      return;
    } 
    getApi().b(this, this.callback);
  }
  
  @Metadata(bv = {}, d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Lcom/chartboost/sdk/impl/j3;", "a", "()Lcom/chartboost/sdk/impl/j3;"}, k = 3, mv = {1, 6, 0})
  public static final class a extends Lambda implements Function0<j3> {
    public a(Interstitial param1Interstitial) {
      super(0);
    }
    
    public final j3 a() {
      return e.b(this.a.mediation);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\ads\Interstitial.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */