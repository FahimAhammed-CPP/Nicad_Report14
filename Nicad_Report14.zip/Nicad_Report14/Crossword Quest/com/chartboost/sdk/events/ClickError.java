package com.chartboost.sdk.events;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000\034\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\007\030\0002\0020\001:\001\fB!\b\000\022\006\020\002\032\0020\003\022\020\b\002\020\004\032\n\030\0010\005j\004\030\001`\006¢\006\002\020\007R\021\020\002\032\0020\003¢\006\b\n\000\032\004\b\b\020\tR\034\020\004\032\n\030\0010\005j\004\030\001`\006X\004¢\006\b\n\000\032\004\b\n\020\013¨\006\r"}, d2 = {"Lcom/chartboost/sdk/events/ClickError;", "Lcom/chartboost/sdk/events/CBError;", "code", "Lcom/chartboost/sdk/events/ClickError$Code;", "exception", "Ljava/lang/Exception;", "Lkotlin/Exception;", "(Lcom/chartboost/sdk/events/ClickError$Code;Ljava/lang/Exception;)V", "getCode", "()Lcom/chartboost/sdk/events/ClickError$Code;", "getException", "()Ljava/lang/Exception;", "Code", "Chartboost-9.1.1_productionRelease"}, k = 1, mv = {1, 6, 0}, xi = 48)
public final class ClickError implements CBError {
  private final Code code;
  
  private final Exception exception;
  
  public ClickError(Code paramCode, Exception paramException) {
    this.code = paramCode;
    this.exception = paramException;
  }
  
  public final Code getCode() {
    return this.code;
  }
  
  public Exception getException() {
    return this.exception;
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\020\n\000\n\002\020\b\n\002\b\007\b\001\030\0002\b\022\004\022\0020\0000\001B\017\b\002\022\006\020\002\032\0020\003¢\006\002\020\004R\021\020\002\032\0020\003¢\006\b\n\000\032\004\b\005\020\006j\002\b\007j\002\b\bj\002\b\t¨\006\n"}, d2 = {"Lcom/chartboost/sdk/events/ClickError$Code;", "", "errorCode", "", "(Ljava/lang/String;II)V", "getErrorCode", "()I", "INTERNAL", "URI_INVALID", "URI_UNRECOGNIZED", "Chartboost-9.1.1_productionRelease"}, k = 1, mv = {1, 6, 0}, xi = 48)
  public enum Code {
    INTERNAL(0),
    URI_INVALID(1),
    URI_UNRECOGNIZED(2);
    
    private final int errorCode;
    
    static {
    
    }
    
    Code(int param1Int1) {
      this.errorCode = param1Int1;
    }
    
    public final int getErrorCode() {
      return this.errorCode;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\events\ClickError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */