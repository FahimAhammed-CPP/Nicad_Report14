package com.bumptech.glide.disklrucache;

import android.os.Build;
import android.os.StrictMode;
import com.safedk.android.internal.partials.GlideFilesBridge;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.Writer;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public final class DiskLruCache implements Closeable {
  static final long ANY_SEQUENCE_NUMBER = -1L;
  
  private static final String CLEAN = "CLEAN";
  
  private static final String DIRTY = "DIRTY";
  
  static final String JOURNAL_FILE = "journal";
  
  static final String JOURNAL_FILE_BACKUP = "journal.bkp";
  
  static final String JOURNAL_FILE_TEMP = "journal.tmp";
  
  static final String MAGIC = "libcore.io.DiskLruCache";
  
  private static final String READ = "READ";
  
  private static final String REMOVE = "REMOVE";
  
  static final String VERSION_1 = "1";
  
  private final int appVersion;
  
  private final Callable<Void> cleanupCallable = new Callable<Void>() {
      public Void call() throws Exception {
        synchronized (DiskLruCache.this) {
          if (DiskLruCache.this.journalWriter == null)
            return null; 
          DiskLruCache.this.trimToSize();
          if (DiskLruCache.this.journalRebuildRequired()) {
            DiskLruCache.this.rebuildJournal();
            DiskLruCache.access$502(DiskLruCache.this, 0);
          } 
          return null;
        } 
      }
    };
  
  private final File directory;
  
  final ThreadPoolExecutor executorService = new ThreadPoolExecutor(0, 1, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>(), new DiskLruCacheThreadFactory());
  
  private final File journalFile;
  
  private final File journalFileBackup;
  
  private final File journalFileTmp;
  
  private Writer journalWriter;
  
  private final LinkedHashMap<String, Entry> lruEntries = new LinkedHashMap<String, Entry>(0, 0.75F, true);
  
  private long maxSize;
  
  private long nextSequenceNumber = 0L;
  
  private int redundantOpCount;
  
  private long size = 0L;
  
  private final int valueCount;
  
  private DiskLruCache(File paramFile, int paramInt1, int paramInt2, long paramLong) {
    this.directory = paramFile;
    this.appVersion = paramInt1;
    this.journalFile = new File(paramFile, "journal");
    this.journalFileTmp = new File(paramFile, "journal.tmp");
    this.journalFileBackup = new File(paramFile, "journal.bkp");
    this.valueCount = paramInt2;
    this.maxSize = paramLong;
  }
  
  private void checkNotClosed() {
    if (this.journalWriter != null)
      return; 
    throw new IllegalStateException("cache is closed");
  }
  
  private static void closeWriter(Writer paramWriter) throws IOException {
    if (Build.VERSION.SDK_INT < 26) {
      paramWriter.close();
      return;
    } 
    StrictMode.ThreadPolicy threadPolicy = StrictMode.getThreadPolicy();
    StrictMode.setThreadPolicy((new StrictMode.ThreadPolicy.Builder(threadPolicy)).permitUnbufferedIo().build());
    try {
      paramWriter.close();
      return;
    } finally {
      StrictMode.setThreadPolicy(threadPolicy);
    } 
  }
  
  private void completeEdit(Editor paramEditor, boolean paramBoolean) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokestatic access$1500 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Editor;)Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;
    //   6: astore #10
    //   8: aload #10
    //   10: invokestatic access$800 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)Lcom/bumptech/glide/disklrucache/DiskLruCache$Editor;
    //   13: aload_1
    //   14: if_acmpne -> 437
    //   17: iconst_0
    //   18: istore #5
    //   20: iload #5
    //   22: istore #4
    //   24: iload_2
    //   25: ifeq -> 126
    //   28: iload #5
    //   30: istore #4
    //   32: aload #10
    //   34: invokestatic access$700 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)Z
    //   37: ifne -> 126
    //   40: iconst_0
    //   41: istore_3
    //   42: iload #5
    //   44: istore #4
    //   46: iload_3
    //   47: aload_0
    //   48: getfield valueCount : I
    //   51: if_icmpge -> 126
    //   54: aload_1
    //   55: invokestatic access$1600 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Editor;)[Z
    //   58: iload_3
    //   59: baload
    //   60: ifeq -> 89
    //   63: aload #10
    //   65: iload_3
    //   66: invokevirtual getDirtyFile : (I)Ljava/io/File;
    //   69: invokevirtual exists : ()Z
    //   72: ifne -> 82
    //   75: aload_1
    //   76: invokevirtual abort : ()V
    //   79: aload_0
    //   80: monitorexit
    //   81: return
    //   82: iload_3
    //   83: iconst_1
    //   84: iadd
    //   85: istore_3
    //   86: goto -> 42
    //   89: aload_1
    //   90: invokevirtual abort : ()V
    //   93: new java/lang/StringBuilder
    //   96: dup
    //   97: invokespecial <init> : ()V
    //   100: astore_1
    //   101: aload_1
    //   102: ldc 'Newly created entry didn't create value for index '
    //   104: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   107: pop
    //   108: aload_1
    //   109: iload_3
    //   110: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   113: pop
    //   114: new java/lang/IllegalStateException
    //   117: dup
    //   118: aload_1
    //   119: invokevirtual toString : ()Ljava/lang/String;
    //   122: invokespecial <init> : (Ljava/lang/String;)V
    //   125: athrow
    //   126: iload #4
    //   128: aload_0
    //   129: getfield valueCount : I
    //   132: if_icmpge -> 221
    //   135: aload #10
    //   137: iload #4
    //   139: invokevirtual getDirtyFile : (I)Ljava/io/File;
    //   142: astore_1
    //   143: iload_2
    //   144: ifeq -> 214
    //   147: aload_1
    //   148: invokevirtual exists : ()Z
    //   151: ifeq -> 456
    //   154: aload #10
    //   156: iload #4
    //   158: invokevirtual getCleanFile : (I)Ljava/io/File;
    //   161: astore #11
    //   163: aload_1
    //   164: aload #11
    //   166: invokevirtual renameTo : (Ljava/io/File;)Z
    //   169: pop
    //   170: aload #10
    //   172: invokestatic access$1100 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)[J
    //   175: iload #4
    //   177: laload
    //   178: lstore #6
    //   180: aload #11
    //   182: invokevirtual length : ()J
    //   185: lstore #8
    //   187: aload #10
    //   189: invokestatic access$1100 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)[J
    //   192: iload #4
    //   194: lload #8
    //   196: lastore
    //   197: aload_0
    //   198: aload_0
    //   199: getfield size : J
    //   202: lload #6
    //   204: lsub
    //   205: lload #8
    //   207: ladd
    //   208: putfield size : J
    //   211: goto -> 456
    //   214: aload_1
    //   215: invokestatic deleteIfExists : (Ljava/io/File;)V
    //   218: goto -> 456
    //   221: aload_0
    //   222: aload_0
    //   223: getfield redundantOpCount : I
    //   226: iconst_1
    //   227: iadd
    //   228: putfield redundantOpCount : I
    //   231: aload #10
    //   233: aconst_null
    //   234: invokestatic access$802 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;Lcom/bumptech/glide/disklrucache/DiskLruCache$Editor;)Lcom/bumptech/glide/disklrucache/DiskLruCache$Editor;
    //   237: pop
    //   238: aload #10
    //   240: invokestatic access$700 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)Z
    //   243: iload_2
    //   244: ior
    //   245: ifeq -> 340
    //   248: aload #10
    //   250: iconst_1
    //   251: invokestatic access$702 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;Z)Z
    //   254: pop
    //   255: aload_0
    //   256: getfield journalWriter : Ljava/io/Writer;
    //   259: ldc 'CLEAN'
    //   261: invokevirtual append : (Ljava/lang/CharSequence;)Ljava/io/Writer;
    //   264: pop
    //   265: aload_0
    //   266: getfield journalWriter : Ljava/io/Writer;
    //   269: bipush #32
    //   271: invokevirtual append : (C)Ljava/io/Writer;
    //   274: pop
    //   275: aload_0
    //   276: getfield journalWriter : Ljava/io/Writer;
    //   279: aload #10
    //   281: invokestatic access$1200 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)Ljava/lang/String;
    //   284: invokevirtual append : (Ljava/lang/CharSequence;)Ljava/io/Writer;
    //   287: pop
    //   288: aload_0
    //   289: getfield journalWriter : Ljava/io/Writer;
    //   292: aload #10
    //   294: invokevirtual getLengths : ()Ljava/lang/String;
    //   297: invokevirtual append : (Ljava/lang/CharSequence;)Ljava/io/Writer;
    //   300: pop
    //   301: aload_0
    //   302: getfield journalWriter : Ljava/io/Writer;
    //   305: bipush #10
    //   307: invokevirtual append : (C)Ljava/io/Writer;
    //   310: pop
    //   311: iload_2
    //   312: ifeq -> 396
    //   315: aload_0
    //   316: getfield nextSequenceNumber : J
    //   319: lstore #6
    //   321: aload_0
    //   322: lconst_1
    //   323: lload #6
    //   325: ladd
    //   326: putfield nextSequenceNumber : J
    //   329: aload #10
    //   331: lload #6
    //   333: invokestatic access$1302 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;J)J
    //   336: pop2
    //   337: goto -> 396
    //   340: aload_0
    //   341: getfield lruEntries : Ljava/util/LinkedHashMap;
    //   344: aload #10
    //   346: invokestatic access$1200 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)Ljava/lang/String;
    //   349: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   352: pop
    //   353: aload_0
    //   354: getfield journalWriter : Ljava/io/Writer;
    //   357: ldc 'REMOVE'
    //   359: invokevirtual append : (Ljava/lang/CharSequence;)Ljava/io/Writer;
    //   362: pop
    //   363: aload_0
    //   364: getfield journalWriter : Ljava/io/Writer;
    //   367: bipush #32
    //   369: invokevirtual append : (C)Ljava/io/Writer;
    //   372: pop
    //   373: aload_0
    //   374: getfield journalWriter : Ljava/io/Writer;
    //   377: aload #10
    //   379: invokestatic access$1200 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)Ljava/lang/String;
    //   382: invokevirtual append : (Ljava/lang/CharSequence;)Ljava/io/Writer;
    //   385: pop
    //   386: aload_0
    //   387: getfield journalWriter : Ljava/io/Writer;
    //   390: bipush #10
    //   392: invokevirtual append : (C)Ljava/io/Writer;
    //   395: pop
    //   396: aload_0
    //   397: getfield journalWriter : Ljava/io/Writer;
    //   400: invokestatic flushWriter : (Ljava/io/Writer;)V
    //   403: aload_0
    //   404: getfield size : J
    //   407: aload_0
    //   408: getfield maxSize : J
    //   411: lcmp
    //   412: ifgt -> 422
    //   415: aload_0
    //   416: invokespecial journalRebuildRequired : ()Z
    //   419: ifeq -> 434
    //   422: aload_0
    //   423: getfield executorService : Ljava/util/concurrent/ThreadPoolExecutor;
    //   426: aload_0
    //   427: getfield cleanupCallable : Ljava/util/concurrent/Callable;
    //   430: invokevirtual submit : (Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;
    //   433: pop
    //   434: aload_0
    //   435: monitorexit
    //   436: return
    //   437: new java/lang/IllegalStateException
    //   440: dup
    //   441: invokespecial <init> : ()V
    //   444: athrow
    //   445: astore_1
    //   446: aload_0
    //   447: monitorexit
    //   448: goto -> 453
    //   451: aload_1
    //   452: athrow
    //   453: goto -> 451
    //   456: iload #4
    //   458: iconst_1
    //   459: iadd
    //   460: istore #4
    //   462: goto -> 126
    // Exception table:
    //   from	to	target	type
    //   2	17	445	finally
    //   32	40	445	finally
    //   46	79	445	finally
    //   89	126	445	finally
    //   126	143	445	finally
    //   147	211	445	finally
    //   214	218	445	finally
    //   221	311	445	finally
    //   315	337	445	finally
    //   340	396	445	finally
    //   396	422	445	finally
    //   422	434	445	finally
    //   437	445	445	finally
  }
  
  private static void deleteIfExists(File paramFile) throws IOException {
    if (paramFile.exists()) {
      if (paramFile.delete())
        return; 
      throw new IOException();
    } 
  }
  
  private Editor edit(String paramString, long paramLong) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial checkNotClosed : ()V
    //   6: aload_0
    //   7: getfield lruEntries : Ljava/util/LinkedHashMap;
    //   10: aload_1
    //   11: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   14: checkcast com/bumptech/glide/disklrucache/DiskLruCache$Entry
    //   17: astore #6
    //   19: lload_2
    //   20: ldc2_w -1
    //   23: lcmp
    //   24: ifeq -> 50
    //   27: aload #6
    //   29: ifnull -> 46
    //   32: aload #6
    //   34: invokestatic access$1300 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)J
    //   37: lstore #4
    //   39: lload #4
    //   41: lload_2
    //   42: lcmp
    //   43: ifeq -> 50
    //   46: aload_0
    //   47: monitorexit
    //   48: aconst_null
    //   49: areturn
    //   50: aload #6
    //   52: ifnonnull -> 81
    //   55: new com/bumptech/glide/disklrucache/DiskLruCache$Entry
    //   58: dup
    //   59: aload_0
    //   60: aload_1
    //   61: aconst_null
    //   62: invokespecial <init> : (Lcom/bumptech/glide/disklrucache/DiskLruCache;Ljava/lang/String;Lcom/bumptech/glide/disklrucache/DiskLruCache$1;)V
    //   65: astore #6
    //   67: aload_0
    //   68: getfield lruEntries : Ljava/util/LinkedHashMap;
    //   71: aload_1
    //   72: aload #6
    //   74: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   77: pop
    //   78: goto -> 97
    //   81: aload #6
    //   83: invokestatic access$800 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)Lcom/bumptech/glide/disklrucache/DiskLruCache$Editor;
    //   86: astore #7
    //   88: aload #7
    //   90: ifnull -> 97
    //   93: aload_0
    //   94: monitorexit
    //   95: aconst_null
    //   96: areturn
    //   97: new com/bumptech/glide/disklrucache/DiskLruCache$Editor
    //   100: dup
    //   101: aload_0
    //   102: aload #6
    //   104: aconst_null
    //   105: invokespecial <init> : (Lcom/bumptech/glide/disklrucache/DiskLruCache;Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;Lcom/bumptech/glide/disklrucache/DiskLruCache$1;)V
    //   108: astore #7
    //   110: aload #6
    //   112: aload #7
    //   114: invokestatic access$802 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;Lcom/bumptech/glide/disklrucache/DiskLruCache$Editor;)Lcom/bumptech/glide/disklrucache/DiskLruCache$Editor;
    //   117: pop
    //   118: aload_0
    //   119: getfield journalWriter : Ljava/io/Writer;
    //   122: ldc 'DIRTY'
    //   124: invokevirtual append : (Ljava/lang/CharSequence;)Ljava/io/Writer;
    //   127: pop
    //   128: aload_0
    //   129: getfield journalWriter : Ljava/io/Writer;
    //   132: bipush #32
    //   134: invokevirtual append : (C)Ljava/io/Writer;
    //   137: pop
    //   138: aload_0
    //   139: getfield journalWriter : Ljava/io/Writer;
    //   142: aload_1
    //   143: invokevirtual append : (Ljava/lang/CharSequence;)Ljava/io/Writer;
    //   146: pop
    //   147: aload_0
    //   148: getfield journalWriter : Ljava/io/Writer;
    //   151: bipush #10
    //   153: invokevirtual append : (C)Ljava/io/Writer;
    //   156: pop
    //   157: aload_0
    //   158: getfield journalWriter : Ljava/io/Writer;
    //   161: invokestatic flushWriter : (Ljava/io/Writer;)V
    //   164: aload_0
    //   165: monitorexit
    //   166: aload #7
    //   168: areturn
    //   169: astore_1
    //   170: aload_0
    //   171: monitorexit
    //   172: aload_1
    //   173: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	169	finally
    //   32	39	169	finally
    //   55	78	169	finally
    //   81	88	169	finally
    //   97	164	169	finally
  }
  
  private static void flushWriter(Writer paramWriter) throws IOException {
    if (Build.VERSION.SDK_INT < 26) {
      paramWriter.flush();
      return;
    } 
    StrictMode.ThreadPolicy threadPolicy = StrictMode.getThreadPolicy();
    StrictMode.setThreadPolicy((new StrictMode.ThreadPolicy.Builder(threadPolicy)).permitUnbufferedIo().build());
    try {
      paramWriter.flush();
      return;
    } finally {
      StrictMode.setThreadPolicy(threadPolicy);
    } 
  }
  
  private static String inputStreamToString(InputStream paramInputStream) throws IOException {
    return Util.readFully(new InputStreamReader(paramInputStream, Util.UTF_8));
  }
  
  private boolean journalRebuildRequired() {
    int i = this.redundantOpCount;
    return (i >= 2000 && i >= this.lruEntries.size());
  }
  
  public static DiskLruCache open(File paramFile, int paramInt1, int paramInt2, long paramLong) throws IOException {
    if (paramLong > 0L) {
      if (paramInt2 > 0) {
        File file = new File(paramFile, "journal.bkp");
        if (file.exists()) {
          File file1 = new File(paramFile, "journal");
          if (file1.exists()) {
            file.delete();
          } else {
            renameTo(file, file1, false);
          } 
        } 
        DiskLruCache diskLruCache2 = new DiskLruCache(paramFile, paramInt1, paramInt2, paramLong);
        if (diskLruCache2.journalFile.exists())
          try {
            diskLruCache2.readJournal();
            diskLruCache2.processJournal();
            return diskLruCache2;
          } catch (IOException iOException) {
            PrintStream printStream = System.out;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("DiskLruCache ");
            stringBuilder.append(paramFile);
            stringBuilder.append(" is corrupt: ");
            stringBuilder.append(iOException.getMessage());
            stringBuilder.append(", removing");
            printStream.println(stringBuilder.toString());
            diskLruCache2.delete();
          }  
        paramFile.mkdirs();
        DiskLruCache diskLruCache1 = new DiskLruCache(paramFile, paramInt1, paramInt2, paramLong);
        diskLruCache1.rebuildJournal();
        return diskLruCache1;
      } 
      throw new IllegalArgumentException("valueCount <= 0");
    } 
    throw new IllegalArgumentException("maxSize <= 0");
  }
  
  private void processJournal() throws IOException {
    deleteIfExists(this.journalFileTmp);
    Iterator<Entry> iterator = this.lruEntries.values().iterator();
    while (iterator.hasNext()) {
      Entry entry = iterator.next();
      Editor editor = entry.currentEditor;
      boolean bool = false;
      int i = 0;
      if (editor == null) {
        while (i < this.valueCount) {
          this.size += entry.lengths[i];
          i++;
        } 
        continue;
      } 
      Entry.access$802(entry, null);
      for (i = bool; i < this.valueCount; i++) {
        deleteIfExists(entry.getCleanFile(i));
        deleteIfExists(entry.getDirtyFile(i));
      } 
      iterator.remove();
    } 
  }
  
  private void readJournal() throws IOException {
    StrictLineReader strictLineReader = new StrictLineReader(new FileInputStream(this.journalFile), Util.US_ASCII);
    try {
      String str1 = strictLineReader.readLine();
      String str2 = strictLineReader.readLine();
      String str5 = strictLineReader.readLine();
      String str3 = strictLineReader.readLine();
      String str4 = strictLineReader.readLine();
      if ("libcore.io.DiskLruCache".equals(str1) && "1".equals(str2) && Integer.toString(this.appVersion).equals(str5) && Integer.toString(this.valueCount).equals(str3)) {
        boolean bool = "".equals(str4);
        if (bool) {
          int i = 0;
          try {
            while (true) {
              readJournalLine(strictLineReader.readLine());
              i++;
            } 
          } catch (EOFException eOFException) {
            this.redundantOpCount = i - this.lruEntries.size();
            if (strictLineReader.hasUnterminatedLine()) {
              rebuildJournal();
            } else {
              this.journalWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(this.journalFile, true), Util.US_ASCII));
            } 
            return;
          } 
        } 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("unexpected journal header: [");
      stringBuilder.append((String)eOFException);
      stringBuilder.append(", ");
      stringBuilder.append(str2);
      stringBuilder.append(", ");
      stringBuilder.append(str3);
      stringBuilder.append(", ");
      stringBuilder.append(str4);
      stringBuilder.append("]");
      throw new IOException(stringBuilder.toString());
    } finally {
      Util.closeQuietly((Closeable)strictLineReader);
    } 
  }
  
  private void readJournalLine(String paramString) throws IOException {
    String[] arrayOfString;
    int i = paramString.indexOf(' ');
    if (i != -1) {
      String str;
      int j = i + 1;
      int k = paramString.indexOf(' ', j);
      if (k == -1) {
        String str1 = paramString.substring(j);
        str = str1;
        if (i == 6) {
          str = str1;
          if (paramString.startsWith("REMOVE")) {
            this.lruEntries.remove(str1);
            return;
          } 
        } 
      } else {
        str = paramString.substring(j, k);
      } 
      Entry entry2 = this.lruEntries.get(str);
      Entry entry1 = entry2;
      if (entry2 == null) {
        entry1 = new Entry(str);
        this.lruEntries.put(str, entry1);
      } 
      if (k != -1 && i == 5 && paramString.startsWith("CLEAN")) {
        arrayOfString = paramString.substring(k + 1).split(" ");
        Entry.access$702(entry1, true);
        Entry.access$802(entry1, null);
        entry1.setLengths(arrayOfString);
        return;
      } 
      if (k == -1 && i == 5 && arrayOfString.startsWith("DIRTY")) {
        Entry.access$802(entry1, new Editor(entry1));
        return;
      } 
      if (k == -1 && i == 4 && arrayOfString.startsWith("READ"))
        return; 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("unexpected journal line: ");
      stringBuilder1.append((String)arrayOfString);
      throw new IOException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("unexpected journal line: ");
    stringBuilder.append((String)arrayOfString);
    throw new IOException(stringBuilder.toString());
  }
  
  private void rebuildJournal() throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield journalWriter : Ljava/io/Writer;
    //   6: astore_1
    //   7: aload_1
    //   8: ifnull -> 15
    //   11: aload_1
    //   12: invokestatic closeWriter : (Ljava/io/Writer;)V
    //   15: new java/io/BufferedWriter
    //   18: dup
    //   19: new java/io/OutputStreamWriter
    //   22: dup
    //   23: aload_0
    //   24: getfield journalFileTmp : Ljava/io/File;
    //   27: invokestatic fileOutputStreamCtor : (Ljava/io/File;)Ljava/io/FileOutputStream;
    //   30: getstatic com/bumptech/glide/disklrucache/Util.US_ASCII : Ljava/nio/charset/Charset;
    //   33: invokespecial <init> : (Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V
    //   36: invokespecial <init> : (Ljava/io/Writer;)V
    //   39: astore_1
    //   40: aload_1
    //   41: ldc 'libcore.io.DiskLruCache'
    //   43: invokevirtual write : (Ljava/lang/String;)V
    //   46: aload_1
    //   47: ldc_w '\\n'
    //   50: invokevirtual write : (Ljava/lang/String;)V
    //   53: aload_1
    //   54: ldc '1'
    //   56: invokevirtual write : (Ljava/lang/String;)V
    //   59: aload_1
    //   60: ldc_w '\\n'
    //   63: invokevirtual write : (Ljava/lang/String;)V
    //   66: aload_1
    //   67: aload_0
    //   68: getfield appVersion : I
    //   71: invokestatic toString : (I)Ljava/lang/String;
    //   74: invokevirtual write : (Ljava/lang/String;)V
    //   77: aload_1
    //   78: ldc_w '\\n'
    //   81: invokevirtual write : (Ljava/lang/String;)V
    //   84: aload_1
    //   85: aload_0
    //   86: getfield valueCount : I
    //   89: invokestatic toString : (I)Ljava/lang/String;
    //   92: invokevirtual write : (Ljava/lang/String;)V
    //   95: aload_1
    //   96: ldc_w '\\n'
    //   99: invokevirtual write : (Ljava/lang/String;)V
    //   102: aload_1
    //   103: ldc_w '\\n'
    //   106: invokevirtual write : (Ljava/lang/String;)V
    //   109: aload_0
    //   110: getfield lruEntries : Ljava/util/LinkedHashMap;
    //   113: invokevirtual values : ()Ljava/util/Collection;
    //   116: invokeinterface iterator : ()Ljava/util/Iterator;
    //   121: astore_2
    //   122: aload_2
    //   123: invokeinterface hasNext : ()Z
    //   128: ifeq -> 254
    //   131: aload_2
    //   132: invokeinterface next : ()Ljava/lang/Object;
    //   137: checkcast com/bumptech/glide/disklrucache/DiskLruCache$Entry
    //   140: astore_3
    //   141: aload_3
    //   142: invokestatic access$800 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)Lcom/bumptech/glide/disklrucache/DiskLruCache$Editor;
    //   145: ifnull -> 196
    //   148: new java/lang/StringBuilder
    //   151: dup
    //   152: invokespecial <init> : ()V
    //   155: astore #4
    //   157: aload #4
    //   159: ldc_w 'DIRTY '
    //   162: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   165: pop
    //   166: aload #4
    //   168: aload_3
    //   169: invokestatic access$1200 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)Ljava/lang/String;
    //   172: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   175: pop
    //   176: aload #4
    //   178: bipush #10
    //   180: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   183: pop
    //   184: aload_1
    //   185: aload #4
    //   187: invokevirtual toString : ()Ljava/lang/String;
    //   190: invokevirtual write : (Ljava/lang/String;)V
    //   193: goto -> 122
    //   196: new java/lang/StringBuilder
    //   199: dup
    //   200: invokespecial <init> : ()V
    //   203: astore #4
    //   205: aload #4
    //   207: ldc_w 'CLEAN '
    //   210: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   213: pop
    //   214: aload #4
    //   216: aload_3
    //   217: invokestatic access$1200 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)Ljava/lang/String;
    //   220: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   223: pop
    //   224: aload #4
    //   226: aload_3
    //   227: invokevirtual getLengths : ()Ljava/lang/String;
    //   230: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   233: pop
    //   234: aload #4
    //   236: bipush #10
    //   238: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   241: pop
    //   242: aload_1
    //   243: aload #4
    //   245: invokevirtual toString : ()Ljava/lang/String;
    //   248: invokevirtual write : (Ljava/lang/String;)V
    //   251: goto -> 122
    //   254: aload_1
    //   255: invokestatic closeWriter : (Ljava/io/Writer;)V
    //   258: aload_0
    //   259: getfield journalFile : Ljava/io/File;
    //   262: invokevirtual exists : ()Z
    //   265: ifeq -> 280
    //   268: aload_0
    //   269: getfield journalFile : Ljava/io/File;
    //   272: aload_0
    //   273: getfield journalFileBackup : Ljava/io/File;
    //   276: iconst_1
    //   277: invokestatic renameTo : (Ljava/io/File;Ljava/io/File;Z)V
    //   280: aload_0
    //   281: getfield journalFileTmp : Ljava/io/File;
    //   284: aload_0
    //   285: getfield journalFile : Ljava/io/File;
    //   288: iconst_0
    //   289: invokestatic renameTo : (Ljava/io/File;Ljava/io/File;Z)V
    //   292: aload_0
    //   293: getfield journalFileBackup : Ljava/io/File;
    //   296: invokevirtual delete : ()Z
    //   299: pop
    //   300: aload_0
    //   301: new java/io/BufferedWriter
    //   304: dup
    //   305: new java/io/OutputStreamWriter
    //   308: dup
    //   309: new java/io/FileOutputStream
    //   312: dup
    //   313: aload_0
    //   314: getfield journalFile : Ljava/io/File;
    //   317: iconst_1
    //   318: invokespecial <init> : (Ljava/io/File;Z)V
    //   321: getstatic com/bumptech/glide/disklrucache/Util.US_ASCII : Ljava/nio/charset/Charset;
    //   324: invokespecial <init> : (Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V
    //   327: invokespecial <init> : (Ljava/io/Writer;)V
    //   330: putfield journalWriter : Ljava/io/Writer;
    //   333: aload_0
    //   334: monitorexit
    //   335: return
    //   336: astore_2
    //   337: aload_1
    //   338: invokestatic closeWriter : (Ljava/io/Writer;)V
    //   341: aload_2
    //   342: athrow
    //   343: astore_1
    //   344: aload_0
    //   345: monitorexit
    //   346: goto -> 351
    //   349: aload_1
    //   350: athrow
    //   351: goto -> 349
    // Exception table:
    //   from	to	target	type
    //   2	7	343	finally
    //   11	15	343	finally
    //   15	40	343	finally
    //   40	122	336	finally
    //   122	193	336	finally
    //   196	251	336	finally
    //   254	280	343	finally
    //   280	333	343	finally
    //   337	343	343	finally
  }
  
  private static void renameTo(File paramFile1, File paramFile2, boolean paramBoolean) throws IOException {
    if (paramBoolean)
      deleteIfExists(paramFile2); 
    if (paramFile1.renameTo(paramFile2))
      return; 
    throw new IOException();
  }
  
  private void trimToSize() throws IOException {
    while (this.size > this.maxSize)
      remove((String)((Map.Entry)this.lruEntries.entrySet().iterator().next()).getKey()); 
  }
  
  public void close() throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield journalWriter : Ljava/io/Writer;
    //   6: astore_1
    //   7: aload_1
    //   8: ifnonnull -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: new java/util/ArrayList
    //   17: dup
    //   18: aload_0
    //   19: getfield lruEntries : Ljava/util/LinkedHashMap;
    //   22: invokevirtual values : ()Ljava/util/Collection;
    //   25: invokespecial <init> : (Ljava/util/Collection;)V
    //   28: invokevirtual iterator : ()Ljava/util/Iterator;
    //   31: astore_1
    //   32: aload_1
    //   33: invokeinterface hasNext : ()Z
    //   38: ifeq -> 68
    //   41: aload_1
    //   42: invokeinterface next : ()Ljava/lang/Object;
    //   47: checkcast com/bumptech/glide/disklrucache/DiskLruCache$Entry
    //   50: astore_2
    //   51: aload_2
    //   52: invokestatic access$800 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)Lcom/bumptech/glide/disklrucache/DiskLruCache$Editor;
    //   55: ifnull -> 32
    //   58: aload_2
    //   59: invokestatic access$800 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)Lcom/bumptech/glide/disklrucache/DiskLruCache$Editor;
    //   62: invokevirtual abort : ()V
    //   65: goto -> 32
    //   68: aload_0
    //   69: invokespecial trimToSize : ()V
    //   72: aload_0
    //   73: getfield journalWriter : Ljava/io/Writer;
    //   76: invokestatic closeWriter : (Ljava/io/Writer;)V
    //   79: aload_0
    //   80: aconst_null
    //   81: putfield journalWriter : Ljava/io/Writer;
    //   84: aload_0
    //   85: monitorexit
    //   86: return
    //   87: astore_1
    //   88: aload_0
    //   89: monitorexit
    //   90: goto -> 95
    //   93: aload_1
    //   94: athrow
    //   95: goto -> 93
    // Exception table:
    //   from	to	target	type
    //   2	7	87	finally
    //   14	32	87	finally
    //   32	65	87	finally
    //   68	84	87	finally
  }
  
  public void delete() throws IOException {
    close();
    Util.deleteContents(this.directory);
  }
  
  public Editor edit(String paramString) throws IOException {
    return edit(paramString, -1L);
  }
  
  public void flush() throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial checkNotClosed : ()V
    //   6: aload_0
    //   7: invokespecial trimToSize : ()V
    //   10: aload_0
    //   11: getfield journalWriter : Ljava/io/Writer;
    //   14: invokestatic flushWriter : (Ljava/io/Writer;)V
    //   17: aload_0
    //   18: monitorexit
    //   19: return
    //   20: astore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_1
    //   24: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	20	finally
  }
  
  public Value get(String paramString) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial checkNotClosed : ()V
    //   6: aload_0
    //   7: getfield lruEntries : Ljava/util/LinkedHashMap;
    //   10: aload_1
    //   11: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   14: checkcast com/bumptech/glide/disklrucache/DiskLruCache$Entry
    //   17: astore #5
    //   19: aload #5
    //   21: ifnonnull -> 28
    //   24: aload_0
    //   25: monitorexit
    //   26: aconst_null
    //   27: areturn
    //   28: aload #5
    //   30: invokestatic access$700 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)Z
    //   33: istore #4
    //   35: iload #4
    //   37: ifne -> 44
    //   40: aload_0
    //   41: monitorexit
    //   42: aconst_null
    //   43: areturn
    //   44: aload #5
    //   46: getfield cleanFiles : [Ljava/io/File;
    //   49: astore #6
    //   51: aload #6
    //   53: arraylength
    //   54: istore_3
    //   55: iconst_0
    //   56: istore_2
    //   57: iload_2
    //   58: iload_3
    //   59: if_icmpge -> 87
    //   62: aload #6
    //   64: iload_2
    //   65: aaload
    //   66: invokevirtual exists : ()Z
    //   69: istore #4
    //   71: iload #4
    //   73: ifne -> 80
    //   76: aload_0
    //   77: monitorexit
    //   78: aconst_null
    //   79: areturn
    //   80: iload_2
    //   81: iconst_1
    //   82: iadd
    //   83: istore_2
    //   84: goto -> 57
    //   87: aload_0
    //   88: aload_0
    //   89: getfield redundantOpCount : I
    //   92: iconst_1
    //   93: iadd
    //   94: putfield redundantOpCount : I
    //   97: aload_0
    //   98: getfield journalWriter : Ljava/io/Writer;
    //   101: ldc 'READ'
    //   103: invokevirtual append : (Ljava/lang/CharSequence;)Ljava/io/Writer;
    //   106: pop
    //   107: aload_0
    //   108: getfield journalWriter : Ljava/io/Writer;
    //   111: bipush #32
    //   113: invokevirtual append : (C)Ljava/io/Writer;
    //   116: pop
    //   117: aload_0
    //   118: getfield journalWriter : Ljava/io/Writer;
    //   121: aload_1
    //   122: invokevirtual append : (Ljava/lang/CharSequence;)Ljava/io/Writer;
    //   125: pop
    //   126: aload_0
    //   127: getfield journalWriter : Ljava/io/Writer;
    //   130: bipush #10
    //   132: invokevirtual append : (C)Ljava/io/Writer;
    //   135: pop
    //   136: aload_0
    //   137: invokespecial journalRebuildRequired : ()Z
    //   140: ifeq -> 155
    //   143: aload_0
    //   144: getfield executorService : Ljava/util/concurrent/ThreadPoolExecutor;
    //   147: aload_0
    //   148: getfield cleanupCallable : Ljava/util/concurrent/Callable;
    //   151: invokevirtual submit : (Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;
    //   154: pop
    //   155: new com/bumptech/glide/disklrucache/DiskLruCache$Value
    //   158: dup
    //   159: aload_0
    //   160: aload_1
    //   161: aload #5
    //   163: invokestatic access$1300 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)J
    //   166: aload #5
    //   168: getfield cleanFiles : [Ljava/io/File;
    //   171: aload #5
    //   173: invokestatic access$1100 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)[J
    //   176: aconst_null
    //   177: invokespecial <init> : (Lcom/bumptech/glide/disklrucache/DiskLruCache;Ljava/lang/String;J[Ljava/io/File;[JLcom/bumptech/glide/disklrucache/DiskLruCache$1;)V
    //   180: astore_1
    //   181: aload_0
    //   182: monitorexit
    //   183: aload_1
    //   184: areturn
    //   185: astore_1
    //   186: aload_0
    //   187: monitorexit
    //   188: goto -> 193
    //   191: aload_1
    //   192: athrow
    //   193: goto -> 191
    // Exception table:
    //   from	to	target	type
    //   2	19	185	finally
    //   28	35	185	finally
    //   44	55	185	finally
    //   62	71	185	finally
    //   87	155	185	finally
    //   155	181	185	finally
  }
  
  public File getDirectory() {
    return this.directory;
  }
  
  public long getMaxSize() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield maxSize : J
    //   6: lstore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: lload_1
    //   10: lreturn
    //   11: astore_3
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_3
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public boolean isClosed() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield journalWriter : Ljava/io/Writer;
    //   6: astore_2
    //   7: aload_2
    //   8: ifnonnull -> 16
    //   11: iconst_1
    //   12: istore_1
    //   13: goto -> 18
    //   16: iconst_0
    //   17: istore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: iload_1
    //   21: ireturn
    //   22: astore_2
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_2
    //   26: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	22	finally
  }
  
  public boolean remove(String paramString) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial checkNotClosed : ()V
    //   6: aload_0
    //   7: getfield lruEntries : Ljava/util/LinkedHashMap;
    //   10: aload_1
    //   11: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   14: checkcast com/bumptech/glide/disklrucache/DiskLruCache$Entry
    //   17: astore #4
    //   19: iconst_0
    //   20: istore_2
    //   21: aload #4
    //   23: ifnull -> 215
    //   26: aload #4
    //   28: invokestatic access$800 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)Lcom/bumptech/glide/disklrucache/DiskLruCache$Editor;
    //   31: ifnull -> 37
    //   34: goto -> 215
    //   37: iload_2
    //   38: aload_0
    //   39: getfield valueCount : I
    //   42: if_icmpge -> 134
    //   45: aload #4
    //   47: iload_2
    //   48: invokevirtual getCleanFile : (I)Ljava/io/File;
    //   51: astore_3
    //   52: aload_3
    //   53: invokevirtual exists : ()Z
    //   56: ifeq -> 103
    //   59: aload_3
    //   60: invokevirtual delete : ()Z
    //   63: ifeq -> 69
    //   66: goto -> 103
    //   69: new java/lang/StringBuilder
    //   72: dup
    //   73: invokespecial <init> : ()V
    //   76: astore_1
    //   77: aload_1
    //   78: ldc_w 'failed to delete '
    //   81: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   84: pop
    //   85: aload_1
    //   86: aload_3
    //   87: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   90: pop
    //   91: new java/io/IOException
    //   94: dup
    //   95: aload_1
    //   96: invokevirtual toString : ()Ljava/lang/String;
    //   99: invokespecial <init> : (Ljava/lang/String;)V
    //   102: athrow
    //   103: aload_0
    //   104: aload_0
    //   105: getfield size : J
    //   108: aload #4
    //   110: invokestatic access$1100 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)[J
    //   113: iload_2
    //   114: laload
    //   115: lsub
    //   116: putfield size : J
    //   119: aload #4
    //   121: invokestatic access$1100 : (Lcom/bumptech/glide/disklrucache/DiskLruCache$Entry;)[J
    //   124: iload_2
    //   125: lconst_0
    //   126: lastore
    //   127: iload_2
    //   128: iconst_1
    //   129: iadd
    //   130: istore_2
    //   131: goto -> 37
    //   134: aload_0
    //   135: aload_0
    //   136: getfield redundantOpCount : I
    //   139: iconst_1
    //   140: iadd
    //   141: putfield redundantOpCount : I
    //   144: aload_0
    //   145: getfield journalWriter : Ljava/io/Writer;
    //   148: ldc 'REMOVE'
    //   150: invokevirtual append : (Ljava/lang/CharSequence;)Ljava/io/Writer;
    //   153: pop
    //   154: aload_0
    //   155: getfield journalWriter : Ljava/io/Writer;
    //   158: bipush #32
    //   160: invokevirtual append : (C)Ljava/io/Writer;
    //   163: pop
    //   164: aload_0
    //   165: getfield journalWriter : Ljava/io/Writer;
    //   168: aload_1
    //   169: invokevirtual append : (Ljava/lang/CharSequence;)Ljava/io/Writer;
    //   172: pop
    //   173: aload_0
    //   174: getfield journalWriter : Ljava/io/Writer;
    //   177: bipush #10
    //   179: invokevirtual append : (C)Ljava/io/Writer;
    //   182: pop
    //   183: aload_0
    //   184: getfield lruEntries : Ljava/util/LinkedHashMap;
    //   187: aload_1
    //   188: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   191: pop
    //   192: aload_0
    //   193: invokespecial journalRebuildRequired : ()Z
    //   196: ifeq -> 211
    //   199: aload_0
    //   200: getfield executorService : Ljava/util/concurrent/ThreadPoolExecutor;
    //   203: aload_0
    //   204: getfield cleanupCallable : Ljava/util/concurrent/Callable;
    //   207: invokevirtual submit : (Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;
    //   210: pop
    //   211: aload_0
    //   212: monitorexit
    //   213: iconst_1
    //   214: ireturn
    //   215: aload_0
    //   216: monitorexit
    //   217: iconst_0
    //   218: ireturn
    //   219: astore_1
    //   220: aload_0
    //   221: monitorexit
    //   222: goto -> 227
    //   225: aload_1
    //   226: athrow
    //   227: goto -> 225
    // Exception table:
    //   from	to	target	type
    //   2	19	219	finally
    //   26	34	219	finally
    //   37	66	219	finally
    //   69	103	219	finally
    //   103	127	219	finally
    //   134	211	219	finally
  }
  
  public void setMaxSize(long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: lload_1
    //   4: putfield maxSize : J
    //   7: aload_0
    //   8: getfield executorService : Ljava/util/concurrent/ThreadPoolExecutor;
    //   11: aload_0
    //   12: getfield cleanupCallable : Ljava/util/concurrent/Callable;
    //   15: invokevirtual submit : (Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;
    //   18: pop
    //   19: aload_0
    //   20: monitorexit
    //   21: return
    //   22: astore_3
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_3
    //   26: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	22	finally
  }
  
  public long size() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield size : J
    //   6: lstore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: lload_1
    //   10: lreturn
    //   11: astore_3
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_3
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  private static final class DiskLruCacheThreadFactory implements ThreadFactory {
    private DiskLruCacheThreadFactory() {}
    
    public Thread newThread(Runnable param1Runnable) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: new java/lang/Thread
      //   5: dup
      //   6: aload_1
      //   7: ldc 'glide-disk-lru-cache-thread'
      //   9: invokespecial <init> : (Ljava/lang/Runnable;Ljava/lang/String;)V
      //   12: astore_1
      //   13: aload_1
      //   14: iconst_1
      //   15: invokevirtual setPriority : (I)V
      //   18: aload_0
      //   19: monitorexit
      //   20: aload_1
      //   21: areturn
      //   22: astore_1
      //   23: aload_0
      //   24: monitorexit
      //   25: aload_1
      //   26: athrow
      // Exception table:
      //   from	to	target	type
      //   2	18	22	finally
    }
  }
  
  public final class Editor {
    private boolean committed;
    
    private final DiskLruCache.Entry entry;
    
    private final boolean[] written;
    
    private Editor(DiskLruCache.Entry param1Entry) {
      boolean[] arrayOfBoolean;
      this.entry = param1Entry;
      if (param1Entry.readable) {
        DiskLruCache.this = null;
      } else {
        arrayOfBoolean = new boolean[DiskLruCache.this.valueCount];
      } 
      this.written = arrayOfBoolean;
    }
    
    private InputStream newInputStream(int param1Int) throws IOException {
      synchronized (DiskLruCache.this) {
        if (this.entry.currentEditor == this) {
          if (!this.entry.readable)
            return null; 
          try {
            return new FileInputStream(this.entry.getCleanFile(param1Int));
          } catch (FileNotFoundException fileNotFoundException) {
            return null;
          } 
        } 
        throw new IllegalStateException();
      } 
    }
    
    public void abort() throws IOException {
      DiskLruCache.this.completeEdit(this, false);
    }
    
    public void abortUnlessCommitted() {
      if (!this.committed)
        try {
          abort();
          return;
        } catch (IOException iOException) {
          return;
        }  
    }
    
    public void commit() throws IOException {
      DiskLruCache.this.completeEdit(this, true);
      this.committed = true;
    }
    
    public File getFile(int param1Int) throws IOException {
      synchronized (DiskLruCache.this) {
        if (this.entry.currentEditor == this) {
          if (!this.entry.readable)
            this.written[param1Int] = true; 
          File file = this.entry.getDirtyFile(param1Int);
          if (!DiskLruCache.this.directory.exists())
            DiskLruCache.this.directory.mkdirs(); 
          return file;
        } 
        throw new IllegalStateException();
      } 
    }
    
    public String getString(int param1Int) throws IOException {
      InputStream inputStream = newInputStream(param1Int);
      return (inputStream != null) ? DiskLruCache.inputStreamToString(inputStream) : null;
    }
    
    public void set(int param1Int, String param1String) throws IOException {
      Exception exception1;
      Exception exception2;
      Exception exception3 = null;
      try {
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(GlideFilesBridge.fileOutputStreamCtor(getFile(param1Int)), Util.UTF_8);
      } finally {
        exception2 = null;
      } 
      Util.closeQuietly((Closeable)exception1);
      throw exception2;
    }
  }
  
  private final class Entry {
    File[] cleanFiles;
    
    private DiskLruCache.Editor currentEditor;
    
    File[] dirtyFiles;
    
    private final String key;
    
    private final long[] lengths;
    
    private boolean readable;
    
    private long sequenceNumber;
    
    private Entry(String param1String) {
      this.key = param1String;
      this.lengths = new long[DiskLruCache.this.valueCount];
      this.cleanFiles = new File[DiskLruCache.this.valueCount];
      this.dirtyFiles = new File[DiskLruCache.this.valueCount];
      StringBuilder stringBuilder = new StringBuilder(param1String);
      stringBuilder.append('.');
      int j = stringBuilder.length();
      for (int i = 0; i < DiskLruCache.this.valueCount; i++) {
        stringBuilder.append(i);
        this.cleanFiles[i] = new File(DiskLruCache.this.directory, stringBuilder.toString());
        stringBuilder.append(".tmp");
        this.dirtyFiles[i] = new File(DiskLruCache.this.directory, stringBuilder.toString());
        stringBuilder.setLength(j);
      } 
    }
    
    private IOException invalidLengths(String[] param1ArrayOfString) throws IOException {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("unexpected journal line: ");
      stringBuilder.append(Arrays.toString((Object[])param1ArrayOfString));
      throw new IOException(stringBuilder.toString());
    }
    
    private void setLengths(String[] param1ArrayOfString) throws IOException {
      if (param1ArrayOfString.length == DiskLruCache.this.valueCount) {
        int i = 0;
        try {
          while (i < param1ArrayOfString.length) {
            this.lengths[i] = Long.parseLong(param1ArrayOfString[i]);
            i++;
          } 
          return;
        } catch (NumberFormatException numberFormatException) {
          throw invalidLengths(param1ArrayOfString);
        } 
      } 
      IOException iOException = invalidLengths(param1ArrayOfString);
      throw iOException;
    }
    
    public File getCleanFile(int param1Int) {
      return this.cleanFiles[param1Int];
    }
    
    public File getDirtyFile(int param1Int) {
      return this.dirtyFiles[param1Int];
    }
    
    public String getLengths() throws IOException {
      StringBuilder stringBuilder = new StringBuilder();
      for (long l : this.lengths) {
        stringBuilder.append(' ');
        stringBuilder.append(l);
      } 
      return stringBuilder.toString();
    }
  }
  
  public final class Value {
    private final File[] files;
    
    private final String key;
    
    private final long[] lengths;
    
    private final long sequenceNumber;
    
    private Value(String param1String, long param1Long, File[] param1ArrayOfFile, long[] param1ArrayOflong) {
      this.key = param1String;
      this.sequenceNumber = param1Long;
      this.files = param1ArrayOfFile;
      this.lengths = param1ArrayOflong;
    }
    
    public DiskLruCache.Editor edit() throws IOException {
      return DiskLruCache.this.edit(this.key, this.sequenceNumber);
    }
    
    public File getFile(int param1Int) {
      return this.files[param1Int];
    }
    
    public long getLength(int param1Int) {
      return this.lengths[param1Int];
    }
    
    public String getString(int param1Int) throws IOException {
      return DiskLruCache.inputStreamToString(new FileInputStream(this.files[param1Int]));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bumptech\glide\disklrucache\DiskLruCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */