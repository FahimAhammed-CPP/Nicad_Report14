package com.bytedance.sdk.openadsdk.activity;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.bykv.vk.openvk.component.video.api.d.c;
import com.bytedance.sdk.component.adexpress.b.c;
import com.bytedance.sdk.component.g.g;
import com.bytedance.sdk.component.utils.e;
import com.bytedance.sdk.component.utils.l;
import com.bytedance.sdk.component.utils.t;
import com.bytedance.sdk.component.utils.y;
import com.bytedance.sdk.openadsdk.AdSlot;
import com.bytedance.sdk.openadsdk.FilterWord;
import com.bytedance.sdk.openadsdk.IListenerManager;
import com.bytedance.sdk.openadsdk.a.d.c;
import com.bytedance.sdk.openadsdk.api.init.PAGSdk;
import com.bytedance.sdk.openadsdk.c.c;
import com.bytedance.sdk.openadsdk.c.f;
import com.bytedance.sdk.openadsdk.common.TTAdDislikeDialog;
import com.bytedance.sdk.openadsdk.common.TTAdDislikeToast;
import com.bytedance.sdk.openadsdk.component.a.a;
import com.bytedance.sdk.openadsdk.component.a.b;
import com.bytedance.sdk.openadsdk.component.c;
import com.bytedance.sdk.openadsdk.component.d.a;
import com.bytedance.sdk.openadsdk.component.f.a;
import com.bytedance.sdk.openadsdk.component.f.b;
import com.bytedance.sdk.openadsdk.component.g.a;
import com.bytedance.sdk.openadsdk.component.h.a;
import com.bytedance.sdk.openadsdk.component.h.b;
import com.bytedance.sdk.openadsdk.component.h.d;
import com.bytedance.sdk.openadsdk.component.view.ButtonFlash;
import com.bytedance.sdk.openadsdk.component.view.OpenScreenAdBackupView;
import com.bytedance.sdk.openadsdk.component.view.OpenScreenAdExpressView;
import com.bytedance.sdk.openadsdk.component.view.OpenScreenAdVideoExpressView;
import com.bytedance.sdk.openadsdk.component.view.a;
import com.bytedance.sdk.openadsdk.core.b;
import com.bytedance.sdk.openadsdk.core.b.b;
import com.bytedance.sdk.openadsdk.core.m;
import com.bytedance.sdk.openadsdk.core.model.k;
import com.bytedance.sdk.openadsdk.core.model.n;
import com.bytedance.sdk.openadsdk.core.nativeexpress.NativeExpressView;
import com.bytedance.sdk.openadsdk.core.nativeexpress.a.a;
import com.bytedance.sdk.openadsdk.core.nativeexpress.d;
import com.bytedance.sdk.openadsdk.core.nativeexpress.e;
import com.bytedance.sdk.openadsdk.core.p;
import com.bytedance.sdk.openadsdk.core.r;
import com.bytedance.sdk.openadsdk.core.settings.j;
import com.bytedance.sdk.openadsdk.core.video.nativevideo.b;
import com.bytedance.sdk.openadsdk.i.a;
import com.bytedance.sdk.openadsdk.i.a.b;
import com.bytedance.sdk.openadsdk.k.a.e;
import com.bytedance.sdk.openadsdk.l.ab;
import com.bytedance.sdk.openadsdk.l.b;
import com.bytedance.sdk.openadsdk.l.i;
import com.bytedance.sdk.openadsdk.l.y;
import com.bytedance.sdk.openadsdk.l.z;
import com.bytedance.sdk.openadsdk.multipro.aidl.a;
import com.bytedance.sdk.openadsdk.multipro.aidl.a.a;
import com.bytedance.sdk.openadsdk.multipro.b;
import com.com.bytedance.overseas.sdk.a.c;
import com.com.bytedance.overseas.sdk.a.d;
import com.safedk.android.analytics.brandsafety.DetectTouchUtils;
import com.safedk.android.analytics.brandsafety.creatives.CreativeInfoManager;
import com.safedk.android.internal.partials.PangleVideoBridge;
import com.safedk.android.utils.Logger;
import java.io.File;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONException;
import org.json.JSONObject;

public class TTAppOpenAdActivity extends Activity implements y.a {
  private static c h;
  
  private String A;
  
  private n B;
  
  private IListenerManager C;
  
  private c D;
  
  private final c.a E;
  
  private int F;
  
  private int G;
  
  private Double H;
  
  private NativeExpressView I;
  
  private final a J;
  
  private FrameLayout K;
  
  private boolean L;
  
  private final Runnable M;
  
  protected final AtomicBoolean a = new AtomicBoolean(false);
  
  protected final y b = new y(Looper.getMainLooper(), this);
  
  final AtomicBoolean c = new AtomicBoolean(false);
  
  final AtomicBoolean d = new AtomicBoolean(false);
  
  protected boolean e;
  
  TTAdDislikeDialog f;
  
  TTAdDislikeToast g;
  
  private final a i = new a();
  
  private final a j;
  
  private final b k;
  
  private final AtomicBoolean l;
  
  private RelativeLayout m;
  
  private FrameLayout n;
  
  private ImageView o;
  
  private TextView p;
  
  private ButtonFlash q;
  
  private ValueAnimator r;
  
  private d s;
  
  private float t;
  
  private float u;
  
  private ImageView v;
  
  private z w;
  
  private f x;
  
  private boolean y;
  
  private int z;
  
  public TTAppOpenAdActivity() {
    a a1 = new a();
    this.j = a1;
    this.k = new b(a1);
    this.l = new AtomicBoolean(false);
    this.e = false;
    this.w = z.b();
    this.E = new c.a(this) {
        public void a() {
          l.a("TTAppOpenAdActivity", "open_ad", "onTimeOut");
          TTAppOpenAdActivity.a(this.a);
          this.a.finish();
        }
        
        public void a(long param1Long, int param1Int) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("onComplete() called with: l = [");
          stringBuilder.append(param1Long);
          stringBuilder.append("], i = [");
          stringBuilder.append(param1Int);
          stringBuilder.append("]");
          l.a("TTAppOpenAdActivity", "open_ad", stringBuilder.toString());
        }
        
        public void a(long param1Long1, long param1Long2) {
          TTAppOpenAdActivity.b(this.a).a(param1Long1);
          if (!this.a.e && TTAppOpenAdActivity.c(this.a) != null && TTAppOpenAdActivity.c(this.a).b())
            TTAppOpenAdActivity.c(this.a).d(); 
          TTAppOpenAdActivity.d(this.a);
        }
        
        public void b(long param1Long, int param1Int) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("onError() called with: totalPlayTime = [");
          stringBuilder.append(param1Long);
          stringBuilder.append("], percent = [");
          stringBuilder.append(param1Int);
          stringBuilder.append("]");
          l.a("TTAppOpenAdActivity", "open_ad", stringBuilder.toString());
          TTAppOpenAdActivity.a(this.a);
          this.a.finish();
        }
      };
    this.J = new a(this) {
        public void a() {
          l.a("TTAppOpenAdActivity", "open_ad", "onCountDownFinish() called");
          if (b.c()) {
            TTAppOpenAdActivity.a(this.a, "onAdTimeOver");
          } else if (TTAppOpenAdActivity.e(this.a) != null) {
            TTAppOpenAdActivity.e(this.a).d();
          } 
          this.a.finish();
        }
        
        public void a(int param1Int1, int param1Int2) {
          if (TTAppOpenAdActivity.f(this.a) != null && !TTAppOpenAdActivity.f(this.a).q())
            TTAppOpenAdActivity.f(this.a).a(String.valueOf(param1Int1), param1Int2, 0, false); 
        }
        
        public void a(View param1View) {
          this.a.a();
        }
        
        public void b(View param1View) {
          this.a.b();
        }
      };
    this.M = new Runnable(this) {
        public void run() {
          if (TTAppOpenAdActivity.p(this.a).get())
            return; 
          TTAppOpenAdActivity.a(this.a, new f());
          TTAppOpenAdActivity.q(this.a).a(System.currentTimeMillis(), 1.0F);
          TTAppOpenAdActivity.i(this.a).d();
          if (TTAppOpenAdActivity.r(this.a) != null && !TTAppOpenAdActivity.r(this.a).isStarted())
            TTAppOpenAdActivity.r(this.a).start(); 
          TTAppOpenAdActivity.s(this.a);
          View view = this.a.findViewById(16908290);
          JSONObject jSONObject = new JSONObject();
          try {
            byte b;
            String str;
            jSONObject.put("width", view.getWidth());
            jSONObject.put("height", view.getHeight());
            jSONObject.put("alpha", view.getAlpha());
            HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
            hashMap.put("root_view", jSONObject.toString());
            hashMap.put("ad_root", Integer.valueOf(TTAppOpenAdActivity.t(this.a)));
            if (TTAppOpenAdActivity.u(this.a)) {
              str = "video_normal_ad";
            } else {
              str = "image_normal_ad";
            } 
            hashMap.put("openad_creative_type", str);
            if (a.c() == null)
              hashMap.put("appicon_acquirefail", "1"); 
            if (TTAppOpenAdActivity.v(this.a))
              hashMap.put("dynamic_show_type", Integer.valueOf(TTAppOpenAdActivity.f(this.a).getDynamicShowType())); 
            c.a(m.a(), TTAppOpenAdActivity.n(this.a), "open_ad", hashMap, TTAppOpenAdActivity.w(this.a));
            View view1 = this.a.findViewById(16908290);
            n n = TTAppOpenAdActivity.n(this.a);
            if (TTAppOpenAdActivity.v(this.a)) {
              b = TTAppOpenAdActivity.f(this.a).getDynamicShowType();
            } else {
              b = -1;
            } 
            e.a(view1, n, b);
            TTAppOpenAdActivity.p(this.a).set(true);
            return;
          } catch (JSONException jSONException) {
            Log.e("TTAppOpenAdActivity", "run: ", (Throwable)jSONException);
            this.a.finish();
            return;
          } 
        }
      };
  }
  
  private void a(Bitmap paramBitmap) {
    if (paramBitmap != null)
      try {
        BitmapDrawable bitmapDrawable = new BitmapDrawable(m.a().getResources(), paramBitmap);
        return;
      } finally {
        paramBitmap = null;
      }  
  }
  
  private void a(OpenScreenAdBackupView paramOpenScreenAdBackupView) {
    this.m = (RelativeLayout)paramOpenScreenAdBackupView.findViewById(t.e((Context)this, "tt_open_ad_container"));
    this.v = (ImageView)paramOpenScreenAdBackupView.findViewById(t.e((Context)this, "tt_open_ad_back_image"));
    this.n = (FrameLayout)paramOpenScreenAdBackupView.findViewById(t.e((Context)this, "tt_open_ad_video_container"));
    this.o = (ImageView)paramOpenScreenAdBackupView.findViewById(t.e((Context)this, "tt_open_ad_image"));
    this.q = (ButtonFlash)paramOpenScreenAdBackupView.findViewById(t.e((Context)this, "tt_open_ad_click_button"));
    this.p = (TextView)paramOpenScreenAdBackupView.findViewById(t.e((Context)this, "tt_ad_logo"));
    this.i.a(this, paramOpenScreenAdBackupView, this.B, this.u, this.t, this.y);
    this.k.a(this, paramOpenScreenAdBackupView);
  }
  
  private void a(String paramString) {
    y.c(new g(this, "AppOpenAd_executeMultiProcessCallback", paramString) {
          public void run() {
            try {
              return;
            } finally {
              Exception exception = null;
              l.b("TTAppOpenAdActivity", "open_ad", "executeAppOpenAdCallback execute throw Exception : ", exception);
            } 
          }
        }5);
  }
  
  private boolean b(Bundle paramBundle) {
    if (b.c()) {
      Intent intent = getIntent();
      if (intent != null) {
        String str = intent.getStringExtra("multi_process_materialmeta");
        if (str != null)
          try {
            this.B = b.a(PangleVideoBridge.jsonObjectInit(str));
          } catch (Exception exception) {
            l.b("TTAppOpenAdActivity", "open_ad", "initData MultiGlobalInfo throws ", exception);
          }  
        this.A = intent.getStringExtra("multi_process_meta_md5");
      } 
    } else {
      this.B = r.a().c();
      this.D = r.a().f();
      r.a().h();
    } 
    a(getIntent());
    a(paramBundle);
    n n1 = this.B;
    if (n1 == null) {
      l.a("TTAppOpenAdActivity", "open_ad", "mMaterialMeta is null , no data to display ,the TTOpenAdActivity finished !!");
      finish();
      return false;
    } 
    this.z = n1.aX();
    return true;
  }
  
  private void g() {
    Pair pair = a.a(getWindow(), this.G);
    AdSlot adSlot = (new AdSlot.Builder()).setCodeId(String.valueOf(this.B.aX())).setExpressViewAcceptedSize(((Float)pair.first).floatValue(), ((Float)pair.second).floatValue()).build();
    b b1 = new b(this) {
        public void a() {
          boolean bool = TTAppOpenAdActivity.f(this.a).q();
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("onRenderSuccess() called. isBackupShow=");
          stringBuilder.append(bool);
          l.a("TTAppOpenAdActivity", "open_ad", stringBuilder.toString());
          if (!bool) {
            TTAppOpenAdActivity.h(this.a);
            TTAppOpenAdActivity.i(this.a).d();
            TTAppOpenAdActivity.j(this.a);
          } 
        }
        
        public void b() {
          this.a.b();
        }
      };
    n.a a1 = this.B.H();
    int i = this.B.r();
    if (a1 != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("tryDynamicNative: id is ");
      stringBuilder.append(a1.b());
      stringBuilder.append(", renderSequence is ");
      stringBuilder.append(i);
      l.a("TTAppOpenAdActivity", "open_ad", stringBuilder.toString());
    } 
    n n2 = this.B;
    boolean bool = true;
    n2.h(1);
    if (this.y) {
      this.I = (NativeExpressView)new OpenScreenAdVideoExpressView((Context)this, this.B, adSlot, "open_ad", this.J, this.E, b1, new b(this) {
            public void a() {
              if (this.a.isFinishing())
                return; 
              TTAppOpenAdActivity.k(this.a);
            }
          });
    } else {
      this.I = (NativeExpressView)new OpenScreenAdExpressView((Context)this, this.B, adSlot, "open_ad", this.J, b1);
    } 
    this.K.addView((View)this.I, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
    n n1 = this.B;
    if (n1 == null || n1.m() != 2 || i != 3)
      bool = false; 
    this.L = bool;
    if (bool) {
      c c1 = h();
      e e = new e((Context)this, this.B, "open_ad", 4);
      e.a((View)this.I);
      e.a(c1);
      b.a((b)e, this.B);
      this.I.setClickListener(e);
      d d1 = new d((Context)this, this.B, "open_ad", 4);
      d1.a((View)this.I);
      d1.a(c1);
      b.a((b)d1, this.B);
      this.I.setClickCreativeListener(d1);
      d1.a(new b.a(this) {
            public void a(View param1View, int param1Int) {
              TTAppOpenAdActivity.l(this.a);
            }
          });
      this.I.setBackupListener(new c(this) {
            public boolean a(ViewGroup param1ViewGroup, int param1Int) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("isUseBackup() called with: view = [");
              stringBuilder.append(param1ViewGroup);
              stringBuilder.append("], errCode = [");
              stringBuilder.append(param1Int);
              stringBuilder.append("]");
              l.a("TTAppOpenAdActivity", "open_ad", stringBuilder.toString());
              try {
                ((NativeExpressView)param1ViewGroup).p();
                TTAppOpenAdActivity.m(this.a);
                return true;
              } catch (Exception exception) {
                Log.e("TTAppOpenAdActivity", "", exception);
                return false;
              } 
            }
          });
      this.I.m();
      return;
    } 
    i();
  }
  
  private c h() {
    return (this.B.M() == 4) ? d.a(getApplicationContext(), this.B, "open_ad") : null;
  }
  
  private void i() {
    l.a("TTAppOpenAdActivity", "open_ad", "performNativeRender() called");
    OpenScreenAdBackupView openScreenAdBackupView = new OpenScreenAdBackupView((Context)this);
    openScreenAdBackupView.a(this.I, this.B);
    if (this.B.d() == 3 && this.G != 2) {
      this.G = 2;
      k();
    } 
    a(openScreenAdBackupView);
    m();
    o();
  }
  
  private void j() {
    if (this.G == 2) {
      if (f()) {
        setRequestedOrientation(8);
      } else {
        setRequestedOrientation(0);
      } 
    } else {
      setRequestedOrientation(1);
    } 
    if (this.G == 2 || !ab.c(this))
      getWindow().addFlags(1024); 
  }
  
  private void k() {
    int i;
    int j;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("changeScreenOrientation: mOrientation=");
    stringBuilder.append(this.G);
    l.a("TTAppOpenAdActivity", "open_ad", stringBuilder.toString());
    if (Build.VERSION.SDK_INT != 26)
      if (Build.VERSION.SDK_INT == 27) {
        try {
          j();
        } finally {
          stringBuilder = null;
          stringBuilder.printStackTrace();
        } 
      } else {
        j();
      }  
    Pair pair = ab.h(getApplicationContext());
    if (this.G == 2) {
      j = Math.max(((Integer)pair.first).intValue(), ((Integer)pair.second).intValue());
      i = Math.min(((Integer)pair.first).intValue(), ((Integer)pair.second).intValue());
    } else {
      j = Math.min(((Integer)pair.first).intValue(), ((Integer)pair.second).intValue());
      i = Math.max(((Integer)pair.first).intValue(), ((Integer)pair.second).intValue());
    } 
    this.t = i;
    this.u = j;
    float f1 = ab.a();
    if (ab.c(this)) {
      i = this.G;
      if (i == 1) {
        this.t -= f1;
        return;
      } 
      if (i == 2)
        this.u -= f1; 
    } 
  }
  
  private void l() {
    if (26 == Build.VERSION.SDK_INT) {
      if ((getResources().getConfiguration()).orientation == 1) {
        this.G = 1;
      } else {
        this.G = 2;
      } 
    } else {
      this.G = this.B.an();
    } 
    k();
  }
  
  private void m() {
    this.p.setOnClickListener(new View.OnClickListener(this) {
          public void onClick(View param1View) {
            Logger.d("Pangle|SafeDK: Execution> Lcom/bytedance/sdk/openadsdk/activity/TTAppOpenAdActivity$14;->onClick(Landroid/view/View;)V");
            CreativeInfoManager.onViewClicked("com.bytedance.sdk", param1View);
            safedk_TTAppOpenAdActivity$14_onClick_22ac1c204b9d3f78c35dc2563e8ab0d9(param1View);
          }
          
          public void safedk_TTAppOpenAdActivity$14_onClick_22ac1c204b9d3f78c35dc2563e8ab0d9(View param1View) {
            try {
              return;
            } finally {
              param1View = null;
              param1View.printStackTrace();
            } 
          }
        });
    b b1 = new b(this.B, this);
    b1.a(new b.a(this) {
          public void a(View param1View, int param1Int) {
            TTAppOpenAdActivity.l(this.a);
          }
        });
    a a1 = b1.a();
    if (this.B.c() == 1) {
      this.m.setOnClickListener((View.OnClickListener)a1);
      this.m.setOnTouchListener((View.OnTouchListener)a1);
    } 
    this.q.setOnClickListener((View.OnClickListener)a1);
    this.q.setOnTouchListener((View.OnTouchListener)a1);
  }
  
  private void n() {
    l.a("TTAppOpenAdActivity", "open_ad", "callbackAdClick() called");
    if (b.c()) {
      a("onAdClicked");
      return;
    } 
    c c1 = this.D;
    if (c1 != null)
      c1.b(); 
  }
  
  private void o() {
    this.i.a();
    this.q.setText(this.B.X());
    p();
    if (this.y) {
      a(0);
      b(8);
      r();
    } else {
      a(8);
      b(0);
      q();
    } 
    this.w.d();
    x();
  }
  
  private void p() {
    Log.d("TTAppOpenAdActivity", "startCountDownTimer() called");
    int i = m.d().s(String.valueOf(this.z));
    this.k.b(i);
    this.k.a(this.j.a());
    this.r = this.k.b();
    this.k.a(0);
  }
  
  private void q() {
    String str;
    k k = this.B.Q().get(0);
    if (TextUtils.isEmpty(k.g())) {
      str = e.a(k.a());
    } else {
      str = k.g();
    } 
    File file = a.b(str);
    i.a(new a(k.a(), k.g()), k.b(), k.c(), new i.a(this) {
          public void a() {}
          
          public void a(b param1b) {
            if (param1b.d()) {
              this.a.a(param1b);
              if (param1b.b() != null)
                TTAppOpenAdActivity.a(this.a, param1b.a()); 
            } 
          }
          
          public void b() {}
        }file.getParent(), 25);
  }
  
  private void r() {
    boolean bool;
    d d1 = new d((Context)this);
    this.s = d1;
    d1.a(this.n, this.B);
  }
  
  private void s() {
    if (this.f == null) {
      TTAdDislikeDialog tTAdDislikeDialog = new TTAdDislikeDialog((Context)this, this.B);
      this.f = tTAdDislikeDialog;
      tTAdDislikeDialog.setCallback(new TTAdDislikeDialog.a(this) {
            public void a(int param1Int, FilterWord param1FilterWord) {
              if (!this.a.d.get() && param1FilterWord != null && !param1FilterWord.hasSecondOptions()) {
                this.a.d.set(true);
                TTAppOpenAdActivity.o(this.a);
              } 
            }
            
            public void a(View param1View) {
              this.a.c.set(true);
              this.a.d();
            }
            
            public void b(View param1View) {
              this.a.c.set(false);
              this.a.c();
            }
            
            public void c(View param1View) {}
          });
    } 
    FrameLayout frameLayout = (FrameLayout)findViewById(16908290);
    frameLayout.addView((View)this.f);
    if (this.g == null) {
      TTAdDislikeToast tTAdDislikeToast = new TTAdDislikeToast((Context)this);
      this.g = tTAdDislikeToast;
      frameLayout.addView((View)tTAdDislikeToast);
    } 
  }
  
  private void t() {
    if (this.y)
      this.b.sendEmptyMessageDelayed(100, 5000L); 
  }
  
  private void u() {
    this.b.removeMessages(100);
  }
  
  private void v() {
    this.g.a(j.d);
  }
  
  private void w() {
    this.g.a(j.e);
  }
  
  private void x() {
    if (this.l.get())
      return; 
    try {
      return;
    } finally {
      Exception exception = null;
      finish();
    } 
  }
  
  private void y() {
    l.a("TTAppOpenAdActivity", "open_ad", "callbackAdShow() called");
    if (b.c()) {
      a("onAdShow");
      return;
    } 
    c c1 = this.D;
    if (c1 != null)
      c1.a(); 
  }
  
  private void z() {
    if (b.c()) {
      a("onAdSkip");
      return;
    } 
    c c1 = this.D;
    if (c1 != null)
      c1.c(); 
  }
  
  void a() {
    l.a("TTAppOpenAdActivity", "open_ad", "onUserWantSkip() called");
    p.c(this.z);
    z();
    d d1 = this.s;
    if (d1 != null)
      d1.a(4); 
    a.a(this.B, (int)this.j.b(), this.k.c(), this.j.a());
    finish();
  }
  
  void a(int paramInt) {
    ab.a((View)this.n, paramInt);
  }
  
  protected void a(Intent paramIntent) {
    if (paramIntent != null)
      this.F = paramIntent.getIntExtra("ad_source", 0); 
  }
  
  protected void a(Bundle paramBundle) {
    if (paramBundle != null)
      if (this.D == null)
        this.D = h;  
  }
  
  public void a(Message paramMessage) {
    if (paramMessage.what == 100) {
      d d1 = this.s;
      if (d1 != null)
        d1.a(1); 
      z();
      finish();
    } 
  }
  
  void a(b paramb) {
    if (paramb.b() != null) {
      this.o.setImageBitmap(paramb.b());
      return;
    } 
    if (this.B.Q() != null && this.B.Q().get(0) != null) {
      int i = ((k)this.B.Q().get(0)).b();
      Drawable drawable = i.a(paramb.c(), i);
      this.o.setScaleType(ImageView.ScaleType.FIT_CENTER);
      this.o.setImageDrawable(drawable);
    } 
  }
  
  protected void b() {
    if (isFinishing())
      return; 
    if (this.d.get()) {
      v();
      return;
    } 
    if (this.f == null)
      s(); 
    this.f.a();
  }
  
  void b(int paramInt) {
    ab.a((View)this.o, paramInt);
  }
  
  void c() {
    if (this.y) {
      d d1 = this.s;
      if (d1 != null && d1.c())
        this.s.e(); 
      NativeExpressView nativeExpressView = this.I;
      if (nativeExpressView instanceof OpenScreenAdVideoExpressView)
        ((OpenScreenAdVideoExpressView)nativeExpressView).k(); 
      nativeExpressView = this.I;
      if ((nativeExpressView != null && nativeExpressView.q()) || this.y)
        t(); 
    } 
    if (this.r != null && Build.VERSION.SDK_INT >= 19)
      this.r.resume(); 
  }
  
  void d() {
    if (this.y) {
      d d1 = this.s;
      if (d1 != null && d1.b())
        this.s.d(); 
      u();
      NativeExpressView nativeExpressView = this.I;
      if (nativeExpressView instanceof OpenScreenAdVideoExpressView)
        ((OpenScreenAdVideoExpressView)nativeExpressView).j(); 
    } 
    if (this.r != null && Build.VERSION.SDK_INT >= 19)
      this.r.pause(); 
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    DetectTouchUtils.activityOnTouch("com.bytedance.sdk", paramMotionEvent);
    return super.dispatchTouchEvent(paramMotionEvent);
  }
  
  protected IListenerManager e() {
    if (this.C == null)
      this.C = a.asInterface(a.a(m.a()).a(7)); 
    return this.C;
  }
  
  protected boolean f() {
    boolean bool = false;
    try {
      int i = getIntent().getIntExtra("orientation_angle", 0);
      if (i == 3)
        bool = true; 
      return bool;
    } catch (Exception exception) {
      exception.printStackTrace();
      return false;
    } 
  }
  
  public void finish() {
    super.finish();
    overridePendingTransition(0, 0);
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    ab.a(this);
    getWindow().getDecorView().setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener(this) {
          public void onSystemUiVisibilityChange(int param1Int) {
            if (param1Int == 0)
              try {
                if (this.a.isFinishing())
                  return; 
                this.a.getWindow().getDecorView().postDelayed(new Runnable(this) {
                      public void run() {
                        ab.a(this.a.a);
                      }
                    },  2500L);
                return;
              } catch (Exception exception) {
                exception.printStackTrace();
              }  
          }
        });
  }
  
  public void onBackPressed() {
    if (m.d().r(String.valueOf(this.z)) == 1) {
      int i = m.d().s(String.valueOf(this.z));
      if (this.j.b() >= i * 1000L)
        a(); 
    } 
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (!b(paramBundle))
      return; 
    if (!PAGSdk.isInitSuccess())
      finish(); 
    this.y = n.c(this.B);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onCreate: isVideo is ");
    stringBuilder.append(this.y);
    l.a("TTAppOpenAdActivity", "open_ad", stringBuilder.toString());
    if (this.y) {
      this.j.a((float)this.B.K().f());
    } else {
      this.j.a(m.d().t(String.valueOf(this.z)));
    } 
    l();
    this.k.a(this.J);
    FrameLayout frameLayout = new FrameLayout((Context)this);
    this.K = frameLayout;
    frameLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
    setContentView((View)this.K);
    this.K.post(new Runnable(this) {
          public void run() {
            TTAppOpenAdActivity.g(this.a);
          }
        });
    b.a(this.B);
  }
  
  protected void onDestroy() {
    super.onDestroy();
    this.b.removeCallbacksAndMessages(null);
    e.a(this.B);
    if (this.y) {
      a.a(this.B, this.j.b(), this.j.a(), true);
    } else {
      a.a(this.B, -1L, this.j.a(), false);
    } 
    if (this.w.e() && this.l.get()) {
      c.a(String.valueOf(this.w.c()), this.B, "open_ad", this.x);
      this.w = z.b();
    } 
    ButtonFlash buttonFlash = this.q;
    if (buttonFlash != null)
      buttonFlash.a(); 
    d d1 = this.s;
    if (d1 != null)
      d1.f(); 
    if (b.c())
      a("recycleRes"); 
    ValueAnimator valueAnimator = this.r;
    if (valueAnimator != null)
      valueAnimator.cancel(); 
    h = null;
    this.D = null;
    TTAdDislikeDialog tTAdDislikeDialog = this.f;
    if (tTAdDislikeDialog != null)
      tTAdDislikeDialog.setCallback(null); 
  }
  
  protected void onPause() {
    super.onPause();
    this.e = false;
    d();
  }
  
  protected void onResume() {
    super.onResume();
    this.e = true;
    if (this.a.getAndSet(true))
      c(); 
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    Bundle bundle = paramBundle;
    if (paramBundle == null)
      bundle = new Bundle(); 
    try {
      String str;
      n n1 = this.B;
      if (n1 != null) {
        str = n1.as().toString();
      } else {
        n1 = null;
      } 
      bundle.putString("material_meta", (String)n1);
      bundle.putString("multi_process_meta_md5", this.A);
      bundle.putInt("ad_source", this.F);
      Double double_ = this.H;
      if (double_ == null) {
        str = "";
      } else {
        str = String.valueOf(str);
      } 
    } finally {
      paramBundle = null;
    } 
    h = this.D;
    super.onSaveInstanceState(bundle);
  }
  
  public void onWindowFocusChanged(boolean paramBoolean) {
    byte b1;
    super.onWindowFocusChanged(paramBoolean);
    if (paramBoolean) {
      if (!this.L)
        this.w.d(); 
    } else if (this.l.get()) {
      if (this.w.e())
        c.a(String.valueOf(this.w.c()), this.B, "open_ad", this.x); 
      this.w = z.b();
    } 
    n n1 = this.B;
    if (paramBoolean) {
      b1 = 4;
    } else {
      b1 = 8;
    } 
    e.a(n1, b1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\activity\TTAppOpenAdActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */