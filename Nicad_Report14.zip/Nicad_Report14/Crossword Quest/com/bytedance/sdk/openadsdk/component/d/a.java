package com.bytedance.sdk.openadsdk.component.d;

import com.bytedance.sdk.openadsdk.c.c;
import com.bytedance.sdk.openadsdk.core.model.n;
import com.bytedance.sdk.openadsdk.core.model.r;
import com.bytedance.sdk.openadsdk.h.a.b;
import com.bytedance.sdk.openadsdk.h.b;
import java.util.HashMap;
import org.json.JSONObject;

public class a {
  public static void a(int paramInt1, int paramInt2) {
    b.a().b(new com.bytedance.sdk.openadsdk.h.a(paramInt1, paramInt2) {
          public com.bytedance.sdk.openadsdk.h.a.a a() throws Exception {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("timeout_type", this.a);
            jSONObject.put("user_timeout_time", this.b);
            return (com.bytedance.sdk.openadsdk.h.a.a)b.b().a("openad_load_ad_timeout").b(jSONObject.toString());
          }
        });
  }
  
  public static void a(n paramn) {
    c.b(paramn, "cache_expire", null);
  }
  
  public static void a(n paramn, int paramInt1, int paramInt2, float paramFloat) {
    String str;
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (n.c(paramn)) {
      str = "video_normal_ad";
    } else {
      str = "image_normal_ad";
    } 
    hashMap.put("openad_creative_type", str);
    hashMap.put("skip_time", Integer.valueOf(paramInt1));
    hashMap.put("skip_show_time", Integer.valueOf(paramInt2));
    hashMap.put("total_time", Float.valueOf(paramFloat));
    c.b(paramn, "skip", hashMap);
  }
  
  public static void a(n paramn, int paramInt, r paramr) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public static void a(n paramn, long paramLong) {
    String str;
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (n.c(paramn)) {
      str = "video_normal_ad";
    } else {
      str = "image_normal_ad";
    } 
    hashMap.put("openad_creative_type", str);
    c.a(paramn, "load_cache_duration", paramLong, hashMap);
  }
  
  public static void a(n paramn, long paramLong, float paramFloat, boolean paramBoolean) {
    String str;
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (n.c(paramn)) {
      str = "video_normal_ad";
    } else {
      str = "image_normal_ad";
    } 
    hashMap.put("openad_creative_type", str);
    if (paramBoolean) {
      hashMap.put("video_duration", Float.valueOf(paramFloat));
      double d1 = paramLong;
      Double.isNaN(d1);
      d1 = d1 * 1.0D / 10.0D;
      double d2 = paramFloat;
      Double.isNaN(d2);
      hashMap.put("video_percent", Integer.valueOf((int)(d1 / d2)));
    } else {
      hashMap.put("image_duration", Float.valueOf(paramFloat));
    } 
    c.b(paramn, "destroy", hashMap);
  }
  
  public static void a(n paramn, long paramLong, boolean paramBoolean) {
    byte b;
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (paramBoolean) {
      b = 1;
    } else {
      b = 2;
    } 
    hashMap.put("order", Integer.valueOf(b));
    c.a(paramn, "download_image_duration", paramLong, hashMap);
  }
  
  public static void b(n paramn) {
    String str;
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (n.c(paramn)) {
      str = "video_normal_ad";
    } else {
      str = "image_normal_ad";
    } 
    hashMap.put("openad_creative_type", str);
    c.b(paramn, "cache_loss", hashMap);
  }
  
  public static void b(n paramn, long paramLong, boolean paramBoolean) {
    byte b;
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("size", Long.valueOf(paramn.K().e()));
    hashMap.put("video_duration", Double.valueOf(paramn.K().f()));
    if (paramBoolean) {
      b = 1;
    } else {
      b = 2;
    } 
    hashMap.put("order", Integer.valueOf(b));
    c.a(paramn, "download_video_duration", paramLong, hashMap);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\component\d\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */