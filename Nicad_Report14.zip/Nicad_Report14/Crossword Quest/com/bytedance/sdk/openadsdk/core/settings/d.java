package com.bytedance.sdk.openadsdk.core.settings;

import com.bytedance.sdk.component.utils.l;
import com.safedk.android.internal.partials.PangleVideoBridge;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

public interface d {
  public static final b<JSONObject> a = new b<JSONObject>() {
      public JSONObject a(String param1String) {
        try {
          return PangleVideoBridge.jsonObjectInit(param1String);
        } catch (Exception exception) {
          l.c("ISettingsDataRepository", "", exception);
          return null;
        } 
      }
    };
  
  public static final b<Set<String>> b = new b<Set<String>>() {
      public Set<String> a(String param1String) {
        HashSet<String> hashSet = new HashSet();
        try {
          JSONArray jSONArray = new JSONArray(param1String);
          int i = 0;
          int j = jSONArray.length();
          while (i < j) {
            hashSet.add(jSONArray.getString(i));
            i++;
          } 
        } catch (Exception exception) {
          l.c("ISettingsDataRepository", "", exception);
        } 
        return hashSet;
      }
    };
  
  float a(String paramString, float paramFloat);
  
  int a(String paramString, int paramInt);
  
  long a(String paramString, long paramLong);
  
  a a();
  
  <T> T a(String paramString, T paramT, b<T> paramb);
  
  String a(String paramString1, String paramString2);
  
  void a(boolean paramBoolean);
  
  boolean b();
  
  public static interface a {
    a a(String param1String);
    
    a a(String param1String, float param1Float);
    
    a a(String param1String, int param1Int);
    
    a a(String param1String, long param1Long);
    
    a a(String param1String1, String param1String2);
    
    void a();
  }
  
  public static interface b<T> {
    T b(String param1String);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\core\settings\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */