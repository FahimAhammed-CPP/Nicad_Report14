package com.bytedance.sdk.openadsdk.core;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import com.bykv.vk.openvk.component.video.api.c.c;
import com.bytedance.JProtect;
import com.bytedance.sdk.component.a.l;
import com.bytedance.sdk.component.a.r;
import com.bytedance.sdk.component.adexpress.a.c.c;
import com.bytedance.sdk.component.adexpress.b.j;
import com.bytedance.sdk.component.adexpress.c;
import com.bytedance.sdk.component.adexpress.d.b;
import com.bytedance.sdk.component.g.g;
import com.bytedance.sdk.component.utils.k;
import com.bytedance.sdk.component.utils.l;
import com.bytedance.sdk.component.utils.y;
import com.bytedance.sdk.component.widget.SSWebView;
import com.bytedance.sdk.openadsdk.ApmHelper;
import com.bytedance.sdk.openadsdk.activity.TTWebsiteActivity;
import com.bytedance.sdk.openadsdk.c.c;
import com.bytedance.sdk.openadsdk.c.m;
import com.bytedance.sdk.openadsdk.component.reward.n;
import com.bytedance.sdk.openadsdk.core.b.d;
import com.bytedance.sdk.openadsdk.core.g.a;
import com.bytedance.sdk.openadsdk.core.model.d;
import com.bytedance.sdk.openadsdk.core.model.j;
import com.bytedance.sdk.openadsdk.core.model.n;
import com.bytedance.sdk.openadsdk.core.model.p;
import com.bytedance.sdk.openadsdk.core.nativeexpress.i;
import com.bytedance.sdk.openadsdk.core.settings.e;
import com.bytedance.sdk.openadsdk.core.widget.a.a;
import com.bytedance.sdk.openadsdk.f.b;
import com.bytedance.sdk.openadsdk.f.c;
import com.bytedance.sdk.openadsdk.f.d;
import com.bytedance.sdk.openadsdk.g.a.b;
import com.bytedance.sdk.openadsdk.g.a.c;
import com.bytedance.sdk.openadsdk.g.a.d;
import com.bytedance.sdk.openadsdk.g.a.e;
import com.bytedance.sdk.openadsdk.jslistener.b;
import com.bytedance.sdk.openadsdk.jslistener.c;
import com.bytedance.sdk.openadsdk.jslistener.d;
import com.bytedance.sdk.openadsdk.jslistener.e;
import com.bytedance.sdk.openadsdk.jslistener.h;
import com.bytedance.sdk.openadsdk.l.aa;
import com.bytedance.sdk.openadsdk.l.ab;
import com.bytedance.sdk.openadsdk.l.f;
import com.bytedance.sdk.openadsdk.l.k;
import com.bytedance.sdk.openadsdk.l.o;
import com.bytedance.sdk.openadsdk.l.y;
import com.safedk.android.internal.partials.PangleNetworkBridge;
import com.safedk.android.internal.partials.PangleVideoBridge;
import java.lang.ref.WeakReference;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONArray;
import org.json.JSONObject;

public class u implements b, y.a, b {
  private static final Map<String, Boolean> g;
  
  private b A;
  
  private h B;
  
  private boolean C = true;
  
  private List<n> D;
  
  private HashMap<String, i> E;
  
  private boolean F = false;
  
  private boolean G = false;
  
  private m H;
  
  private r I;
  
  private String J;
  
  private boolean K = false;
  
  private a L;
  
  protected Map<String, Object> a;
  
  boolean b;
  
  boolean c = false;
  
  private WeakReference<SSWebView> d;
  
  private y e;
  
  private String f;
  
  private WeakReference<Context> h;
  
  private c i;
  
  private String j;
  
  private WeakReference<View> k;
  
  private String l;
  
  private int m;
  
  private String n;
  
  private int o;
  
  private boolean p = true;
  
  private n q;
  
  private j r;
  
  private i s;
  
  private JSONObject t;
  
  private d u;
  
  private com.bytedance.sdk.openadsdk.jslistener.a v;
  
  private e w;
  
  private d x;
  
  private JSONObject y;
  
  private d z;
  
  static {
    ConcurrentHashMap<Object, Object> concurrentHashMap = new ConcurrentHashMap<Object, Object>();
    g = (Map)concurrentHashMap;
    concurrentHashMap.put(e.e1671532477438dc("lne\\asci|"), Boolean.TRUE);
    concurrentHashMap.put(e.e1671532477438dc("pskueqc"), Boolean.TRUE);
    concurrentHashMap.put(e.e1671532477438dc("dhqseqeoWdoxlij"), Boolean.TRUE);
    concurrentHashMap.put(e.e1671532477438dc("ctqwkhYb~ld"), Boolean.TRUE);
    concurrentHashMap.put(e.e1671532477438dc("lne\\asci|V|8"), Boolean.TRUE);
  }
  
  public u(Context paramContext) {
    this.h = new WeakReference<Context>(paramContext);
    this.e = new y(Looper.getMainLooper(), this);
  }
  
  private void a(a parama, JSONObject paramJSONObject) {
    if (parama == null)
      return; 
    try {
      a(parama.d, new c(this, paramJSONObject, parama) {
          
          });
      return;
    } catch (Exception exception) {
      return;
    } 
  }
  
  private void a(String paramString, boolean paramBoolean) {
    if (this.H != null) {
      if (TextUtils.isEmpty(paramString))
        return; 
      if (paramBoolean) {
        this.H.a(paramString);
        return;
      } 
      this.H.b(paramString);
    } 
  }
  
  @JProtect
  private void a(JSONObject paramJSONObject, int paramInt) throws Exception {
    String str1;
    String str2;
    JSONArray jSONArray = new JSONArray();
    Iterator<String> iterator = p().iterator();
    while (iterator.hasNext())
      jSONArray.put(iterator.next()); 
    paramJSONObject.put(n.n1671532477404dc("aqrMehc"), com.bytedance.sdk.openadsdk.common.a.a());
    paramJSONObject.put(n.n1671532477404dc("iolfvDvwFhgn"), com.bytedance.sdk.openadsdk.common.a.e());
    paramJSONObject.put(n.n1671532477404dc("ahf"), com.bytedance.sdk.openadsdk.common.a.b());
    paramJSONObject.put(n.n1671532477404dc("seiF`lrngg"), com.bytedance.sdk.openadsdk.common.a.c());
    paramJSONObject.put(n.n1671532477404dc("aqrUawungg"), com.bytedance.sdk.openadsdk.common.a.d());
    paramJSONObject.put(n.n1671532477404dc("ndvW}uc"), com.bytedance.sdk.openadsdk.common.a.f());
    paramJSONObject.put(n.n1671532477404dc("strskwrKaz~"), jSONArray);
    paramJSONObject.put(n.n1671532477404dc("ddtjg`Oc"), com.bytedance.sdk.openadsdk.common.a.a(m.a()));
    if (f.a(m.a())) {
      str2 = n.n1671532477404dc("ddtjg`Ywdh~mcc");
      str1 = "AofqklbXXhn";
    } else {
      str2 = n.n1671532477404dc("ddtjg`Ywdh~mcc");
      str1 = "Aofqklb";
    } 
    paramJSONObject.put(str2, n.n1671532477404dc(str1));
    paramJSONObject.put(n.n1671532477404dc("ddtjg`Ysqyo"), Build.VERSION.RELEASE);
  }
  
  @JProtect
  private boolean a(String paramString, int paramInt, j paramj) {
    if (!TextUtils.isEmpty(paramString)) {
      HashMap<String, i> hashMap = this.E;
      if (hashMap == null)
        return false; 
      i i1 = hashMap.get(paramString);
      if (i1 != null) {
        i1.a(paramInt, paramj);
        return true;
      } 
    } 
    return false;
  }
  
  public static JSONArray b(List<n> paramList) {
    JSONArray jSONArray = new JSONArray();
    if (paramList == null)
      return jSONArray; 
    int i1 = paramList.size();
    for (int k = 0; k < i1; k++)
      jSONArray.put(((n)paramList.get(k)).as()); 
    return jSONArray;
  }
  
  private void b(String paramString, JSONObject paramJSONObject) {
    try {
      JSONObject jSONObject = new JSONObject();
      jSONObject.put(com.bytedance.sdk.component.f.c.a.a1671532477457dc("_^opcZr~xl"), com.bytedance.sdk.component.f.c.a.a1671532477457dc("c`nofdel"));
      jSONObject.put(com.bytedance.sdk.component.f.c.a.a1671532477457dc("_^abhidfkbUbh"), paramString);
      if (paramJSONObject != null)
        jSONObject.put(com.bytedance.sdk.component.f.c.a.a1671532477457dc("_^rbvdkt"), paramJSONObject); 
      p(jSONObject);
      return;
    } catch (Exception exception) {
      return;
    } 
  }
  
  private void c(String paramString, JSONObject paramJSONObject) {
    try {
      if (TextUtils.isEmpty(paramString))
        return; 
      JSONObject jSONObject = new JSONObject();
      jSONObject.put(ApmHelper.ApmHelper1671532477463dc("_^opcZr~xl"), ApmHelper.ApmHelper1671532477463dc("ewgmp"));
      jSONObject.put(ApmHelper.ApmHelper1671532477463dc("_^guakrXam"), paramString);
      if (paramJSONObject != null)
        jSONObject.put(ApmHelper.ApmHelper1671532477463dc("_^rbvdkt"), paramJSONObject); 
      p(jSONObject);
      return;
    } catch (Exception exception) {
      return;
    } 
  }
  
  private void d(JSONObject paramJSONObject) throws Exception {
    String str1;
    if (!TextUtils.isEmpty(this.j))
      paramJSONObject.put(com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("chf"), this.j); 
    if (!TextUtils.isEmpty(this.l))
      paramJSONObject.put(com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("lne\\a}rui"), this.l); 
    if (!TextUtils.isEmpty(this.n))
      paramJSONObject.put(com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("dnumhjgcW|xg"), this.n); 
    String str2 = com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("db");
    if (TextUtils.isEmpty(m.d().G())) {
      str1 = m.d().G();
    } else {
      str1 = com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("SF");
    } 
    paramJSONObject.put(str2, str1);
    paramJSONObject.put(com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("l`ldqdab"), aa.h(m.a()));
  }
  
  private void e(JSONObject paramJSONObject) throws Exception {
    if (!TextUtils.isEmpty(p.b(this.q)))
      paramJSONObject.put(com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("pmczegjbWz~r`h"), p.b(this.q)); 
  }
  
  private void f(JSONObject paramJSONObject) {
    if (paramJSONObject != null) {
      m m1 = this.H;
      if (m1 == null)
        return; 
      m1.b(paramJSONObject);
    } 
  }
  
  private void g(JSONObject paramJSONObject) {
    b b1 = this.A;
    if (b1 != null) {
      if (paramJSONObject == null)
        return; 
      b1.a(paramJSONObject.optBoolean(ApmHelper.ApmHelper1671532477463dc("irPfjacu[|i"), false), paramJSONObject.optInt(ApmHelper.ApmHelper1671532477463dc("cnff"), -1), paramJSONObject.optString(ApmHelper.ApmHelper1671532477463dc("mre"), ""));
    } 
  }
  
  private void h(String paramString) {
    try {
      String str = new String(Base64.decode(paramString, 2));
      l.b(ApmHelper.ApmHelper1671532477463dc("TUCm`winlFhainz"), str);
      JSONArray jSONArray = new JSONArray(str);
      int i1 = jSONArray.length();
      int k = 0;
      while (true) {
        if (k < i1) {
          a a1 = new a();
          try {
            JSONObject jSONObject = jSONArray.optJSONObject(k);
            if (jSONObject != null) {
              a1.a = jSONObject.optString(ApmHelper.ApmHelper1671532477463dc("_^opcZr~xl"), null);
              a1.b = jSONObject.optString(ApmHelper.ApmHelper1671532477463dc("_^abhidfkbUbh"), null);
              a1.c = jSONObject.optString(ApmHelper.ApmHelper1671532477463dc("ftl`"));
              a1.d = jSONObject.optJSONObject(ApmHelper.ApmHelper1671532477463dc("p`pbiv"));
              a1.e = jSONObject.optInt(ApmHelper.ApmHelper1671532477463dc("JRQGO"));
            } 
          } finally {
            Exception exception;
          } 
          if (!TextUtils.isEmpty(a1.a) && !TextUtils.isEmpty(a1.c)) {
            Message message = this.e.obtainMessage(11);
            message.obj = a1;
            this.e.sendMessage(message);
          } 
          k++;
          continue;
        } 
        return;
      } 
    } catch (Exception exception) {
      if (l.a()) {
        String str = ApmHelper.ApmHelper1671532477463dc("TUCm`winlFhainz");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(ApmHelper.ApmHelper1671532477463dc("f`koaa&sg)zj~~k/zbpa}qqr8ti|<lkzUD\002"));
        stringBuilder.append(paramString);
        l.d(str, stringBuilder.toString());
        return;
      } 
      l.d(ApmHelper.ApmHelper1671532477463dc("TUCm`winlFhainz"), ApmHelper.ApmHelper1671532477463dc("f`koaa&sg)zj~~k/zbpa}qqr8ti|<lkzUD"));
    } 
  }
  
  private void h(JSONObject paramJSONObject) {
    if (this.s != null) {
      if (paramJSONObject == null)
        return; 
      try {
        boolean bool = paramJSONObject.optBoolean(d.d1671532477445dc("mtvf"), false);
        this.s.a(bool);
        return;
      } catch (Exception exception) {
        return;
      } 
    } 
  }
  
  private void i(JSONObject paramJSONObject) {
    if (this.s != null) {
      if (paramJSONObject == null)
        return; 
      try {
        int k = paramJSONObject.optInt(d.d1671532477445dc("sucwaQwm"), -1);
        this.s.a(k);
        return;
      } catch (Exception exception) {
        return;
      } 
    } 
  }
  
  private boolean i(String paramString) {
    return TextUtils.isEmpty(paramString) ? true : (!c.c1671532477447dc("cmk`oZis`lx").equals(paramString) ? true : (!!j()));
  }
  
  private String j(String paramString) {
    if (this.r == null) {
      int k = this.m;
      label16: while (true) {
        byte b2 = 94;
        for (byte b1 = 125;; b1 = 95) {
          switch (b2) {
            default:
              continue label16;
            case 95:
              switch (b1) {
                default:
                  switch (b1) {
                    case 56:
                      continue label16;
                    default:
                      break;
                    case 55:
                    case 57:
                      break;
                  } 
                case 95:
                  return aa.a(k);
                case 94:
                case 96:
                  break;
              } 
              break;
            case 96:
            
            case 94:
              break;
          } 
          b2 = 95;
        } 
        break;
      } 
    } 
    return paramString;
  }
  
  private boolean j(JSONObject paramJSONObject) {
    i i1 = this.s;
    if (i1 != null) {
      if (paramJSONObject == null)
        return false; 
      double d1 = i1.c();
      int k = this.s.d();
      try {
        String str2 = d.d1671532477445dc("ctpqakrSado");
        Double.isNaN(d1);
        d1 /= 1000.0D;
        paramJSONObject.put(str2, d1);
        paramJSONObject.put(d.d1671532477445dc("sucwa"), k);
        String str1 = d.d1671532477445dc("TUCm`winlFhainz");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(d.d1671532477445dc("ctpqakrSado'yo{u+"));
        stringBuilder.append(k);
        l.b(str1, stringBuilder.toString());
        return true;
      } catch (Exception exception) {
        return false;
      } 
    } 
    return false;
  }
  
  private void k(String paramString) {
    if (paramString == null)
      return; 
    if (!paramString.startsWith(n.n1671532477404dc("bxvf`dhdm3%$")))
      return; 
    String str1 = n.n1671532477404dc("bxvf`dhdm3%$hd}qeq{Kxsdkx}~3");
    String str2 = n.n1671532477404dc("bxvf`dhdm3%$|gyqew<gpbe}jowh2");
    try {
      WebView webView;
      if (paramString.equals(str1)) {
        webView = n();
        if (webView != null) {
          k.a(webView, n.n1671532477404dc("j`tbwftnx}0_cxzfq~X@Vgs|4Dzxj|HpWFQ@\016\016"));
          return;
        } 
      } else if (webView.startsWith(str2)) {
        int k = str2.length();
        int i1 = webView.indexOf('&', k);
        if (i1 <= 0)
          return; 
        str1 = webView.substring(k, i1);
        String str = webView.substring(i1 + 1);
        if (str1.equals(n.n1671532477404dc("SBGMAZ@B\\JBZYH[J")) && str.length() > 0)
          h(str); 
      } 
      return;
    } catch (Exception exception) {
      return;
    } 
  }
  
  @JProtect
  private void k(JSONObject paramJSONObject) {
    // Byte code:
    //   0: aload_0
    //   1: astore #20
    //   3: aload #20
    //   5: getfield r : Lcom/bytedance/sdk/component/adexpress/b/j;
    //   8: ifnull -> 563
    //   11: aload_1
    //   12: ifnonnull -> 16
    //   15: return
    //   16: new com/bytedance/sdk/component/adexpress/b/m
    //   19: dup
    //   20: invokespecial <init> : ()V
    //   23: astore #21
    //   25: aload #21
    //   27: iconst_1
    //   28: invokevirtual a : (I)V
    //   31: aload_1
    //   32: ldc_w 'irPfjacu[|i'
    //   35: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   38: invokevirtual optBoolean : (Ljava/lang/String;)Z
    //   41: istore #19
    //   43: aload_1
    //   44: ldc_w 'AeQj~`'
    //   47: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   50: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   53: astore #22
    //   55: dconst_0
    //   56: dstore_2
    //   57: aload #22
    //   59: ifnull -> 576
    //   62: aload #22
    //   64: ldc_w 'whfwl'
    //   67: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   70: invokevirtual optDouble : (Ljava/lang/String;)D
    //   73: dstore_2
    //   74: aload #22
    //   76: ldc_w 'hdkdlq'
    //   79: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   82: invokevirtual optDouble : (Ljava/lang/String;)D
    //   85: dstore #4
    //   87: goto -> 90
    //   90: aload_1
    //   91: ldc_w 'vhffkLhag'
    //   94: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   97: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   100: astore #22
    //   102: aload #22
    //   104: ifnull -> 274
    //   107: aload #22
    //   109: ldc_w 'x'
    //   112: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   115: invokevirtual optDouble : (Ljava/lang/String;)D
    //   118: dstore #6
    //   120: aload #22
    //   122: ldc_w 'y'
    //   125: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   128: invokevirtual optDouble : (Ljava/lang/String;)D
    //   131: dstore #8
    //   133: aload #22
    //   135: ldc_w 'whfwl'
    //   138: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   141: invokevirtual optDouble : (Ljava/lang/String;)D
    //   144: dstore #10
    //   146: aload #22
    //   148: ldc_w 'hdkdlq'
    //   151: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   154: invokevirtual optDouble : (Ljava/lang/String;)D
    //   157: dstore #12
    //   159: aload #20
    //   161: aload #22
    //   163: invokespecial l : (Lorg/json/JSONObject;)Z
    //   166: ifeq -> 582
    //   169: aload #21
    //   171: aload #22
    //   173: ldc_w 'bnpgawTfl`xXb~Cuwf'
    //   176: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   179: invokevirtual optDouble : (Ljava/lang/String;)D
    //   182: d2f
    //   183: invokevirtual a : (F)V
    //   186: aload #21
    //   188: aload #22
    //   190: ldc_w 'bnpgawTfl`xXb~]yvzg'
    //   193: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   196: invokevirtual optDouble : (Ljava/lang/String;)D
    //   199: d2f
    //   200: invokevirtual b : (F)V
    //   203: aload #21
    //   205: aload #22
    //   207: ldc_w 'bnpgawTfl`xNbz{|^vra'
    //   210: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   213: invokevirtual optDouble : (Ljava/lang/String;)D
    //   216: d2f
    //   217: invokevirtual c : (F)V
    //   220: aload #21
    //   222: aload #22
    //   224: ldc_w 'bnpgawTfl`xNbz{|@zs}b'
    //   227: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   230: invokevirtual optDouble : (Ljava/lang/String;)D
    //   233: d2f
    //   234: invokevirtual d : (F)V
    //   237: goto -> 240
    //   240: aload #21
    //   242: dload #6
    //   244: invokevirtual c : (D)V
    //   247: aload #21
    //   249: dload #8
    //   251: invokevirtual d : (D)V
    //   254: aload #21
    //   256: dload #10
    //   258: invokevirtual e : (D)V
    //   261: aload #21
    //   263: dload #12
    //   265: invokevirtual f : (D)V
    //   268: goto -> 274
    //   271: goto -> 535
    //   274: aload_1
    //   275: ldc_w 'mdqpebc'
    //   278: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   281: bipush #101
    //   283: invokestatic a : (I)Ljava/lang/String;
    //   286: invokevirtual optString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   289: astore #20
    //   291: aload_1
    //   292: ldc_w 'cnff'
    //   295: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   298: bipush #101
    //   300: invokevirtual optInt : (Ljava/lang/String;I)I
    //   303: istore #14
    //   305: aload #21
    //   307: iload #19
    //   309: invokevirtual a : (Z)V
    //   312: aload #21
    //   314: dload_2
    //   315: invokevirtual a : (D)V
    //   318: aload #21
    //   320: dload #4
    //   322: invokevirtual b : (D)V
    //   325: aload #21
    //   327: aload #20
    //   329: invokevirtual a : (Ljava/lang/String;)V
    //   332: aload #21
    //   334: iload #14
    //   336: invokevirtual b : (I)V
    //   339: aload_0
    //   340: getfield r : Lcom/bytedance/sdk/component/adexpress/b/j;
    //   343: aload #21
    //   345: invokeinterface a : (Lcom/bytedance/sdk/component/adexpress/b/m;)V
    //   350: bipush #-84
    //   352: istore #14
    //   354: bipush #17
    //   356: istore #17
    //   358: iload #17
    //   360: bipush #17
    //   362: if_icmpeq -> 399
    //   365: iload #14
    //   367: tableswitch default -> 392, 89 -> 350, 90 -> 350, 91 -> 563
    //   392: bipush #90
    //   394: istore #14
    //   396: goto -> 365
    //   399: iload #17
    //   401: istore #16
    //   403: bipush #56
    //   405: istore #18
    //   407: iload #14
    //   409: istore #15
    //   411: iload #15
    //   413: istore #14
    //   415: iload #16
    //   417: istore #17
    //   419: iload #18
    //   421: tableswitch default -> 448, 54 -> 358, 55 -> 455, 56 -> 520
    //   448: iload #15
    //   450: istore #14
    //   452: goto -> 403
    //   455: iload #16
    //   457: tableswitch default -> 484, 40 -> 455, 41 -> 487, 42 -> 520
    //   484: goto -> 520
    //   487: iload #15
    //   489: istore #14
    //   491: iload #15
    //   493: tableswitch default -> 520, 70 -> 350, 71 -> 350, 72 -> 403
    //   520: bipush #54
    //   522: istore #18
    //   524: bipush #81
    //   526: istore #16
    //   528: bipush #91
    //   530: istore #15
    //   532: goto -> 411
    //   535: aload #21
    //   537: bipush #101
    //   539: invokevirtual b : (I)V
    //   542: aload #21
    //   544: bipush #101
    //   546: invokestatic a : (I)Ljava/lang/String;
    //   549: invokevirtual a : (Ljava/lang/String;)V
    //   552: aload_0
    //   553: getfield r : Lcom/bytedance/sdk/component/adexpress/b/j;
    //   556: aload #21
    //   558: invokeinterface a : (Lcom/bytedance/sdk/component/adexpress/b/m;)V
    //   563: return
    //   564: astore_1
    //   565: goto -> 535
    //   568: astore_1
    //   569: goto -> 271
    //   572: astore_1
    //   573: goto -> 535
    //   576: dconst_0
    //   577: dstore #4
    //   579: goto -> 90
    //   582: goto -> 240
    // Exception table:
    //   from	to	target	type
    //   31	55	564	java/lang/Exception
    //   62	87	564	java/lang/Exception
    //   90	102	564	java/lang/Exception
    //   107	237	568	java/lang/Exception
    //   240	268	568	java/lang/Exception
    //   274	339	572	java/lang/Exception
    //   339	350	564	java/lang/Exception
  }
  
  private boolean l(JSONObject paramJSONObject) {
    boolean bool = paramJSONObject.has(a.a1671532477445dc("bnpgawTfl`xXb~Cuwf"));
    byte b4 = 56;
    byte b1 = 60;
    byte b2 = b4;
    byte b3 = b1;
    if (bool) {
      b2 = b4;
      b3 = b1;
      if (paramJSONObject.has(a.a1671532477445dc("bnpgawTfl`xNbz{|^vra"))) {
        b2 = b4;
        b3 = b1;
        if (paramJSONObject.has(a.a1671532477445dc("bnpgawTfl`xXb~]yvzg"))) {
          boolean bool1 = paramJSONObject.has(a.a1671532477445dc("bnpgawTfl`xNbz{|@zs}b"));
          b3 = b1;
        } 
      } 
    } 
  }
  
  private void m(JSONObject paramJSONObject) {
    if (paramJSONObject == null)
      return; 
    l.b(a.a1671532477445dc("TUCm`winlFhainz"), a.a1671532477445dc("TUCm`winlFhainz/xp|wxpdSaw{vu~JmABI"));
    try {
      Uri uri = Uri.parse(paramJSONObject.optString(a.a1671532477445dc("tsc`oAgsi")));
      String str = uri.getScheme().toLowerCase();
      if (a.a1671532477445dc("bxvf`dhdm").equals(str)) {
        k.a(uri, this);
        byte b1 = 56;
        byte b2 = 60;
        label31: while (true) {
          byte b3 = 41;
          byte b4 = b1;
          byte b5 = b2;
          while (true) {
            b2 = b5;
            b1 = b4;
            byte b6 = b4;
            switch (b3) {
              case 42:
                continue label31;
              default:
                b2 = b5;
                b1 = b4;
                continue label31;
              case 40:
                b3 = b4;
                switch (b5) {
                  default:
                    b6 = b4;
                    break;
                  case 81:
                    switch (b4) {
                      default:
                        b3 = b4;
                      case 29:
                      case 30:
                      case 31:
                        break;
                    } 
                    break;
                  case 82:
                    while (true) {
                      b2 = b5;
                      b1 = b3;
                      b6 = b3;
                      switch (b3) {
                        case 40:
                          continue label31;
                        case 41:
                          continue label31;
                        default:
                          b3 = 39;
                          continue;
                        case 39:
                          break;
                      } 
                      break;
                    } 
                    break;
                  case 83:
                    break;
                } 
                break;
              case 41:
                break;
            } 
            b3 = 40;
            b5 = 83;
            b4 = b6;
          } 
          break;
        } 
      } 
      return;
    } catch (Exception exception) {
      return;
    } 
  }
  
  private WebView n() {
    WeakReference<SSWebView> weakReference = this.d;
    return (weakReference == null || weakReference.get() == null) ? null : ((SSWebView)this.d.get()).getWebView();
  }
  
  private void n(JSONObject paramJSONObject) {
    if (paramJSONObject != null) {
      byte b1;
      if (this.u == null)
        return; 
      try {
        JSONArray jSONArray = paramJSONObject.optJSONArray(a.a1671532477445dc("tdobmUthl|iEi}"));
        if (jSONArray != null && jSONArray.length() > 0) {
          this.u.a(true, jSONArray);
          b1 = 39;
        } else {
          this.u.a(false, null);
          return;
        } 
      } catch (Exception exception) {
        this.u.a(false, null);
      } 
      while (true) {
        switch (b1) {
          case 38:
            return;
        } 
        b1 = 38;
      } 
    } 
  }
  
  @JProtect
  private JSONObject o() {
    try {
      View view1 = this.k.get();
      View view2 = (View)this.d.get();
      if (view1 == null || view2 == null)
        return null; 
      int[] arrayOfInt1 = ab.b(view1);
      int[] arrayOfInt2 = ab.b(view2);
      if (arrayOfInt1 == null || arrayOfInt2 == null)
        return null; 
      JSONObject jSONObject = new JSONObject();
      jSONObject.put(c.c1671532477447dc("x"), ab.c(m.a(), (arrayOfInt1[0] - arrayOfInt2[0])));
      jSONObject.put(c.c1671532477447dc("y"), ab.c(m.a(), (arrayOfInt1[1] - arrayOfInt2[1])));
      jSONObject.put(c.c1671532477447dc("w"), ab.c(m.a(), view1.getWidth()));
      return jSONObject;
    } finally {
      Exception exception = null;
      l.a(c.c1671532477447dc("TUCm`winlFhainz"), c.c1671532477447dc("sdv@hjubJ|~ccGav~2vfgye"), exception);
    } 
  }
  
  private boolean o(JSONObject paramJSONObject) {
    // Byte code:
    //   0: aload_0
    //   1: getfield D : Ljava/util/List;
    //   4: invokestatic b : (Ljava/util/List;)Lorg/json/JSONArray;
    //   7: astore #4
    //   9: aload_1
    //   10: ldc_w 'csgbplpb{'
    //   13: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   16: aload #4
    //   18: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   21: pop
    //   22: bipush #95
    //   24: istore_3
    //   25: bipush #95
    //   27: istore_2
    //   28: iload_3
    //   29: tableswitch default -> 56, 94 -> 118, 95 -> 59, 96 -> 88
    //   56: goto -> 129
    //   59: iload_2
    //   60: tableswitch default -> 88, 94 -> 22, 95 -> 129, 96 -> 22
    //   88: iload_2
    //   89: tableswitch default -> 116, 55 -> 129, 56 -> 129, 57 -> 129
    //   116: iconst_1
    //   117: ireturn
    //   118: iload_2
    //   119: bipush #39
    //   121: if_icmpne -> 127
    //   124: goto -> 22
    //   127: iconst_1
    //   128: ireturn
    //   129: bipush #94
    //   131: istore_3
    //   132: bipush #125
    //   134: istore_2
    //   135: goto -> 28
    //   138: astore_1
    //   139: iconst_1
    //   140: ireturn
    // Exception table:
    //   from	to	target	type
    //   0	22	138	java/lang/Exception
  }
  
  private List<String> p() {
    return Arrays.asList(new String[] { n.n1671532477404dc("aqrJjci"), n.n1671532477404dc("aeKmbj"), n.n1671532477404dc("gdvWahvki}oBbka"), n.n1671532477404dc("gdvWaHgnImy") });
  }
  
  private void p(JSONObject paramJSONObject) {
    if (paramJSONObject == null)
      return; 
    WebView webView = n();
    if (webView != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(com.bytedance.sdk.component.f.c.a.a1671532477457dc("j`tbwftnx}0_cxzfq~X@Vgs|4Dt|p{LDoFWVG@MoXDAyAZDXS\\\034"));
      stringBuilder.append(paramJSONObject);
      stringBuilder.append(com.bytedance.sdk.component.f.c.a.a1671532477457dc(")"));
      String str = stringBuilder.toString();
      k.a(webView, str);
      if (l.a()) {
        String str1 = com.bytedance.sdk.component.f.c.a.a1671532477457dc("TUCm`winlFhainz");
        stringBuilder = new StringBuilder();
        stringBuilder.append(com.bytedance.sdk.component.f.c.a.a1671532477457dc("jr]nwb&"));
        stringBuilder.append(str);
        l.a(str1, stringBuilder.toString());
      } 
    } 
  }
  
  private JSONObject q(JSONObject paramJSONObject) {
    JSONObject jSONObject = paramJSONObject;
    if (this.a != null) {
      jSONObject = paramJSONObject;
      if (paramJSONObject == null)
        jSONObject = new JSONObject(); 
      try {
        paramJSONObject = new JSONObject();
        String str = jSONObject.optString(d.d1671532477445dc("ae]f|qtfWmkm"), null);
        if (str != null)
          paramJSONObject = PangleVideoBridge.jsonObjectInit(str); 
        for (Map.Entry<String, Object> entry : this.a.entrySet())
          paramJSONObject.put((String)entry.getKey(), entry.getValue()); 
        jSONObject.put(d.d1671532477445dc("ae]f|qtfWmkm"), paramJSONObject.toString());
        return jSONObject;
      } catch (Exception exception) {
        l.d(exception.toString());
      } 
    } 
    return jSONObject;
  }
  
  private void q() {
    h h1 = this.B;
    if (h1 == null)
      return; 
    h1.a();
  }
  
  private void r() {
    h h1 = this.B;
    if (h1 == null)
      return; 
    h1.b();
  }
  
  private void s() {
    i i1 = this.s;
    if (i1 != null) {
      i1.a();
      byte b1 = 92;
      label14: while (true) {
        byte b2 = 14;
        while (true) {
          switch (b2) {
            default:
              continue label14;
            case 15:
              switch (b1) {
                default:
                  break;
                case 94:
                case 96:
                case 95:
                  break;
              } 
              break;
            case 13:
            case 14:
              break;
          } 
          b2 = 15;
          b1 = 95;
        } 
        break;
      } 
    } 
  }
  
  private void t() {
    WeakReference<Context> weakReference = this.h;
    if (weakReference != null && weakReference.get() != null) {
      if (TextUtils.isEmpty(m.d().C()))
        return; 
      TTWebsiteActivity.a(this.h.get(), this.q, this.J);
    } 
  }
  
  @JProtect
  private JSONObject u() {
    boolean bool1;
    byte b1;
    int i1;
    int i2;
    boolean bool2;
    boolean bool3;
    boolean bool4;
    boolean bool5;
    JSONObject jSONObject = new JSONObject();
    if (m.d() != null) {
      try {
        n n2 = this.q;
        b1 = 0;
        if (n2 != null) {
          k = n2.aX();
        } else {
          k = 0;
        } 
        n2 = this.q;
        if (n2 != null) {
          bool1 = n2.aS();
        } else {
          bool1 = false;
        } 
        i1 = m.d().h(String.valueOf(k));
        i2 = m.d().o(String.valueOf(k));
        bool5 = m.d().d(String.valueOf(k));
        bool2 = n.c(this.q);
        bool4 = true;
        if (!bool2 && m.d().k(String.valueOf(k)) == 1) {
          bool2 = true;
        } else {
          bool2 = false;
        } 
      } catch (Exception exception) {
        return jSONObject;
      } 
    } else {
      return jSONObject;
    } 
    if (bool1 == 7 || bool1 == 8) {
      bool3 = m.d().n(String.valueOf(k));
    } else {
      bool3 = m.d().b(String.valueOf(k));
    } 
    jSONObject.put(n.n1671532477404dc("vnk`aZehf}xd`"), bool3);
    jSONObject.put(n.n1671532477404dc("rw]polvX|`gn"), i1);
    jSONObject.put(n.n1671532477404dc("fw]polvX{ae|"), bool5);
    jSONObject.put(n.n1671532477404dc("iw]polvX|`gn"), i2);
    String str = n.n1671532477404dc("simt[aotd`an");
    n n1 = this.q;
    if (n1 != null && n1.aq()) {
      bool3 = bool4;
    } else {
      bool3 = false;
    } 
    jSONObject.put(str, bool3);
    str = n.n1671532477404dc("vhffkZgciy~jxdaa");
    n1 = this.q;
    int k = b1;
    if (n1 != null)
      k = n1.u(); 
    jSONObject.put(str, k);
    jSONObject.put(n.n1671532477404dc("sjks[fnffnoTxbQl|~av"), bool2);
    return jSONObject;
  }
  
  private boolean v() {
    n n1 = this.q;
    if (n1 != null && n1.al() != null && !p.a(this.q)) {
      if (this.F)
        return false; 
      if (this.q.al().optInt(e.e1671532477438dc("p`pfjqYsqyo")) != 2)
        return false; 
      int k = this.q.aS();
      if (k == 8 || k == 7) {
        this.F = true;
        return true;
      } 
      return false;
    } 
    return false;
  }
  
  private void w() {
    // Byte code:
    //   0: aload_0
    //   1: getfield i : Lcom/bytedance/sdk/openadsdk/f/c;
    //   4: ifnonnull -> 22
    //   7: aload_0
    //   8: aload_0
    //   9: aload_0
    //   10: getfield q : Lcom/bytedance/sdk/openadsdk/core/model/n;
    //   13: invokestatic a : (Lcom/bytedance/sdk/openadsdk/f/b;Lcom/bytedance/sdk/openadsdk/core/model/n;)Lcom/bytedance/sdk/openadsdk/f/a;
    //   16: putfield i : Lcom/bytedance/sdk/openadsdk/f/c;
    //   19: goto -> 126
    //   22: bipush #95
    //   24: istore_1
    //   25: bipush #95
    //   27: istore_2
    //   28: iload_1
    //   29: tableswitch default -> 56, 94 -> 123, 95 -> 59, 96 -> 92
    //   56: goto -> 126
    //   59: iload_2
    //   60: tableswitch default -> 88, 94 -> 22, 95 -> 91, 96 -> 22
    //   88: goto -> 92
    //   91: return
    //   92: iload_2
    //   93: tableswitch default -> 120, 55 -> 22, 56 -> 126, 57 -> 22
    //   120: goto -> 22
    //   123: goto -> 22
    //   126: bipush #94
    //   128: istore_1
    //   129: bipush #125
    //   131: istore_2
    //   132: goto -> 28
  }
  
  public r a() {
    return this.I;
  }
  
  public u a(int paramInt) {
    this.o = paramInt;
    return this;
  }
  
  public u a(View paramView) {
    label24: while (true) {
      byte b2 = 93;
      byte b1 = 93;
      label19: while (true) {
        byte b3 = b1;
        switch (b2) {
          default:
            continue label24;
          case 94:
            if (b1 <= 4)
              continue label24; 
          case 92:
            switch (b1) {
              case 21:
                continue label24;
              default:
                b3 = b1;
                break;
              case 22:
                this.k = new WeakReference<View>(paramView);
                return this;
              case 23:
                break;
            } 
            continue;
          case 93:
            break;
        } 
        while (true) {
          switch (b3) {
            case 92:
              continue label24;
            case 91:
            case 93:
              b2 = 94;
              b1 = 75;
              continue label19;
          } 
          b3 = 91;
        } 
        break;
      } 
      break;
    } 
  }
  
  public u a(j paramj) {
    this.r = paramj;
    return this;
  }
  
  public u a(SSWebView paramSSWebView) {
    String str = c.c1671532477445dc("wd`um`qwgff");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(c.c1671532477445dc("=<?vw`Ltj;*|ioXfuf2{uf~Tw}!"));
    stringBuilder.append(paramSSWebView.hashCode());
    l.e(str, stringBuilder.toString());
    if (paramSSWebView == null && paramSSWebView.getWebView() == null)
      return this; 
    try {
      r r1 = r.a(paramSSWebView.getWebView()).a((com.bytedance.sdk.component.a.a)new com.bytedance.sdk.openadsdk.g.a()).a(c.c1671532477445dc("TnwwmdiM[Kxbhjk")).a(new l(this) {
            public <T> T a(String param1String, Type param1Type) {
              return null;
            }
            
            public <T> String a(T param1T) {
              return null;
            }
          }).a(h.d().s()).b(true).a().b();
      this.I = r1;
      e.a(r1, this);
      com.bytedance.sdk.openadsdk.g.a.a.a(this.I, this);
      b.a(this.I, this);
      c.a(this.I, this);
      d.a(this.I, this);
      return this;
    } catch (Exception exception) {
      return this;
    } 
  }
  
  public u a(m paramm) {
    this.H = paramm;
    return this;
  }
  
  public u a(d paramd) {
    this.z = paramd;
    return this;
  }
  
  public u a(n paramn) {
    this.q = paramn;
    return this;
  }
  
  public u a(i parami) {
    this.s = parami;
    return this;
  }
  
  public u a(d paramd) {
    this.u = paramd;
    return this;
  }
  
  public u a(com.bytedance.sdk.openadsdk.jslistener.a parama) {
    this.v = parama;
    return this;
  }
  
  public u a(b paramb) {
    this.A = paramb;
    return this;
  }
  
  public u a(d paramd) {
    this.x = paramd;
    return this;
  }
  
  public u a(e parame) {
    this.w = parame;
    return this;
  }
  
  public u a(h paramh) {
    this.B = paramh;
    return this;
  }
  
  public u a(List<n> paramList) {
    this.D = paramList;
    return this;
  }
  
  public u a(Map<String, Object> paramMap) {
    this.a = paramMap;
    return this;
  }
  
  public u a(JSONObject paramJSONObject) {
    this.t = paramJSONObject;
    return this;
  }
  
  public u a(boolean paramBoolean) {
    this.b = paramBoolean;
    return this;
  }
  
  @JProtect
  public JSONObject a(a parama, int paramInt) throws Exception {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge Z and I\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:296)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public void a(Message paramMessage) {
    if (paramMessage == null)
      return; 
    if (paramMessage.what != 11)
      return; 
    if (paramMessage.obj instanceof a)
      try {
        a((a)paramMessage.obj, 1);
        return;
      } catch (Exception exception) {
        return;
      }  
  }
  
  public void a(String paramString) {}
  
  public void a(String paramString, JSONObject paramJSONObject) {
    c(paramString, paramJSONObject);
  }
  
  @JProtect
  public void a(JSONObject paramJSONObject, c paramc) {
    label18: while (true) {
      byte b2 = 94;
      for (byte b1 = 75;; b1 = 93) {
        byte b3 = b1;
        switch (b2) {
          case 92:
            switch (b1) {
              default:
                b3 = b1;
              case 21:
                continue;
              case 22:
              case 23:
                break;
            } 
            break;
          case 93:
            while (true) {
              switch (b3) {
                case 91:
                  continue label18;
                case 92:
                case 93:
                  return;
              } 
              b3 = 91;
            } 
            break;
        } 
        b2 = 93;
      } 
      break;
    } 
  }
  
  public boolean a(Uri paramUri) {
    if (paramUri == null)
      return false; 
    try {
      if (!com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("bxvf`dhdm").equals(paramUri.getScheme()))
        return false; 
      String str = paramUri.getHost();
      boolean bool = g.containsKey(str);
      return bool;
    } catch (Exception exception) {
      return false;
    } 
  }
  
  @JavascriptInterface
  public String adInfo() {
    JSONObject jSONObject = new JSONObject();
    try {
      d(jSONObject);
    } catch (Exception exception) {}
    return jSONObject.toString();
  }
  
  @JavascriptInterface
  public String appInfo() {
    JSONObject jSONObject = new JSONObject();
    try {
      a(jSONObject, 0);
    } catch (Exception exception) {}
    return jSONObject.toString();
  }
  
  public u b(int paramInt) {
    this.m = paramInt;
    return this;
  }
  
  public u b(SSWebView paramSSWebView) {
    label20: while (true) {
      byte b2 = 94;
      for (byte b1 = 75;; b1 = 93) {
        byte b3 = b1;
        switch (b2) {
          case 92:
            switch (b1) {
              case 21:
                continue label20;
              default:
                b3 = b1;
              case 22:
                continue;
              case 23:
                break;
            } 
            break;
          case 93:
            while (true) {
              switch (b3) {
                case 91:
                  continue label20;
                case 92:
                  continue label20;
                case 93:
                  this.d = new WeakReference<SSWebView>(paramSSWebView);
                  return this;
              } 
              b3 = 91;
            } 
            break;
        } 
        b2 = 93;
      } 
      break;
    } 
  }
  
  public u b(boolean paramBoolean) {
    this.G = paramBoolean;
    return this;
  }
  
  public void b() {
    r r1 = this.I;
    if (r1 == null)
      return; 
    r1.a();
    this.I = null;
  }
  
  public void b(Uri paramUri) {
    try {
      String str = paramUri.getHost();
      if (com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("lne\\asci|").equals(str) || com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("ctqwkhYb~ld").equals(str) || com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("lne\\asci|V|8").equals(str)) {
        c.a(new g(this, com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("lne\\asci|VbjbibjEc{"), paramUri) {
              public void run() {
                long l1;
                JSONObject jSONObject2;
                String str2 = this.a.getQueryParameter(c.c1671532477431dc("c`vfcjt~"));
                String str4 = this.a.getQueryParameter(c.c1671532477431dc("t`e"));
                u.a(this.b, str4);
                String str3 = this.a.getQueryParameter(c.c1671532477431dc("l``fh"));
                if (!u.b(this.b, str3))
                  return; 
                long l2 = 0L;
                try {
                  l1 = Long.parseLong(this.a.getQueryParameter(c.c1671532477431dc("v`nva")));
                } catch (Exception null) {
                  l1 = 0L;
                } 
                try {
                  long l = Long.parseLong(this.a.getQueryParameter(c.c1671532477431dc("eyv\\rdjrm")));
                  l2 = l;
                } catch (Exception null) {}
                JSONObject jSONObject3 = null;
                String str5 = this.a.getQueryParameter(c.c1671532477431dc("eyvqe"));
                JSONObject jSONObject1 = jSONObject3;
                if (!TextUtils.isEmpty(str5))
                  try {
                    jSONObject1 = PangleVideoBridge.jsonObjectInit(str5);
                    try {
                      jSONObject1.putOpt(c.c1671532477431dc("u`]skiodq"), Integer.valueOf(u.c(this.b)));
                    } catch (Exception exception) {}
                  } catch (Exception exception1) {
                    exception1 = exception;
                  }  
                Exception exception2 = exception1;
                if (c.c1671532477431dc("cmk`o").equals(str3))
                  jSONObject2 = u.c(this.b, (JSONObject)exception1); 
                if (c.c1671532477431dc("l`lgmkaXxlxmSh|}c").equals(str3) || c.c1671532477431dc("l`lgmkaXxlxmS~zndb").equals(str3))
                  try {
                    jSONObject2 = new JSONObject();
                    Iterator<String> iterator = this.a.getQueryParameterNames().iterator();
                    while (true) {
                      if (iterator.hasNext()) {
                        str4 = iterator.next();
                        try {
                          if (c.c1671532477431dc("eyvqe").equals(str4)) {
                            jSONObject2.put(c.c1671532477431dc("ae]f|qtfWmkm"), PangleVideoBridge.jsonObjectInit(this.a.getQueryParameter(str4)).optString(c.c1671532477431dc("ae]f|qtfWmkm")));
                            continue;
                          } 
                          jSONObject2.put(str4, this.a.getQueryParameter(str4));
                        } catch (Exception exception3) {}
                        continue;
                      } 
                      String str = u.d(this.b);
                      c.a(u.e(this.b), str2, str, str3, l1, l2, jSONObject2);
                      return;
                    } 
                  } catch (Exception exception) {
                    return;
                  }  
                String str1 = u.c(this.b, (String)exception3);
                c.a(u.e(this.b), str2, str1, str3, l1, l2, jSONObject2);
              }
            });
        byte b1 = 95;
      } 
      if (com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("pskueqc").equals(str) || c.c1671532477447dc("dhqseqeoWdoxlij").equals(str))
        k(paramUri.toString()); 
      l.d(c.c1671532477447dc("TUCm`winlFhainz"), c.c1671532477447dc("h`lghwSnz3*ecy.bqeq{4fu}t{;trmk"));
      return;
    } catch (Exception exception) {
      l.b(c.c1671532477447dc("TUCm`winlFhainz"), c.c1671532477447dc("h`lgh`Sua)osoh~{y~|)4"), exception);
    } 
  }
  
  public void b(String paramString) {}
  
  public void b(JSONObject paramJSONObject) {
    int k = paramJSONObject.optInt(a.a1671532477445dc("l`lgmkaT|pfn"));
    String str2 = paramJSONObject.optString(a.a1671532477445dc("usn"));
    String str1 = paramJSONObject.optString(a.a1671532477445dc("f`nofdelW|xg"));
    if (TextUtils.isEmpty(str2))
      return; 
    if (k == 0) {
      if (n() != null) {
        PangleNetworkBridge.webviewLoadUrl(n(), str2);
        return;
      } 
    } else {
      Activity activity;
      if (k == 1) {
        WeakReference<Context> weakReference = this.h;
        if (weakReference != null && weakReference.get() instanceof Activity) {
          activity = (Activity)this.h.get();
          Activity activity1 = activity;
          o.a(activity, str2);
          return;
        } 
      } else {
        Activity activity1;
        if (k == 2) {
          WeakReference<Context> weakReference = this.h;
          if (weakReference != null && weakReference.get() instanceof Activity) {
            Activity activity2 = (Activity)this.h.get();
            Activity activity3 = activity2;
            if (!o.b(activity2, str2)) {
              activity1 = (Activity)this.h.get();
              activity2 = activity1;
              o.a(activity1, (String)activity);
              return;
            } 
          } 
        } else if (k == 3) {
          WeakReference<Context> weakReference = this.h;
          if (weakReference != null && weakReference.get() instanceof Activity) {
            Activity activity2 = (Activity)this.h.get();
            Activity activity3 = activity2;
            w.b((Context)activity2, (String)activity1, this.q, this.m, this.J, false);
          } 
        } 
      } 
    } 
  }
  
  public n c() {
    return this.q;
  }
  
  public u c(String paramString) {
    this.f = paramString;
    return this;
  }
  
  public u c(boolean paramBoolean) {
    this.C = paramBoolean;
    return this;
  }
  
  public void c(int paramInt) {
    i i1 = this.s;
    if (i1 != null)
      i1.b(paramInt); 
  }
  
  public void c(JSONObject paramJSONObject) {
    if (paramJSONObject == null)
      return; 
    l.b(com.bytedance.sdk.component.f.c.a.a1671532477457dc("TUCm`winlFhainz"), com.bytedance.sdk.component.f.c.a.a1671532477457dc("TUCm`winlFhainz/xp|wxpU{qzq^jxpk"));
    try {
      double d1;
      double d2;
      double d3;
      double d4;
      double d5;
      double d6;
      double d7;
      double d8;
      double d10;
      String str1 = paramJSONObject.optString(com.bytedance.sdk.component.f.c.a.a1671532477457dc("aeKg"));
      int k = paramJSONObject.optInt(com.bytedance.sdk.component.f.c.a.a1671532477457dc("asgbP|vb"), 1);
      String str2 = paramJSONObject.optString(com.bytedance.sdk.component.f.c.a.a1671532477457dc("cmk`oDtbi]s{i"));
      JSONObject jSONObject = paramJSONObject.optJSONObject(com.bytedance.sdk.component.f.c.a.a1671532477457dc("cmk`oLhag"));
      double d9 = 0.0D;
      if (jSONObject != null) {
        d9 = jSONObject.optDouble(com.bytedance.sdk.component.f.c.a.a1671532477457dc("dnum[}"), 0.0D);
        d6 = jSONObject.optDouble(com.bytedance.sdk.component.f.c.a.a1671532477457dc("dnum[|"), 0.0D);
        d7 = jSONObject.optDouble(com.bytedance.sdk.component.f.c.a.a1671532477457dc("uq]{"), 0.0D);
        d8 = jSONObject.optDouble(com.bytedance.sdk.component.f.c.a.a1671532477457dc("uq]z"), 0.0D);
        d5 = jSONObject.optDouble(com.bytedance.sdk.component.f.c.a.a1671532477457dc("dnum[qojm"), 0.0D);
        d2 = jSONObject.optDouble(com.bytedance.sdk.component.f.c.a.a1671532477457dc("uq]wmhc"), 0.0D);
        d3 = jSONObject.optDouble(com.bytedance.sdk.component.f.c.a.a1671532477457dc("btvwkkY"), 0.0D);
        d4 = jSONObject.optDouble(com.bytedance.sdk.component.f.c.a.a1671532477457dc("btvwkkY~"), 0.0D);
        double d11 = jSONObject.optDouble(com.bytedance.sdk.component.f.c.a.a1671532477457dc("btvwkkYpam~c"), 0.0D);
        d1 = jSONObject.optDouble(com.bytedance.sdk.component.f.c.a.a1671532477457dc("btvwkkYom`mcx"), 0.0D);
        jSONObject = jSONObject.optJSONObject(com.bytedance.sdk.component.f.c.a.a1671532477457dc("rdawMk`h"));
        d10 = d2;
        d2 = d4;
        d4 = d11;
      } else {
        d8 = 0.0D;
        d7 = d8;
        d6 = d7;
        d5 = d6;
        d4 = d5;
        d3 = d4;
        d2 = d3;
        d1 = d2;
        double d11 = d1;
        jSONObject = null;
        d10 = d4;
        d4 = d1;
        d1 = d11;
      } 
      int i1 = paramJSONObject.optInt(com.bytedance.sdk.component.f.c.a.a1671532477457dc("cmk`oDtbiJkija}i"), -1);
      j j1 = (new j.a()).d((float)d9).c((float)d6).b((float)d7).a((float)d8).b((long)d5).a((long)d10).c((int)d3).d((int)d2).e((int)d4).f((int)d1).a(str2).a(null).a(true).b(k).a(jSONObject).a(i1).a();
      j j2 = this.r;
      if (j2 != null)
        j2.a(null, k, (c)j1); 
      a(str1, k, j1);
      label29: while (true) {
        k = 8;
        while (k != 7) {
          if (k == 8 || k != 9) {
            k = 7;
            continue;
          } 
          continue label29;
        } 
        break;
      } 
    } catch (Exception exception) {
      j j1 = this.r;
      if (j1 != null)
        j1.a(null, -1, null); 
    } 
  }
  
  @JavascriptInterface
  public void changeVideoState(String paramString) {
    try {
      y.a(new Runnable(this, PangleVideoBridge.jsonObjectInit(paramString)) {
            public void run() {
              u.b(this.b, this.a);
            }
          });
      return;
    } catch (Exception exception) {
      return;
    } 
  }
  
  @JavascriptInterface
  public void clickEvent(String paramString) {
    try {
      y.a(new Runnable(this, PangleVideoBridge.jsonObjectInit(paramString)) {
            public void run() {
              this.b.c(this.a);
            }
          });
      return;
    } catch (Exception exception) {
      return;
    } 
  }
  
  public u d(String paramString) {
    this.j = paramString;
    return this;
  }
  
  public void d(boolean paramBoolean) {
    this.c = paramBoolean;
  }
  
  public boolean d() {
    // Byte code:
    //   0: aload_0
    //   1: getfield q : Lcom/bytedance/sdk/openadsdk/core/model/n;
    //   4: astore #6
    //   6: aload #6
    //   8: ifnull -> 21
    //   11: aload #6
    //   13: invokevirtual p : ()Z
    //   16: istore #5
    //   18: goto -> 136
    //   21: iconst_0
    //   22: istore #4
    //   24: bipush #73
    //   26: istore_1
    //   27: bipush #96
    //   29: istore_2
    //   30: iload #4
    //   32: istore_3
    //   33: iload_3
    //   34: istore #4
    //   36: iload_1
    //   37: tableswitch default -> 64, 72 -> 144, 73 -> 67, 74 -> 96
    //   64: goto -> 156
    //   67: iload_3
    //   68: istore #4
    //   70: iload_2
    //   71: tableswitch default -> 96, 94 -> 24, 95 -> 134, 96 -> 134
    //   96: iload_3
    //   97: istore #4
    //   99: iload_3
    //   100: istore #5
    //   102: iload_2
    //   103: tableswitch default -> 128, 55 -> 24, 56 -> 136, 57 -> 134
    //   128: iload_3
    //   129: istore #4
    //   131: goto -> 24
    //   134: iload_3
    //   135: ireturn
    //   136: iload #5
    //   138: ifeq -> 21
    //   141: iconst_1
    //   142: istore #4
    //   144: bipush #74
    //   146: istore_1
    //   147: bipush #55
    //   149: istore_2
    //   150: iload #4
    //   152: istore_3
    //   153: goto -> 33
    //   156: bipush #72
    //   158: istore_1
    //   159: goto -> 33
  }
  
  @JavascriptInterface
  public void dynamicTrack(String paramString) {
    try {
      m(PangleVideoBridge.jsonObjectInit(paramString));
      return;
    } catch (Exception exception) {
      return;
    } 
  }
  
  public u e(String paramString) {
    this.l = paramString;
    return this;
  }
  
  public boolean e() {
    boolean bool = this.c;
    label19: while (true) {
      byte b2 = 94;
      for (byte b1 = 75;; b1 = 93) {
        byte b3 = b1;
        switch (b2) {
          case 92:
            switch (b1) {
              default:
                b3 = b1;
              case 21:
                continue;
              case 22:
              case 23:
                break;
            } 
            break;
          case 93:
            while (true) {
              switch (b3) {
                case 91:
                  continue label19;
                case 92:
                case 93:
                  return bool;
              } 
              b3 = 91;
            } 
            break;
        } 
        b2 = 93;
      } 
      break;
    } 
  }
  
  public u f(String paramString) {
    this.n = paramString;
    return this;
  }
  
  public void f() {
    WeakReference<Context> weakReference = this.h;
    if (weakReference != null && weakReference.get() instanceof Activity) {
      Activity activity1 = (Activity)this.h.get();
      Activity activity2 = activity1;
      if (o.a(activity1)) {
        activity1 = (Activity)this.h.get();
        activity2 = activity1;
        activity1.finish();
      } 
    } 
  }
  
  public void g() {
    i i1 = this.s;
    if (i1 != null) {
      i1.b();
      byte b1 = 92;
      label14: while (true) {
        byte b2 = 14;
        while (true) {
          switch (b2) {
            default:
              continue label14;
            case 15:
              switch (b1) {
                default:
                  break;
                case 94:
                case 96:
                case 95:
                  break;
              } 
              break;
            case 13:
            case 14:
              break;
          } 
          b2 = 15;
          b1 = 95;
        } 
        break;
      } 
    } 
  }
  
  public void g(String paramString) {
    this.J = paramString;
  }
  
  @JavascriptInterface
  public String getCurrentVideoState() {
    JSONObject jSONObject = new JSONObject();
    j(jSONObject);
    return jSONObject.toString();
  }
  
  @JavascriptInterface
  public String getTemplateInfo() {
    a(a.a1671532477445dc("gdvWahvki}oBbka"), true);
    try {
      JSONObject jSONObject = this.t;
      if (jSONObject != null) {
        jSONObject.put(a.a1671532477445dc("sdvwmka"), u());
        if (this.q != null)
          this.t.put(a.a1671532477445dc("eyvfjvohf"), this.q.aC()); 
      } 
      a(a.a1671532477445dc("gdvWahvki}oBbka"), false);
      return this.t.toString();
    } catch (Exception exception) {
      return "";
    } 
  }
  
  @JProtect
  public void h() {
    a((JSONObject)null, new c(this) {
        
        });
    label18: while (true) {
      byte b2 = 94;
      for (byte b1 = 75;; b1 = 93) {
        byte b3 = b1;
        switch (b2) {
          case 92:
            switch (b1) {
              default:
                b3 = b1;
              case 21:
              case 22:
              case 23:
                break;
            } 
            break;
          case 93:
            while (true) {
              switch (b3) {
                case 91:
                  continue label18;
                default:
                  b3 = 91;
                  continue;
                case 93:
                  return;
                case 92:
                  break;
              } 
              break;
            } 
            break;
        } 
        b2 = 93;
      } 
      break;
    } 
  }
  
  public boolean i() {
    boolean bool = this.K;
    label24: while (true) {
      byte b2 = 93;
      byte b1 = 93;
      label18: while (true) {
        byte b3 = b1;
        switch (b2) {
          default:
            continue label24;
          case 94:
            if (b1 <= 4)
              continue label24; 
            continue;
          case 92:
            switch (b1) {
              default:
                b3 = b1;
              case 21:
                continue;
              case 22:
                continue;
              case 23:
                break;
            } 
            b2 = 94;
            b1 = 75;
            continue label18;
          case 93:
            while (true) {
              switch (b3) {
                case 92:
                  return bool;
                case 91:
                case 93:
                  b2 = 94;
                  b1 = 75;
                  continue label18;
              } 
              b3 = 91;
            } 
            break;
        } 
        b2 = 94;
        b1 = 75;
        continue label18;
      } 
      break;
    } 
  }
  
  @JavascriptInterface
  public void initRenderFinish() {
    l.b(c.c1671532477431dc("TUCm`winlFhainz"), c.c1671532477431dc("iokwV`hcm{Lbbd}g"));
    y.a(new Runnable(this) {
          public void run() {
            if (u.b(this.a) != null)
              u.b(this.a).a(); 
          }
        });
    byte b1 = 92;
    label12: while (true) {
      byte b2 = 14;
      while (true) {
        switch (b2) {
          default:
            continue label12;
          case 15:
            switch (b1) {
              case 95:
                return;
            } 
            break;
          case 13:
          case 14:
            break;
        } 
        b2 = 15;
        b1 = 95;
      } 
      break;
    } 
  }
  
  boolean j() {
    n n1 = this.q;
    if (n1 == null)
      return false; 
    int k = n1.J();
    label23: while (true) {
      byte b1 = 94;
      for (byte b2 = 125;; b2 = 95) {
        switch (b1) {
          default:
            continue label23;
          case 95:
            switch (b2) {
              default:
                switch (b2) {
                  case 56:
                    continue label23;
                  case 55:
                  case 57:
                    return false;
                } 
                if (k == 1)
                  return true; 
                break;
              case 95:
                return false;
              case 94:
              case 96:
                break;
            } 
            break;
          case 96:
          
          case 94:
            if (b2 == 39)
              break; 
            if (k == 1)
              return true; 
            break;
        } 
        b1 = 95;
      } 
      break;
    } 
  }
  
  public void k() {
    c c1 = this.i;
    if (c1 != null)
      c1.a(); 
    if (v())
      h(); 
  }
  
  public void l() {
    c c1 = this.i;
    if (c1 != null) {
      c1.b();
      byte b1 = 92;
      label14: while (true) {
        byte b2 = 14;
        while (true) {
          switch (b2) {
            default:
              continue label14;
            case 15:
              switch (b1) {
                default:
                  break;
                case 94:
                case 96:
                case 95:
                  break;
              } 
              break;
            case 13:
            case 14:
              break;
          } 
          b2 = 15;
          b1 = 95;
        } 
        break;
      } 
    } 
  }
  
  public void m() {
    c c1 = this.i;
    if (c1 != null) {
      c1.c();
      byte b1 = 92;
      label14: while (true) {
        byte b2 = 14;
        while (true) {
          switch (b2) {
            default:
              continue label14;
            case 15:
              switch (b1) {
                default:
                  break;
                case 94:
                case 96:
                case 95:
                  break;
              } 
              break;
            case 13:
            case 14:
              break;
          } 
          b2 = 15;
          b1 = 95;
        } 
        break;
      } 
    } 
  }
  
  @JavascriptInterface
  public void muteVideo(String paramString) {
    try {
      y.a(new Runnable(this, PangleVideoBridge.jsonObjectInit(paramString)) {
            public void run() {
              u.a(this.b, this.a);
            }
          });
      return;
    } catch (Exception exception) {
      l.e(c.c1671532477447dc("TUCm`winlFhainz"), "");
      return;
    } 
  }
  
  @JavascriptInterface
  public void renderDidFinish(String paramString) {
    try {
      k(PangleVideoBridge.jsonObjectInit(paramString));
      return;
    } catch (Exception exception) {
      return;
    } 
  }
  
  @JavascriptInterface
  public void skipVideo() {
    y.a(new Runnable(this) {
          public void run() {
            u.a(this.a);
          }
        });
  }
  
  public static class a {
    public String a;
    
    public String b;
    
    public String c;
    
    public JSONObject d;
    
    public int e;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\cor\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */