package com.bytedance.sdk.openadsdk;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface IAppOpenAdInteractionListener extends IInterface {
  void onAdClicked() throws RemoteException;
  
  void onAdShow() throws RemoteException;
  
  void onAdSkip() throws RemoteException;
  
  void onAdTimeOver() throws RemoteException;
  
  void onDestroy() throws RemoteException;
  
  public static class Default implements IAppOpenAdInteractionListener {
    public IBinder asBinder() {
      return null;
    }
    
    public void onAdClicked() throws RemoteException {}
    
    public void onAdShow() throws RemoteException {}
    
    public void onAdSkip() throws RemoteException {}
    
    public void onAdTimeOver() throws RemoteException {}
    
    public void onDestroy() throws RemoteException {}
  }
  
  public static abstract class Stub extends Binder implements IAppOpenAdInteractionListener {
    public Stub() {
      attachInterface(this, "com.bytedance.sdk.openadsdk.IAppOpenAdInteractionListener");
    }
    
    public static IAppOpenAdInteractionListener asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.bytedance.sdk.openadsdk.IAppOpenAdInteractionListener");
      return (iInterface != null && iInterface instanceof IAppOpenAdInteractionListener) ? (IAppOpenAdInteractionListener)iInterface : new a(param1IBinder);
    }
    
    public static IAppOpenAdInteractionListener getDefaultImpl() {
      return a.a;
    }
    
    public static boolean setDefaultImpl(IAppOpenAdInteractionListener param1IAppOpenAdInteractionListener) {
      if (a.a == null && param1IAppOpenAdInteractionListener != null) {
        a.a = param1IAppOpenAdInteractionListener;
        return true;
      } 
      return false;
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      if (param1Int1 != 1) {
        if (param1Int1 != 2) {
          if (param1Int1 != 3) {
            if (param1Int1 != 4) {
              if (param1Int1 != 5) {
                if (param1Int1 != 1598968902)
                  return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
                param1Parcel2.writeString("com.bytedance.sdk.openadsdk.IAppOpenAdInteractionListener");
                return true;
              } 
              param1Parcel1.enforceInterface("com.bytedance.sdk.openadsdk.IAppOpenAdInteractionListener");
              onAdTimeOver();
              param1Parcel2.writeNoException();
              return true;
            } 
            param1Parcel1.enforceInterface("com.bytedance.sdk.openadsdk.IAppOpenAdInteractionListener");
            onAdSkip();
            param1Parcel2.writeNoException();
            return true;
          } 
          param1Parcel1.enforceInterface("com.bytedance.sdk.openadsdk.IAppOpenAdInteractionListener");
          onAdClicked();
          param1Parcel2.writeNoException();
          return true;
        } 
        param1Parcel1.enforceInterface("com.bytedance.sdk.openadsdk.IAppOpenAdInteractionListener");
        onAdShow();
        param1Parcel2.writeNoException();
        return true;
      } 
      param1Parcel1.enforceInterface("com.bytedance.sdk.openadsdk.IAppOpenAdInteractionListener");
      onDestroy();
      param1Parcel2.writeNoException();
      return true;
    }
    
    private static class a implements IAppOpenAdInteractionListener {
      public static IAppOpenAdInteractionListener a;
      
      private IBinder b;
      
      a(IBinder param2IBinder) {
        this.b = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.b;
      }
      
      public void onAdClicked() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.bytedance.sdk.openadsdk.IAppOpenAdInteractionListener");
          if (!this.b.transact(3, parcel1, parcel2, 0) && IAppOpenAdInteractionListener.Stub.getDefaultImpl() != null) {
            IAppOpenAdInteractionListener.Stub.getDefaultImpl().onAdClicked();
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void onAdShow() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.bytedance.sdk.openadsdk.IAppOpenAdInteractionListener");
          if (!this.b.transact(2, parcel1, parcel2, 0) && IAppOpenAdInteractionListener.Stub.getDefaultImpl() != null) {
            IAppOpenAdInteractionListener.Stub.getDefaultImpl().onAdShow();
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void onAdSkip() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.bytedance.sdk.openadsdk.IAppOpenAdInteractionListener");
          if (!this.b.transact(4, parcel1, parcel2, 0) && IAppOpenAdInteractionListener.Stub.getDefaultImpl() != null) {
            IAppOpenAdInteractionListener.Stub.getDefaultImpl().onAdSkip();
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void onAdTimeOver() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.bytedance.sdk.openadsdk.IAppOpenAdInteractionListener");
          if (!this.b.transact(5, parcel1, parcel2, 0) && IAppOpenAdInteractionListener.Stub.getDefaultImpl() != null) {
            IAppOpenAdInteractionListener.Stub.getDefaultImpl().onAdTimeOver();
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void onDestroy() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.bytedance.sdk.openadsdk.IAppOpenAdInteractionListener");
          if (!this.b.transact(1, parcel1, parcel2, 0) && IAppOpenAdInteractionListener.Stub.getDefaultImpl() != null) {
            IAppOpenAdInteractionListener.Stub.getDefaultImpl().onDestroy();
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class a implements IAppOpenAdInteractionListener {
    public static IAppOpenAdInteractionListener a;
    
    private IBinder b;
    
    a(IBinder param1IBinder) {
      this.b = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.b;
    }
    
    public void onAdClicked() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.bytedance.sdk.openadsdk.IAppOpenAdInteractionListener");
        if (!this.b.transact(3, parcel1, parcel2, 0) && IAppOpenAdInteractionListener.Stub.getDefaultImpl() != null) {
          IAppOpenAdInteractionListener.Stub.getDefaultImpl().onAdClicked();
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void onAdShow() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.bytedance.sdk.openadsdk.IAppOpenAdInteractionListener");
        if (!this.b.transact(2, parcel1, parcel2, 0) && IAppOpenAdInteractionListener.Stub.getDefaultImpl() != null) {
          IAppOpenAdInteractionListener.Stub.getDefaultImpl().onAdShow();
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void onAdSkip() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.bytedance.sdk.openadsdk.IAppOpenAdInteractionListener");
        if (!this.b.transact(4, parcel1, parcel2, 0) && IAppOpenAdInteractionListener.Stub.getDefaultImpl() != null) {
          IAppOpenAdInteractionListener.Stub.getDefaultImpl().onAdSkip();
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void onAdTimeOver() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.bytedance.sdk.openadsdk.IAppOpenAdInteractionListener");
        if (!this.b.transact(5, parcel1, parcel2, 0) && IAppOpenAdInteractionListener.Stub.getDefaultImpl() != null) {
          IAppOpenAdInteractionListener.Stub.getDefaultImpl().onAdTimeOver();
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void onDestroy() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.bytedance.sdk.openadsdk.IAppOpenAdInteractionListener");
        if (!this.b.transact(1, parcel1, parcel2, 0) && IAppOpenAdInteractionListener.Stub.getDefaultImpl() != null) {
          IAppOpenAdInteractionListener.Stub.getDefaultImpl().onDestroy();
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\IAppOpenAdInteractionListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */