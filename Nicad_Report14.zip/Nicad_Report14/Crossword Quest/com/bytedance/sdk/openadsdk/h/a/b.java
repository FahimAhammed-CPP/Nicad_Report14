package com.bytedance.sdk.openadsdk.h.a;

import android.os.Build;
import android.text.TextUtils;
import com.bytedance.JProtect;
import com.bytedance.sdk.component.adexpress.a.c.c;
import com.bytedance.sdk.component.utils.o;
import com.bytedance.sdk.openadsdk.component.reward.n;
import com.bytedance.sdk.openadsdk.core.h;
import com.bytedance.sdk.openadsdk.core.m;
import com.bytedance.sdk.openadsdk.core.model.d;
import com.bytedance.sdk.openadsdk.l.aa;
import org.json.JSONObject;

public class b<T extends b> implements a {
  private String a;
  
  private String b;
  
  private String c;
  
  private String d = c.c1671532477445dc("4/;-4+0");
  
  private long e = System.currentTimeMillis() / 1000L;
  
  private int f = 0;
  
  private String g;
  
  private int h = 0;
  
  private String i;
  
  private String j;
  
  private String k;
  
  private String l;
  
  public static b<b> b() {
    return new b<b>();
  }
  
  @JProtect
  private JSONObject o() {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put(n.n1671532477404dc("or"), 1);
      jSONObject.put(n.n1671532477404dc("mnffh"), Build.MODEL);
      jSONObject.put(n.n1671532477404dc("vdlgkw"), Build.MANUFACTURER);
      jSONObject.put(n.n1671532477404dc("p`ahebcXfhgn"), aa.e());
      jSONObject.put(n.n1671532477404dc("u`"), aa.c());
      return jSONObject;
    } finally {
      Exception exception = null;
    } 
  }
  
  private T p() {
    return (T)this;
  }
  
  public T a(int paramInt) {
    this.f = paramInt;
    return p();
  }
  
  public T a(String paramString) {
    this.a = paramString;
    return p();
  }
  
  @JProtect
  public JSONObject a() {
    label37: while (true) {
      for (byte b1 = 62;; b1 = 64) {
        JSONObject jSONObject;
        switch (b1) {
          default:
            continue label37;
          case 64:
            jSONObject = new JSONObject();
            try {
              String str1;
              jSONObject.put(c.c1671532477445dc("ae]p`nYqm{ybcc"), g());
              jSONObject.put(c.c1671532477445dc("aqr\\r`ttafd"), aa.g());
              jSONObject.put(d.d1671532477445dc("thofwqgjx"), h());
              jSONObject.put(d.d1671532477445dc("cnlm[qwm"), o.b(m.a()));
              String str2 = d.d1671532477445dc("aqrj`");
              if (TextUtils.isEmpty(h.d().f())) {
                str1 = "";
              } else {
                str1 = h.d().f();
              } 
              jSONObject.put(str2, str1);
              jSONObject.put(d.d1671532477445dc("ddtjg`Ynfoe"), o());
              if (!TextUtils.isEmpty(c()))
                jSONObject.put(d.d1671532477445dc("txrf"), c()); 
              jSONObject.put(d.d1671532477445dc("esplvZehll"), k());
              if (!TextUtils.isEmpty(l()))
                jSONObject.put(d.d1671532477445dc("esplvZkto"), l()); 
              if (!TextUtils.isEmpty(e()))
                jSONObject.put(d.d1671532477445dc("rhv"), e()); 
              if (!TextUtils.isEmpty(f()))
                jSONObject.put(d.d1671532477445dc("csgbplpbW`n"), f()); 
              if (i() > 0)
                jSONObject.put(d.d1671532477445dc("aevzt`"), i()); 
              if (!TextUtils.isEmpty(j()))
                jSONObject.put(d.d1671532477445dc("rds\\ma"), j()); 
              if (!TextUtils.isEmpty(m()))
                jSONObject.put(d.d1671532477445dc("eyvqe"), m()); 
              if (!TextUtils.isEmpty(d()))
                jSONObject.put(d.d1671532477445dc("ewgmpZc|{k"), d()); 
            } finally {
              Exception exception = null;
            } 
            return jSONObject;
          case 62:
          case 63:
            break;
        } 
      } 
      break;
    } 
  }
  
  public T b(int paramInt) {
    this.h = paramInt;
    return p();
  }
  
  public T b(String paramString) {
    this.k = paramString;
    return p();
  }
  
  public T c(String paramString) {
    this.b = paramString;
    return p();
  }
  
  public String c() {
    return this.a;
  }
  
  public T d(String paramString) {
    this.c = paramString;
    return p();
  }
  
  public String d() {
    return this.k;
  }
  
  public T e(String paramString) {
    this.g = paramString;
    return p();
  }
  
  public String e() {
    return this.b;
  }
  
  public T f(String paramString) {
    this.i = paramString;
    return p();
  }
  
  public String f() {
    return this.c;
  }
  
  public T g(String paramString) {
    this.j = paramString;
    return p();
  }
  
  public String g() {
    return TextUtils.isEmpty(this.d) ? "" : this.d;
  }
  
  public long h() {
    long l = this.e;
    label24: while (true) {
      byte b2 = 93;
      byte b1 = 93;
      label18: while (true) {
        byte b3 = b1;
        switch (b2) {
          default:
            continue label24;
          case 94:
            if (b1 <= 4)
              continue label24; 
            continue;
          case 92:
            switch (b1) {
              default:
                b3 = b1;
              case 21:
                continue;
              case 22:
                continue;
              case 23:
                break;
            } 
            b2 = 94;
            b1 = 75;
            continue label18;
          case 93:
            while (true) {
              switch (b3) {
                case 92:
                  return l;
                case 91:
                case 93:
                  b2 = 94;
                  b1 = 75;
                  continue label18;
              } 
              b3 = 91;
            } 
            break;
        } 
        b2 = 94;
        b1 = 75;
        continue label18;
      } 
      break;
    } 
  }
  
  public T h(String paramString) {
    this.l = paramString;
    return p();
  }
  
  public int i() {
    int i = this.f;
    label24: while (true) {
      byte b2 = 93;
      byte b1 = 93;
      label18: while (true) {
        byte b3 = b1;
        switch (b2) {
          default:
            continue label24;
          case 94:
            if (b1 <= 4)
              continue label24; 
            continue;
          case 92:
            switch (b1) {
              default:
                b3 = b1;
              case 21:
                continue;
              case 22:
                continue;
              case 23:
                break;
            } 
            b2 = 94;
            b1 = 75;
            continue label18;
          case 93:
            while (true) {
              switch (b3) {
                case 92:
                  return i;
                case 91:
                case 93:
                  b2 = 94;
                  b1 = 75;
                  continue label18;
              } 
              b3 = 91;
            } 
            break;
        } 
        b2 = 94;
        b1 = 75;
        continue label18;
      } 
      break;
    } 
  }
  
  public String j() {
    return this.g;
  }
  
  public int k() {
    int i = this.h;
    label24: while (true) {
      byte b2 = 93;
      byte b1 = 93;
      label18: while (true) {
        byte b3 = b1;
        switch (b2) {
          default:
            continue label24;
          case 94:
            if (b1 <= 4)
              continue label24; 
            continue;
          case 92:
            switch (b1) {
              default:
                b3 = b1;
              case 21:
                continue;
              case 22:
                continue;
              case 23:
                break;
            } 
            b2 = 94;
            b1 = 75;
            continue label18;
          case 93:
            while (true) {
              switch (b3) {
                case 92:
                  return i;
                case 91:
                case 93:
                  b2 = 94;
                  b1 = 75;
                  continue label18;
              } 
              b3 = 91;
            } 
            break;
        } 
        b2 = 94;
        b1 = 75;
        continue label18;
      } 
      break;
    } 
  }
  
  public String l() {
    return this.i;
  }
  
  public String m() {
    return this.j;
  }
  
  public String n() {
    return this.l;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\h\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */