package com.bytedance.sdk.openadsdk;

public final class BuildConfig {
  public static final String BUILD_TYPE = "release";
  
  public static final boolean DEBUG = false;
  
  public static final boolean IS_TEST = false;
  
  public static final String LIBRARY_PACKAGE_NAME = "com.bytedance.sdk.openadsdk";
  
  public static final int VERSION_CODE = 4906;
  
  public static final String VERSION_NAME = "4.9.0.6";
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\BuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */