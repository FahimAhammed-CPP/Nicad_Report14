package com.bytedance.sdk.openadsdk.f;

import org.json.JSONObject;

public interface b {
  void a(String paramString, JSONObject paramJSONObject);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\f\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */