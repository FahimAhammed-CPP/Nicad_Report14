package com.bytedance.sdk.openadsdk.f;

import android.content.Context;
import org.json.JSONObject;

public interface c {
  void a();
  
  void a(Context paramContext, JSONObject paramJSONObject, String paramString);
  
  void a(Context paramContext, JSONObject paramJSONObject, String paramString, int paramInt, boolean paramBoolean);
  
  void a(JSONObject paramJSONObject);
  
  void b();
  
  void b(JSONObject paramJSONObject);
  
  void c();
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\f\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */