package com.bytedance.sdk.openadsdk.f;

import android.content.Context;
import android.text.TextUtils;
import com.bytedance.sdk.openadsdk.core.model.n;
import com.bytedance.sdk.openadsdk.core.video.c.b;
import com.bytedance.sdk.openadsdk.l.aa;
import com.com.bytedance.overseas.sdk.a.c;
import com.com.bytedance.overseas.sdk.a.d;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class a implements c {
  private final n a;
  
  private final b b;
  
  private final Map<String, c> c = new HashMap<String, c>();
  
  private a(b paramb, n paramn) {
    this.b = paramb;
    this.a = paramn;
  }
  
  private n a(JSONObject paramJSONObject, String paramString) {
    String str;
    JSONObject jSONObject = null;
    if (paramJSONObject == null)
      return null; 
    n n1 = new n();
    n1.b(paramJSONObject);
    if (!TextUtils.isEmpty(paramString))
      n1.m(paramString); 
    if (this.a == null)
      return n1; 
    paramJSONObject = jSONObject;
    if (n1.ab() != null)
      str = n1.ab().a(); 
    if (TextUtils.isEmpty(str))
      return this.a; 
    if (this.a.ab() != null && str.equals(this.a.ab().a()))
      return this.a; 
    if (this.a.ab() != null && str.contains("play.google.com/store/apps/details?id=") && !str.contains("referrer"))
      n1.ab().a(this.a.ab().a()); 
    return n1;
  }
  
  public static a a(b paramb, n paramn) {
    return new a(paramb, paramn);
  }
  
  private c a(Context paramContext, n paramn, JSONObject paramJSONObject, String paramString, boolean paramBoolean) {
    c c1 = d.a(paramContext, paramn, paramString);
    c1.a(true);
    return c1;
  }
  
  private void a(Context paramContext, n paramn, String paramString) {
    if (paramContext != null) {
      if (paramn == null)
        return; 
      if (paramn.ab() == null) {
        d.a(paramContext, paramn, paramString).d();
      } else {
        c c1 = this.c.get(paramn.ab().a());
        if (c1 != null)
          c1.d(); 
      } 
      if (paramContext instanceof b)
        ((b)paramContext).t(); 
    } 
  }
  
  private void a(Context paramContext, n paramn, JSONObject paramJSONObject, int paramInt, boolean paramBoolean) {
    if (paramContext != null && paramn != null && paramn.ab() != null && paramJSONObject != null) {
      if (this.b == null)
        return; 
      if ((c)this.c.get(paramn.ab().a()) != null)
        return; 
      String str = aa.a(paramInt);
      if (TextUtils.isEmpty(str))
        return; 
      c c1 = a(paramContext, paramn, paramJSONObject, str, paramBoolean);
      this.c.put(paramn.ab().a(), c1);
    } 
  }
  
  private void a(n paramn, JSONObject paramJSONObject) {
    if (this.b != null && paramn != null) {
      if (paramn.ab() == null)
        return; 
      String str = paramn.ab().a();
      if (this.c.containsKey(str)) {
        this.c.remove(str);
        try {
          JSONObject jSONObject = new JSONObject();
          jSONObject.put("message", "success");
          jSONObject.put("status", "unsubscribed");
          jSONObject.put("appad", paramJSONObject);
          this.b.a("app_ad_event", jSONObject);
          return;
        } catch (JSONException jSONException) {
          jSONException.printStackTrace();
        } 
      } 
    } 
  }
  
  public void a() {}
  
  public void a(Context paramContext, JSONObject paramJSONObject, String paramString) {
    if (paramContext != null) {
      if (paramJSONObject == null)
        return; 
      paramJSONObject = paramJSONObject.optJSONObject("data");
      if (paramJSONObject != null)
        a(paramContext, a(paramJSONObject, (String)null), paramString); 
    } 
  }
  
  public void a(Context paramContext, JSONObject paramJSONObject, String paramString, int paramInt, boolean paramBoolean) {
    if (paramContext != null) {
      if (paramJSONObject == null)
        return; 
      paramJSONObject = paramJSONObject.optJSONObject("data");
      if (paramJSONObject != null)
        a(paramContext, a(paramJSONObject, paramString), paramJSONObject, paramInt, paramBoolean); 
    } 
  }
  
  public void a(JSONObject paramJSONObject) {
    if (paramJSONObject == null)
      return; 
    paramJSONObject = paramJSONObject.optJSONObject("data");
    if (paramJSONObject != null)
      a(a(paramJSONObject, (String)null), paramJSONObject); 
  }
  
  public void b() {}
  
  public void b(JSONObject paramJSONObject) {}
  
  public void c() {
    this.c.clear();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\f\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */