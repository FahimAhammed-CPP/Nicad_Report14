package com.bytedance.sdk.component.adexpress.dynamic.a;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.bytedance.sdk.component.adexpress.b.d;
import com.bytedance.sdk.component.adexpress.b.f;
import com.bytedance.sdk.component.adexpress.b.g;
import com.bytedance.sdk.component.adexpress.b.j;
import com.bytedance.sdk.component.adexpress.b.l;
import com.bytedance.sdk.component.adexpress.b.m;
import com.bytedance.sdk.component.adexpress.c;
import com.bytedance.sdk.component.adexpress.dynamic.b.f;
import com.bytedance.sdk.component.adexpress.dynamic.b.h;
import com.bytedance.sdk.component.adexpress.dynamic.c.g;
import com.bytedance.sdk.component.adexpress.dynamic.d.b;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicRootView;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.d;
import com.bytedance.sdk.component.adexpress.theme.ThemeStatusBroadcastReceiver;
import com.bytedance.sdk.component.g.e;
import com.bytedance.sdk.component.utils.h;
import com.bytedance.sdk.component.utils.l;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class a implements d<DynamicRootView>, j {
  private DynamicRootView a;
  
  private g b;
  
  private Context c;
  
  private f d;
  
  private g e;
  
  private l f;
  
  private ScheduledFuture<?> g;
  
  private AtomicBoolean h = new AtomicBoolean(false);
  
  public a(Context paramContext, ThemeStatusBroadcastReceiver paramThemeStatusBroadcastReceiver, boolean paramBoolean, g paramg, l paraml, com.bytedance.sdk.component.adexpress.dynamic.d.a parama) {
    this.c = paramContext;
    DynamicRootView dynamicRootView = new DynamicRootView(paramContext, paramThemeStatusBroadcastReceiver, paramBoolean, paraml, parama);
    this.a = dynamicRootView;
    this.b = paramg;
    this.f = paraml;
    dynamicRootView.setRenderListener(this);
    this.f = paraml;
  }
  
  private void a(View paramView) {
    if (paramView == null)
      return; 
    if (paramView instanceof ViewGroup) {
      int i = 0;
      while (true) {
        ViewGroup viewGroup = (ViewGroup)paramView;
        if (i < viewGroup.getChildCount()) {
          a(viewGroup.getChildAt(i));
          i++;
          continue;
        } 
        break;
      } 
    } 
    if (paramView instanceof d)
      ((d)paramView).b(); 
  }
  
  private void a(h paramh) {
    if (paramh == null)
      return; 
    List<?> list = paramh.k();
    if (list != null) {
      if (list.size() <= 0)
        return; 
      Collections.sort(list, new Comparator<h>(this) {
            public int a(h param1h1, h param1h2) {
              f f1 = param1h1.j().e();
              f f2 = param1h2.j().e();
              return (f1 == null || f2 == null) ? 0 : ((f1.ah() >= f2.ah()) ? 1 : -1);
            }
          });
      for (h h1 : list) {
        if (h1 == null)
          continue; 
        a(h1);
      } 
    } 
  }
  
  private void b(h paramh) {
    if (paramh == null)
      return; 
    List list = paramh.k();
    if (list != null && list.size() > 0) {
      Iterator<h> iterator = list.iterator();
      while (iterator.hasNext())
        b(iterator.next()); 
    } 
    h h1 = paramh.l();
    if (h1 == null)
      return; 
    float f1 = paramh.f();
    float f2 = h1.f();
    float f3 = paramh.g();
    float f4 = h1.g();
    paramh.c(f1 - f2);
    paramh.d(f3 - f4);
  }
  
  private void c(h paramh) {
    if (paramh == null) {
      byte b;
      if (this.b instanceof com.bytedance.sdk.component.adexpress.dynamic.c.f) {
        b = 123;
      } else {
        b = 113;
      } 
      this.a.a(b);
      return;
    } 
    this.f.d().e(c());
    try {
      this.a.a(paramh, c());
      return;
    } catch (Exception exception) {
      byte b;
      if (this.b instanceof com.bytedance.sdk.component.adexpress.dynamic.c.f) {
        b = 128;
      } else {
        b = 118;
      } 
      this.a.a(b);
      return;
    } 
  }
  
  private void f() {
    this.f.d().c(c());
    if (!com.bytedance.sdk.component.adexpress.a.b.a.a(this.f.b())) {
      byte b;
      if (this.b instanceof com.bytedance.sdk.component.adexpress.dynamic.c.f) {
        b = 123;
      } else {
        b = 113;
      } 
      this.a.a(b);
      return;
    } 
    this.b.a(new b(this) {
          public void a(h param1h) {
            a.b(this.a);
            a.c(this.a).d().d(this.a.c());
            a.a(this.a, param1h);
            a.b(this.a, param1h);
            (new Handler(Looper.getMainLooper())).post(new Runnable(this, param1h) {
                  public void run() {
                    a.c(this.b.a, this.a);
                  }
                });
            if (a.d(this.a) != null && param1h != null) {
              a.d(this.a).setBgColor(param1h.a());
              a.d(this.a).setBgMaterialCenterCalcColor(param1h.b());
            } 
          }
        });
    this.b.a(this.f);
  }
  
  private boolean g() {
    DynamicRootView dynamicRootView = this.a;
    return (dynamicRootView == null) ? false : (!(dynamicRootView.getChildCount() == 0));
  }
  
  private void h() {
    try {
      ScheduledFuture<?> scheduledFuture = this.g;
      return;
    } finally {
      Exception exception = null;
      exception.printStackTrace();
    } 
  }
  
  public DynamicRootView a() {
    return d();
  }
  
  public void a(View paramView, int paramInt, c paramc) {
    g g1 = this.e;
    if (g1 != null)
      g1.a(paramView, paramInt, paramc); 
  }
  
  public void a(f paramf) {
    this.d = paramf;
    int i = this.f.e();
    if (i < 0) {
      if (this.b instanceof com.bytedance.sdk.component.adexpress.dynamic.c.f) {
        i = 127;
      } else {
        i = 117;
      } 
      this.a.a(i);
      return;
    } 
    this.g = e.e().schedule(new a(this, 2), i, TimeUnit.MILLISECONDS);
    h.b().postDelayed(new Runnable(this) {
          public void run() {
            a.a(this.a);
          }
        },  this.f.g());
  }
  
  public void a(g paramg) {
    this.e = paramg;
  }
  
  public void a(m paramm) {
    if (this.h.get())
      return; 
    this.h.set(true);
    if (paramm.a() && g()) {
      FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1);
      this.a.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
      this.d.a((View)a(), paramm);
      return;
    } 
    this.d.a(paramm.h());
  }
  
  public void b() {
    a((View)a());
  }
  
  public int c() {
    return (this.b instanceof com.bytedance.sdk.component.adexpress.dynamic.c.f) ? 3 : 2;
  }
  
  public DynamicRootView d() {
    return this.a;
  }
  
  private class a implements Runnable {
    private int b;
    
    public a(a this$0, int param1Int) {
      this.b = param1Int;
    }
    
    public void run() {
      if (this.b == 2) {
        byte b;
        l.b("DynamicRender", "Dynamic parse time out");
        if (a.e(this.a) instanceof com.bytedance.sdk.component.adexpress.dynamic.c.f) {
          b = 127;
        } else {
          b = 117;
        } 
        a.d(this.a).a(b);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\component\adexpress\dynamic\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */