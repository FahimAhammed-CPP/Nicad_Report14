package com.bytedance.sdk.component.adexpress.widget;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.bytedance.sdk.component.adexpress.c.b;
import com.bytedance.sdk.component.utils.t;

public class HandLongPressView extends FrameLayout {
  private Context a;
  
  private ImageView b;
  
  private CircleRippleView c;
  
  private AnimatorSet d;
  
  private boolean e = true;
  
  private TextView f;
  
  public HandLongPressView(Context paramContext) {
    super(paramContext);
    this.a = paramContext;
    this.d = new AnimatorSet();
    c();
    d();
    post(new Runnable(this) {
          public void run() {
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)HandLongPressView.a(this.a).getLayoutParams();
            layoutParams.topMargin = (int)(HandLongPressView.b(this.a).getMeasuredHeight() / 2.0F - b.a(this.a.getContext(), 5.0F)) + (int)b.a(HandLongPressView.c(this.a), 20.0F);
            layoutParams.leftMargin = (int)(HandLongPressView.b(this.a).getMeasuredWidth() / 2.0F - b.a(this.a.getContext(), 5.0F)) + (int)b.a(HandLongPressView.c(this.a), 20.0F);
            layoutParams.bottomMargin = (int)(-HandLongPressView.b(this.a).getMeasuredHeight() / 2.0F + b.a(this.a.getContext(), 5.0F));
            layoutParams.rightMargin = (int)(-HandLongPressView.b(this.a).getMeasuredWidth() / 2.0F + b.a(this.a.getContext(), 5.0F));
            HandLongPressView.a(this.a).setLayoutParams((ViewGroup.LayoutParams)layoutParams);
          }
        });
  }
  
  private void c() {
    this.c = new CircleRippleView(this.a);
    FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams((int)b.a(this.a, 80.0F), (int)b.a(this.a, 80.0F));
    layoutParams2.gravity = 51;
    layoutParams2.topMargin = (int)b.a(this.a, 20.0F);
    layoutParams2.leftMargin = (int)b.a(this.a, 20.0F);
    addView((View)this.c, (ViewGroup.LayoutParams)layoutParams2);
    this.c.a();
    this.b = new ImageView(this.a);
    layoutParams2 = new FrameLayout.LayoutParams((int)b.a(this.a, 80.0F), (int)b.a(this.a, 80.0F));
    this.b.setImageResource(t.d(this.a, "tt_splash_hand"));
    addView((View)this.b, (ViewGroup.LayoutParams)layoutParams2);
    TextView textView = new TextView(this.a);
    this.f = textView;
    textView.setTextColor(-1);
    FrameLayout.LayoutParams layoutParams1 = new FrameLayout.LayoutParams(-2, -2);
    layoutParams1.gravity = 81;
    layoutParams1.bottomMargin = (int)b.a(this.a, 10.0F);
    addView((View)this.f, (ViewGroup.LayoutParams)layoutParams1);
  }
  
  private void d() {
    ObjectAnimator objectAnimator1 = ObjectAnimator.ofFloat(this.b, "scaleX", new float[] { 1.0F, 0.8F });
    objectAnimator1.setDuration(1000L);
    objectAnimator1.setRepeatMode(2);
    objectAnimator1.setRepeatCount(-1);
    objectAnimator1.addListener(new Animator.AnimatorListener(this) {
          public void onAnimationCancel(Animator param1Animator) {}
          
          public void onAnimationEnd(Animator param1Animator) {}
          
          public void onAnimationRepeat(Animator param1Animator) {
            if (HandLongPressView.d(this.a)) {
              HandLongPressView.b(this.a).a();
              HandLongPressView.b(this.a).setAlpha(1.0F);
            } else {
              HandLongPressView.b(this.a).b();
              HandLongPressView.b(this.a).setAlpha(0.0F);
            } 
            HandLongPressView handLongPressView = this.a;
            HandLongPressView.a(handLongPressView, HandLongPressView.d(handLongPressView) ^ true);
          }
          
          public void onAnimationStart(Animator param1Animator) {
            ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(HandLongPressView.a(this.a), "alpha", new float[] { 0.0F, 1.0F });
            objectAnimator.setDuration(200L);
            objectAnimator.setInterpolator((TimeInterpolator)new LinearInterpolator());
            objectAnimator.start();
            HandLongPressView.a(this.a).setVisibility(0);
          }
        });
    ObjectAnimator objectAnimator2 = ObjectAnimator.ofFloat(this.b, "scaleY", new float[] { 1.0F, 0.8F });
    objectAnimator2.setDuration(1000L);
    objectAnimator2.setRepeatMode(2);
    objectAnimator2.setRepeatCount(-1);
    this.d.playTogether(new Animator[] { (Animator)objectAnimator1, (Animator)objectAnimator2 });
  }
  
  public void a() {
    this.d.start();
  }
  
  public void b() {
    AnimatorSet animatorSet = this.d;
    if (animatorSet != null)
      animatorSet.cancel(); 
    CircleRippleView circleRippleView = this.c;
    if (circleRippleView != null)
      circleRippleView.b(); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (!true) {
      setMeasuredDimension(0, 0);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setGuideText(String paramString) {
    this.f.setText(paramString);
  }
  
  public void setGuideTextColor(int paramInt) {
    this.f.setTextColor(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\component\adexpress\widget\HandLongPressView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */