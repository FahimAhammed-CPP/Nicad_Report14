package com.bytedance.sdk.component.utils;

import android.os.Build;
import android.text.TextUtils;
import java.security.SecureRandom;
import java.util.Random;
import org.json.JSONObject;

public class a {
  public static String a() {
    String str = a(16);
    if (str != null) {
      String str1 = str;
      return (str.length() != 32) ? null : str1;
    } 
    return null;
  }
  
  public static String a(int paramInt) {
    try {
      byte[] arrayOfByte = new byte[paramInt];
      a.a.nextBytes(arrayOfByte);
      return e.a(arrayOfByte);
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public static String a(String paramString) {
    if (TextUtils.isEmpty(paramString))
      return paramString; 
    String str3 = a();
    String str5 = a(str3, 32);
    String str4 = b();
    String str2 = null;
    String str1 = str2;
    if (str5 != null) {
      str1 = str2;
      if (str4 != null)
        str1 = com.bytedance.sdk.component.c.a.a(paramString, str4, str5); 
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(3);
    stringBuilder.append(str3);
    stringBuilder.append(str4);
    stringBuilder.append(str1);
    return stringBuilder.toString();
  }
  
  public static String a(String paramString, int paramInt) {
    if (paramString == null || paramString.length() != paramInt)
      return null; 
    int i = paramInt / 2;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString.substring(i, paramInt));
    stringBuilder.append(paramString.substring(0, i));
    return stringBuilder.toString();
  }
  
  public static JSONObject a(JSONObject paramJSONObject) {
    JSONObject jSONObject = new JSONObject();
    if (paramJSONObject == null)
      return jSONObject; 
    try {
      String str = a(paramJSONObject.toString());
      if (!TextUtils.isEmpty(str)) {
        jSONObject.put("message", str);
        return jSONObject;
      } 
      jSONObject.put("message", paramJSONObject.toString());
      return jSONObject;
    } finally {
      Exception exception = null;
    } 
  }
  
  public static String b() {
    String str = a(8);
    if (str != null) {
      String str1 = str;
      return (str.length() != 16) ? null : str1;
    } 
    return null;
  }
  
  public static String b(String paramString) {
    String str = paramString;
    if (!TextUtils.isEmpty(paramString)) {
      str = paramString;
      if (paramString.length() >= 49) {
        String str1 = a(paramString.substring(1, 33), 32);
        String str2 = paramString.substring(33, 49);
        str = paramString;
        if (str2 != null) {
          str = paramString;
          if (str1 != null)
            str = com.bytedance.sdk.component.c.a.b(paramString.substring(49), str2, str1); 
        } 
      } 
    } 
    return str;
  }
  
  public static Random c() {
    if (Build.VERSION.SDK_INT >= 26)
      try {
        return SecureRandom.getInstanceStrong();
      } finally {
        Exception exception = null;
      }  
    return new SecureRandom();
  }
  
  static class a {
    static final Random a = a.c();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\componen\\utils\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */