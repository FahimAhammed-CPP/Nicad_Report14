package com.bytedance.sdk.component.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.SystemClock;
import com.bytedance.sdk.component.g.e;
import com.bytedance.sdk.component.g.g;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

public class w {
  private static final Object a = new Object();
  
  private static final Map<a, Object> b = new ConcurrentHashMap<a, Object>();
  
  private static AtomicBoolean c = new AtomicBoolean(false);
  
  private static volatile int d = -1;
  
  private static volatile long e = 0L;
  
  private static volatile int f = 60000;
  
  private static p g = null;
  
  private static final AtomicBoolean h = new AtomicBoolean(false);
  
  public static int a(Context paramContext) {
    d = b(paramContext);
    e = SystemClock.elapsedRealtime();
    return d;
  }
  
  public static int a(Context paramContext, long paramLong) {
    long l = SystemClock.elapsedRealtime();
    if (e + paramLong <= l)
      return a(paramContext); 
    if (d == -1)
      return a(paramContext); 
    if (l - e >= f)
      c(paramContext); 
    return d;
  }
  
  public static void a(a parama) {
    if (parama == null)
      return; 
    b.remove(parama);
  }
  
  public static void a(a parama, Context paramContext) {
    if (parama == null)
      return; 
    if (!c.get())
      try {
        IntentFilter intentFilter = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        paramContext.registerReceiver(new b(), intentFilter);
        c.set(true);
      } finally {} 
    b.put(parama, a);
  }
  
  public static int b(Context paramContext) {
    try {
      NetworkInfo networkInfo = ((ConnectivityManager)paramContext.getSystemService("connectivity")).getActiveNetworkInfo();
      if (networkInfo == null || !networkInfo.isAvailable())
        return 0; 
      int i = networkInfo.getType();
    } finally {
      paramContext = null;
    } 
    return 4;
  }
  
  private static void b(Context paramContext, Intent paramIntent) {
    c(paramContext);
    boolean bool = paramIntent.getBooleanExtra("noConnectivity", false);
    if (bool)
      d = 0; 
    Map<a, Object> map = b;
    if (map != null) {
      if (map.size() <= 0)
        return; 
      for (a a : map.keySet()) {
        if (a != null)
          a.a(paramContext, paramIntent, bool ^ true); 
      } 
    } 
  }
  
  private static void c(Context paramContext) {
    if (h.compareAndSet(false, true))
      e.b(new g("getNetworkType", paramContext) {
            public void run() {
              w.a(this.a);
              w.a().set(false);
            }
          }); 
  }
  
  public static interface a {
    void a(Context param1Context, Intent param1Intent, boolean param1Boolean);
  }
  
  private static class b extends BroadcastReceiver {
    private b() {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      w.a(param1Context, param1Intent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\componen\\utils\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */