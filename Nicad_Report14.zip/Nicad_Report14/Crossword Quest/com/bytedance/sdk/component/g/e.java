package com.bytedance.sdk.component.g;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadPoolExecutor;

public class e {
  public static final int a = Runtime.getRuntime().availableProcessors();
  
  public static c b;
  
  public static int c = 120;
  
  public static boolean d = true;
  
  private static volatile ThreadPoolExecutor e;
  
  private static volatile ThreadPoolExecutor f;
  
  private static volatile ThreadPoolExecutor g;
  
  private static volatile ThreadPoolExecutor h;
  
  private static volatile ScheduledExecutorService i;
  
  public static ExecutorService a() {
    return a(10);
  }
  
  public static ExecutorService a(int paramInt) {
    // Byte code:
    //   0: getstatic com/bytedance/sdk/component/g/e.e : Ljava/util/concurrent/ThreadPoolExecutor;
    //   3: ifnonnull -> 91
    //   6: ldc com/bytedance/sdk/component/g/e
    //   8: monitorenter
    //   9: getstatic com/bytedance/sdk/component/g/e.e : Ljava/util/concurrent/ThreadPoolExecutor;
    //   12: ifnonnull -> 79
    //   15: new com/bytedance/sdk/component/g/a$a
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: ldc 'io'
    //   24: invokevirtual a : (Ljava/lang/String;)Lcom/bytedance/sdk/component/g/a$a;
    //   27: iconst_4
    //   28: invokevirtual a : (I)Lcom/bytedance/sdk/component/g/a$a;
    //   31: iload_0
    //   32: invokevirtual c : (I)Lcom/bytedance/sdk/component/g/a$a;
    //   35: ldc2_w 40
    //   38: invokevirtual a : (J)Lcom/bytedance/sdk/component/g/a$a;
    //   41: getstatic java/util/concurrent/TimeUnit.SECONDS : Ljava/util/concurrent/TimeUnit;
    //   44: invokevirtual a : (Ljava/util/concurrent/TimeUnit;)Lcom/bytedance/sdk/component/g/a$a;
    //   47: new java/util/concurrent/PriorityBlockingQueue
    //   50: dup
    //   51: getstatic com/bytedance/sdk/component/g/e.a : I
    //   54: invokespecial <init> : (I)V
    //   57: invokevirtual a : (Ljava/util/concurrent/BlockingQueue;)Lcom/bytedance/sdk/component/g/a$a;
    //   60: invokestatic g : ()Ljava/util/concurrent/RejectedExecutionHandler;
    //   63: invokevirtual a : (Ljava/util/concurrent/RejectedExecutionHandler;)Lcom/bytedance/sdk/component/g/a$a;
    //   66: invokevirtual a : ()Lcom/bytedance/sdk/component/g/a;
    //   69: putstatic com/bytedance/sdk/component/g/e.e : Ljava/util/concurrent/ThreadPoolExecutor;
    //   72: getstatic com/bytedance/sdk/component/g/e.e : Ljava/util/concurrent/ThreadPoolExecutor;
    //   75: iconst_1
    //   76: invokevirtual allowCoreThreadTimeOut : (Z)V
    //   79: ldc com/bytedance/sdk/component/g/e
    //   81: monitorexit
    //   82: goto -> 91
    //   85: astore_1
    //   86: ldc com/bytedance/sdk/component/g/e
    //   88: monitorexit
    //   89: aload_1
    //   90: athrow
    //   91: getstatic com/bytedance/sdk/component/g/e.e : Ljava/util/concurrent/ThreadPoolExecutor;
    //   94: areturn
    // Exception table:
    //   from	to	target	type
    //   9	79	85	finally
    //   79	82	85	finally
    //   86	89	85	finally
  }
  
  public static void a(c paramc) {
    b = paramc;
  }
  
  public static void a(g paramg) {
    a(paramg, 10);
  }
  
  public static void a(g paramg, int paramInt) {
    if (e == null)
      b(); 
    if (paramg != null && e != null) {
      paramg.setPriority(paramInt);
      e.execute((Runnable)paramg);
    } 
  }
  
  public static void a(g paramg, int paramInt1, int paramInt2) {
    if (e == null)
      a(paramInt2); 
    if (paramg != null && e != null) {
      paramg.setPriority(paramInt1);
      e.execute((Runnable)paramg);
    } 
  }
  
  public static void a(boolean paramBoolean) {
    d = paramBoolean;
  }
  
  public static ExecutorService b() {
    return a(10);
  }
  
  public static ExecutorService b(int paramInt) {
    // Byte code:
    //   0: getstatic com/bytedance/sdk/component/g/e.f : Ljava/util/concurrent/ThreadPoolExecutor;
    //   3: ifnonnull -> 88
    //   6: ldc com/bytedance/sdk/component/g/e
    //   8: monitorenter
    //   9: getstatic com/bytedance/sdk/component/g/e.f : Ljava/util/concurrent/ThreadPoolExecutor;
    //   12: ifnonnull -> 76
    //   15: new com/bytedance/sdk/component/g/a$a
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: ldc 'ad'
    //   24: invokevirtual a : (Ljava/lang/String;)Lcom/bytedance/sdk/component/g/a$a;
    //   27: iconst_1
    //   28: invokevirtual b : (I)Lcom/bytedance/sdk/component/g/a$a;
    //   31: iload_0
    //   32: invokevirtual c : (I)Lcom/bytedance/sdk/component/g/a$a;
    //   35: ldc2_w 300
    //   38: invokevirtual a : (J)Lcom/bytedance/sdk/component/g/a$a;
    //   41: getstatic java/util/concurrent/TimeUnit.SECONDS : Ljava/util/concurrent/TimeUnit;
    //   44: invokevirtual a : (Ljava/util/concurrent/TimeUnit;)Lcom/bytedance/sdk/component/g/a$a;
    //   47: new java/util/concurrent/LinkedBlockingQueue
    //   50: dup
    //   51: invokespecial <init> : ()V
    //   54: invokevirtual a : (Ljava/util/concurrent/BlockingQueue;)Lcom/bytedance/sdk/component/g/a$a;
    //   57: invokestatic g : ()Ljava/util/concurrent/RejectedExecutionHandler;
    //   60: invokevirtual a : (Ljava/util/concurrent/RejectedExecutionHandler;)Lcom/bytedance/sdk/component/g/a$a;
    //   63: invokevirtual a : ()Lcom/bytedance/sdk/component/g/a;
    //   66: putstatic com/bytedance/sdk/component/g/e.f : Ljava/util/concurrent/ThreadPoolExecutor;
    //   69: getstatic com/bytedance/sdk/component/g/e.f : Ljava/util/concurrent/ThreadPoolExecutor;
    //   72: iconst_1
    //   73: invokevirtual allowCoreThreadTimeOut : (Z)V
    //   76: ldc com/bytedance/sdk/component/g/e
    //   78: monitorexit
    //   79: goto -> 88
    //   82: astore_1
    //   83: ldc com/bytedance/sdk/component/g/e
    //   85: monitorexit
    //   86: aload_1
    //   87: athrow
    //   88: getstatic com/bytedance/sdk/component/g/e.f : Ljava/util/concurrent/ThreadPoolExecutor;
    //   91: areturn
    // Exception table:
    //   from	to	target	type
    //   9	76	82	finally
    //   76	79	82	finally
    //   83	86	82	finally
  }
  
  public static void b(g paramg) {
    if (e == null)
      b(); 
    if (e != null)
      e.execute((Runnable)paramg); 
  }
  
  public static void b(g paramg, int paramInt) {
    if (g == null)
      c(); 
    if (paramg != null && g != null) {
      paramg.setPriority(paramInt);
      g.execute((Runnable)paramg);
    } 
  }
  
  public static ExecutorService c() {
    // Byte code:
    //   0: getstatic com/bytedance/sdk/component/g/e.g : Ljava/util/concurrent/ThreadPoolExecutor;
    //   3: ifnonnull -> 89
    //   6: ldc com/bytedance/sdk/component/g/e
    //   8: monitorenter
    //   9: getstatic com/bytedance/sdk/component/g/e.g : Ljava/util/concurrent/ThreadPoolExecutor;
    //   12: ifnonnull -> 77
    //   15: new com/bytedance/sdk/component/g/a$a
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: ldc 'log'
    //   24: invokevirtual a : (Ljava/lang/String;)Lcom/bytedance/sdk/component/g/a$a;
    //   27: bipush #10
    //   29: invokevirtual c : (I)Lcom/bytedance/sdk/component/g/a$a;
    //   32: iconst_2
    //   33: invokevirtual a : (I)Lcom/bytedance/sdk/component/g/a$a;
    //   36: ldc2_w 40
    //   39: invokevirtual a : (J)Lcom/bytedance/sdk/component/g/a$a;
    //   42: getstatic java/util/concurrent/TimeUnit.SECONDS : Ljava/util/concurrent/TimeUnit;
    //   45: invokevirtual a : (Ljava/util/concurrent/TimeUnit;)Lcom/bytedance/sdk/component/g/a$a;
    //   48: new java/util/concurrent/PriorityBlockingQueue
    //   51: dup
    //   52: invokespecial <init> : ()V
    //   55: invokevirtual a : (Ljava/util/concurrent/BlockingQueue;)Lcom/bytedance/sdk/component/g/a$a;
    //   58: invokestatic g : ()Ljava/util/concurrent/RejectedExecutionHandler;
    //   61: invokevirtual a : (Ljava/util/concurrent/RejectedExecutionHandler;)Lcom/bytedance/sdk/component/g/a$a;
    //   64: invokevirtual a : ()Lcom/bytedance/sdk/component/g/a;
    //   67: putstatic com/bytedance/sdk/component/g/e.g : Ljava/util/concurrent/ThreadPoolExecutor;
    //   70: getstatic com/bytedance/sdk/component/g/e.g : Ljava/util/concurrent/ThreadPoolExecutor;
    //   73: iconst_1
    //   74: invokevirtual allowCoreThreadTimeOut : (Z)V
    //   77: ldc com/bytedance/sdk/component/g/e
    //   79: monitorexit
    //   80: goto -> 89
    //   83: astore_0
    //   84: ldc com/bytedance/sdk/component/g/e
    //   86: monitorexit
    //   87: aload_0
    //   88: athrow
    //   89: getstatic com/bytedance/sdk/component/g/e.g : Ljava/util/concurrent/ThreadPoolExecutor;
    //   92: areturn
    // Exception table:
    //   from	to	target	type
    //   9	77	83	finally
    //   77	80	83	finally
    //   84	87	83	finally
  }
  
  public static void c(int paramInt) {
    c = paramInt;
  }
  
  public static void c(g paramg) {
    if (g == null)
      c(); 
    if (g != null)
      g.execute((Runnable)paramg); 
  }
  
  public static void c(g paramg, int paramInt) {
    if (h == null)
      d(); 
    if (paramg != null && h != null) {
      paramg.setPriority(paramInt);
      h.execute((Runnable)paramg);
    } 
  }
  
  public static ExecutorService d() {
    // Byte code:
    //   0: getstatic com/bytedance/sdk/component/g/e.h : Ljava/util/concurrent/ThreadPoolExecutor;
    //   3: ifnonnull -> 89
    //   6: ldc com/bytedance/sdk/component/g/e
    //   8: monitorenter
    //   9: getstatic com/bytedance/sdk/component/g/e.h : Ljava/util/concurrent/ThreadPoolExecutor;
    //   12: ifnonnull -> 77
    //   15: new com/bytedance/sdk/component/g/a$a
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: ldc 'aidl'
    //   24: invokevirtual a : (Ljava/lang/String;)Lcom/bytedance/sdk/component/g/a$a;
    //   27: bipush #10
    //   29: invokevirtual c : (I)Lcom/bytedance/sdk/component/g/a$a;
    //   32: iconst_2
    //   33: invokevirtual a : (I)Lcom/bytedance/sdk/component/g/a$a;
    //   36: ldc2_w 30
    //   39: invokevirtual a : (J)Lcom/bytedance/sdk/component/g/a$a;
    //   42: getstatic java/util/concurrent/TimeUnit.SECONDS : Ljava/util/concurrent/TimeUnit;
    //   45: invokevirtual a : (Ljava/util/concurrent/TimeUnit;)Lcom/bytedance/sdk/component/g/a$a;
    //   48: new java/util/concurrent/PriorityBlockingQueue
    //   51: dup
    //   52: invokespecial <init> : ()V
    //   55: invokevirtual a : (Ljava/util/concurrent/BlockingQueue;)Lcom/bytedance/sdk/component/g/a$a;
    //   58: invokestatic g : ()Ljava/util/concurrent/RejectedExecutionHandler;
    //   61: invokevirtual a : (Ljava/util/concurrent/RejectedExecutionHandler;)Lcom/bytedance/sdk/component/g/a$a;
    //   64: invokevirtual a : ()Lcom/bytedance/sdk/component/g/a;
    //   67: putstatic com/bytedance/sdk/component/g/e.h : Ljava/util/concurrent/ThreadPoolExecutor;
    //   70: getstatic com/bytedance/sdk/component/g/e.h : Ljava/util/concurrent/ThreadPoolExecutor;
    //   73: iconst_1
    //   74: invokevirtual allowCoreThreadTimeOut : (Z)V
    //   77: ldc com/bytedance/sdk/component/g/e
    //   79: monitorexit
    //   80: goto -> 89
    //   83: astore_0
    //   84: ldc com/bytedance/sdk/component/g/e
    //   86: monitorexit
    //   87: aload_0
    //   88: athrow
    //   89: getstatic com/bytedance/sdk/component/g/e.h : Ljava/util/concurrent/ThreadPoolExecutor;
    //   92: areturn
    // Exception table:
    //   from	to	target	type
    //   9	77	83	finally
    //   77	80	83	finally
    //   84	87	83	finally
  }
  
  public static void d(g paramg) {
    if (f == null)
      b(5); 
    if (paramg != null && f != null)
      f.execute((Runnable)paramg); 
  }
  
  public static ScheduledExecutorService e() {
    // Byte code:
    //   0: getstatic com/bytedance/sdk/component/g/e.i : Ljava/util/concurrent/ScheduledExecutorService;
    //   3: ifnonnull -> 43
    //   6: ldc com/bytedance/sdk/component/g/e
    //   8: monitorenter
    //   9: getstatic com/bytedance/sdk/component/g/e.i : Ljava/util/concurrent/ScheduledExecutorService;
    //   12: ifnonnull -> 31
    //   15: new com/bytedance/sdk/component/g/h
    //   18: dup
    //   19: iconst_5
    //   20: ldc 'scheduled'
    //   22: invokespecial <init> : (ILjava/lang/String;)V
    //   25: invokestatic newSingleThreadScheduledExecutor : (Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ScheduledExecutorService;
    //   28: putstatic com/bytedance/sdk/component/g/e.i : Ljava/util/concurrent/ScheduledExecutorService;
    //   31: ldc com/bytedance/sdk/component/g/e
    //   33: monitorexit
    //   34: goto -> 43
    //   37: astore_0
    //   38: ldc com/bytedance/sdk/component/g/e
    //   40: monitorexit
    //   41: aload_0
    //   42: athrow
    //   43: getstatic com/bytedance/sdk/component/g/e.i : Ljava/util/concurrent/ScheduledExecutorService;
    //   46: areturn
    // Exception table:
    //   from	to	target	type
    //   9	31	37	finally
    //   31	34	37	finally
    //   38	41	37	finally
  }
  
  public static boolean f() {
    return d;
  }
  
  public static RejectedExecutionHandler g() {
    return new RejectedExecutionHandler() {
        public void rejectedExecution(Runnable param1Runnable, ThreadPoolExecutor param1ThreadPoolExecutor) {}
      };
  }
  
  public static c h() {
    return b;
  }
  
  public static ExecutorService i() {
    return b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\component\g\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */