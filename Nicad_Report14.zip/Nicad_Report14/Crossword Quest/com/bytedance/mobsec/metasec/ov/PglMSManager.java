package com.bytedance.mobsec.metasec.ov;

import java.util.Map;
import ms.bd.o.Pgl.l0;

public final class PglMSManager implements l0.pgla {
  private final l0.pgla a;
  
  PglMSManager(l0.pgla parampgla) {
    this.a = parampgla;
  }
  
  public Map<String, String> frameSign(String paramString, int paramInt) {
    return this.a.frameSign(paramString, paramInt);
  }
  
  public Map<String, String> getFeatureHash(String paramString, byte[] paramArrayOfbyte) {
    return this.a.getFeatureHash(paramString, paramArrayOfbyte);
  }
  
  public Map<String, String> getReportRaw(String paramString, int paramInt, Map<String, String> paramMap) {
    return this.a.getReportRaw(paramString, paramInt, paramMap);
  }
  
  public String getToken() {
    return this.a.getToken();
  }
  
  public void report(String paramString) {
    this.a.report(paramString);
  }
  
  public void setBDDeviceID(String paramString) {
    this.a.setBDDeviceID(paramString);
  }
  
  public void setCollectMode(int paramInt) {
    this.a.setCollectMode(paramInt);
  }
  
  public void setDeviceID(String paramString) {
    this.a.setDeviceID(paramString);
  }
  
  public void setInstallID(String paramString) {
    this.a.setInstallID(paramString);
  }
  
  public void setSessionID(String paramString) {
    this.a.setSessionID(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\mobsec\metasec\ov\PglMSManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */