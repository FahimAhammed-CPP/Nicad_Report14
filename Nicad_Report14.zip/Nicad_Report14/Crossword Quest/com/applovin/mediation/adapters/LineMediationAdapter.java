package com.applovin.mediation.adapters;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.applovin.impl.sdk.utils.BundleUtils;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.adapter.MaxAdViewAdapter;
import com.applovin.mediation.adapter.MaxAdapter;
import com.applovin.mediation.adapter.MaxAdapterError;
import com.applovin.mediation.adapter.MaxInterstitialAdapter;
import com.applovin.mediation.adapter.MaxRewardedAdapter;
import com.applovin.mediation.adapter.listeners.MaxAdViewAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxInterstitialAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxNativeAdAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxRewardedAdapterListener;
import com.applovin.mediation.adapter.parameters.MaxAdapterInitializationParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterResponseParameters;
import com.applovin.mediation.nativeAds.MaxNativeAd;
import com.applovin.mediation.nativeAds.MaxNativeAdView;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkConfiguration;
import com.applovin.sdk.AppLovinSdkUtils;
import com.five_corp.ad.FiveAd;
import com.five_corp.ad.FiveAdConfig;
import com.five_corp.ad.FiveAdCustomLayout;
import com.five_corp.ad.FiveAdErrorCode;
import com.five_corp.ad.FiveAdInterface;
import com.five_corp.ad.FiveAdInterstitial;
import com.five_corp.ad.FiveAdLoadListener;
import com.five_corp.ad.FiveAdNative;
import com.five_corp.ad.FiveAdState;
import com.five_corp.ad.FiveAdVideoReward;
import com.five_corp.ad.FiveAdViewEventListener;
import com.five_corp.ad.NeedChildDirectedTreatment;
import com.five_corp.ad.NeedGdprNonPersonalizedAdsTreatment;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class LineMediationAdapter extends MediationAdapterBase implements MaxInterstitialAdapter, MaxRewardedAdapter, MaxAdViewAdapter {
  private static final AtomicBoolean INITIALIZED = new AtomicBoolean();
  
  private FiveAdCustomLayout adView;
  
  private FiveAdInterstitial interstitialAd;
  
  private FiveAdNative nativeAd;
  
  private FiveAdVideoReward rewardedAd;
  
  public LineMediationAdapter(AppLovinSdk paramAppLovinSdk) {
    super(paramAppLovinSdk);
  }
  
  private Boolean getPrivacySetting(String paramString, MaxAdapterParameters paramMaxAdapterParameters) {
    try {
      return (Boolean)paramMaxAdapterParameters.getClass().getMethod(paramString, new Class[0]).invoke(paramMaxAdapterParameters, new Object[0]);
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Error getting privacy setting ");
      stringBuilder.append(paramString);
      stringBuilder.append(" with exception: ");
      log(stringBuilder.toString(), exception);
      return (AppLovinSdk.VERSION_CODE >= 9140000) ? null : Boolean.valueOf(false);
    } 
  }
  
  private static MaxAdapterError toMaxError(FiveAdErrorCode paramFiveAdErrorCode) {
    MaxAdapterError maxAdapterError = MaxAdapterError.UNSPECIFIED;
    int i = null.$SwitchMap$com$five_corp$ad$FiveAdErrorCode[paramFiveAdErrorCode.ordinal()];
    String str = "Please contact us.";
    switch (i) {
      default:
        return new MaxAdapterError(maxAdapterError.getErrorCode(), maxAdapterError.getErrorMessage(), paramFiveAdErrorCode.ordinal(), str);
      case 8:
      case 9:
        maxAdapterError = MaxAdapterError.UNSPECIFIED;
      case 7:
        maxAdapterError = MaxAdapterError.INVALID_CONFIGURATION;
        str = "Make sure you are using the SlotID issued on the FIVE Dashboard.";
      case 6:
        maxAdapterError = MaxAdapterError.INVALID_LOAD_STATE;
        str = "There is a problem with the implementation. Please check the following. Whether the initialization process (FiveAd.initialize) is executed before the creation of the ad object or loadAdAsync. Are you calling loadAdAsync multiple times for one ad object?";
      case 5:
        maxAdapterError = MaxAdapterError.INTERNAL_ERROR;
      case 4:
        maxAdapterError = MaxAdapterError.UNSPECIFIED;
        str = "There is a problem with the device storage. Please try again with another device.";
      case 3:
        maxAdapterError = MaxAdapterError.INVALID_CONFIGURATION;
        str = "Check if the OS type, PackageName, and issued AppID registered in FIVE Dashboard and the application settings match. Please be careful about blanks.";
      case 2:
        maxAdapterError = MaxAdapterError.NO_FILL;
        str = "Ad was not ready at display time. Please try again.";
      case 1:
        break;
    } 
    maxAdapterError = MaxAdapterError.NO_CONNECTION;
    str = "Please try again in a stable network environment.";
  }
  
  public String getAdapterVersion() {
    return "2022.2.16.3";
  }
  
  public String getSdkVersion() {
    return FiveAd.getSdkSemanticVersion();
  }
  
  public void initialize(MaxAdapterInitializationParameters paramMaxAdapterInitializationParameters, Activity paramActivity, MaxAdapter.OnCompletionListener paramOnCompletionListener) {
    if (INITIALIZED.compareAndSet(false, true)) {
      Context context;
      String str = paramMaxAdapterInitializationParameters.getServerParameters().getString("app_id");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Initializing Line SDK with app id: ");
      stringBuilder.append(str);
      stringBuilder.append("...");
      log(stringBuilder.toString());
      FiveAdConfig fiveAdConfig = new FiveAdConfig(str);
      fiveAdConfig.isTest = paramMaxAdapterInitializationParameters.isTesting();
      Bundle bundle = paramMaxAdapterInitializationParameters.getServerParameters();
      if (bundle.containsKey("is_muted"))
        fiveAdConfig.enableSoundByDefault(bundle.getBoolean("is_muted") ^ true); 
      if (getWrappingSdk().getConfiguration().getConsentDialogState() == AppLovinSdkConfiguration.ConsentDialogState.APPLIES) {
        Boolean bool1 = getPrivacySetting("hasUserConsent", (MaxAdapterParameters)paramMaxAdapterInitializationParameters);
        if (bool1 != null) {
          NeedGdprNonPersonalizedAdsTreatment needGdprNonPersonalizedAdsTreatment;
          if (bool1.booleanValue()) {
            needGdprNonPersonalizedAdsTreatment = NeedGdprNonPersonalizedAdsTreatment.FALSE;
          } else {
            needGdprNonPersonalizedAdsTreatment = NeedGdprNonPersonalizedAdsTreatment.TRUE;
          } 
          fiveAdConfig.needGdprNonPersonalizedAdsTreatment = needGdprNonPersonalizedAdsTreatment;
        } 
      } 
      Boolean bool = getPrivacySetting("isAgeRestrictedUser", (MaxAdapterParameters)paramMaxAdapterInitializationParameters);
      if (bool != null) {
        NeedChildDirectedTreatment needChildDirectedTreatment;
        if (bool.booleanValue()) {
          needChildDirectedTreatment = NeedChildDirectedTreatment.TRUE;
        } else {
          needChildDirectedTreatment = NeedChildDirectedTreatment.FALSE;
        } 
        fiveAdConfig.needChildDirectedTreatment = needChildDirectedTreatment;
      } 
      if (paramActivity != null) {
        context = paramActivity.getApplicationContext();
      } else {
        context = getApplicationContext();
      } 
      FiveAd.initialize(context, fiveAdConfig);
      paramOnCompletionListener.onCompletion(MaxAdapter.InitializationStatus.INITIALIZED_UNKNOWN, null);
      return;
    } 
    if (FiveAd.isInitialized()) {
      log("Line SDK is already initialized");
      paramOnCompletionListener.onCompletion(MaxAdapter.InitializationStatus.INITIALIZED_UNKNOWN, null);
      return;
    } 
    log("Line SDK still initializing");
    paramOnCompletionListener.onCompletion(MaxAdapter.InitializationStatus.INITIALIZING, null);
  }
  
  public void loadAdViewAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, MaxAdFormat paramMaxAdFormat, Activity paramActivity, MaxAdViewAdapterListener paramMaxAdViewAdapterListener) {
    String str1;
    boolean bool = paramMaxAdapterResponseParameters.getServerParameters().getBoolean("is_native");
    String str2 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading ");
    if (bool) {
      str1 = "native ";
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    stringBuilder.append(paramMaxAdFormat.getLabel());
    stringBuilder.append(" ad for slot id: ");
    stringBuilder.append(str2);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    if (bool) {
      this.nativeAd = new FiveAdNative((Context)paramActivity, str2, (new DisplayMetrics()).widthPixels);
      NativeAdViewListener nativeAdViewListener = new NativeAdViewListener(paramMaxAdViewAdapterListener, paramMaxAdFormat, paramMaxAdapterResponseParameters.getServerParameters(), paramActivity);
      this.nativeAd.setLoadListener(nativeAdViewListener);
      this.nativeAd.setViewEventListener(nativeAdViewListener);
      this.nativeAd.enableSound(false);
      this.nativeAd.loadAdAsync();
      return;
    } 
    this.adView = new FiveAdCustomLayout((Context)paramActivity, str2, (new DisplayMetrics()).widthPixels);
    AdViewListener adViewListener = new AdViewListener(paramMaxAdViewAdapterListener, paramMaxAdFormat);
    this.adView.setLoadListener(adViewListener);
    this.adView.setViewEventListener(adViewListener);
    this.adView.enableSound(false);
    this.adView.loadAdAsync();
  }
  
  public void loadInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxInterstitialAdapterListener paramMaxInterstitialAdapterListener) {
    String str = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading interstitial ad for slot id: ");
    stringBuilder.append(str);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    this.interstitialAd = new FiveAdInterstitial(paramActivity, str);
    InterstitialListener interstitialListener = new InterstitialListener(paramMaxInterstitialAdapterListener);
    this.interstitialAd.setLoadListener(interstitialListener);
    this.interstitialAd.setViewEventListener(interstitialListener);
    this.interstitialAd.loadAdAsync();
  }
  
  public void loadNativeAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxNativeAdAdapterListener paramMaxNativeAdAdapterListener) {
    String str = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading native ad for slot id: ");
    stringBuilder.append(str);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    this.nativeAd = new FiveAdNative((Context)paramActivity, str, (new DisplayMetrics()).widthPixels);
    NativeAdListener nativeAdListener = new NativeAdListener(paramMaxNativeAdAdapterListener, paramMaxAdapterResponseParameters.getServerParameters(), paramActivity);
    this.nativeAd.setLoadListener(nativeAdListener);
    this.nativeAd.setViewEventListener(nativeAdListener);
    this.nativeAd.enableSound(false);
    this.nativeAd.loadAdAsync();
  }
  
  public void loadRewardedAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxRewardedAdapterListener paramMaxRewardedAdapterListener) {
    String str = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading rewarded ad for slot id: ");
    stringBuilder.append(str);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    this.rewardedAd = new FiveAdVideoReward(paramActivity, str);
    RewardedListener rewardedListener = new RewardedListener(paramMaxRewardedAdapterListener);
    this.rewardedAd.setLoadListener(rewardedListener);
    this.rewardedAd.setViewEventListener(rewardedListener);
    this.rewardedAd.loadAdAsync();
  }
  
  public void onDestroy() {
    this.interstitialAd = null;
    this.rewardedAd = null;
    this.adView = null;
    this.nativeAd = null;
  }
  
  public void showInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxInterstitialAdapterListener paramMaxInterstitialAdapterListener) {
    String str = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Showing interstitial ad for slot id: ");
    stringBuilder.append(str);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    this.interstitialAd.show(paramActivity);
  }
  
  public void showRewardedAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxRewardedAdapterListener paramMaxRewardedAdapterListener) {
    String str = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Showing rewarded ad for slot id: ");
    stringBuilder.append(str);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    configureReward(paramMaxAdapterResponseParameters);
    this.rewardedAd.show(paramActivity);
  }
  
  private class AdViewListener implements FiveAdLoadListener, FiveAdViewEventListener {
    private final MaxAdFormat adFormat;
    
    private final MaxAdViewAdapterListener listener;
    
    AdViewListener(MaxAdViewAdapterListener param1MaxAdViewAdapterListener, MaxAdFormat param1MaxAdFormat) {
      this.listener = param1MaxAdViewAdapterListener;
      this.adFormat = param1MaxAdFormat;
    }
    
    public void onFiveAdClick(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad clicked for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdClicked();
    }
    
    public void onFiveAdClose(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad hidden for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdHidden();
    }
    
    public void onFiveAdImpression(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad impression tracked for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdDisplayed();
    }
    
    public void onFiveAdLoad(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad loaded for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdLoaded((View)LineMediationAdapter.this.adView);
    }
    
    public void onFiveAdLoadError(FiveAdInterface param1FiveAdInterface, FiveAdErrorCode param1FiveAdErrorCode) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad failed to load for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append(" with error: ");
      stringBuilder.append(param1FiveAdErrorCode);
      lineMediationAdapter.log(stringBuilder.toString());
      MaxAdapterError maxAdapterError = LineMediationAdapter.toMaxError(param1FiveAdErrorCode);
      this.listener.onAdViewAdLoadFailed(maxAdapterError);
    }
    
    public void onFiveAdPause(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad did pause for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdRecover(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad did recover for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdReplay(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad did replay for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdResume(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad did resume for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdStall(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad did stall for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdStart(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad shown for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdDisplayed();
    }
    
    public void onFiveAdViewError(FiveAdInterface param1FiveAdInterface, FiveAdErrorCode param1FiveAdErrorCode) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad failed to show for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append(" with error: ");
      stringBuilder.append(param1FiveAdErrorCode);
      lineMediationAdapter.log(stringBuilder.toString());
      MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad Display Failed", param1FiveAdErrorCode.value, "Please Contact Us");
      this.listener.onAdViewAdDisplayFailed(maxAdapterError);
    }
    
    public void onFiveAdViewThrough(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad completed for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
  }
  
  private class InterstitialListener implements FiveAdLoadListener, FiveAdViewEventListener {
    private final MaxInterstitialAdapterListener listener;
    
    InterstitialListener(MaxInterstitialAdapterListener param1MaxInterstitialAdapterListener) {
      this.listener = param1MaxInterstitialAdapterListener;
    }
    
    public void onFiveAdClick(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad clicked for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onInterstitialAdClicked();
    }
    
    public void onFiveAdClose(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad hidden for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onInterstitialAdHidden();
    }
    
    public void onFiveAdImpression(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad impression tracked for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onInterstitialAdDisplayed();
    }
    
    public void onFiveAdLoad(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad loaded for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onInterstitialAdLoaded();
    }
    
    public void onFiveAdLoadError(FiveAdInterface param1FiveAdInterface, FiveAdErrorCode param1FiveAdErrorCode) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad failed to load for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append(" with error: ");
      stringBuilder.append(param1FiveAdErrorCode);
      lineMediationAdapter.log(stringBuilder.toString());
      MaxAdapterError maxAdapterError = LineMediationAdapter.toMaxError(param1FiveAdErrorCode);
      this.listener.onInterstitialAdLoadFailed(maxAdapterError);
    }
    
    public void onFiveAdPause(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad did pause for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdRecover(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad did recover for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdReplay(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad did replay for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdResume(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad did resume for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdStall(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad did stall for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdStart(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad shown for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onInterstitialAdDisplayed();
    }
    
    public void onFiveAdViewError(FiveAdInterface param1FiveAdInterface, FiveAdErrorCode param1FiveAdErrorCode) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad failed to show for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append(" with error: ");
      stringBuilder.append(param1FiveAdErrorCode);
      lineMediationAdapter.log(stringBuilder.toString());
      MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad Display Failed", param1FiveAdErrorCode.value, "Please Contact Us");
      this.listener.onInterstitialAdDisplayFailed(maxAdapterError);
    }
    
    public void onFiveAdViewThrough(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad completed for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
  }
  
  private class MaxLineNativeAd extends MaxNativeAd {
    private MaxLineNativeAd(MaxNativeAd.Builder param1Builder) {
      super(param1Builder);
    }
    
    public boolean prepareForInteraction(List<View> param1List, ViewGroup param1ViewGroup) {
      ImageView imageView;
      FiveAdNative fiveAdNative = LineMediationAdapter.this.nativeAd;
      if (fiveAdNative == null) {
        LineMediationAdapter.this.e("Failed to register native ad views: native ad is null.");
        return false;
      } 
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Preparing views for interaction: ");
      stringBuilder.append(param1List);
      stringBuilder.append(" with container: ");
      stringBuilder.append(param1ViewGroup);
      lineMediationAdapter.d(stringBuilder.toString());
      stringBuilder = null;
      Iterator<View> iterator = param1List.iterator();
      while (true) {
        StringBuilder stringBuilder1 = stringBuilder;
        if (iterator.hasNext()) {
          View view = iterator.next();
          if (view instanceof ImageView) {
            imageView = (ImageView)view;
            break;
          } 
          continue;
        } 
        break;
      } 
      fiveAdNative.registerViews((View)param1ViewGroup, (View)imageView, param1List);
      return true;
    }
    
    public void prepareViewForInteraction(MaxNativeAdView param1MaxNativeAdView) {
      ArrayList<TextView> arrayList = new ArrayList();
      if (AppLovinSdkUtils.isValidString(getTitle()) && param1MaxNativeAdView.getTitleTextView() != null)
        arrayList.add(param1MaxNativeAdView.getTitleTextView()); 
      if (AppLovinSdkUtils.isValidString(getBody()) && param1MaxNativeAdView.getBodyTextView() != null)
        arrayList.add(param1MaxNativeAdView.getBodyTextView()); 
      if (AppLovinSdkUtils.isValidString(getCallToAction()) && param1MaxNativeAdView.getCallToActionButton() != null)
        arrayList.add(param1MaxNativeAdView.getCallToActionButton()); 
      if (getIcon() != null && param1MaxNativeAdView.getIconImageView() != null)
        arrayList.add(param1MaxNativeAdView.getIconImageView()); 
      if (getMediaView() != null && param1MaxNativeAdView.getMediaContentViewGroup() != null)
        arrayList.add(param1MaxNativeAdView.getMediaContentViewGroup()); 
      if (AppLovinSdkUtils.isValidString(getAdvertiser()) && param1MaxNativeAdView.getAdvertiserTextView() != null)
        arrayList.add(param1MaxNativeAdView.getAdvertiserTextView()); 
      prepareForInteraction((List)arrayList, (ViewGroup)param1MaxNativeAdView);
    }
  }
  
  private class NativeAdListener implements FiveAdLoadListener, FiveAdViewEventListener {
    private final WeakReference<Activity> activityRef;
    
    private final MaxNativeAdAdapterListener listener;
    
    private final Bundle serverParameters;
    
    NativeAdListener(MaxNativeAdAdapterListener param1MaxNativeAdAdapterListener, Bundle param1Bundle, Activity param1Activity) {
      this.listener = param1MaxNativeAdAdapterListener;
      this.serverParameters = param1Bundle;
      this.activityRef = new WeakReference<Activity>(param1Activity);
    }
    
    public void onFiveAdClick(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad clicked for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onNativeAdClicked();
    }
    
    public void onFiveAdClose(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad hidden for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdImpression(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad impression tracked for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onNativeAdDisplayed(null);
    }
    
    public void onFiveAdLoad(final FiveAdInterface ad) {
      LineMediationAdapter lineMediationAdapter1;
      final StringBuilder activity;
      LineMediationAdapter lineMediationAdapter2 = LineMediationAdapter.this;
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append("Native ad loaded for slot id: ");
      stringBuilder2.append(ad.getSlotId());
      stringBuilder2.append("...");
      lineMediationAdapter2.log(stringBuilder2.toString());
      FiveAdNative fiveAdNative = LineMediationAdapter.this.nativeAd;
      if (fiveAdNative == null) {
        lineMediationAdapter1 = LineMediationAdapter.this;
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Native ad destroyed before the ad successfully loaded: ");
        stringBuilder2.append(ad.getSlotId());
        stringBuilder2.append("...");
        lineMediationAdapter1.log(stringBuilder2.toString());
        this.listener.onNativeAdLoadFailed(MaxAdapterError.INVALID_LOAD_STATE);
        return;
      } 
      Activity activity = this.activityRef.get();
      if (activity == null) {
        lineMediationAdapter1 = LineMediationAdapter.this;
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Native ad (");
        stringBuilder1.append(ad.getSlotId());
        stringBuilder1.append(") failed to load: activity reference is null when ad is loaded");
        lineMediationAdapter1.log(stringBuilder1.toString());
        this.listener.onNativeAdLoadFailed(MaxAdapterError.INVALID_LOAD_STATE);
        return;
      } 
      if (AppLovinSdkUtils.isValidString(BundleUtils.getString("template", "", this.serverParameters)) && TextUtils.isEmpty(lineMediationAdapter1.getAdTitle())) {
        lineMediationAdapter1 = LineMediationAdapter.this;
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Native ad (");
        stringBuilder1.append(ad);
        stringBuilder1.append(") does not have required assets.");
        lineMediationAdapter1.e(stringBuilder1.toString());
        this.listener.onNativeAdLoadFailed(new MaxAdapterError(-5400, "Missing Native Ad Assets"));
        return;
      } 
      lineMediationAdapter1.loadIconImageAsync(new FiveAdNative.LoadImageCallback() {
            public void onImageLoad(Bitmap param2Bitmap) {
              LineMediationAdapter lineMediationAdapter;
              StringBuilder stringBuilder;
              FiveAdNative fiveAdNative = LineMediationAdapter.this.nativeAd;
              if (fiveAdNative == null) {
                lineMediationAdapter = LineMediationAdapter.this;
                stringBuilder = new StringBuilder();
                stringBuilder.append("Native ad destroyed before assets finished load for slot id: ");
                stringBuilder.append(ad.getSlotId());
                lineMediationAdapter.log(stringBuilder.toString());
                return;
              } 
              MaxNativeAd.Builder builder = (new MaxNativeAd.Builder()).setAdFormat(MaxAdFormat.NATIVE).setTitle(stringBuilder.getAdTitle()).setBody(stringBuilder.getDescriptionText()).setCallToAction(stringBuilder.getButtonText()).setAdvertiser(stringBuilder.getAdvertiserName()).setIcon(new MaxNativeAd.MaxNativeAdImage((Drawable)new BitmapDrawable(activity.getResources(), (Bitmap)lineMediationAdapter))).setMediaView(stringBuilder.getAdMainView()).setAdvertiser(stringBuilder.getAdvertiserName());
              LineMediationAdapter.MaxLineNativeAd maxLineNativeAd = new LineMediationAdapter.MaxLineNativeAd(builder);
              LineMediationAdapter.NativeAdListener.this.listener.onNativeAdLoaded(maxLineNativeAd, null);
            }
          });
    }
    
    public void onFiveAdLoadError(FiveAdInterface param1FiveAdInterface, FiveAdErrorCode param1FiveAdErrorCode) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad failed to load for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append(" with error: ");
      stringBuilder.append(param1FiveAdErrorCode);
      lineMediationAdapter.log(stringBuilder.toString());
      MaxAdapterError maxAdapterError = LineMediationAdapter.toMaxError(param1FiveAdErrorCode);
      this.listener.onNativeAdLoadFailed(maxAdapterError);
    }
    
    public void onFiveAdPause(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad did pause for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdRecover(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad did recover for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdReplay(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad did replay for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdResume(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad did resume for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdStall(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad did stall for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdStart(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad shown for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onNativeAdDisplayed(null);
    }
    
    public void onFiveAdViewError(FiveAdInterface param1FiveAdInterface, FiveAdErrorCode param1FiveAdErrorCode) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad failed to show for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append(" with error: ");
      stringBuilder.append(param1FiveAdErrorCode);
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdViewThrough(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad completed for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
  }
  
  class null implements FiveAdNative.LoadImageCallback {
    public void onImageLoad(Bitmap param1Bitmap) {
      LineMediationAdapter lineMediationAdapter;
      StringBuilder stringBuilder;
      FiveAdNative fiveAdNative = LineMediationAdapter.this.nativeAd;
      if (fiveAdNative == null) {
        lineMediationAdapter = LineMediationAdapter.this;
        stringBuilder = new StringBuilder();
        stringBuilder.append("Native ad destroyed before assets finished load for slot id: ");
        stringBuilder.append(ad.getSlotId());
        lineMediationAdapter.log(stringBuilder.toString());
        return;
      } 
      MaxNativeAd.Builder builder = (new MaxNativeAd.Builder()).setAdFormat(MaxAdFormat.NATIVE).setTitle(stringBuilder.getAdTitle()).setBody(stringBuilder.getDescriptionText()).setCallToAction(stringBuilder.getButtonText()).setAdvertiser(stringBuilder.getAdvertiserName()).setIcon(new MaxNativeAd.MaxNativeAdImage((Drawable)new BitmapDrawable(activity.getResources(), (Bitmap)lineMediationAdapter))).setMediaView(stringBuilder.getAdMainView()).setAdvertiser(stringBuilder.getAdvertiserName());
      LineMediationAdapter.MaxLineNativeAd maxLineNativeAd = new LineMediationAdapter.MaxLineNativeAd(builder);
      this.this$1.listener.onNativeAdLoaded(maxLineNativeAd, null);
    }
  }
  
  private class NativeAdViewListener implements FiveAdLoadListener, FiveAdViewEventListener {
    private final WeakReference<Activity> activityRef;
    
    private final MaxAdFormat adFormat;
    
    private final MaxAdViewAdapterListener listener;
    
    private final Bundle serverParameters;
    
    NativeAdViewListener(MaxAdViewAdapterListener param1MaxAdViewAdapterListener, MaxAdFormat param1MaxAdFormat, Bundle param1Bundle, Activity param1Activity) {
      this.listener = param1MaxAdViewAdapterListener;
      this.adFormat = param1MaxAdFormat;
      this.serverParameters = param1Bundle;
      this.activityRef = new WeakReference<Activity>(param1Activity);
    }
    
    private void renderCustomNativeBanner(final String slotId, final Activity activity) {
      LineMediationAdapter.this.nativeAd.loadIconImageAsync(new FiveAdNative.LoadImageCallback() {
            public void onImageLoad(final Bitmap bitmap) {
              AppLovinSdkUtils.runOnUiThread(new Runnable() {
                    public void run() {
                      MaxNativeAdView maxNativeAdView;
                      FrameLayout frameLayout;
                      FiveAdNative fiveAdNative = LineMediationAdapter.this.nativeAd;
                      if (fiveAdNative == null) {
                        LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Native ");
                        stringBuilder.append(LineMediationAdapter.NativeAdViewListener.this.adFormat.getLabel());
                        stringBuilder.append(" ad destroyed before assets finished load for slot id: ");
                        stringBuilder.append(slotId);
                        lineMediationAdapter.log(stringBuilder.toString());
                        return;
                      } 
                      MaxNativeAd maxNativeAd = (new MaxNativeAd.Builder()).setAdFormat(LineMediationAdapter.NativeAdViewListener.this.adFormat).setTitle(fiveAdNative.getAdTitle()).setBody(fiveAdNative.getDescriptionText()).setCallToAction(fiveAdNative.getButtonText()).setIcon(new MaxNativeAd.MaxNativeAdImage((Drawable)new BitmapDrawable(activity.getResources(), bitmap))).setMediaView(fiveAdNative.getAdMainView()).build();
                      String str = BundleUtils.getString("template", "", LineMediationAdapter.NativeAdViewListener.this.serverParameters);
                      if (str.contains("vertical") && AppLovinSdk.VERSION_CODE < 9140500)
                        LineMediationAdapter.this.log("Vertical native banners are only supported on MAX SDK 9.14.5 and above. Default native template will be used."); 
                      if (AppLovinSdk.VERSION_CODE < 9140000) {
                        LineMediationAdapter.this.log("Native ads with media views are only supported on MAX SDK version 9.14.0 and above. Default native template will be used.");
                        maxNativeAdView = new MaxNativeAdView(maxNativeAd, activity);
                      } else if (maxNativeAdView.equals("vertical")) {
                        String str1;
                        if (LineMediationAdapter.NativeAdViewListener.this.adFormat == MaxAdFormat.LEADER) {
                          str1 = "vertical_leader_template";
                        } else {
                          str1 = "vertical_media_banner_template";
                        } 
                        if (AppLovinSdk.VERSION_CODE >= 11010000) {
                          maxNativeAdView = new MaxNativeAdView(maxNativeAd, str1, LineMediationAdapter.this.getApplicationContext());
                        } else {
                          maxNativeAdView = new MaxNativeAdView(maxNativeAd, (String)maxNativeAdView, activity);
                        } 
                      } else if (AppLovinSdk.VERSION_CODE >= 11010000) {
                        maxNativeAdView = new MaxNativeAdView(maxNativeAd, (String)maxNativeAdView, LineMediationAdapter.this.getApplicationContext());
                      } else {
                        maxNativeAdView = new MaxNativeAdView(maxNativeAd, (String)maxNativeAdView, activity);
                      } 
                      ArrayList<ImageView> arrayList = new ArrayList();
                      if (maxNativeAd.getIcon() != null && maxNativeAdView.getIconImageView() != null)
                        arrayList.add(maxNativeAdView.getIconImageView()); 
                      if (AppLovinSdk.VERSION_CODE >= 11000000) {
                        ViewGroup viewGroup = maxNativeAdView.getMediaContentViewGroup();
                      } else {
                        frameLayout = maxNativeAdView.getMediaContentView();
                      } 
                      if (maxNativeAd.getMediaView() != null && frameLayout != null)
                        arrayList.add(frameLayout); 
                      if (AppLovinSdkUtils.isValidString(maxNativeAd.getTitle()) && maxNativeAdView.getTitleTextView() != null)
                        arrayList.add(maxNativeAdView.getTitleTextView()); 
                      if (AppLovinSdkUtils.isValidString(maxNativeAd.getCallToAction()) && maxNativeAdView.getCallToActionButton() != null)
                        arrayList.add(maxNativeAdView.getCallToActionButton()); 
                      if (AppLovinSdkUtils.isValidString(maxNativeAd.getBody()) && maxNativeAdView.getBodyTextView() != null)
                        arrayList.add(maxNativeAdView.getBodyTextView()); 
                      fiveAdNative.registerViews((View)maxNativeAdView, (View)maxNativeAdView.getIconImageView(), arrayList);
                      LineMediationAdapter.NativeAdViewListener.this.listener.onAdViewAdLoaded((View)maxNativeAdView);
                    }
                  });
            }
          });
    }
    
    public void onFiveAdClick(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad clicked for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdClicked();
    }
    
    public void onFiveAdClose(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad hidden for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdHidden();
    }
    
    public void onFiveAdImpression(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad impression tracked for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdDisplayed();
    }
    
    public void onFiveAdLoad(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad loaded for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      if (LineMediationAdapter.this.nativeAd == null) {
        lineMediationAdapter = LineMediationAdapter.this;
        stringBuilder = new StringBuilder();
        stringBuilder.append("Native ");
        stringBuilder.append(this.adFormat.getLabel());
        stringBuilder.append(" ad failed to load: no fill for slot id: ");
        stringBuilder.append(param1FiveAdInterface.getSlotId());
        stringBuilder.append("...");
        lineMediationAdapter.log(stringBuilder.toString());
        this.listener.onAdViewAdLoadFailed(MaxAdapterError.NO_FILL);
        return;
      } 
      renderCustomNativeBanner(param1FiveAdInterface.getSlotId(), this.activityRef.get());
    }
    
    public void onFiveAdLoadError(FiveAdInterface param1FiveAdInterface, FiveAdErrorCode param1FiveAdErrorCode) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad failed to load for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append(" with error: ");
      stringBuilder.append(param1FiveAdErrorCode);
      lineMediationAdapter.log(stringBuilder.toString());
      MaxAdapterError maxAdapterError = LineMediationAdapter.toMaxError(param1FiveAdErrorCode);
      this.listener.onAdViewAdLoadFailed(maxAdapterError);
    }
    
    public void onFiveAdPause(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad did pause for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdRecover(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad did recover for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdReplay(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad did replay for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdResume(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad did resume for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdStall(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad did stall for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdStart(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad shown for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdDisplayed();
    }
    
    public void onFiveAdViewError(FiveAdInterface param1FiveAdInterface, FiveAdErrorCode param1FiveAdErrorCode) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad failed to show for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append(" with error: ");
      stringBuilder.append(param1FiveAdErrorCode);
      lineMediationAdapter.log(stringBuilder.toString());
      MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad Display Failed", param1FiveAdErrorCode.value, "Please Contact Us");
      this.listener.onAdViewAdDisplayFailed(maxAdapterError);
    }
    
    public void onFiveAdViewThrough(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad completed for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
  }
  
  class null implements FiveAdNative.LoadImageCallback {
    public void onImageLoad(final Bitmap bitmap) {
      AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
              MaxNativeAdView maxNativeAdView;
              FrameLayout frameLayout;
              FiveAdNative fiveAdNative = LineMediationAdapter.this.nativeAd;
              if (fiveAdNative == null) {
                LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Native ");
                stringBuilder.append(this.this$2.this$1.adFormat.getLabel());
                stringBuilder.append(" ad destroyed before assets finished load for slot id: ");
                stringBuilder.append(slotId);
                lineMediationAdapter.log(stringBuilder.toString());
                return;
              } 
              MaxNativeAd maxNativeAd = (new MaxNativeAd.Builder()).setAdFormat(this.this$2.this$1.adFormat).setTitle(fiveAdNative.getAdTitle()).setBody(fiveAdNative.getDescriptionText()).setCallToAction(fiveAdNative.getButtonText()).setIcon(new MaxNativeAd.MaxNativeAdImage((Drawable)new BitmapDrawable(activity.getResources(), bitmap))).setMediaView(fiveAdNative.getAdMainView()).build();
              String str = BundleUtils.getString("template", "", this.this$2.this$1.serverParameters);
              if (str.contains("vertical") && AppLovinSdk.VERSION_CODE < 9140500)
                LineMediationAdapter.this.log("Vertical native banners are only supported on MAX SDK 9.14.5 and above. Default native template will be used."); 
              if (AppLovinSdk.VERSION_CODE < 9140000) {
                LineMediationAdapter.this.log("Native ads with media views are only supported on MAX SDK version 9.14.0 and above. Default native template will be used.");
                maxNativeAdView = new MaxNativeAdView(maxNativeAd, activity);
              } else if (maxNativeAdView.equals("vertical")) {
                String str1;
                if (this.this$2.this$1.adFormat == MaxAdFormat.LEADER) {
                  str1 = "vertical_leader_template";
                } else {
                  str1 = "vertical_media_banner_template";
                } 
                if (AppLovinSdk.VERSION_CODE >= 11010000) {
                  maxNativeAdView = new MaxNativeAdView(maxNativeAd, str1, LineMediationAdapter.this.getApplicationContext());
                } else {
                  maxNativeAdView = new MaxNativeAdView(maxNativeAd, (String)maxNativeAdView, activity);
                } 
              } else if (AppLovinSdk.VERSION_CODE >= 11010000) {
                maxNativeAdView = new MaxNativeAdView(maxNativeAd, (String)maxNativeAdView, LineMediationAdapter.this.getApplicationContext());
              } else {
                maxNativeAdView = new MaxNativeAdView(maxNativeAd, (String)maxNativeAdView, activity);
              } 
              ArrayList<ImageView> arrayList = new ArrayList();
              if (maxNativeAd.getIcon() != null && maxNativeAdView.getIconImageView() != null)
                arrayList.add(maxNativeAdView.getIconImageView()); 
              if (AppLovinSdk.VERSION_CODE >= 11000000) {
                ViewGroup viewGroup = maxNativeAdView.getMediaContentViewGroup();
              } else {
                frameLayout = maxNativeAdView.getMediaContentView();
              } 
              if (maxNativeAd.getMediaView() != null && frameLayout != null)
                arrayList.add(frameLayout); 
              if (AppLovinSdkUtils.isValidString(maxNativeAd.getTitle()) && maxNativeAdView.getTitleTextView() != null)
                arrayList.add(maxNativeAdView.getTitleTextView()); 
              if (AppLovinSdkUtils.isValidString(maxNativeAd.getCallToAction()) && maxNativeAdView.getCallToActionButton() != null)
                arrayList.add(maxNativeAdView.getCallToActionButton()); 
              if (AppLovinSdkUtils.isValidString(maxNativeAd.getBody()) && maxNativeAdView.getBodyTextView() != null)
                arrayList.add(maxNativeAdView.getBodyTextView()); 
              fiveAdNative.registerViews((View)maxNativeAdView, (View)maxNativeAdView.getIconImageView(), arrayList);
              this.this$2.this$1.listener.onAdViewAdLoaded((View)maxNativeAdView);
            }
          });
    }
  }
  
  class null implements Runnable {
    public void run() {
      MaxNativeAdView maxNativeAdView;
      FrameLayout frameLayout;
      FiveAdNative fiveAdNative = LineMediationAdapter.this.nativeAd;
      if (fiveAdNative == null) {
        LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Native ");
        stringBuilder.append(this.this$2.this$1.adFormat.getLabel());
        stringBuilder.append(" ad destroyed before assets finished load for slot id: ");
        stringBuilder.append(slotId);
        lineMediationAdapter.log(stringBuilder.toString());
        return;
      } 
      MaxNativeAd maxNativeAd = (new MaxNativeAd.Builder()).setAdFormat(this.this$2.this$1.adFormat).setTitle(fiveAdNative.getAdTitle()).setBody(fiveAdNative.getDescriptionText()).setCallToAction(fiveAdNative.getButtonText()).setIcon(new MaxNativeAd.MaxNativeAdImage((Drawable)new BitmapDrawable(activity.getResources(), bitmap))).setMediaView(fiveAdNative.getAdMainView()).build();
      String str = BundleUtils.getString("template", "", this.this$2.this$1.serverParameters);
      if (str.contains("vertical") && AppLovinSdk.VERSION_CODE < 9140500)
        LineMediationAdapter.this.log("Vertical native banners are only supported on MAX SDK 9.14.5 and above. Default native template will be used."); 
      if (AppLovinSdk.VERSION_CODE < 9140000) {
        LineMediationAdapter.this.log("Native ads with media views are only supported on MAX SDK version 9.14.0 and above. Default native template will be used.");
        maxNativeAdView = new MaxNativeAdView(maxNativeAd, activity);
      } else if (maxNativeAdView.equals("vertical")) {
        String str1;
        if (this.this$2.this$1.adFormat == MaxAdFormat.LEADER) {
          str1 = "vertical_leader_template";
        } else {
          str1 = "vertical_media_banner_template";
        } 
        if (AppLovinSdk.VERSION_CODE >= 11010000) {
          maxNativeAdView = new MaxNativeAdView(maxNativeAd, str1, LineMediationAdapter.this.getApplicationContext());
        } else {
          maxNativeAdView = new MaxNativeAdView(maxNativeAd, (String)maxNativeAdView, activity);
        } 
      } else if (AppLovinSdk.VERSION_CODE >= 11010000) {
        maxNativeAdView = new MaxNativeAdView(maxNativeAd, (String)maxNativeAdView, LineMediationAdapter.this.getApplicationContext());
      } else {
        maxNativeAdView = new MaxNativeAdView(maxNativeAd, (String)maxNativeAdView, activity);
      } 
      ArrayList<ImageView> arrayList = new ArrayList();
      if (maxNativeAd.getIcon() != null && maxNativeAdView.getIconImageView() != null)
        arrayList.add(maxNativeAdView.getIconImageView()); 
      if (AppLovinSdk.VERSION_CODE >= 11000000) {
        ViewGroup viewGroup = maxNativeAdView.getMediaContentViewGroup();
      } else {
        frameLayout = maxNativeAdView.getMediaContentView();
      } 
      if (maxNativeAd.getMediaView() != null && frameLayout != null)
        arrayList.add(frameLayout); 
      if (AppLovinSdkUtils.isValidString(maxNativeAd.getTitle()) && maxNativeAdView.getTitleTextView() != null)
        arrayList.add(maxNativeAdView.getTitleTextView()); 
      if (AppLovinSdkUtils.isValidString(maxNativeAd.getCallToAction()) && maxNativeAdView.getCallToActionButton() != null)
        arrayList.add(maxNativeAdView.getCallToActionButton()); 
      if (AppLovinSdkUtils.isValidString(maxNativeAd.getBody()) && maxNativeAdView.getBodyTextView() != null)
        arrayList.add(maxNativeAdView.getBodyTextView()); 
      fiveAdNative.registerViews((View)maxNativeAdView, (View)maxNativeAdView.getIconImageView(), arrayList);
      this.this$2.this$1.listener.onAdViewAdLoaded((View)maxNativeAdView);
    }
  }
  
  private class RewardedListener implements FiveAdLoadListener, FiveAdViewEventListener {
    private boolean hasGrantedReward;
    
    private final MaxRewardedAdapterListener listener;
    
    RewardedListener(MaxRewardedAdapterListener param1MaxRewardedAdapterListener) {
      this.listener = param1MaxRewardedAdapterListener;
    }
    
    public void onFiveAdClick(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad clicked for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdClicked();
    }
    
    public void onFiveAdClose(FiveAdInterface param1FiveAdInterface) {
      if (param1FiveAdInterface.getState() != FiveAdState.ERROR && (this.hasGrantedReward || LineMediationAdapter.this.shouldAlwaysRewardUser())) {
        MaxReward maxReward = LineMediationAdapter.this.getReward();
        LineMediationAdapter lineMediationAdapter1 = LineMediationAdapter.this;
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Rewarded ad user with reward: ");
        stringBuilder1.append(maxReward);
        stringBuilder1.append(" for slot id: ");
        stringBuilder1.append(param1FiveAdInterface.getSlotId());
        stringBuilder1.append("...");
        lineMediationAdapter1.log(stringBuilder1.toString());
        this.listener.onUserRewarded(maxReward);
      } 
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad hidden for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdHidden();
    }
    
    public void onFiveAdImpression(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad impression tracked for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdDisplayed();
      this.listener.onRewardedAdVideoStarted();
    }
    
    public void onFiveAdLoad(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad loaded for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdLoaded();
    }
    
    public void onFiveAdLoadError(FiveAdInterface param1FiveAdInterface, FiveAdErrorCode param1FiveAdErrorCode) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad failed to load for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append(" with error: ");
      stringBuilder.append(param1FiveAdErrorCode);
      lineMediationAdapter.log(stringBuilder.toString());
      MaxAdapterError maxAdapterError = LineMediationAdapter.toMaxError(param1FiveAdErrorCode);
      this.listener.onRewardedAdLoadFailed(maxAdapterError);
    }
    
    public void onFiveAdPause(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad did pause for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdRecover(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad did recover for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdReplay(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad did replay for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdResume(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad did resume for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdStall(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad did stall for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onFiveAdStart(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad shown for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdDisplayed();
      this.listener.onRewardedAdVideoStarted();
    }
    
    public void onFiveAdViewError(FiveAdInterface param1FiveAdInterface, FiveAdErrorCode param1FiveAdErrorCode) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad failed to show for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append(" with error: ");
      stringBuilder.append(param1FiveAdErrorCode);
      lineMediationAdapter.log(stringBuilder.toString());
      MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad Display Failed", param1FiveAdErrorCode.value, "Please Contact Us");
      this.listener.onRewardedAdDisplayFailed(maxAdapterError);
    }
    
    public void onFiveAdViewThrough(FiveAdInterface param1FiveAdInterface) {
      LineMediationAdapter lineMediationAdapter = LineMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad completed for slot id: ");
      stringBuilder.append(param1FiveAdInterface.getSlotId());
      stringBuilder.append("...");
      lineMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdVideoCompleted();
      this.hasGrantedReward = true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\mediation\adapters\LineMediationAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */