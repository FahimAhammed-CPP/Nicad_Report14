package com.applovin.mediation.adapters;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.applovin.impl.sdk.utils.BundleUtils;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.adapter.MaxAdViewAdapter;
import com.applovin.mediation.adapter.MaxAdapter;
import com.applovin.mediation.adapter.MaxAdapterError;
import com.applovin.mediation.adapter.MaxInterstitialAdapter;
import com.applovin.mediation.adapter.MaxRewardedAdapter;
import com.applovin.mediation.adapter.MaxSignalProvider;
import com.applovin.mediation.adapter.listeners.MaxAdViewAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxInterstitialAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxNativeAdAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxRewardedAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxSignalCollectionListener;
import com.applovin.mediation.adapter.parameters.MaxAdapterInitializationParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterResponseParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterSignalCollectionParameters;
import com.applovin.mediation.nativeAds.MaxNativeAd;
import com.applovin.mediation.nativeAds.MaxNativeAdView;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkConfiguration;
import com.applovin.sdk.AppLovinSdkUtils;
import com.inmobi.ads.AdMetaInfo;
import com.inmobi.ads.InMobiAdRequestStatus;
import com.inmobi.ads.InMobiBanner;
import com.inmobi.ads.InMobiInterstitial;
import com.inmobi.ads.InMobiNative;
import com.inmobi.ads.listeners.BannerAdEventListener;
import com.inmobi.ads.listeners.InterstitialAdEventListener;
import com.inmobi.ads.listeners.NativeAdEventListener;
import com.inmobi.sdk.InMobiSdk;
import com.inmobi.sdk.SdkInitializationListener;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONException;
import org.json.JSONObject;

public class InMobiMediationAdapter extends MediationAdapterBase implements MaxAdViewAdapter, MaxInterstitialAdapter, MaxRewardedAdapter, MaxSignalProvider {
  private static final int DEFAULT_IMAGE_TASK_TIMEOUT_SECONDS = 5;
  
  private static final AtomicBoolean INITIALIZED = new AtomicBoolean();
  
  private static final String KEY_PARTNER_GDPR_APPLIES = "partner_gdpr_applies";
  
  private static final String KEY_PARTNER_GDPR_CONSENT = "partner_gdpr_consent_available";
  
  private static MaxAdapter.InitializationStatus status;
  
  private InMobiBanner adView;
  
  private InMobiInterstitial interstitialAd;
  
  private InMobiNative nativeAd;
  
  private InMobiInterstitial rewardedAd;
  
  public InMobiMediationAdapter(AppLovinSdk paramAppLovinSdk) {
    super(paramAppLovinSdk);
  }
  
  private InMobiInterstitial createFullscreenAd(long paramLong, MaxAdapterResponseParameters paramMaxAdapterResponseParameters, InterstitialAdEventListener paramInterstitialAdEventListener, Activity paramActivity) {
    InMobiInterstitial inMobiInterstitial = new InMobiInterstitial((Context)paramActivity, paramLong, paramInterstitialAdEventListener);
    inMobiInterstitial.setExtras(getExtras((MaxAdapterParameters)paramMaxAdapterResponseParameters));
    InMobiSdk.setPartnerGDPRConsent(getConsentJSONObject((MaxAdapterParameters)paramMaxAdapterResponseParameters));
    return inMobiInterstitial;
  }
  
  private MaxNativeAdView createMaxNativeAdView(MaxNativeAd paramMaxNativeAd, String paramString, Activity paramActivity) {
    return (AppLovinSdk.VERSION_CODE >= 11010000) ? new MaxNativeAdView(paramMaxNativeAd, paramString, getApplicationContext()) : new MaxNativeAdView(paramMaxNativeAd, paramString, paramActivity);
  }
  
  private Drawable fetchNativeAdIcon(String paramString, Bundle paramBundle, Context paramContext) {
    StringBuilder stringBuilder1;
    if (TextUtils.isEmpty(paramString)) {
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Native ad icon url ");
      stringBuilder1.append(paramString);
      stringBuilder1.append(" is not valid");
      log(stringBuilder1.toString());
      return null;
    } 
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Adding native ad icon (");
    stringBuilder2.append(paramString);
    stringBuilder2.append(") to queue to be fetched");
    log(stringBuilder2.toString());
    Future<Drawable> future = createDrawableFuture(paramString, paramContext.getResources());
    try {
      return future.get(BundleUtils.getInt("image_task_timeout_seconds", 5, (Bundle)stringBuilder1), TimeUnit.SECONDS);
    } finally {
      stringBuilder1 = null;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to fetch icon image from URL: ");
      stringBuilder.append(paramString);
      e(stringBuilder.toString(), (Throwable)stringBuilder1);
    } 
  }
  
  private List<View> getClickableViews(MaxNativeAdView paramMaxNativeAdView) {
    if (AppLovinSdk.VERSION_CODE < 11050300) {
      ArrayList<TextView> arrayList = new ArrayList(5);
      if (paramMaxNativeAdView.getTitleTextView() != null)
        arrayList.add(paramMaxNativeAdView.getTitleTextView()); 
      if (paramMaxNativeAdView.getAdvertiserTextView() != null)
        arrayList.add(paramMaxNativeAdView.getAdvertiserTextView()); 
      if (paramMaxNativeAdView.getBodyTextView() != null)
        arrayList.add(paramMaxNativeAdView.getBodyTextView()); 
      if (paramMaxNativeAdView.getIconImageView() != null)
        arrayList.add(paramMaxNativeAdView.getIconImageView()); 
      if (paramMaxNativeAdView.getCallToActionButton() != null)
        arrayList.add(paramMaxNativeAdView.getCallToActionButton()); 
      return (List)arrayList;
    } 
    return paramMaxNativeAdView.getClickableViews();
  }
  
  private JSONObject getConsentJSONObject(MaxAdapterParameters paramMaxAdapterParameters) {
    JSONObject jSONObject = new JSONObject();
    try {
      AppLovinSdkConfiguration.ConsentDialogState consentDialogState1 = getWrappingSdk().getConfiguration().getConsentDialogState();
      AppLovinSdkConfiguration.ConsentDialogState consentDialogState2 = AppLovinSdkConfiguration.ConsentDialogState.APPLIES;
      if (consentDialogState1 == consentDialogState2) {
        jSONObject.put("partner_gdpr_applies", 1);
        Boolean bool = getPrivacySetting("hasUserConsent", paramMaxAdapterParameters);
        if (bool != null) {
          jSONObject.put("partner_gdpr_consent_available", bool);
          return jSONObject;
        } 
      } else if (getWrappingSdk().getConfiguration().getConsentDialogState() == AppLovinSdkConfiguration.ConsentDialogState.DOES_NOT_APPLY) {
        jSONObject.put("partner_gdpr_applies", 0);
        return jSONObject;
      } 
    } catch (JSONException jSONException) {
      log("Failed to create consent JSON object", (Throwable)jSONException);
    } 
    return jSONObject;
  }
  
  private Context getContext(Activity paramActivity) {
    return (paramActivity != null) ? paramActivity.getApplicationContext() : getApplicationContext();
  }
  
  private Map<String, String> getExtras(MaxAdapterParameters paramMaxAdapterParameters) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>(3);
    hashMap.put("tp", "c_applovin");
    hashMap.put("tp-ver", AppLovinSdk.VERSION);
    Boolean bool = getPrivacySetting("isAgeRestrictedUser", paramMaxAdapterParameters);
    String str = "1";
    if (bool != null) {
      String str1;
      if (bool.booleanValue()) {
        str1 = "1";
      } else {
        str1 = "0";
      } 
      hashMap.put("coppa", str1);
    } 
    if (AppLovinSdk.VERSION_CODE >= 91100) {
      Boolean bool1 = getPrivacySetting("isDoNotSell", paramMaxAdapterParameters);
      if (bool1 != null) {
        String str1;
        if (bool1.booleanValue()) {
          str1 = str;
        } else {
          str1 = "0";
        } 
        hashMap.put("do_not_sell", str1);
      } 
    } 
    return (Map)hashMap;
  }
  
  private Boolean getPrivacySetting(String paramString, MaxAdapterParameters paramMaxAdapterParameters) {
    try {
      return (Boolean)paramMaxAdapterParameters.getClass().getMethod(paramString, new Class[0]).invoke(paramMaxAdapterParameters, new Object[0]);
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Error getting privacy setting ");
      stringBuilder.append(paramString);
      stringBuilder.append(" with exception: ");
      log(stringBuilder.toString(), exception);
      return (AppLovinSdk.VERSION_CODE >= 9140000) ? null : Boolean.valueOf(false);
    } 
  }
  
  private boolean showFullscreenAd(InMobiInterstitial paramInMobiInterstitial) {
    if (paramInMobiInterstitial.isReady()) {
      paramInMobiInterstitial.show();
      return true;
    } 
    return false;
  }
  
  private static MaxAdapterError toMaxError(InMobiAdRequestStatus paramInMobiAdRequestStatus) {
    InMobiAdRequestStatus.StatusCode statusCode = paramInMobiAdRequestStatus.getStatusCode();
    MaxAdapterError maxAdapterError = MaxAdapterError.UNSPECIFIED;
    switch (statusCode) {
      default:
        return new MaxAdapterError(maxAdapterError.getErrorCode(), maxAdapterError.getErrorMessage(), statusCode.ordinal(), paramInMobiAdRequestStatus.getMessage());
      case null:
      case null:
        maxAdapterError = MaxAdapterError.INVALID_CONFIGURATION;
      case null:
        maxAdapterError = MaxAdapterError.AD_EXPIRED;
      case null:
      case null:
      case null:
      case null:
      case null:
        maxAdapterError = MaxAdapterError.INVALID_LOAD_STATE;
      case null:
        maxAdapterError = MaxAdapterError.SERVER_ERROR;
      case null:
      case null:
      case null:
      case null:
      case null:
      case null:
      case null:
        maxAdapterError = MaxAdapterError.INTERNAL_ERROR;
      case null:
        maxAdapterError = MaxAdapterError.TIMEOUT;
      case null:
        maxAdapterError = MaxAdapterError.BAD_REQUEST;
      case null:
        maxAdapterError = MaxAdapterError.NO_FILL;
      case null:
        maxAdapterError = MaxAdapterError.NO_CONNECTION;
      case null:
        break;
    } 
    maxAdapterError = MaxAdapterError.UNSPECIFIED;
  }
  
  private void updateAgeRestrictedUser(MaxAdapterParameters paramMaxAdapterParameters) {
    Boolean bool = getPrivacySetting("isAgeRestrictedUser", paramMaxAdapterParameters);
    if (bool != null)
      InMobiSdk.setIsAgeRestricted(bool.booleanValue()); 
  }
  
  public void collectSignal(MaxAdapterSignalCollectionParameters paramMaxAdapterSignalCollectionParameters, Activity paramActivity, MaxSignalCollectionListener paramMaxSignalCollectionListener) {
    if (!InMobiSdk.isSDKInitialized()) {
      paramMaxSignalCollectionListener.onSignalCollectionFailed("InMobi SDK initialization failed.");
      return;
    } 
    updateAgeRestrictedUser((MaxAdapterParameters)paramMaxAdapterSignalCollectionParameters);
    InMobiSdk.setPartnerGDPRConsent(getConsentJSONObject((MaxAdapterParameters)paramMaxAdapterSignalCollectionParameters));
    paramMaxSignalCollectionListener.onSignalCollected(InMobiSdk.getToken(getExtras((MaxAdapterParameters)paramMaxAdapterSignalCollectionParameters), null));
  }
  
  public String getAdapterVersion() {
    return "10.1.2.2";
  }
  
  public String getSdkVersion() {
    return InMobiSdk.getVersion();
  }
  
  public void initialize(MaxAdapterInitializationParameters paramMaxAdapterInitializationParameters, Activity paramActivity, final MaxAdapter.OnCompletionListener onCompletionListener) {
    if (INITIALIZED.compareAndSet(false, true)) {
      InMobiSdk.LogLevel logLevel;
      String str = paramMaxAdapterInitializationParameters.getServerParameters().getString("account_id");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Initializing InMobi SDK with account id: ");
      stringBuilder.append(str);
      stringBuilder.append("...");
      log(stringBuilder.toString());
      Context context = getContext(paramActivity);
      status = MaxAdapter.InitializationStatus.INITIALIZING;
      updateAgeRestrictedUser((MaxAdapterParameters)paramMaxAdapterInitializationParameters);
      InMobiSdk.init(context, str, getConsentJSONObject((MaxAdapterParameters)paramMaxAdapterInitializationParameters), new SdkInitializationListener() {
            public void onInitializationComplete(Error param1Error) {
              if (param1Error != null) {
                InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("InMobi SDK initialization failed with error: ");
                stringBuilder.append(param1Error.getMessage());
                inMobiMediationAdapter.log(stringBuilder.toString());
                InMobiMediationAdapter.access$002(MaxAdapter.InitializationStatus.INITIALIZED_FAILURE);
                onCompletionListener.onCompletion(InMobiMediationAdapter.status, param1Error.getMessage());
                return;
              } 
              InMobiMediationAdapter.this.log("InMobi SDK successfully initialized.");
              InMobiMediationAdapter.access$002(MaxAdapter.InitializationStatus.INITIALIZED_SUCCESS);
              onCompletionListener.onCompletion(InMobiMediationAdapter.status, null);
            }
          });
      if (paramMaxAdapterInitializationParameters.isTesting()) {
        logLevel = InMobiSdk.LogLevel.DEBUG;
      } else {
        logLevel = InMobiSdk.LogLevel.ERROR;
      } 
      InMobiSdk.setLogLevel(logLevel);
      return;
    } 
    log("InMobi SDK already initialized");
    onCompletionListener.onCompletion(status, null);
  }
  
  public void loadAdViewAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, MaxAdFormat paramMaxAdFormat, Activity paramActivity, MaxAdViewAdapterListener paramMaxAdViewAdapterListener) {
    StringBuilder stringBuilder2;
    StringBuilder stringBuilder1;
    InMobiNative inMobiNative;
    char c1;
    char c2;
    long l = Long.parseLong(paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId());
    boolean bool1 = paramMaxAdapterResponseParameters.getServerParameters().getBoolean("is_native");
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append("Loading");
    if (bool1) {
      str = " native ";
    } else {
      str = " ";
    } 
    stringBuilder3.append(str);
    stringBuilder3.append(paramMaxAdFormat.getLabel());
    stringBuilder3.append(" AdView ad for placement: ");
    stringBuilder3.append(l);
    stringBuilder3.append("...");
    log(stringBuilder3.toString());
    if (!InMobiSdk.isSDKInitialized()) {
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append("InMobi SDK not successfully initialized: failing ");
      stringBuilder2.append(paramMaxAdFormat.getLabel());
      stringBuilder2.append(" ad load...");
      log(stringBuilder2.toString());
      paramMaxAdViewAdapterListener.onAdViewAdLoadFailed(MaxAdapterError.NOT_INITIALIZED);
      return;
    } 
    updateAgeRestrictedUser((MaxAdapterParameters)stringBuilder2);
    InMobiSdk.setPartnerGDPRConsent(getConsentJSONObject((MaxAdapterParameters)stringBuilder2));
    String str = stringBuilder2.getBidResponse();
    boolean bool2 = AppLovinSdkUtils.isValidString(str);
    Context context = getContext(paramActivity);
    if (bool1) {
      inMobiNative = new InMobiNative(context, l, new NativeAdViewListener((MaxAdapterResponseParameters)stringBuilder2, paramMaxAdFormat, paramActivity, paramMaxAdViewAdapterListener));
      this.nativeAd = inMobiNative;
      inMobiNative.setExtras(getExtras((MaxAdapterParameters)stringBuilder2));
      if (bool2) {
        this.nativeAd.load(str.getBytes());
        return;
      } 
      this.nativeAd.load();
      return;
    } 
    InMobiBanner inMobiBanner = new InMobiBanner(context, l);
    this.adView = inMobiBanner;
    inMobiBanner.setExtras(getExtras((MaxAdapterParameters)stringBuilder2));
    this.adView.setAnimationType(InMobiBanner.AnimationType.ANIMATION_OFF);
    this.adView.setEnableAutoRefresh(false);
    this.adView.setListener(new AdViewListener(paramMaxAdViewAdapterListener));
    DisplayMetrics displayMetrics = new DisplayMetrics();
    ((WindowManager)context.getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
    if (inMobiNative == MaxAdFormat.BANNER) {
      c1 = 'ŀ';
      c2 = '2';
    } else if (inMobiNative == MaxAdFormat.LEADER) {
      c1 = '˘';
      c2 = 'Z';
    } else if (inMobiNative == MaxAdFormat.MREC) {
      c1 = 'Ĭ';
      c2 = 'ú';
    } else {
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Unsupported ad format: ");
      stringBuilder1.append(inMobiNative);
      throw new IllegalArgumentException(stringBuilder1.toString());
    } 
    this.adView.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(Math.round(c1 * ((DisplayMetrics)stringBuilder1).density), Math.round(c2 * ((DisplayMetrics)stringBuilder1).density)));
    if (bool2) {
      this.adView.load(str.getBytes());
      return;
    } 
    this.adView.load();
  }
  
  public void loadInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxInterstitialAdapterListener paramMaxInterstitialAdapterListener) {
    long l = Long.parseLong(paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId());
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading interstitial ad for placement: ");
    stringBuilder.append(l);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    if (!InMobiSdk.isSDKInitialized()) {
      log("InMobi SDK not successfully initialized: failing interstitial ad load...");
      paramMaxInterstitialAdapterListener.onInterstitialAdLoadFailed(MaxAdapterError.NOT_INITIALIZED);
      return;
    } 
    updateAgeRestrictedUser((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    this.interstitialAd = createFullscreenAd(l, paramMaxAdapterResponseParameters, new InterstitialListener(paramMaxInterstitialAdapterListener), paramActivity);
    String str = paramMaxAdapterResponseParameters.getBidResponse();
    if (!TextUtils.isEmpty(str)) {
      this.interstitialAd.load(str.getBytes());
      return;
    } 
    this.interstitialAd.load();
  }
  
  public void loadNativeAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxNativeAdAdapterListener paramMaxNativeAdAdapterListener) {
    String str1;
    if (!InMobiSdk.isSDKInitialized()) {
      log("InMobi SDK not successfully initialized: failing native ad load...");
      paramMaxNativeAdAdapterListener.onNativeAdLoadFailed(MaxAdapterError.NOT_INITIALIZED);
      return;
    } 
    updateAgeRestrictedUser((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    long l = Long.parseLong(paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId());
    String str2 = paramMaxAdapterResponseParameters.getBidResponse();
    boolean bool = AppLovinSdkUtils.isValidString(str2);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading ");
    if (bool) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    stringBuilder.append("native ad for placement: ");
    stringBuilder.append(l);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    InMobiSdk.setPartnerGDPRConsent(getConsentJSONObject((MaxAdapterParameters)paramMaxAdapterResponseParameters));
    Context context = getContext(paramActivity);
    InMobiNative inMobiNative = new InMobiNative(context, l, new NativeAdListener(paramMaxAdapterResponseParameters, context, paramMaxNativeAdAdapterListener));
    this.nativeAd = inMobiNative;
    inMobiNative.setExtras(getExtras((MaxAdapterParameters)paramMaxAdapterResponseParameters));
    if (bool) {
      this.nativeAd.load(str2.getBytes());
      return;
    } 
    this.nativeAd.load();
  }
  
  public void loadRewardedAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxRewardedAdapterListener paramMaxRewardedAdapterListener) {
    long l = Long.parseLong(paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId());
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading rewarded ad for placement: ");
    stringBuilder.append(l);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    if (!InMobiSdk.isSDKInitialized()) {
      log("InMobi SDK not successfully initialized: failing rewarded ad load...");
      paramMaxRewardedAdapterListener.onRewardedAdLoadFailed(MaxAdapterError.NOT_INITIALIZED);
      return;
    } 
    updateAgeRestrictedUser((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    this.rewardedAd = createFullscreenAd(l, paramMaxAdapterResponseParameters, new RewardedAdListener(paramMaxRewardedAdapterListener), paramActivity);
    String str = paramMaxAdapterResponseParameters.getBidResponse();
    if (!TextUtils.isEmpty(str)) {
      this.rewardedAd.load(str.getBytes());
      return;
    } 
    this.rewardedAd.load();
  }
  
  public void onDestroy() {
    InMobiBanner inMobiBanner = this.adView;
    if (inMobiBanner != null) {
      inMobiBanner.destroy();
      this.adView = null;
    } 
    InMobiNative inMobiNative = this.nativeAd;
    if (inMobiNative != null) {
      inMobiNative.destroy();
      this.nativeAd = null;
    } 
    this.interstitialAd = null;
    this.rewardedAd = null;
  }
  
  public void showInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxInterstitialAdapterListener paramMaxInterstitialAdapterListener) {
    log("Showing interstitial ad...");
    if (!showFullscreenAd(this.interstitialAd)) {
      log("Interstitial ad not ready");
      paramMaxInterstitialAdapterListener.onInterstitialAdDisplayFailed(new MaxAdapterError(-4205, "Ad Display Failed", 0, "Interstitial ad not ready"));
    } 
  }
  
  public void showRewardedAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxRewardedAdapterListener paramMaxRewardedAdapterListener) {
    log("Showing rewarded ad...");
    configureReward(paramMaxAdapterResponseParameters);
    if (!showFullscreenAd(this.rewardedAd)) {
      log("Rewarded ad not ready");
      paramMaxRewardedAdapterListener.onRewardedAdDisplayFailed(new MaxAdapterError(-4205, "Ad Display Failed", 0, "Rewarded ad not ready"));
    } 
  }
  
  private class AdViewListener extends BannerAdEventListener {
    final MaxAdViewAdapterListener listener;
    
    AdViewListener(MaxAdViewAdapterListener param1MaxAdViewAdapterListener) {
      this.listener = param1MaxAdViewAdapterListener;
    }
    
    public void onAdClicked(InMobiBanner param1InMobiBanner, Map<Object, Object> param1Map) {
      InMobiMediationAdapter.this.log("AdView clicked");
      this.listener.onAdViewAdClicked();
    }
    
    public void onAdDismissed(InMobiBanner param1InMobiBanner) {
      InMobiMediationAdapter.this.log("AdView collapsed");
      this.listener.onAdViewAdCollapsed();
    }
    
    public void onAdDisplayed(InMobiBanner param1InMobiBanner) {
      InMobiMediationAdapter.this.log("AdView expanded");
      this.listener.onAdViewAdExpanded();
    }
    
    public void onAdImpression(InMobiBanner param1InMobiBanner) {
      InMobiMediationAdapter.this.log("AdView impression tracked");
      this.listener.onAdViewAdDisplayed();
    }
    
    public void onAdLoadFailed(InMobiBanner param1InMobiBanner, InMobiAdRequestStatus param1InMobiAdRequestStatus) {
      InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("AdView failed to load with error code ");
      stringBuilder.append(param1InMobiAdRequestStatus.getStatusCode());
      stringBuilder.append(" and message: ");
      stringBuilder.append(param1InMobiAdRequestStatus.getMessage());
      inMobiMediationAdapter.log(stringBuilder.toString());
      MaxAdapterError maxAdapterError = InMobiMediationAdapter.toMaxError(param1InMobiAdRequestStatus);
      this.listener.onAdViewAdLoadFailed(maxAdapterError);
    }
    
    public void onAdLoadSucceeded(InMobiBanner param1InMobiBanner, AdMetaInfo param1AdMetaInfo) {
      InMobiMediationAdapter.this.log("AdView loaded");
      if (AppLovinSdk.VERSION_CODE >= 9150000 && !TextUtils.isEmpty(param1AdMetaInfo.getCreativeID())) {
        Bundle bundle = new Bundle(1);
        bundle.putString("creative_id", param1AdMetaInfo.getCreativeID());
        this.listener.onAdViewAdLoaded((View)param1InMobiBanner, bundle);
        return;
      } 
      this.listener.onAdViewAdLoaded((View)param1InMobiBanner);
    }
    
    public void onUserLeftApplication(InMobiBanner param1InMobiBanner) {
      InMobiMediationAdapter.this.log("AdView will leave application");
    }
  }
  
  private class InterstitialListener extends InterstitialAdEventListener {
    final MaxInterstitialAdapterListener listener;
    
    InterstitialListener(MaxInterstitialAdapterListener param1MaxInterstitialAdapterListener) {
      this.listener = param1MaxInterstitialAdapterListener;
    }
    
    public void onAdClicked(InMobiInterstitial param1InMobiInterstitial, Map<Object, Object> param1Map) {
      InMobiMediationAdapter.this.log("Interstitial clicked");
      this.listener.onInterstitialAdClicked();
    }
    
    public void onAdDismissed(InMobiInterstitial param1InMobiInterstitial) {
      InMobiMediationAdapter.this.log("Interstitial hidden");
      this.listener.onInterstitialAdHidden();
    }
    
    public void onAdDisplayFailed(InMobiInterstitial param1InMobiInterstitial) {
      InMobiMediationAdapter.this.log("Interstitial failed to display");
      this.listener.onInterstitialAdDisplayFailed(new MaxAdapterError(-4205, "Ad Display Failed"));
    }
    
    public void onAdDisplayed(InMobiInterstitial param1InMobiInterstitial, AdMetaInfo param1AdMetaInfo) {
      InMobiMediationAdapter.this.log("Interstitial did show");
    }
    
    public void onAdFetchSuccessful(InMobiInterstitial param1InMobiInterstitial, AdMetaInfo param1AdMetaInfo) {
      InMobiMediationAdapter.this.log("Interstitial request succeeded");
    }
    
    public void onAdImpression(InMobiInterstitial param1InMobiInterstitial) {
      InMobiMediationAdapter.this.log("Interstitial impression tracked");
      this.listener.onInterstitialAdDisplayed();
    }
    
    public void onAdLoadFailed(InMobiInterstitial param1InMobiInterstitial, InMobiAdRequestStatus param1InMobiAdRequestStatus) {
      InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial failed to load with error code ");
      stringBuilder.append(param1InMobiAdRequestStatus.getStatusCode());
      stringBuilder.append(" and message: ");
      stringBuilder.append(param1InMobiAdRequestStatus.getMessage());
      inMobiMediationAdapter.log(stringBuilder.toString());
      MaxAdapterError maxAdapterError = InMobiMediationAdapter.toMaxError(param1InMobiAdRequestStatus);
      this.listener.onInterstitialAdLoadFailed(maxAdapterError);
    }
    
    public void onAdLoadSucceeded(InMobiInterstitial param1InMobiInterstitial, AdMetaInfo param1AdMetaInfo) {
      InMobiMediationAdapter.this.log("Interstitial loaded");
      if (AppLovinSdk.VERSION_CODE >= 9150000 && !TextUtils.isEmpty(param1AdMetaInfo.getCreativeID())) {
        Bundle bundle = new Bundle(1);
        bundle.putString("creative_id", param1AdMetaInfo.getCreativeID());
        this.listener.onInterstitialAdLoaded(bundle);
        return;
      } 
      this.listener.onInterstitialAdLoaded();
    }
    
    public void onAdWillDisplay(InMobiInterstitial param1InMobiInterstitial) {
      InMobiMediationAdapter.this.log("Interstitial will show");
    }
    
    public void onUserLeftApplication(InMobiInterstitial param1InMobiInterstitial) {
      InMobiMediationAdapter.this.log("Interstitial will leave application");
    }
  }
  
  private class MaxInMobiNativeAd extends MaxNativeAd {
    private final MaxAdFormat format;
    
    private final MaxAdapterListener listener;
    
    public MaxInMobiNativeAd(MaxAdapterListener param1MaxAdapterListener, MaxNativeAd.Builder param1Builder, MaxAdFormat param1MaxAdFormat) {
      super(param1Builder);
      this.listener = param1MaxAdapterListener;
      this.format = param1MaxAdFormat;
    }
    
    public boolean prepareForInteraction(List<View> param1List, ViewGroup param1ViewGroup) {
      final InMobiNative nativeAd = InMobiMediationAdapter.this.nativeAd;
      if (inMobiNative == null) {
        InMobiMediationAdapter.this.e("Failed to register native ad views: native ad is null.");
        return false;
      } 
      final FrameLayout mediaView = (FrameLayout)getMediaView();
      final FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(-1, -1);
      frameLayout.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
      frameLayout.post(new Runnable() {
            public void run() {
              int j = mediaView.getWidth();
              int i = j;
              if (InMobiMediationAdapter.MaxInMobiNativeAd.this.format == MaxAdFormat.BANNER) {
                i = j;
                if (mediaView.getWidth() > mediaView.getHeight()) {
                  double d = mediaView.getHeight();
                  Double.isNaN(d);
                  i = (int)(d * 1.7777777777777777D);
                  params.leftMargin = (mediaView.getWidth() - i) / 2;
                  mediaView.setLayoutParams((ViewGroup.LayoutParams)params);
                } 
              } 
              View view = nativeAd.getPrimaryViewOfWidth(mediaView.getContext(), null, (ViewGroup)mediaView, i);
              if (view == null)
                return; 
              mediaView.addView(view);
            }
          });
      View.OnClickListener onClickListener = new View.OnClickListener() {
          public void onClick(View param2View) {
            InMobiMediationAdapter.this.log("Native ad clicked from click listener");
            nativeAd.reportAdClickAndOpenLandingPage();
            if (InMobiMediationAdapter.MaxInMobiNativeAd.this.format == MaxAdFormat.NATIVE) {
              ((MaxNativeAdAdapterListener)InMobiMediationAdapter.MaxInMobiNativeAd.this.listener).onNativeAdClicked();
              return;
            } 
            if (InMobiMediationAdapter.MaxInMobiNativeAd.this.format.isAdViewAd()) {
              ((MaxAdViewAdapterListener)InMobiMediationAdapter.MaxInMobiNativeAd.this.listener).onAdViewAdClicked();
              return;
            } 
            InMobiMediationAdapter.this.log("Unsupported ad format: must be adView ad or native ad");
          }
        };
      for (View view : param1List) {
        if (view != null)
          view.setOnClickListener(onClickListener); 
      } 
      return true;
    }
    
    public void prepareViewForInteraction(MaxNativeAdView param1MaxNativeAdView) {
      prepareForInteraction(InMobiMediationAdapter.this.getClickableViews(param1MaxNativeAdView), (ViewGroup)param1MaxNativeAdView);
    }
  }
  
  class null implements Runnable {
    public void run() {
      int j = mediaView.getWidth();
      int i = j;
      if (this.this$1.format == MaxAdFormat.BANNER) {
        i = j;
        if (mediaView.getWidth() > mediaView.getHeight()) {
          double d = mediaView.getHeight();
          Double.isNaN(d);
          i = (int)(d * 1.7777777777777777D);
          params.leftMargin = (mediaView.getWidth() - i) / 2;
          mediaView.setLayoutParams((ViewGroup.LayoutParams)params);
        } 
      } 
      View view = nativeAd.getPrimaryViewOfWidth(mediaView.getContext(), null, (ViewGroup)mediaView, i);
      if (view == null)
        return; 
      mediaView.addView(view);
    }
  }
  
  class null implements View.OnClickListener {
    public void onClick(View param1View) {
      InMobiMediationAdapter.this.log("Native ad clicked from click listener");
      nativeAd.reportAdClickAndOpenLandingPage();
      if (this.this$1.format == MaxAdFormat.NATIVE) {
        ((MaxNativeAdAdapterListener)this.this$1.listener).onNativeAdClicked();
        return;
      } 
      if (this.this$1.format.isAdViewAd()) {
        ((MaxAdViewAdapterListener)this.this$1.listener).onAdViewAdClicked();
        return;
      } 
      InMobiMediationAdapter.this.log("Unsupported ad format: must be adView ad or native ad");
    }
  }
  
  private class NativeAdListener extends NativeAdEventListener {
    private final Context context;
    
    private final MaxNativeAdAdapterListener listener;
    
    private final String placementId;
    
    private final Bundle serverParameters;
    
    NativeAdListener(MaxAdapterResponseParameters param1MaxAdapterResponseParameters, Context param1Context, MaxNativeAdAdapterListener param1MaxNativeAdAdapterListener) {
      this.placementId = param1MaxAdapterResponseParameters.getThirdPartyAdPlacementId();
      this.serverParameters = param1MaxAdapterResponseParameters.getServerParameters();
      this.context = param1Context;
      this.listener = param1MaxNativeAdAdapterListener;
    }
    
    private void handleNativeAdLoaded(final InMobiNative inMobiNative, final AdMetaInfo adMetaInfo, final Drawable iconDrawable, final Context context) {
      AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
              (new ImageView(context)).setImageDrawable(iconDrawable);
              FrameLayout frameLayout = new FrameLayout(context);
              MaxNativeAd.Builder builder = (new MaxNativeAd.Builder()).setAdFormat(MaxAdFormat.NATIVE).setTitle(inMobiNative.getAdTitle()).setBody(inMobiNative.getAdDescription()).setMediaView((View)frameLayout).setIcon(new MaxNativeAd.MaxNativeAdImage(iconDrawable)).setCallToAction(inMobiNative.getAdCtaText());
              InMobiMediationAdapter.MaxInMobiNativeAd maxInMobiNativeAd = new InMobiMediationAdapter.MaxInMobiNativeAd((MaxAdapterListener)InMobiMediationAdapter.NativeAdListener.this.listener, builder, MaxAdFormat.NATIVE);
              if (AppLovinSdkUtils.isValidString(adMetaInfo.getCreativeID())) {
                Bundle bundle = new Bundle(1);
                bundle.putString("creative_id", adMetaInfo.getCreativeID());
                InMobiMediationAdapter.NativeAdListener.this.listener.onNativeAdLoaded(maxInMobiNativeAd, bundle);
                return;
              } 
              InMobiMediationAdapter.NativeAdListener.this.listener.onNativeAdLoaded(maxInMobiNativeAd, null);
            }
          });
    }
    
    public void onAdClicked(InMobiNative param1InMobiNative) {
      InMobiMediationAdapter.this.log("Native ad clicked");
      this.listener.onNativeAdClicked();
    }
    
    public void onAdFullScreenDismissed(InMobiNative param1InMobiNative) {
      InMobiMediationAdapter.this.log("Native ad fullscreen dismissed");
    }
    
    public void onAdFullScreenDisplayed(InMobiNative param1InMobiNative) {
      InMobiMediationAdapter.this.log("Native ad fullscreen displayed");
    }
    
    public void onAdFullScreenWillDisplay(InMobiNative param1InMobiNative) {
      InMobiMediationAdapter.this.log("Native ad fullscreen will display");
    }
    
    public void onAdImpression(InMobiNative param1InMobiNative) {
      InMobiMediationAdapter.this.log("Native ad shown");
      this.listener.onNativeAdDisplayed(null);
    }
    
    public void onAdLoadFailed(InMobiNative param1InMobiNative, InMobiAdRequestStatus param1InMobiAdRequestStatus) {
      MaxAdapterError maxAdapterError = InMobiMediationAdapter.toMaxError(param1InMobiAdRequestStatus);
      InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad failed to load with error ");
      stringBuilder.append(maxAdapterError);
      inMobiMediationAdapter.log(stringBuilder.toString());
      this.listener.onNativeAdLoadFailed(maxAdapterError);
    }
    
    public void onAdLoadSucceeded(final InMobiNative inMobiNative, AdMetaInfo param1AdMetaInfo) {
      final InMobiMediationAdapter adMetaInfo;
      if (InMobiMediationAdapter.this.nativeAd == null || inMobiNative == null || InMobiMediationAdapter.this.nativeAd != inMobiNative) {
        InMobiMediationAdapter.this.log("Native ad failed to load: no fill");
        this.listener.onNativeAdLoadFailed(MaxAdapterError.NO_FILL);
        return;
      } 
      if (AppLovinSdkUtils.isValidString(BundleUtils.getString("template", "", this.serverParameters)) && TextUtils.isEmpty(inMobiNative.getAdTitle())) {
        inMobiMediationAdapter1 = InMobiMediationAdapter.this;
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Native ad (");
        stringBuilder1.append(inMobiNative);
        stringBuilder1.append(") does not have required assets.");
        inMobiMediationAdapter1.e(stringBuilder1.toString());
        this.listener.onNativeAdLoadFailed(MaxAdapterError.MISSING_REQUIRED_NATIVE_AD_ASSETS);
        return;
      } 
      InMobiMediationAdapter inMobiMediationAdapter2 = InMobiMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad loaded: ");
      stringBuilder.append(this.placementId);
      inMobiMediationAdapter2.log(stringBuilder.toString());
      InMobiMediationAdapter.this.getCachingExecutorService().execute(new Runnable() {
            public void run() {
              Drawable drawable = InMobiMediationAdapter.this.fetchNativeAdIcon(inMobiNative.getAdIconUrl(), InMobiMediationAdapter.NativeAdListener.this.serverParameters, InMobiMediationAdapter.NativeAdListener.this.context);
              InMobiMediationAdapter.NativeAdListener nativeAdListener = InMobiMediationAdapter.NativeAdListener.this;
              nativeAdListener.handleNativeAdLoaded(inMobiNative, adMetaInfo, drawable, nativeAdListener.context);
            }
          });
    }
    
    public void onAdStatusChanged(InMobiNative param1InMobiNative) {
      InMobiMediationAdapter.this.log("Native ad status changed");
    }
    
    public void onUserWillLeaveApplication(InMobiNative param1InMobiNative) {
      InMobiMediationAdapter.this.log("Native ad user will leave application");
    }
  }
  
  class null implements Runnable {
    public void run() {
      Drawable drawable = InMobiMediationAdapter.this.fetchNativeAdIcon(inMobiNative.getAdIconUrl(), this.this$1.serverParameters, this.this$1.context);
      InMobiMediationAdapter.NativeAdListener nativeAdListener = this.this$1;
      nativeAdListener.handleNativeAdLoaded(inMobiNative, adMetaInfo, drawable, nativeAdListener.context);
    }
  }
  
  class null implements Runnable {
    public void run() {
      (new ImageView(context)).setImageDrawable(iconDrawable);
      FrameLayout frameLayout = new FrameLayout(context);
      MaxNativeAd.Builder builder = (new MaxNativeAd.Builder()).setAdFormat(MaxAdFormat.NATIVE).setTitle(inMobiNative.getAdTitle()).setBody(inMobiNative.getAdDescription()).setMediaView((View)frameLayout).setIcon(new MaxNativeAd.MaxNativeAdImage(iconDrawable)).setCallToAction(inMobiNative.getAdCtaText());
      InMobiMediationAdapter.MaxInMobiNativeAd maxInMobiNativeAd = new InMobiMediationAdapter.MaxInMobiNativeAd((MaxAdapterListener)this.this$1.listener, builder, MaxAdFormat.NATIVE);
      if (AppLovinSdkUtils.isValidString(adMetaInfo.getCreativeID())) {
        Bundle bundle = new Bundle(1);
        bundle.putString("creative_id", adMetaInfo.getCreativeID());
        this.this$1.listener.onNativeAdLoaded(maxInMobiNativeAd, bundle);
        return;
      } 
      this.this$1.listener.onNativeAdLoaded(maxInMobiNativeAd, null);
    }
  }
  
  private class NativeAdViewListener extends NativeAdEventListener {
    private final WeakReference<Activity> activityRef;
    
    private final MaxAdFormat adFormat;
    
    private final MaxAdViewAdapterListener listener;
    
    private final String placementId;
    
    private final Bundle serverParameters;
    
    NativeAdViewListener(MaxAdapterResponseParameters param1MaxAdapterResponseParameters, MaxAdFormat param1MaxAdFormat, Activity param1Activity, MaxAdViewAdapterListener param1MaxAdViewAdapterListener) {
      this.placementId = param1MaxAdapterResponseParameters.getThirdPartyAdPlacementId();
      this.serverParameters = param1MaxAdapterResponseParameters.getServerParameters();
      this.adFormat = param1MaxAdFormat;
      this.activityRef = new WeakReference<Activity>(param1Activity);
      this.listener = param1MaxAdViewAdapterListener;
    }
    
    public void onAdClicked(InMobiNative param1InMobiNative) {
      InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad clicked");
      inMobiMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdClicked();
    }
    
    public void onAdFullScreenDismissed(InMobiNative param1InMobiNative) {
      InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad fullscreen dismissed");
      inMobiMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onAdFullScreenDisplayed(InMobiNative param1InMobiNative) {
      InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad fullscreen displayed");
      inMobiMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onAdFullScreenWillDisplay(InMobiNative param1InMobiNative) {
      InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad fullscreen will display");
      inMobiMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onAdImpression(InMobiNative param1InMobiNative) {
      InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad shown");
      inMobiMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdDisplayed();
    }
    
    public void onAdLoadFailed(InMobiNative param1InMobiNative, InMobiAdRequestStatus param1InMobiAdRequestStatus) {
      MaxAdapterError maxAdapterError = InMobiMediationAdapter.toMaxError(param1InMobiAdRequestStatus);
      InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad failed to load with error ");
      stringBuilder.append(maxAdapterError);
      inMobiMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdLoadFailed(maxAdapterError);
    }
    
    public void onAdLoadSucceeded(InMobiNative param1InMobiNative, AdMetaInfo param1AdMetaInfo) {
      final InMobiMediationAdapter inMobiNative;
      final StringBuilder adMetaInfo;
      if (InMobiMediationAdapter.this.nativeAd == null || param1InMobiNative == null || InMobiMediationAdapter.this.nativeAd != param1InMobiNative) {
        inMobiMediationAdapter1 = InMobiMediationAdapter.this;
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Native ");
        stringBuilder1.append(this.adFormat.getLabel());
        stringBuilder1.append(" ad failed to load: no fill");
        inMobiMediationAdapter1.log(stringBuilder1.toString());
        this.listener.onAdViewAdLoadFailed(MaxAdapterError.NO_FILL);
        return;
      } 
      if (TextUtils.isEmpty(inMobiMediationAdapter1.getAdTitle())) {
        inMobiMediationAdapter1 = InMobiMediationAdapter.this;
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Native ");
        stringBuilder1.append(this.adFormat.getLabel());
        stringBuilder1.append(" ad does not have required assets.");
        inMobiMediationAdapter1.log(stringBuilder1.toString());
        this.listener.onAdViewAdLoadFailed(MaxAdapterError.INVALID_CONFIGURATION);
        return;
      } 
      InMobiMediationAdapter inMobiMediationAdapter2 = InMobiMediationAdapter.this;
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append("Native ");
      stringBuilder2.append(this.adFormat.getLabel());
      stringBuilder2.append(" ad loaded: ");
      stringBuilder2.append(this.placementId);
      inMobiMediationAdapter2.log(stringBuilder2.toString());
      final Activity activity = this.activityRef.get();
      final Context context = InMobiMediationAdapter.this.getContext(activity);
      InMobiMediationAdapter.this.getCachingExecutorService().execute(new Runnable() {
            public void run() {
              AppLovinSdkUtils.runOnUiThread(new Runnable() {
                    public void run() {
                      MaxNativeAdView maxNativeAdView;
                      (new ImageView(context)).setImageDrawable(iconDrawable);
                      FrameLayout frameLayout = new FrameLayout(context);
                      MaxNativeAd.Builder builder = (new MaxNativeAd.Builder()).setAdFormat(InMobiMediationAdapter.NativeAdViewListener.this.adFormat).setTitle(inMobiNative.getAdTitle()).setBody(inMobiNative.getAdDescription()).setMediaView((View)frameLayout).setIcon(new MaxNativeAd.MaxNativeAdImage(iconDrawable)).setCallToAction(inMobiNative.getAdCtaText());
                      InMobiMediationAdapter.MaxInMobiNativeAd maxInMobiNativeAd = new InMobiMediationAdapter.MaxInMobiNativeAd((MaxAdapterListener)InMobiMediationAdapter.NativeAdViewListener.this.listener, builder, InMobiMediationAdapter.NativeAdViewListener.this.adFormat);
                      String str = BundleUtils.getString("template", "", InMobiMediationAdapter.NativeAdViewListener.this.serverParameters);
                      if (str.contains("vertical")) {
                        if (AppLovinSdk.VERSION_CODE < 9140500)
                          InMobiMediationAdapter.this.log("Vertical native banners are only supported on MAX SDK 9.14.5 and above. Default horizontal native template will be used."); 
                        if (str.equals("vertical")) {
                          if (InMobiMediationAdapter.NativeAdViewListener.this.adFormat == MaxAdFormat.LEADER) {
                            str = "vertical_leader_template";
                          } else {
                            str = "vertical_media_banner_template";
                          } 
                          maxNativeAdView = InMobiMediationAdapter.this.createMaxNativeAdView(maxInMobiNativeAd, str, activity);
                        } else {
                          maxNativeAdView = InMobiMediationAdapter.this.createMaxNativeAdView(maxInMobiNativeAd, (String)maxNativeAdView, activity);
                        } 
                      } else {
                        MaxNativeAdView maxNativeAdView1;
                        if (AppLovinSdk.VERSION_CODE < 9140500) {
                          String str1;
                          InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
                          if (!AppLovinSdkUtils.isValidString((String)maxNativeAdView))
                            str1 = "no_body_banner_template"; 
                          maxNativeAdView1 = inMobiMediationAdapter.createMaxNativeAdView(maxInMobiNativeAd, str1, activity);
                        } else {
                          String str1;
                          InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
                          if (!AppLovinSdkUtils.isValidString((String)maxNativeAdView1))
                            str1 = "media_banner_template"; 
                          maxNativeAdView = inMobiMediationAdapter.createMaxNativeAdView(maxInMobiNativeAd, str1, activity);
                        } 
                      } 
                      maxInMobiNativeAd.prepareForInteraction(InMobiMediationAdapter.this.getClickableViews(maxNativeAdView), (ViewGroup)maxNativeAdView);
                      if (AppLovinSdk.VERSION_CODE >= 9150000 && AppLovinSdkUtils.isValidString(adMetaInfo.getCreativeID())) {
                        Bundle bundle = new Bundle(1);
                        bundle.putString("creative_id", adMetaInfo.getCreativeID());
                        InMobiMediationAdapter.NativeAdViewListener.this.listener.onAdViewAdLoaded((View)maxNativeAdView, bundle);
                        return;
                      } 
                      InMobiMediationAdapter.NativeAdViewListener.this.listener.onAdViewAdLoaded((View)maxNativeAdView);
                    }
                  });
            }
          });
    }
    
    public void onAdStatusChanged(InMobiNative param1InMobiNative) {
      InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad status changed");
      inMobiMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onUserWillLeaveApplication(InMobiNative param1InMobiNative) {
      InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad user will leave application");
      inMobiMediationAdapter.log(stringBuilder.toString());
    }
  }
  
  class null implements Runnable {
    public void run() {
      AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
              MaxNativeAdView maxNativeAdView;
              (new ImageView(context)).setImageDrawable(iconDrawable);
              FrameLayout frameLayout = new FrameLayout(context);
              MaxNativeAd.Builder builder = (new MaxNativeAd.Builder()).setAdFormat(this.this$2.this$1.adFormat).setTitle(inMobiNative.getAdTitle()).setBody(inMobiNative.getAdDescription()).setMediaView((View)frameLayout).setIcon(new MaxNativeAd.MaxNativeAdImage(iconDrawable)).setCallToAction(inMobiNative.getAdCtaText());
              InMobiMediationAdapter.MaxInMobiNativeAd maxInMobiNativeAd = new InMobiMediationAdapter.MaxInMobiNativeAd((MaxAdapterListener)this.this$2.this$1.listener, builder, this.this$2.this$1.adFormat);
              String str = BundleUtils.getString("template", "", this.this$2.this$1.serverParameters);
              if (str.contains("vertical")) {
                if (AppLovinSdk.VERSION_CODE < 9140500)
                  InMobiMediationAdapter.this.log("Vertical native banners are only supported on MAX SDK 9.14.5 and above. Default horizontal native template will be used."); 
                if (str.equals("vertical")) {
                  if (this.this$2.this$1.adFormat == MaxAdFormat.LEADER) {
                    str = "vertical_leader_template";
                  } else {
                    str = "vertical_media_banner_template";
                  } 
                  maxNativeAdView = InMobiMediationAdapter.this.createMaxNativeAdView(maxInMobiNativeAd, str, activity);
                } else {
                  maxNativeAdView = InMobiMediationAdapter.this.createMaxNativeAdView(maxInMobiNativeAd, (String)maxNativeAdView, activity);
                } 
              } else {
                MaxNativeAdView maxNativeAdView1;
                if (AppLovinSdk.VERSION_CODE < 9140500) {
                  String str1;
                  InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
                  if (!AppLovinSdkUtils.isValidString((String)maxNativeAdView))
                    str1 = "no_body_banner_template"; 
                  maxNativeAdView1 = inMobiMediationAdapter.createMaxNativeAdView(maxInMobiNativeAd, str1, activity);
                } else {
                  String str1;
                  InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
                  if (!AppLovinSdkUtils.isValidString((String)maxNativeAdView1))
                    str1 = "media_banner_template"; 
                  maxNativeAdView = inMobiMediationAdapter.createMaxNativeAdView(maxInMobiNativeAd, str1, activity);
                } 
              } 
              maxInMobiNativeAd.prepareForInteraction(InMobiMediationAdapter.this.getClickableViews(maxNativeAdView), (ViewGroup)maxNativeAdView);
              if (AppLovinSdk.VERSION_CODE >= 9150000 && AppLovinSdkUtils.isValidString(adMetaInfo.getCreativeID())) {
                Bundle bundle = new Bundle(1);
                bundle.putString("creative_id", adMetaInfo.getCreativeID());
                this.this$2.this$1.listener.onAdViewAdLoaded((View)maxNativeAdView, bundle);
                return;
              } 
              this.this$2.this$1.listener.onAdViewAdLoaded((View)maxNativeAdView);
            }
          });
    }
  }
  
  class null implements Runnable {
    public void run() {
      MaxNativeAdView maxNativeAdView;
      (new ImageView(context)).setImageDrawable(iconDrawable);
      FrameLayout frameLayout = new FrameLayout(context);
      MaxNativeAd.Builder builder = (new MaxNativeAd.Builder()).setAdFormat(this.this$2.this$1.adFormat).setTitle(inMobiNative.getAdTitle()).setBody(inMobiNative.getAdDescription()).setMediaView((View)frameLayout).setIcon(new MaxNativeAd.MaxNativeAdImage(iconDrawable)).setCallToAction(inMobiNative.getAdCtaText());
      InMobiMediationAdapter.MaxInMobiNativeAd maxInMobiNativeAd = new InMobiMediationAdapter.MaxInMobiNativeAd((MaxAdapterListener)this.this$2.this$1.listener, builder, this.this$2.this$1.adFormat);
      String str = BundleUtils.getString("template", "", this.this$2.this$1.serverParameters);
      if (str.contains("vertical")) {
        if (AppLovinSdk.VERSION_CODE < 9140500)
          InMobiMediationAdapter.this.log("Vertical native banners are only supported on MAX SDK 9.14.5 and above. Default horizontal native template will be used."); 
        if (str.equals("vertical")) {
          if (this.this$2.this$1.adFormat == MaxAdFormat.LEADER) {
            str = "vertical_leader_template";
          } else {
            str = "vertical_media_banner_template";
          } 
          maxNativeAdView = InMobiMediationAdapter.this.createMaxNativeAdView(maxInMobiNativeAd, str, activity);
        } else {
          maxNativeAdView = InMobiMediationAdapter.this.createMaxNativeAdView(maxInMobiNativeAd, (String)maxNativeAdView, activity);
        } 
      } else {
        MaxNativeAdView maxNativeAdView1;
        if (AppLovinSdk.VERSION_CODE < 9140500) {
          String str1;
          InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
          if (!AppLovinSdkUtils.isValidString((String)maxNativeAdView))
            str1 = "no_body_banner_template"; 
          maxNativeAdView1 = inMobiMediationAdapter.createMaxNativeAdView(maxInMobiNativeAd, str1, activity);
        } else {
          String str1;
          InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
          if (!AppLovinSdkUtils.isValidString((String)maxNativeAdView1))
            str1 = "media_banner_template"; 
          maxNativeAdView = inMobiMediationAdapter.createMaxNativeAdView(maxInMobiNativeAd, str1, activity);
        } 
      } 
      maxInMobiNativeAd.prepareForInteraction(InMobiMediationAdapter.this.getClickableViews(maxNativeAdView), (ViewGroup)maxNativeAdView);
      if (AppLovinSdk.VERSION_CODE >= 9150000 && AppLovinSdkUtils.isValidString(adMetaInfo.getCreativeID())) {
        Bundle bundle = new Bundle(1);
        bundle.putString("creative_id", adMetaInfo.getCreativeID());
        this.this$2.this$1.listener.onAdViewAdLoaded((View)maxNativeAdView, bundle);
        return;
      } 
      this.this$2.this$1.listener.onAdViewAdLoaded((View)maxNativeAdView);
    }
  }
  
  private class RewardedAdListener extends InterstitialAdEventListener {
    private boolean hasGrantedReward;
    
    final MaxRewardedAdapterListener listener;
    
    RewardedAdListener(MaxRewardedAdapterListener param1MaxRewardedAdapterListener) {
      this.listener = param1MaxRewardedAdapterListener;
    }
    
    public void onAdClicked(InMobiInterstitial param1InMobiInterstitial, Map<Object, Object> param1Map) {
      InMobiMediationAdapter.this.log("Rewarded ad clicked");
      this.listener.onRewardedAdClicked();
    }
    
    public void onAdDismissed(InMobiInterstitial param1InMobiInterstitial) {
      InMobiMediationAdapter.this.log("Rewarded ad hidden");
      this.listener.onRewardedAdVideoCompleted();
      if (this.hasGrantedReward || InMobiMediationAdapter.this.shouldAlwaysRewardUser()) {
        MaxReward maxReward = InMobiMediationAdapter.this.getReward();
        InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Rewarded user with reward: ");
        stringBuilder.append(maxReward);
        inMobiMediationAdapter.log(stringBuilder.toString());
        this.listener.onUserRewarded(maxReward);
      } 
      this.listener.onRewardedAdHidden();
    }
    
    public void onAdDisplayFailed(InMobiInterstitial param1InMobiInterstitial) {
      InMobiMediationAdapter.this.log("Rewarded ad failed to display");
      this.listener.onRewardedAdDisplayFailed(MaxAdapterError.UNSPECIFIED);
    }
    
    public void onAdDisplayed(InMobiInterstitial param1InMobiInterstitial, AdMetaInfo param1AdMetaInfo) {
      InMobiMediationAdapter.this.log("Rewarded ad did show");
      this.listener.onRewardedAdVideoStarted();
    }
    
    public void onAdFetchSuccessful(InMobiInterstitial param1InMobiInterstitial, AdMetaInfo param1AdMetaInfo) {
      InMobiMediationAdapter.this.log("Rewarded ad request succeeded");
    }
    
    public void onAdImpression(InMobiInterstitial param1InMobiInterstitial) {
      InMobiMediationAdapter.this.log("Rewarded ad impression tracked");
      this.listener.onRewardedAdDisplayed();
    }
    
    public void onAdLoadFailed(InMobiInterstitial param1InMobiInterstitial, InMobiAdRequestStatus param1InMobiAdRequestStatus) {
      InMobiMediationAdapter inMobiMediationAdapter = InMobiMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad failed to load with error code ");
      stringBuilder.append(param1InMobiAdRequestStatus.getStatusCode());
      stringBuilder.append(" and message: ");
      stringBuilder.append(param1InMobiAdRequestStatus.getMessage());
      inMobiMediationAdapter.log(stringBuilder.toString());
      MaxAdapterError maxAdapterError = InMobiMediationAdapter.toMaxError(param1InMobiAdRequestStatus);
      this.listener.onRewardedAdLoadFailed(maxAdapterError);
    }
    
    public void onAdLoadSucceeded(InMobiInterstitial param1InMobiInterstitial, AdMetaInfo param1AdMetaInfo) {
      InMobiMediationAdapter.this.log("Rewarded ad loaded");
      if (AppLovinSdk.VERSION_CODE >= 9150000 && !TextUtils.isEmpty(param1AdMetaInfo.getCreativeID())) {
        Bundle bundle = new Bundle(1);
        bundle.putString("creative_id", param1AdMetaInfo.getCreativeID());
        this.listener.onRewardedAdLoaded(bundle);
        return;
      } 
      this.listener.onRewardedAdLoaded();
    }
    
    public void onAdWillDisplay(InMobiInterstitial param1InMobiInterstitial) {
      InMobiMediationAdapter.this.log("Rewarded ad did show");
    }
    
    public void onRewardsUnlocked(InMobiInterstitial param1InMobiInterstitial, Map<Object, Object> param1Map) {
      InMobiMediationAdapter.this.log("Rewarded ad granted reward");
      this.hasGrantedReward = true;
    }
    
    public void onUserLeftApplication(InMobiInterstitial param1InMobiInterstitial) {
      InMobiMediationAdapter.this.log("Rewarded ad will leave application");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\mediation\adapters\InMobiMediationAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */