package com.applovin.sdk;

import java.util.Locale;

public class AppLovinAdType {
  public static final AppLovinAdType APP_OPEN;
  
  public static final AppLovinAdType AUTO_INCENTIVIZED;
  
  public static final AppLovinAdType INCENTIVIZED;
  
  public static final AppLovinAdType NATIVE;
  
  public static final AppLovinAdType REGULAR = new AppLovinAdType("REGULAR");
  
  private final String a;
  
  static {
    APP_OPEN = new AppLovinAdType("APPOPEN");
    INCENTIVIZED = new AppLovinAdType("VIDEOA");
    AUTO_INCENTIVIZED = new AppLovinAdType("AUTOREW");
    NATIVE = new AppLovinAdType("NATIVE");
  }
  
  private AppLovinAdType(String paramString) {
    this.a = paramString;
  }
  
  public static AppLovinAdType fromString(String paramString) {
    if ("REGULAR".equalsIgnoreCase(paramString))
      return REGULAR; 
    if ("APPOPEN".equalsIgnoreCase(paramString))
      return APP_OPEN; 
    if ("VIDEOA".equalsIgnoreCase(paramString))
      return INCENTIVIZED; 
    if ("AUTOREW".equalsIgnoreCase(paramString))
      return AUTO_INCENTIVIZED; 
    if ("NATIVE".equalsIgnoreCase(paramString))
      return NATIVE; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Unknown Ad Type: ");
    stringBuilder.append(paramString);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public String getLabel() {
    return this.a.toUpperCase(Locale.ENGLISH);
  }
  
  public String toString() {
    return getLabel();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\sdk\AppLovinAdType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */