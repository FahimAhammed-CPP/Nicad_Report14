package com.applovin.sdk;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Point;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import com.applovin.impl.sdk.utils.CollectionUtils;
import com.applovin.impl.sdk.utils.JsonUtils;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.utils.h;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class AppLovinSdkUtils {
  private static final Handler a = new Handler(Looper.getMainLooper());
  
  private static boolean a(String paramString1, String paramString2) {
    Iterator<String> iterator = CollectionUtils.explode(paramString2).iterator();
    while (iterator.hasNext()) {
      if (paramString1.startsWith(iterator.next()))
        return true; 
    } 
    return false;
  }
  
  public static int dpToPx(Context paramContext, int paramInt) {
    return (int)TypedValue.applyDimension(1, paramInt, paramContext.getResources().getDisplayMetrics());
  }
  
  public static int getOrientation(Context paramContext) {
    if (paramContext != null) {
      Resources resources = paramContext.getResources();
      if (resources != null) {
        Configuration configuration = resources.getConfiguration();
        if (configuration != null)
          return configuration.orientation; 
      } 
    } 
    return 0;
  }
  
  public static boolean isEmulator() {
    return (a(Build.DEVICE, "goldfish,vbox") || a(Build.HARDWARE, "ranchu,generic,vbox") || a(Build.MANUFACTURER, "Genymotion") || a(Build.MODEL, "Android SDK built for x86"));
  }
  
  public static boolean isFireOS(Context paramContext) {
    return ("amazon".equalsIgnoreCase(Build.MANUFACTURER) || isFireTv(paramContext));
  }
  
  public static boolean isFireTv(Context paramContext) {
    return paramContext.getPackageManager().hasSystemFeature("amazon.hardware.fire_tv");
  }
  
  public static boolean isSdkVersionGreaterThanOrEqualTo(String paramString) {
    return (AppLovinSdk.VERSION_CODE >= Utils.toVersionCode(paramString));
  }
  
  public static boolean isTablet(Context paramContext) {
    Point point = h.a(paramContext);
    return (Math.min(point.x, point.y) >= dpToPx(paramContext, 600));
  }
  
  public static boolean isTv(Context paramContext) {
    if (isFireTv(paramContext))
      return true; 
    PackageManager packageManager = paramContext.getPackageManager();
    if (h.d()) {
      String str1 = "android.software.leanback";
      return packageManager.hasSystemFeature(str1);
    } 
    String str = "android.hardware.type.television";
    return packageManager.hasSystemFeature(str);
  }
  
  public static boolean isValidString(String paramString) {
    return TextUtils.isEmpty(paramString) ^ true;
  }
  
  public static int pxToDp(Context paramContext, int paramInt) {
    return (int)Math.ceil((paramInt / (paramContext.getResources().getDisplayMetrics()).density));
  }
  
  public static void runOnUiThread(Runnable paramRunnable) {
    runOnUiThread(false, paramRunnable);
  }
  
  public static void runOnUiThread(boolean paramBoolean, Runnable paramRunnable) {
    if (!paramBoolean && Utils.isMainThread()) {
      paramRunnable.run();
      return;
    } 
    a.post(paramRunnable);
  }
  
  public static void runOnUiThreadDelayed(Runnable paramRunnable, long paramLong) {
    runOnUiThreadDelayed(paramRunnable, paramLong, a);
  }
  
  public static void runOnUiThreadDelayed(Runnable paramRunnable, long paramLong, Handler paramHandler) {
    if (paramLong > 0L) {
      paramHandler.postDelayed(paramRunnable, paramLong);
      return;
    } 
    if (Utils.isMainThread()) {
      paramRunnable.run();
      return;
    } 
    paramHandler.post(paramRunnable);
  }
  
  public static Map<String, String> toMap(JSONObject paramJSONObject) throws JSONException {
    return JsonUtils.toStringMap(paramJSONObject);
  }
  
  public static final class Size {
    public static final Size ZERO = new Size(0, 0);
    
    private int a;
    
    private int b;
    
    private Size() {}
    
    public Size(int param1Int1, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Int2;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof Size))
        return false; 
      param1Object = param1Object;
      return (this.a == param1Object.getWidth() && this.b == param1Object.getHeight());
    }
    
    public int getHeight() {
      return this.b;
    }
    
    public int getWidth() {
      return this.a;
    }
    
    public int hashCode() {
      int i = this.b;
      int j = this.a;
      return i ^ (j >>> 16 | j << 16);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.a);
      stringBuilder.append("x");
      stringBuilder.append(this.b);
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\sdk\AppLovinSdkUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */