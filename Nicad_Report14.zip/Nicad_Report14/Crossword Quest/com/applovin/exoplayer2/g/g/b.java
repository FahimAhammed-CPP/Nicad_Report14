package com.applovin.exoplayer2.g.g;

import com.applovin.exoplayer2.ac;
import com.applovin.exoplayer2.g.a;
import com.applovin.exoplayer2.v;

public abstract class b implements a.a {
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("SCTE-35 splice command: type=");
    stringBuilder.append(getClass().getSimpleName());
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\g\g\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */