package com.applovin.exoplayer2.g.g;

import com.applovin.exoplayer2.g.a;
import com.applovin.exoplayer2.g.d;
import com.applovin.exoplayer2.g.g;
import com.applovin.exoplayer2.l.ag;
import com.applovin.exoplayer2.l.x;
import com.applovin.exoplayer2.l.y;
import java.nio.ByteBuffer;

public final class c extends g {
  private final y a = new y();
  
  private final x b = new x();
  
  private ag c;
  
  protected a a(d paramd, ByteBuffer paramByteBuffer) {
    e e;
    if (this.c == null || paramd.f != this.c.c()) {
      ag ag1 = new ag(paramd.d);
      this.c = ag1;
      ag1.c(paramd.d - paramd.f);
    } 
    byte[] arrayOfByte = paramByteBuffer.array();
    int i = paramByteBuffer.limit();
    this.a.a(arrayOfByte, i);
    this.b.a(arrayOfByte, i);
    this.b.b(39);
    long l = this.b.c(1) << 32L | this.b.c(32);
    this.b.b(20);
    i = this.b.c(12);
    int j = this.b.c(8);
    arrayOfByte = null;
    this.a.e(14);
    if (j != 0) {
      if (j != 255) {
        if (j != 4) {
          if (j != 5) {
            if (j == 6)
              g g1 = g.a(this.a, l, this.c); 
          } else {
            d d1 = d.a(this.a, l, this.c);
          } 
        } else {
          f f = f.a(this.a);
        } 
      } else {
        a a = a.a(this.a, i, l);
      } 
    } else {
      e = new e();
    } 
    return (e == null) ? new a(new a.a[0]) : new a(new a.a[] { e });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\g\g\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */