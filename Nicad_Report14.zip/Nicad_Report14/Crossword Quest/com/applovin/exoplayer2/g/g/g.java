package com.applovin.exoplayer2.g.g;

import android.os.Parcel;
import android.os.Parcelable;
import com.applovin.exoplayer2.l.ag;
import com.applovin.exoplayer2.l.y;

public final class g extends b {
  public static final Parcelable.Creator<g> CREATOR = new Parcelable.Creator<g>() {
      public g a(Parcel param1Parcel) {
        return new g(param1Parcel.readLong(), param1Parcel.readLong());
      }
      
      public g[] a(int param1Int) {
        return new g[param1Int];
      }
    };
  
  public final long a;
  
  public final long b;
  
  private g(long paramLong1, long paramLong2) {
    this.a = paramLong1;
    this.b = paramLong2;
  }
  
  static long a(y paramy, long paramLong) {
    long l = paramy.h();
    return ((0x80L & l) != 0L) ? (0x1FFFFFFFFL & ((l & 0x1L) << 32L | paramy.o()) + paramLong) : -9223372036854775807L;
  }
  
  static g a(y paramy, long paramLong, ag paramag) {
    paramLong = a(paramy, paramLong);
    return new g(paramLong, paramag.b(paramLong));
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeLong(this.a);
    paramParcel.writeLong(this.b);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\g\g\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */