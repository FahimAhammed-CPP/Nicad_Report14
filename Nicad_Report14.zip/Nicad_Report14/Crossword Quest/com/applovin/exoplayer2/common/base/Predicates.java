package com.applovin.exoplayer2.common.base;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public final class Predicates {
  public static <T> Predicate<T> alwaysFalse() {
    return g.b.a();
  }
  
  public static <T> Predicate<T> alwaysTrue() {
    return g.a.a();
  }
  
  public static <T> Predicate<T> and(Predicate<? super T> paramPredicate1, Predicate<? super T> paramPredicate2) {
    return new a<T>(asList(Preconditions.<Predicate>checkNotNull(paramPredicate1), Preconditions.<Predicate>checkNotNull(paramPredicate2)));
  }
  
  public static <T> Predicate<T> and(Iterable<? extends Predicate<? super T>> paramIterable) {
    return new a<T>(defensiveCopy(paramIterable));
  }
  
  @SafeVarargs
  public static <T> Predicate<T> and(Predicate<? super T>... paramVarArgs) {
    return new a<T>(defensiveCopy(paramVarArgs));
  }
  
  private static <T> List<Predicate<? super T>> asList(Predicate<? super T> paramPredicate1, Predicate<? super T> paramPredicate2) {
    return Arrays.asList((Predicate<? super T>[])new Predicate[] { paramPredicate1, paramPredicate2 });
  }
  
  public static <A, B> Predicate<A> compose(Predicate<B> paramPredicate, Function<A, ? extends B> paramFunction) {
    return new b<A, Object>(paramPredicate, paramFunction);
  }
  
  static <T> List<T> defensiveCopy(Iterable<T> paramIterable) {
    ArrayList<T> arrayList = new ArrayList();
    Iterator<T> iterator = paramIterable.iterator();
    while (iterator.hasNext())
      arrayList.add(Preconditions.checkNotNull(iterator.next())); 
    return arrayList;
  }
  
  private static <T> List<T> defensiveCopy(T... paramVarArgs) {
    return defensiveCopy(Arrays.asList(paramVarArgs));
  }
  
  public static <T> Predicate<T> equalTo(@NullableDecl T paramT) {
    return (paramT == null) ? isNull() : new e<T>(paramT);
  }
  
  public static <T> Predicate<T> in(Collection<? extends T> paramCollection) {
    return new c<T>(paramCollection);
  }
  
  public static Predicate<Object> instanceOf(Class<?> paramClass) {
    return new d(paramClass);
  }
  
  public static <T> Predicate<T> isNull() {
    return g.c.a();
  }
  
  public static <T> Predicate<T> not(Predicate<T> paramPredicate) {
    return new f<T>(paramPredicate);
  }
  
  public static <T> Predicate<T> notNull() {
    return g.d.a();
  }
  
  public static <T> Predicate<T> or(Predicate<? super T> paramPredicate1, Predicate<? super T> paramPredicate2) {
    return new h<T>(asList(Preconditions.<Predicate>checkNotNull(paramPredicate1), Preconditions.<Predicate>checkNotNull(paramPredicate2)));
  }
  
  public static <T> Predicate<T> or(Iterable<? extends Predicate<? super T>> paramIterable) {
    return new h<T>(defensiveCopy(paramIterable));
  }
  
  @SafeVarargs
  public static <T> Predicate<T> or(Predicate<? super T>... paramVarArgs) {
    return new h<T>(defensiveCopy(paramVarArgs));
  }
  
  public static Predicate<Class<?>> subtypeOf(Class<?> paramClass) {
    return new i(paramClass);
  }
  
  private static String toStringHelper(String paramString, Iterable<?> paramIterable) {
    StringBuilder stringBuilder = new StringBuilder("Predicates.");
    stringBuilder.append(paramString);
    stringBuilder.append('(');
    Iterator<?> iterator = paramIterable.iterator();
    for (boolean bool = true; iterator.hasNext(); bool = false) {
      paramIterable = (Iterable<?>)iterator.next();
      if (!bool)
        stringBuilder.append(','); 
      stringBuilder.append(paramIterable);
    } 
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  private static class a<T> implements Predicate<T>, Serializable {
    private final List<? extends Predicate<? super T>> a;
    
    private a(List<? extends Predicate<? super T>> param1List) {
      this.a = param1List;
    }
    
    public boolean apply(@NullableDecl T param1T) {
      for (int i = 0; i < this.a.size(); i++) {
        if (!((Predicate<T>)this.a.get(i)).apply(param1T))
          return false; 
      } 
      return true;
    }
    
    public boolean equals(@NullableDecl Object param1Object) {
      if (param1Object instanceof a) {
        param1Object = param1Object;
        return this.a.equals(((a)param1Object).a);
      } 
      return false;
    }
    
    public int hashCode() {
      return this.a.hashCode() + 306654252;
    }
    
    public String toString() {
      return Predicates.toStringHelper("and", this.a);
    }
  }
  
  private static class b<A, B> implements Predicate<A>, Serializable {
    final Predicate<B> a;
    
    final Function<A, ? extends B> b;
    
    private b(Predicate<B> param1Predicate, Function<A, ? extends B> param1Function) {
      this.a = Preconditions.<Predicate<B>>checkNotNull(param1Predicate);
      this.b = Preconditions.<Function<A, ? extends B>>checkNotNull(param1Function);
    }
    
    public boolean apply(@NullableDecl A param1A) {
      return this.a.apply(this.b.apply(param1A));
    }
    
    public boolean equals(@NullableDecl Object param1Object) {
      boolean bool = param1Object instanceof b;
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        param1Object = param1Object;
        bool1 = bool2;
        if (this.b.equals(((b)param1Object).b)) {
          bool1 = bool2;
          if (this.a.equals(((b)param1Object).a))
            bool1 = true; 
        } 
      } 
      return bool1;
    }
    
    public int hashCode() {
      return this.b.hashCode() ^ this.a.hashCode();
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.a);
      stringBuilder.append("(");
      stringBuilder.append(this.b);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  private static class c<T> implements Predicate<T>, Serializable {
    private final Collection<?> a;
    
    private c(Collection<?> param1Collection) {
      this.a = Preconditions.<Collection>checkNotNull(param1Collection);
    }
    
    public boolean apply(@NullableDecl T param1T) {
      try {
        return this.a.contains(param1T);
      } catch (NullPointerException|ClassCastException nullPointerException) {
        return false;
      } 
    }
    
    public boolean equals(@NullableDecl Object param1Object) {
      if (param1Object instanceof c) {
        param1Object = param1Object;
        return this.a.equals(((c)param1Object).a);
      } 
      return false;
    }
    
    public int hashCode() {
      return this.a.hashCode();
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Predicates.in(");
      stringBuilder.append(this.a);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  private static class d implements Predicate<Object>, Serializable {
    private final Class<?> a;
    
    private d(Class<?> param1Class) {
      this.a = Preconditions.<Class<?>>checkNotNull(param1Class);
    }
    
    public boolean apply(@NullableDecl Object param1Object) {
      return this.a.isInstance(param1Object);
    }
    
    public boolean equals(@NullableDecl Object param1Object) {
      boolean bool = param1Object instanceof d;
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        param1Object = param1Object;
        bool1 = bool2;
        if (this.a == ((d)param1Object).a)
          bool1 = true; 
      } 
      return bool1;
    }
    
    public int hashCode() {
      return this.a.hashCode();
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Predicates.instanceOf(");
      stringBuilder.append(this.a.getName());
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  private static class e<T> implements Predicate<T>, Serializable {
    private final T a;
    
    private e(T param1T) {
      this.a = param1T;
    }
    
    public boolean apply(T param1T) {
      return this.a.equals(param1T);
    }
    
    public boolean equals(@NullableDecl Object param1Object) {
      if (param1Object instanceof e) {
        param1Object = param1Object;
        return this.a.equals(((e)param1Object).a);
      } 
      return false;
    }
    
    public int hashCode() {
      return this.a.hashCode();
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Predicates.equalTo(");
      stringBuilder.append(this.a);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  private static class f<T> implements Predicate<T>, Serializable {
    final Predicate<T> a;
    
    f(Predicate<T> param1Predicate) {
      this.a = Preconditions.<Predicate<T>>checkNotNull(param1Predicate);
    }
    
    public boolean apply(@NullableDecl T param1T) {
      return this.a.apply(param1T) ^ true;
    }
    
    public boolean equals(@NullableDecl Object param1Object) {
      if (param1Object instanceof f) {
        param1Object = param1Object;
        return this.a.equals(((f)param1Object).a);
      } 
      return false;
    }
    
    public int hashCode() {
      return this.a.hashCode() ^ 0xFFFFFFFF;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Predicates.not(");
      stringBuilder.append(this.a);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  enum g implements Predicate<Object> {
    a, b, c, d;
    
    static {
      null  = new null("ALWAYS_TRUE", 0);
      a = ;
      null 1 = new null("ALWAYS_FALSE", 1);
      b = 1;
      null 2 = new null("IS_NULL", 2);
      c = 2;
      null 3 = new null("NOT_NULL", 3);
      d = 3;
      e = new g[] { , 1, 2, 3 };
    }
    
    <T> Predicate<T> a() {
      return this;
    }
  }
  
  enum null {
    public boolean apply(@NullableDecl Object param1Object) {
      return true;
    }
    
    public String toString() {
      return "Predicates.alwaysTrue()";
    }
  }
  
  enum null {
    public boolean apply(@NullableDecl Object param1Object) {
      return false;
    }
    
    public String toString() {
      return "Predicates.alwaysFalse()";
    }
  }
  
  enum null {
    public boolean apply(@NullableDecl Object param1Object) {
      return (param1Object == null);
    }
    
    public String toString() {
      return "Predicates.isNull()";
    }
  }
  
  enum null {
    public boolean apply(@NullableDecl Object param1Object) {
      return (param1Object != null);
    }
    
    public String toString() {
      return "Predicates.notNull()";
    }
  }
  
  private static class h<T> implements Predicate<T>, Serializable {
    private final List<? extends Predicate<? super T>> a;
    
    private h(List<? extends Predicate<? super T>> param1List) {
      this.a = param1List;
    }
    
    public boolean apply(@NullableDecl T param1T) {
      for (int i = 0; i < this.a.size(); i++) {
        if (((Predicate<T>)this.a.get(i)).apply(param1T))
          return true; 
      } 
      return false;
    }
    
    public boolean equals(@NullableDecl Object param1Object) {
      if (param1Object instanceof h) {
        param1Object = param1Object;
        return this.a.equals(((h)param1Object).a);
      } 
      return false;
    }
    
    public int hashCode() {
      return this.a.hashCode() + 87855567;
    }
    
    public String toString() {
      return Predicates.toStringHelper("or", this.a);
    }
  }
  
  private static class i implements Predicate<Class<?>>, Serializable {
    private final Class<?> a;
    
    private i(Class<?> param1Class) {
      this.a = Preconditions.<Class<?>>checkNotNull(param1Class);
    }
    
    public boolean a(Class<?> param1Class) {
      return this.a.isAssignableFrom(param1Class);
    }
    
    public boolean equals(@NullableDecl Object param1Object) {
      boolean bool = param1Object instanceof i;
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        param1Object = param1Object;
        bool1 = bool2;
        if (this.a == ((i)param1Object).a)
          bool1 = true; 
      } 
      return bool1;
    }
    
    public int hashCode() {
      return this.a.hashCode();
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Predicates.subtypeOf(");
      stringBuilder.append(this.a.getName());
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\base\Predicates.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */