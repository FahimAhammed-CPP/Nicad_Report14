package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.base.Preconditions;
import java.util.NoSuchElementException;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public abstract class b<T> extends ax<T> {
  private a a = a.b;
  
  @NullableDecl
  private T b;
  
  private boolean c() {
    this.a = a.d;
    this.b = a();
    if (this.a != a.c) {
      this.a = a.a;
      return true;
    } 
    return false;
  }
  
  protected abstract T a();
  
  protected final T b() {
    this.a = a.c;
    return null;
  }
  
  public final boolean hasNext() {
    boolean bool;
    if (this.a != a.d) {
      bool = true;
    } else {
      bool = false;
    } 
    Preconditions.checkState(bool);
    int i = null.a[this.a.ordinal()];
    return (i != 1) ? ((i != 2) ? c() : true) : false;
  }
  
  public final T next() {
    if (hasNext()) {
      this.a = a.b;
      T t = this.b;
      this.b = null;
      return t;
    } 
    throw new NoSuchElementException();
  }
  
  private enum a {
    a, b, c, d;
    
    static {
      a a1 = new a("READY", 0);
      a = a1;
      a a2 = new a("NOT_READY", 1);
      b = a2;
      a a3 = new a("DONE", 2);
      c = a3;
      a a4 = new a("FAILED", 3);
      d = a4;
      e = new a[] { a1, a2, a3, a4 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */