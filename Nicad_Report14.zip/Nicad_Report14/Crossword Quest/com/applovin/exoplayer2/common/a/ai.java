package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.base.Function;
import java.util.Comparator;
import java.util.Map;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public abstract class ai<T> implements Comparator<T> {
  public static <T> ai<T> a(Comparator<T> paramComparator) {
    return (paramComparator instanceof ai) ? (ai<T>)paramComparator : new m<T>(paramComparator);
  }
  
  public static <C extends Comparable> ai<C> b() {
    return (ai<C>)ag.a;
  }
  
  public <S extends T> ai<S> a() {
    return new ao<S>(this);
  }
  
  public <F> ai<F> a(Function<F, ? extends T> paramFunction) {
    return new i<F, T>(paramFunction, this);
  }
  
  public <E extends T> s<E> a(Iterable<E> paramIterable) {
    return s.a(this, paramIterable);
  }
  
  <T2 extends T> ai<Map.Entry<T2, ?>> c() {
    return a(ab.a());
  }
  
  public abstract int compare(@NullableDecl T paramT1, @NullableDecl T paramT2);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\a\ai.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */