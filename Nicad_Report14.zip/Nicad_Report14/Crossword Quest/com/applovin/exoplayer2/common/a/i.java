package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.base.Function;
import com.applovin.exoplayer2.common.base.Objects;
import com.applovin.exoplayer2.common.base.Preconditions;
import java.io.Serializable;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

final class i<F, T> extends ai<F> implements Serializable {
  final Function<F, ? extends T> a;
  
  final ai<T> b;
  
  i(Function<F, ? extends T> paramFunction, ai<T> paramai) {
    this.a = (Function<F, ? extends T>)Preconditions.checkNotNull(paramFunction);
    this.b = (ai<T>)Preconditions.checkNotNull(paramai);
  }
  
  public int compare(F paramF1, F paramF2) {
    return this.b.compare((T)this.a.apply(paramF1), (T)this.a.apply(paramF2));
  }
  
  public boolean equals(@NullableDecl Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof i) {
      paramObject = paramObject;
      return (this.a.equals(((i)paramObject).a) && this.b.equals(((i)paramObject).b));
    } 
    return false;
  }
  
  public int hashCode() {
    return Objects.hashCode(new Object[] { this.a, this.b });
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.b);
    stringBuilder.append(".onResultOf(");
    stringBuilder.append(this.a);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\a\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */