package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.b.c;
import com.applovin.exoplayer2.common.b.d;
import java.util.Comparator;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public abstract class n {
  private static final n a = new n() {
      n a(int param1Int) {
        return (param1Int < 0) ? n.c() : ((param1Int > 0) ? n.d() : n.e());
      }
      
      public n a(int param1Int1, int param1Int2) {
        return a(c.a(param1Int1, param1Int2));
      }
      
      public n a(long param1Long1, long param1Long2) {
        return a(d.a(param1Long1, param1Long2));
      }
      
      public <T> n a(@NullableDecl T param1T1, @NullableDecl T param1T2, Comparator<T> param1Comparator) {
        return a(param1Comparator.compare(param1T1, param1T2));
      }
      
      public n a(boolean param1Boolean1, boolean param1Boolean2) {
        return a(com.applovin.exoplayer2.common.b.a.a(param1Boolean2, param1Boolean1));
      }
      
      public int b() {
        return 0;
      }
      
      public n b(boolean param1Boolean1, boolean param1Boolean2) {
        return a(com.applovin.exoplayer2.common.b.a.a(param1Boolean1, param1Boolean2));
      }
    };
  
  private static final n b = new a(-1);
  
  private static final n c = new a(1);
  
  private n() {}
  
  public static n a() {
    return a;
  }
  
  public abstract n a(int paramInt1, int paramInt2);
  
  public abstract n a(long paramLong1, long paramLong2);
  
  public abstract <T> n a(@NullableDecl T paramT1, @NullableDecl T paramT2, Comparator<T> paramComparator);
  
  public abstract n a(boolean paramBoolean1, boolean paramBoolean2);
  
  public abstract int b();
  
  public abstract n b(boolean paramBoolean1, boolean paramBoolean2);
  
  private static final class a extends n {
    final int a;
    
    a(int param1Int) {
      this.a = param1Int;
    }
    
    public n a(int param1Int1, int param1Int2) {
      return this;
    }
    
    public n a(long param1Long1, long param1Long2) {
      return this;
    }
    
    public <T> n a(@NullableDecl T param1T1, @NullableDecl T param1T2, @NullableDecl Comparator<T> param1Comparator) {
      return this;
    }
    
    public n a(boolean param1Boolean1, boolean param1Boolean2) {
      return this;
    }
    
    public int b() {
      return this.a;
    }
    
    public n b(boolean param1Boolean1, boolean param1Boolean2) {
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\a\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */