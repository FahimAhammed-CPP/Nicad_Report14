package com.applovin.exoplayer2.common.a;

import java.util.Collection;
import java.util.Map;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public interface ac<K, V> {
  boolean a(@NullableDecl K paramK, @NullableDecl V paramV);
  
  Collection<V> b(@NullableDecl K paramK);
  
  Map<K, Collection<V>> b();
  
  boolean b(@NullableDecl Object paramObject1, @NullableDecl Object paramObject2);
  
  boolean c(@NullableDecl Object paramObject1, @NullableDecl Object paramObject2);
  
  int d();
  
  void e();
  
  Collection<V> h();
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\a\ac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */