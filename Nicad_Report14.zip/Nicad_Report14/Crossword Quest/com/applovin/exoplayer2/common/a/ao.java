package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.base.Preconditions;
import java.io.Serializable;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

final class ao<T> extends ai<T> implements Serializable {
  final ai<? super T> a;
  
  ao(ai<? super T> paramai) {
    this.a = (ai<? super T>)Preconditions.checkNotNull(paramai);
  }
  
  public <S extends T> ai<S> a() {
    return (ai)this.a;
  }
  
  public int compare(T paramT1, T paramT2) {
    return this.a.compare(paramT2, paramT1);
  }
  
  public boolean equals(@NullableDecl Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof ao) {
      paramObject = paramObject;
      return this.a.equals(((ao)paramObject).a);
    } 
    return false;
  }
  
  public int hashCode() {
    return -this.a.hashCode();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.a);
    stringBuilder.append(".reverse()");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\a\ao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */