package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.base.Objects;
import com.applovin.exoplayer2.common.base.Preconditions;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public final class y {
  static <T> ax<T> a() {
    return (ax)b();
  }
  
  public static <T> ax<T> a(@NullableDecl T paramT) {
    return new ax<T>(paramT) {
        boolean a;
        
        public boolean hasNext() {
          return this.a ^ true;
        }
        
        public T next() {
          if (!this.a) {
            this.a = true;
            return (T)this.b;
          } 
          throw new NoSuchElementException();
        }
      };
  }
  
  @NullableDecl
  public static <T> T a(Iterator<? extends T> paramIterator, @NullableDecl T paramT) {
    if (paramIterator.hasNext())
      paramT = paramIterator.next(); 
    return paramT;
  }
  
  public static String a(Iterator<?> paramIterator) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append('[');
    boolean bool = true;
    while (paramIterator.hasNext()) {
      if (!bool)
        stringBuilder.append(", "); 
      bool = false;
      stringBuilder.append(paramIterator.next());
    } 
    stringBuilder.append(']');
    return stringBuilder.toString();
  }
  
  public static <T> boolean a(Collection<T> paramCollection, Iterator<? extends T> paramIterator) {
    Preconditions.checkNotNull(paramCollection);
    Preconditions.checkNotNull(paramIterator);
    boolean bool;
    for (bool = false; paramIterator.hasNext(); bool |= paramCollection.add(paramIterator.next()));
    return bool;
  }
  
  public static boolean a(Iterator<?> paramIterator, Collection<?> paramCollection) {
    Preconditions.checkNotNull(paramCollection);
    boolean bool = false;
    while (paramIterator.hasNext()) {
      if (paramCollection.contains(paramIterator.next())) {
        paramIterator.remove();
        bool = true;
      } 
    } 
    return bool;
  }
  
  public static boolean a(Iterator<?> paramIterator1, Iterator<?> paramIterator2) {
    while (paramIterator1.hasNext()) {
      if (!paramIterator2.hasNext())
        return false; 
      if (!Objects.equal(paramIterator1.next(), paramIterator2.next()))
        return false; 
    } 
    return paramIterator2.hasNext() ^ true;
  }
  
  static <T> ay<T> b() {
    return (ay)a.a;
  }
  
  public static <T> T b(Iterator<T> paramIterator) {
    while (true) {
      T t = paramIterator.next();
      if (!paramIterator.hasNext())
        return t; 
    } 
  }
  
  @NullableDecl
  static <T> T c(Iterator<T> paramIterator) {
    if (paramIterator.hasNext()) {
      T t = paramIterator.next();
      paramIterator.remove();
      return t;
    } 
    return null;
  }
  
  static <T> Iterator<T> c() {
    return b.a;
  }
  
  static void d(Iterator<?> paramIterator) {
    Preconditions.checkNotNull(paramIterator);
    while (paramIterator.hasNext()) {
      paramIterator.next();
      paramIterator.remove();
    } 
  }
  
  private static final class a<T> extends a<T> {
    static final ay<Object> a = (ay<Object>)new a((T[])new Object[0], 0, 0, 0);
    
    private final T[] b;
    
    private final int c;
    
    a(T[] param1ArrayOfT, int param1Int1, int param1Int2, int param1Int3) {
      super(param1Int2, param1Int3);
      this.b = param1ArrayOfT;
      this.c = param1Int1;
    }
    
    protected T a(int param1Int) {
      return this.b[this.c + param1Int];
    }
  }
  
  private enum b implements Iterator<Object> {
    a;
    
    static {
      b b1 = new b("INSTANCE", 0);
      a = b1;
      b = new b[] { b1 };
    }
    
    public boolean hasNext() {
      return false;
    }
    
    public Object next() {
      throw new NoSuchElementException();
    }
    
    public void remove() {
      j.a(false);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\a\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */