package com.applovin.exoplayer2.common.a;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public abstract class v<K, V> extends g<K, V> implements Serializable {
  final transient u<K, ? extends q<V>> b;
  
  final transient int c;
  
  v(u<K, ? extends q<V>> paramu, int paramInt) {
    this.b = paramu;
    this.c = paramInt;
  }
  
  @Deprecated
  public boolean a(K paramK, V paramV) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public boolean c(Object paramObject1, Object paramObject2) {
    throw new UnsupportedOperationException();
  }
  
  public int d() {
    return this.c;
  }
  
  public boolean d(@NullableDecl Object paramObject) {
    return (paramObject != null && super.d(paramObject));
  }
  
  public abstract q<V> e(K paramK);
  
  @Deprecated
  public void e() {
    throw new UnsupportedOperationException();
  }
  
  Set<K> f() {
    throw new AssertionError("unreachable");
  }
  
  boolean g() {
    return this.b.i();
  }
  
  Map<K, Collection<V>> n() {
    throw new AssertionError("should never be called");
  }
  
  public w<K> o() {
    return this.b.e();
  }
  
  public u<K, Collection<V>> q() {
    return (u)this.b;
  }
  
  public q<Map.Entry<K, V>> r() {
    return (q<Map.Entry<K, V>>)super.k();
  }
  
  q<Map.Entry<K, V>> s() {
    return new b<K, V>(this);
  }
  
  ax<Map.Entry<K, V>> t() {
    return new ax<Map.Entry<K, V>>(this) {
        final Iterator<? extends Map.Entry<K, ? extends q<V>>> a;
        
        K b;
        
        Iterator<V> c;
        
        public Map.Entry<K, V> a() {
          if (!this.c.hasNext()) {
            Map.Entry entry = this.a.next();
            this.b = (K)entry.getKey();
            this.c = (Iterator<V>)((q)entry.getValue()).a();
          } 
          return ab.a(this.b, this.c.next());
        }
        
        public boolean hasNext() {
          return (this.c.hasNext() || this.a.hasNext());
        }
      };
  }
  
  public q<V> u() {
    return (q<V>)super.h();
  }
  
  q<V> v() {
    return new c<Object, V>(this);
  }
  
  ax<V> w() {
    return new ax<V>(this) {
        Iterator<? extends q<V>> a;
        
        Iterator<V> b;
        
        public boolean hasNext() {
          return (this.b.hasNext() || this.a.hasNext());
        }
        
        public V next() {
          if (!this.b.hasNext())
            this.b = (Iterator<V>)((q)this.a.next()).a(); 
          return this.b.next();
        }
      };
  }
  
  public static class a<K, V> {
    Map<K, Collection<V>> a = aj.a();
    
    @MonotonicNonNullDecl
    Comparator<? super K> b;
    
    @MonotonicNonNullDecl
    Comparator<? super V> c;
    
    public a<K, V> b(K param1K, Iterable<? extends V> param1Iterable) {
      Iterator<? extends V> iterator;
      if (param1K != null) {
        Collection<V> collection = this.a.get(param1K);
        iterator = param1Iterable.iterator();
        if (collection != null) {
          while (iterator.hasNext()) {
            V v = iterator.next();
            j.a(param1K, v);
            collection.add(v);
          } 
          return this;
        } 
        if (!iterator.hasNext())
          return this; 
        collection = c();
        while (iterator.hasNext()) {
          V v = iterator.next();
          j.a(param1K, v);
          collection.add(v);
        } 
        this.a.put(param1K, collection);
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("null key in entry: null=");
      stringBuilder.append(x.a((Iterable<?>)iterator));
      NullPointerException nullPointerException = new NullPointerException(stringBuilder.toString());
      throw nullPointerException;
    }
    
    public a<K, V> b(K param1K, V... param1VarArgs) {
      return b(param1K, Arrays.asList(param1VarArgs));
    }
    
    public v<K, V> b() {
      s s;
      Set<Map.Entry<K, Collection<V>>> set2 = this.a.entrySet();
      Comparator<? super K> comparator = this.b;
      Set<Map.Entry<K, Collection<V>>> set1 = set2;
      if (comparator != null)
        s = ai.<K>a(comparator).c().a(set2); 
      return t.a((Collection<? extends Map.Entry<? extends K, ? extends Collection<? extends V>>>)s, this.c);
    }
    
    Collection<V> c() {
      return new ArrayList<V>();
    }
  }
  
  private static class b<K, V> extends q<Map.Entry<K, V>> {
    final v<K, V> a;
    
    b(v<K, V> param1v) {
      this.a = param1v;
    }
    
    public ax<Map.Entry<K, V>> a() {
      return this.a.t();
    }
    
    public boolean contains(Object param1Object) {
      if (param1Object instanceof Map.Entry) {
        param1Object = param1Object;
        return this.a.b(param1Object.getKey(), param1Object.getValue());
      } 
      return false;
    }
    
    boolean f() {
      return this.a.g();
    }
    
    public int size() {
      return this.a.d();
    }
  }
  
  private static final class c<K, V> extends q<V> {
    private final transient v<K, V> a;
    
    c(v<K, V> param1v) {
      this.a = param1v;
    }
    
    int a(Object[] param1ArrayOfObject, int param1Int) {
      ax<q> ax = this.a.b.g().a();
      while (ax.hasNext())
        param1Int = ((q)ax.next()).a(param1ArrayOfObject, param1Int); 
      return param1Int;
    }
    
    public ax<V> a() {
      return this.a.w();
    }
    
    public boolean contains(@NullableDecl Object param1Object) {
      return this.a.d(param1Object);
    }
    
    boolean f() {
      return true;
    }
    
    public int size() {
      return this.a.d();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\a\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */