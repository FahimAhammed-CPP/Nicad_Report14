package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.base.Objects;
import com.applovin.exoplayer2.common.base.Preconditions;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public final class aa {
  public static <E> ArrayList<E> a() {
    return new ArrayList<E>();
  }
  
  public static <E> ArrayList<E> a(Iterator<? extends E> paramIterator) {
    ArrayList<?> arrayList = a();
    y.a(arrayList, paramIterator);
    return (ArrayList)arrayList;
  }
  
  static boolean a(List<?> paramList, @NullableDecl Object paramObject) {
    if (paramObject == Preconditions.checkNotNull(paramList))
      return true; 
    if (!(paramObject instanceof List))
      return false; 
    paramObject = paramObject;
    int i = paramList.size();
    if (i != paramObject.size())
      return false; 
    if (paramList instanceof java.util.RandomAccess && paramObject instanceof java.util.RandomAccess) {
      for (int j = 0; j < i; j++) {
        if (!Objects.equal(paramList.get(j), paramObject.get(j)))
          return false; 
      } 
      return true;
    } 
    return y.a(paramList.iterator(), paramObject.iterator());
  }
  
  static int b(List<?> paramList, @NullableDecl Object paramObject) {
    if (paramList instanceof java.util.RandomAccess)
      return d(paramList, paramObject); 
    ListIterator<?> listIterator = paramList.listIterator();
    while (listIterator.hasNext()) {
      if (Objects.equal(paramObject, listIterator.next()))
        return listIterator.previousIndex(); 
    } 
    return -1;
  }
  
  static int c(List<?> paramList, @NullableDecl Object paramObject) {
    if (paramList instanceof java.util.RandomAccess)
      return e(paramList, paramObject); 
    ListIterator<?> listIterator = paramList.listIterator(paramList.size());
    while (listIterator.hasPrevious()) {
      if (Objects.equal(paramObject, listIterator.previous()))
        return listIterator.nextIndex(); 
    } 
    return -1;
  }
  
  private static int d(List<?> paramList, @NullableDecl Object paramObject) {
    int j = paramList.size();
    int i = 0;
    byte b = 0;
    if (paramObject == null) {
      for (i = b; i < j; i++) {
        if (paramList.get(i) == null)
          return i; 
      } 
    } else {
      while (i < j) {
        if (paramObject.equals(paramList.get(i)))
          return i; 
        i++;
      } 
    } 
    return -1;
  }
  
  private static int e(List<?> paramList, @NullableDecl Object paramObject) {
    if (paramObject == null) {
      for (int i = paramList.size() - 1; i >= 0; i--) {
        if (paramList.get(i) == null)
          return i; 
      } 
    } else {
      for (int i = paramList.size() - 1; i >= 0; i--) {
        if (paramObject.equals(paramList.get(i)))
          return i; 
      } 
    } 
    return -1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\a\aa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */