package com.applovin.exoplayer2.e.i;

import com.applovin.exoplayer2.e.b;
import com.applovin.exoplayer2.e.j;
import com.applovin.exoplayer2.e.x;
import com.applovin.exoplayer2.l.a;
import com.applovin.exoplayer2.l.y;
import com.applovin.exoplayer2.v;
import java.util.List;

final class af {
  private final List<v> a;
  
  private final x[] b;
  
  public af(List<v> paramList) {
    this.a = paramList;
    this.b = new x[paramList.size()];
  }
  
  public void a(long paramLong, y paramy) {
    if (paramy.a() < 9)
      return; 
    int i = paramy.q();
    int j = paramy.q();
    int k = paramy.h();
    if (i == 434 && j == 1195456820 && k == 3)
      b.b(paramLong, paramy, this.b); 
  }
  
  public void a(j paramj, ad.d paramd) {
    for (int i = 0; i < this.b.length; i++) {
      boolean bool;
      paramd.a();
      x x1 = paramj.a(paramd.b(), 3);
      v v = this.a.get(i);
      String str = v.l;
      if ("application/cea-608".equals(str) || "application/cea-708".equals(str)) {
        bool = true;
      } else {
        bool = false;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid closed caption mime type provided: ");
      stringBuilder.append(str);
      a.a(bool, stringBuilder.toString());
      x1.a((new v.a()).a(paramd.c()).f(str).b(v.d).c(v.c).p(v.D).a(v.n).a());
      this.b[i] = x1;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\e\i\af.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */