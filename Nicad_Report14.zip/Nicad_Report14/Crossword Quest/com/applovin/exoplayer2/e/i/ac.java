package com.applovin.exoplayer2.e.i;

import android.util.SparseArray;
import android.util.SparseBooleanArray;
import android.util.SparseIntArray;
import com.applovin.exoplayer2.ai;
import com.applovin.exoplayer2.e.h;
import com.applovin.exoplayer2.e.i;
import com.applovin.exoplayer2.e.j;
import com.applovin.exoplayer2.e.l;
import com.applovin.exoplayer2.e.u;
import com.applovin.exoplayer2.e.v;
import com.applovin.exoplayer2.l.ag;
import com.applovin.exoplayer2.l.x;
import com.applovin.exoplayer2.l.y;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ac implements h {
  public static final l a = (l)ac$.ExternalSyntheticLambda0.INSTANCE;
  
  private final int b;
  
  private final int c;
  
  private final List<ag> d;
  
  private final y e;
  
  private final SparseIntArray f;
  
  private final ad.c g;
  
  private final SparseArray<ad> h;
  
  private final SparseBooleanArray i;
  
  private final SparseBooleanArray j;
  
  private final ab k;
  
  private aa l;
  
  private j m;
  
  private int n;
  
  private boolean o;
  
  private boolean p;
  
  private boolean q;
  
  private ad r;
  
  private int s;
  
  private int t;
  
  public ac() {
    this(0);
  }
  
  public ac(int paramInt) {
    this(1, paramInt, 112800);
  }
  
  public ac(int paramInt1, int paramInt2, int paramInt3) {
    this(paramInt1, new ag(0L), (ad.c)new g(paramInt2), paramInt3);
  }
  
  public ac(int paramInt1, ag paramag, ad.c paramc, int paramInt2) {
    this.g = (ad.c)com.applovin.exoplayer2.l.a.b(paramc);
    this.c = paramInt2;
    this.b = paramInt1;
    if (paramInt1 == 1 || paramInt1 == 2) {
      this.d = Collections.singletonList(paramag);
    } else {
      ArrayList<ag> arrayList = new ArrayList();
      this.d = arrayList;
      arrayList.add(paramag);
    } 
    this.e = new y(new byte[9400], 0);
    this.i = new SparseBooleanArray();
    this.j = new SparseBooleanArray();
    this.h = new SparseArray();
    this.f = new SparseIntArray();
    this.k = new ab(paramInt2);
    this.m = j.a;
    this.t = -1;
    b();
  }
  
  private int a() throws ai {
    int k = this.e.c();
    int m = this.e.b();
    int n = ae.a(this.e.d(), k, m);
    this.e.d(n);
    int i = n + 188;
    if (i > m) {
      k = this.s + n - k;
      this.s = k;
      if (this.b == 2) {
        if (k <= 376)
          return i; 
        throw ai.b("Cannot find sync byte. Most likely not a Transport Stream.", null);
      } 
    } else {
      this.s = 0;
    } 
    return i;
  }
  
  private void a(long paramLong) {
    if (!this.p) {
      j j1;
      v.b b;
      this.p = true;
      if (this.k.b() != -9223372036854775807L) {
        aa aa1 = new aa(this.k.c(), this.k.b(), paramLong, this.t, this.c);
        this.l = aa1;
        j1 = this.m;
        v v = aa1.a();
      } else {
        j1 = this.m;
        b = new v.b(this.k.b());
      } 
      j1.a((v)b);
    } 
  }
  
  private boolean a(int paramInt) {
    int i = this.b;
    boolean bool = false;
    if (i == 2 || this.o || !this.j.get(paramInt, false))
      bool = true; 
    return bool;
  }
  
  private void b() {
    this.i.clear();
    this.h.clear();
    SparseArray<ad> sparseArray = this.g.a();
    int k = sparseArray.size();
    for (int i = 0; i < k; i++)
      this.h.put(sparseArray.keyAt(i), sparseArray.valueAt(i)); 
    this.h.put(0, new y(new a(this)));
    this.r = null;
  }
  
  private boolean b(i parami) throws IOException {
    byte[] arrayOfByte = this.e.d();
    if (9400 - this.e.c() < 188) {
      int k = this.e.a();
      if (k > 0)
        System.arraycopy(arrayOfByte, this.e.c(), arrayOfByte, 0, k); 
      this.e.a(arrayOfByte, k);
    } 
    while (this.e.a() < 188) {
      int k = this.e.b();
      int m = parami.a(arrayOfByte, k, 9400 - k);
      if (m == -1)
        return false; 
      this.e.c(k + m);
    } 
    return true;
  }
  
  public int a(i parami, u paramu) throws IOException {
    long l1 = parami.d();
    if (this.o) {
      boolean bool;
      if (l1 != -1L && this.b != 2) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool && !this.k.a())
        return this.k.a(parami, paramu, this.t); 
      a(l1);
      if (this.q) {
        this.q = false;
        a(0L, 0L);
        if (parami.c() != 0L) {
          paramu.a = 0L;
          return 1;
        } 
      } 
      aa aa1 = this.l;
      if (aa1 != null && aa1.b())
        return this.l.a(parami, paramu); 
    } 
    if (!b(parami))
      return -1; 
    int k = a();
    int m = this.e.b();
    if (k > m)
      return 0; 
    int n = this.e.q();
    if ((0x800000 & n) == 0) {
      byte b;
      int i1;
      if ((0x400000 & n) != 0) {
        b = 1;
      } else {
        b = 0;
      } 
      int i2 = b | 0x0;
      int i3 = (0x1FFF00 & n) >> 8;
      if ((n & 0x20) != 0) {
        b = 1;
      } else {
        b = 0;
      } 
      if ((n & 0x10) != 0) {
        i1 = 1;
      } else {
        i1 = 0;
      } 
      if (i1) {
        ad ad1 = (ad)this.h.get(i3);
      } else {
        parami = null;
      } 
      if (parami != null) {
        if (this.b != 2) {
          i1 = n & 0xF;
          n = this.f.get(i3, i1 - 1);
          this.f.put(i3, i1);
          if (n == i1) {
            this.e.d(k);
            return 0;
          } 
          if (i1 != (n + 1 & 0xF))
            parami.a(); 
        } 
        i1 = i2;
        if (b) {
          n = this.e.h();
          if ((this.e.h() & 0x40) != 0) {
            b = 2;
          } else {
            b = 0;
          } 
          i1 = i2 | b;
          this.e.e(n - 1);
        } 
        boolean bool = this.o;
        if (a(i3)) {
          this.e.c(k);
          parami.a(this.e, i1);
          this.e.c(m);
        } 
        if (this.b != 2 && !bool && this.o && l1 != -1L)
          this.q = true; 
      } 
    } 
    this.e.d(k);
    return 0;
  }
  
  public void a(long paramLong1, long paramLong2) {
    boolean bool;
    if (this.b != 2) {
      bool = true;
    } else {
      bool = false;
    } 
    com.applovin.exoplayer2.l.a.b(bool);
    int m = this.d.size();
    int k;
    for (k = 0; k < m; k++) {
      boolean bool1;
      ag ag = this.d.get(k);
      if (ag.c() == -9223372036854775807L) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      boolean bool2 = bool1;
      if (!bool1) {
        paramLong1 = ag.a();
        if (paramLong1 != -9223372036854775807L && paramLong1 != 0L && paramLong1 != paramLong2) {
          bool2 = true;
        } else {
          bool2 = false;
        } 
      } 
      if (bool2)
        ag.a(paramLong2); 
    } 
    if (paramLong2 != 0L) {
      aa aa1 = this.l;
      if (aa1 != null)
        aa1.a(paramLong2); 
    } 
    this.e.a(0);
    this.f.clear();
    int i;
    for (i = 0; i < this.h.size(); i++)
      ((ad)this.h.valueAt(i)).a(); 
    this.s = 0;
  }
  
  public void a(j paramj) {
    this.m = paramj;
  }
  
  public boolean a(i parami) throws IOException {
    byte[] arrayOfByte = this.e.d();
    parami.d(arrayOfByte, 0, 940);
    for (int k = 0; k < 188; k++) {
      int m = 0;
      while (true) {
        if (m < 5) {
          if (arrayOfByte[m * 188 + k] != 71) {
            m = 0;
            break;
          } 
          m++;
          continue;
        } 
        m = 1;
        break;
      } 
      if (m != 0) {
        parami.b(k);
        return true;
      } 
    } 
    return false;
  }
  
  public void c() {}
  
  private class a implements x {
    private final x b = new x(new byte[4]);
    
    public a(ac this$0) {}
    
    public void a(ag param1ag, j param1j, ad.d param1d) {}
    
    public void a(y param1y) {
      if (param1y.h() != 0)
        return; 
      if ((param1y.h() & 0x80) == 0)
        return; 
      param1y.e(6);
      int j = param1y.a() / 4;
      for (int i = 0; i < j; i++) {
        param1y.a(this.b, 4);
        int k = this.b.c(16);
        this.b.b(3);
        if (k == 0) {
          this.b.b(13);
        } else {
          k = this.b.c(13);
          if (ac.a(this.a).get(k) == null) {
            ac.a(this.a).put(k, new y(new ac.b(this.a, k)));
            ac.b(this.a);
          } 
        } 
      } 
      if (ac.c(this.a) != 2)
        ac.a(this.a).remove(0); 
    }
  }
  
  private class b implements x {
    private final x b = new x(new byte[5]);
    
    private final SparseArray<ad> c = new SparseArray();
    
    private final SparseIntArray d = new SparseIntArray();
    
    private final int e;
    
    public b(ac this$0, int param1Int) {
      this.e = param1Int;
    }
    
    private ad.b a(y param1y, int param1Int) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual c : ()I
      //   4: istore_3
      //   5: iload_2
      //   6: iload_3
      //   7: iadd
      //   8: istore #4
      //   10: aconst_null
      //   11: astore #9
      //   13: aconst_null
      //   14: astore #10
      //   16: iconst_m1
      //   17: istore_2
      //   18: aload_1
      //   19: invokevirtual c : ()I
      //   22: iload #4
      //   24: if_icmpge -> 401
      //   27: aload_1
      //   28: invokevirtual h : ()I
      //   31: istore #6
      //   33: aload_1
      //   34: invokevirtual h : ()I
      //   37: istore #5
      //   39: aload_1
      //   40: invokevirtual c : ()I
      //   43: iload #5
      //   45: iadd
      //   46: istore #5
      //   48: iload #5
      //   50: iload #4
      //   52: if_icmple -> 58
      //   55: goto -> 401
      //   58: iload #6
      //   60: iconst_5
      //   61: if_icmpne -> 149
      //   64: aload_1
      //   65: invokevirtual o : ()J
      //   68: lstore #7
      //   70: lload #7
      //   72: ldc2_w 1094921523
      //   75: lcmp
      //   76: ifne -> 82
      //   79: goto -> 156
      //   82: lload #7
      //   84: ldc2_w 1161904947
      //   87: lcmp
      //   88: ifne -> 94
      //   91: goto -> 178
      //   94: lload #7
      //   96: ldc2_w 1094921524
      //   99: lcmp
      //   100: ifne -> 118
      //   103: sipush #172
      //   106: istore_2
      //   107: aload #9
      //   109: astore #11
      //   111: aload #10
      //   113: astore #12
      //   115: goto -> 379
      //   118: aload #9
      //   120: astore #11
      //   122: aload #10
      //   124: astore #12
      //   126: lload #7
      //   128: ldc2_w 1212503619
      //   131: lcmp
      //   132: ifne -> 379
      //   135: bipush #36
      //   137: istore_2
      //   138: aload #9
      //   140: astore #11
      //   142: aload #10
      //   144: astore #12
      //   146: goto -> 379
      //   149: iload #6
      //   151: bipush #106
      //   153: if_icmpne -> 171
      //   156: sipush #129
      //   159: istore_2
      //   160: aload #9
      //   162: astore #11
      //   164: aload #10
      //   166: astore #12
      //   168: goto -> 379
      //   171: iload #6
      //   173: bipush #122
      //   175: if_icmpne -> 193
      //   178: sipush #135
      //   181: istore_2
      //   182: aload #9
      //   184: astore #11
      //   186: aload #10
      //   188: astore #12
      //   190: goto -> 379
      //   193: iload #6
      //   195: bipush #127
      //   197: if_icmpne -> 220
      //   200: aload #9
      //   202: astore #11
      //   204: aload #10
      //   206: astore #12
      //   208: aload_1
      //   209: invokevirtual h : ()I
      //   212: bipush #21
      //   214: if_icmpne -> 379
      //   217: goto -> 103
      //   220: iload #6
      //   222: bipush #123
      //   224: if_icmpne -> 242
      //   227: sipush #138
      //   230: istore_2
      //   231: aload #9
      //   233: astore #11
      //   235: aload #10
      //   237: astore #12
      //   239: goto -> 379
      //   242: iload #6
      //   244: bipush #10
      //   246: if_icmpne -> 266
      //   249: aload_1
      //   250: iconst_3
      //   251: invokevirtual f : (I)Ljava/lang/String;
      //   254: invokevirtual trim : ()Ljava/lang/String;
      //   257: astore #11
      //   259: aload #10
      //   261: astore #12
      //   263: goto -> 379
      //   266: iload #6
      //   268: bipush #89
      //   270: if_icmpne -> 352
      //   273: new java/util/ArrayList
      //   276: dup
      //   277: invokespecial <init> : ()V
      //   280: astore #12
      //   282: aload_1
      //   283: invokevirtual c : ()I
      //   286: iload #5
      //   288: if_icmpge -> 342
      //   291: aload_1
      //   292: iconst_3
      //   293: invokevirtual f : (I)Ljava/lang/String;
      //   296: invokevirtual trim : ()Ljava/lang/String;
      //   299: astore #10
      //   301: aload_1
      //   302: invokevirtual h : ()I
      //   305: istore_2
      //   306: iconst_4
      //   307: newarray byte
      //   309: astore #11
      //   311: aload_1
      //   312: aload #11
      //   314: iconst_0
      //   315: iconst_4
      //   316: invokevirtual a : ([BII)V
      //   319: aload #12
      //   321: new com/applovin/exoplayer2/e/i/ad$a
      //   324: dup
      //   325: aload #10
      //   327: iload_2
      //   328: aload #11
      //   330: invokespecial <init> : (Ljava/lang/String;I[B)V
      //   333: invokeinterface add : (Ljava/lang/Object;)Z
      //   338: pop
      //   339: goto -> 282
      //   342: bipush #89
      //   344: istore_2
      //   345: aload #9
      //   347: astore #11
      //   349: goto -> 379
      //   352: aload #9
      //   354: astore #11
      //   356: aload #10
      //   358: astore #12
      //   360: iload #6
      //   362: bipush #111
      //   364: if_icmpne -> 379
      //   367: sipush #257
      //   370: istore_2
      //   371: aload #10
      //   373: astore #12
      //   375: aload #9
      //   377: astore #11
      //   379: aload_1
      //   380: iload #5
      //   382: aload_1
      //   383: invokevirtual c : ()I
      //   386: isub
      //   387: invokevirtual e : (I)V
      //   390: aload #11
      //   392: astore #9
      //   394: aload #12
      //   396: astore #10
      //   398: goto -> 18
      //   401: aload_1
      //   402: iload #4
      //   404: invokevirtual d : (I)V
      //   407: new com/applovin/exoplayer2/e/i/ad$b
      //   410: dup
      //   411: iload_2
      //   412: aload #9
      //   414: aload #10
      //   416: aload_1
      //   417: invokevirtual d : ()[B
      //   420: iload_3
      //   421: iload #4
      //   423: invokestatic copyOfRange : ([BII)[B
      //   426: invokespecial <init> : (ILjava/lang/String;Ljava/util/List;[B)V
      //   429: areturn
    }
    
    public void a(ag param1ag, j param1j, ad.d param1d) {}
    
    public void a(y param1y) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual h : ()I
      //   4: iconst_2
      //   5: if_icmpeq -> 9
      //   8: return
      //   9: aload_0
      //   10: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   13: invokestatic c : (Lcom/applovin/exoplayer2/e/i/ac;)I
      //   16: iconst_1
      //   17: if_icmpeq -> 91
      //   20: aload_0
      //   21: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   24: invokestatic c : (Lcom/applovin/exoplayer2/e/i/ac;)I
      //   27: iconst_2
      //   28: if_icmpeq -> 91
      //   31: aload_0
      //   32: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   35: invokestatic d : (Lcom/applovin/exoplayer2/e/i/ac;)I
      //   38: iconst_1
      //   39: if_icmpne -> 45
      //   42: goto -> 91
      //   45: new com/applovin/exoplayer2/l/ag
      //   48: dup
      //   49: aload_0
      //   50: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   53: invokestatic e : (Lcom/applovin/exoplayer2/e/i/ac;)Ljava/util/List;
      //   56: iconst_0
      //   57: invokeinterface get : (I)Ljava/lang/Object;
      //   62: checkcast com/applovin/exoplayer2/l/ag
      //   65: invokevirtual a : ()J
      //   68: invokespecial <init> : (J)V
      //   71: astore #8
      //   73: aload_0
      //   74: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   77: invokestatic e : (Lcom/applovin/exoplayer2/e/i/ac;)Ljava/util/List;
      //   80: aload #8
      //   82: invokeinterface add : (Ljava/lang/Object;)Z
      //   87: pop
      //   88: goto -> 109
      //   91: aload_0
      //   92: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   95: invokestatic e : (Lcom/applovin/exoplayer2/e/i/ac;)Ljava/util/List;
      //   98: iconst_0
      //   99: invokeinterface get : (I)Ljava/lang/Object;
      //   104: checkcast com/applovin/exoplayer2/l/ag
      //   107: astore #8
      //   109: aload_1
      //   110: invokevirtual h : ()I
      //   113: sipush #128
      //   116: iand
      //   117: ifne -> 121
      //   120: return
      //   121: aload_1
      //   122: iconst_1
      //   123: invokevirtual e : (I)V
      //   126: aload_1
      //   127: invokevirtual i : ()I
      //   130: istore #6
      //   132: aload_1
      //   133: iconst_3
      //   134: invokevirtual e : (I)V
      //   137: aload_1
      //   138: aload_0
      //   139: getfield b : Lcom/applovin/exoplayer2/l/x;
      //   142: iconst_2
      //   143: invokevirtual a : (Lcom/applovin/exoplayer2/l/x;I)V
      //   146: aload_0
      //   147: getfield b : Lcom/applovin/exoplayer2/l/x;
      //   150: iconst_3
      //   151: invokevirtual b : (I)V
      //   154: aload_0
      //   155: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   158: aload_0
      //   159: getfield b : Lcom/applovin/exoplayer2/l/x;
      //   162: bipush #13
      //   164: invokevirtual c : (I)I
      //   167: invokestatic a : (Lcom/applovin/exoplayer2/e/i/ac;I)I
      //   170: pop
      //   171: aload_1
      //   172: aload_0
      //   173: getfield b : Lcom/applovin/exoplayer2/l/x;
      //   176: iconst_2
      //   177: invokevirtual a : (Lcom/applovin/exoplayer2/l/x;I)V
      //   180: aload_0
      //   181: getfield b : Lcom/applovin/exoplayer2/l/x;
      //   184: iconst_4
      //   185: invokevirtual b : (I)V
      //   188: aload_1
      //   189: aload_0
      //   190: getfield b : Lcom/applovin/exoplayer2/l/x;
      //   193: bipush #12
      //   195: invokevirtual c : (I)I
      //   198: invokevirtual e : (I)V
      //   201: aload_0
      //   202: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   205: invokestatic c : (Lcom/applovin/exoplayer2/e/i/ac;)I
      //   208: iconst_2
      //   209: if_icmpne -> 309
      //   212: aload_0
      //   213: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   216: invokestatic f : (Lcom/applovin/exoplayer2/e/i/ac;)Lcom/applovin/exoplayer2/e/i/ad;
      //   219: ifnonnull -> 309
      //   222: new com/applovin/exoplayer2/e/i/ad$b
      //   225: dup
      //   226: bipush #21
      //   228: aconst_null
      //   229: aconst_null
      //   230: getstatic com/applovin/exoplayer2/l/ai.f : [B
      //   233: invokespecial <init> : (ILjava/lang/String;Ljava/util/List;[B)V
      //   236: astore #9
      //   238: aload_0
      //   239: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   242: astore #10
      //   244: aload #10
      //   246: aload #10
      //   248: invokestatic g : (Lcom/applovin/exoplayer2/e/i/ac;)Lcom/applovin/exoplayer2/e/i/ad$c;
      //   251: bipush #21
      //   253: aload #9
      //   255: invokeinterface a : (ILcom/applovin/exoplayer2/e/i/ad$b;)Lcom/applovin/exoplayer2/e/i/ad;
      //   260: invokestatic a : (Lcom/applovin/exoplayer2/e/i/ac;Lcom/applovin/exoplayer2/e/i/ad;)Lcom/applovin/exoplayer2/e/i/ad;
      //   263: pop
      //   264: aload_0
      //   265: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   268: invokestatic f : (Lcom/applovin/exoplayer2/e/i/ac;)Lcom/applovin/exoplayer2/e/i/ad;
      //   271: ifnull -> 309
      //   274: aload_0
      //   275: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   278: invokestatic f : (Lcom/applovin/exoplayer2/e/i/ac;)Lcom/applovin/exoplayer2/e/i/ad;
      //   281: aload #8
      //   283: aload_0
      //   284: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   287: invokestatic h : (Lcom/applovin/exoplayer2/e/i/ac;)Lcom/applovin/exoplayer2/e/j;
      //   290: new com/applovin/exoplayer2/e/i/ad$d
      //   293: dup
      //   294: iload #6
      //   296: bipush #21
      //   298: sipush #8192
      //   301: invokespecial <init> : (III)V
      //   304: invokeinterface a : (Lcom/applovin/exoplayer2/l/ag;Lcom/applovin/exoplayer2/e/j;Lcom/applovin/exoplayer2/e/i/ad$d;)V
      //   309: aload_0
      //   310: getfield c : Landroid/util/SparseArray;
      //   313: invokevirtual clear : ()V
      //   316: aload_0
      //   317: getfield d : Landroid/util/SparseIntArray;
      //   320: invokevirtual clear : ()V
      //   323: aload_1
      //   324: invokevirtual a : ()I
      //   327: istore_3
      //   328: iload_3
      //   329: ifle -> 564
      //   332: aload_1
      //   333: aload_0
      //   334: getfield b : Lcom/applovin/exoplayer2/l/x;
      //   337: iconst_5
      //   338: invokevirtual a : (Lcom/applovin/exoplayer2/l/x;I)V
      //   341: aload_0
      //   342: getfield b : Lcom/applovin/exoplayer2/l/x;
      //   345: bipush #8
      //   347: invokevirtual c : (I)I
      //   350: istore #5
      //   352: aload_0
      //   353: getfield b : Lcom/applovin/exoplayer2/l/x;
      //   356: iconst_3
      //   357: invokevirtual b : (I)V
      //   360: aload_0
      //   361: getfield b : Lcom/applovin/exoplayer2/l/x;
      //   364: bipush #13
      //   366: invokevirtual c : (I)I
      //   369: istore #4
      //   371: aload_0
      //   372: getfield b : Lcom/applovin/exoplayer2/l/x;
      //   375: iconst_4
      //   376: invokevirtual b : (I)V
      //   379: aload_0
      //   380: getfield b : Lcom/applovin/exoplayer2/l/x;
      //   383: bipush #12
      //   385: invokevirtual c : (I)I
      //   388: istore #7
      //   390: aload_0
      //   391: aload_1
      //   392: iload #7
      //   394: invokespecial a : (Lcom/applovin/exoplayer2/l/y;I)Lcom/applovin/exoplayer2/e/i/ad$b;
      //   397: astore #9
      //   399: iload #5
      //   401: bipush #6
      //   403: if_icmpeq -> 415
      //   406: iload #5
      //   408: istore_2
      //   409: iload #5
      //   411: iconst_5
      //   412: if_icmpne -> 421
      //   415: aload #9
      //   417: getfield a : I
      //   420: istore_2
      //   421: iload_3
      //   422: iload #7
      //   424: iconst_5
      //   425: iadd
      //   426: isub
      //   427: istore #5
      //   429: aload_0
      //   430: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   433: invokestatic c : (Lcom/applovin/exoplayer2/e/i/ac;)I
      //   436: iconst_2
      //   437: if_icmpne -> 445
      //   440: iload_2
      //   441: istore_3
      //   442: goto -> 448
      //   445: iload #4
      //   447: istore_3
      //   448: aload_0
      //   449: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   452: invokestatic i : (Lcom/applovin/exoplayer2/e/i/ac;)Landroid/util/SparseBooleanArray;
      //   455: iload_3
      //   456: invokevirtual get : (I)Z
      //   459: ifeq -> 465
      //   462: goto -> 558
      //   465: aload_0
      //   466: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   469: invokestatic c : (Lcom/applovin/exoplayer2/e/i/ac;)I
      //   472: iconst_2
      //   473: if_icmpne -> 494
      //   476: iload_2
      //   477: bipush #21
      //   479: if_icmpne -> 494
      //   482: aload_0
      //   483: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   486: invokestatic f : (Lcom/applovin/exoplayer2/e/i/ac;)Lcom/applovin/exoplayer2/e/i/ad;
      //   489: astore #9
      //   491: goto -> 511
      //   494: aload_0
      //   495: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   498: invokestatic g : (Lcom/applovin/exoplayer2/e/i/ac;)Lcom/applovin/exoplayer2/e/i/ad$c;
      //   501: iload_2
      //   502: aload #9
      //   504: invokeinterface a : (ILcom/applovin/exoplayer2/e/i/ad$b;)Lcom/applovin/exoplayer2/e/i/ad;
      //   509: astore #9
      //   511: aload_0
      //   512: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   515: invokestatic c : (Lcom/applovin/exoplayer2/e/i/ac;)I
      //   518: iconst_2
      //   519: if_icmpne -> 538
      //   522: iload #4
      //   524: aload_0
      //   525: getfield d : Landroid/util/SparseIntArray;
      //   528: iload_3
      //   529: sipush #8192
      //   532: invokevirtual get : (II)I
      //   535: if_icmpge -> 558
      //   538: aload_0
      //   539: getfield d : Landroid/util/SparseIntArray;
      //   542: iload_3
      //   543: iload #4
      //   545: invokevirtual put : (II)V
      //   548: aload_0
      //   549: getfield c : Landroid/util/SparseArray;
      //   552: iload_3
      //   553: aload #9
      //   555: invokevirtual put : (ILjava/lang/Object;)V
      //   558: iload #5
      //   560: istore_3
      //   561: goto -> 328
      //   564: aload_0
      //   565: getfield d : Landroid/util/SparseIntArray;
      //   568: invokevirtual size : ()I
      //   571: istore_3
      //   572: iconst_0
      //   573: istore_2
      //   574: iload_2
      //   575: iload_3
      //   576: if_icmpge -> 701
      //   579: aload_0
      //   580: getfield d : Landroid/util/SparseIntArray;
      //   583: iload_2
      //   584: invokevirtual keyAt : (I)I
      //   587: istore #4
      //   589: aload_0
      //   590: getfield d : Landroid/util/SparseIntArray;
      //   593: iload_2
      //   594: invokevirtual valueAt : (I)I
      //   597: istore #5
      //   599: aload_0
      //   600: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   603: invokestatic i : (Lcom/applovin/exoplayer2/e/i/ac;)Landroid/util/SparseBooleanArray;
      //   606: iload #4
      //   608: iconst_1
      //   609: invokevirtual put : (IZ)V
      //   612: aload_0
      //   613: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   616: invokestatic j : (Lcom/applovin/exoplayer2/e/i/ac;)Landroid/util/SparseBooleanArray;
      //   619: iload #5
      //   621: iconst_1
      //   622: invokevirtual put : (IZ)V
      //   625: aload_0
      //   626: getfield c : Landroid/util/SparseArray;
      //   629: iload_2
      //   630: invokevirtual valueAt : (I)Ljava/lang/Object;
      //   633: checkcast com/applovin/exoplayer2/e/i/ad
      //   636: astore_1
      //   637: aload_1
      //   638: ifnull -> 694
      //   641: aload_1
      //   642: aload_0
      //   643: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   646: invokestatic f : (Lcom/applovin/exoplayer2/e/i/ac;)Lcom/applovin/exoplayer2/e/i/ad;
      //   649: if_acmpeq -> 681
      //   652: aload_1
      //   653: aload #8
      //   655: aload_0
      //   656: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   659: invokestatic h : (Lcom/applovin/exoplayer2/e/i/ac;)Lcom/applovin/exoplayer2/e/j;
      //   662: new com/applovin/exoplayer2/e/i/ad$d
      //   665: dup
      //   666: iload #6
      //   668: iload #4
      //   670: sipush #8192
      //   673: invokespecial <init> : (III)V
      //   676: invokeinterface a : (Lcom/applovin/exoplayer2/l/ag;Lcom/applovin/exoplayer2/e/j;Lcom/applovin/exoplayer2/e/i/ad$d;)V
      //   681: aload_0
      //   682: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   685: invokestatic a : (Lcom/applovin/exoplayer2/e/i/ac;)Landroid/util/SparseArray;
      //   688: iload #5
      //   690: aload_1
      //   691: invokevirtual put : (ILjava/lang/Object;)V
      //   694: iload_2
      //   695: iconst_1
      //   696: iadd
      //   697: istore_2
      //   698: goto -> 574
      //   701: aload_0
      //   702: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   705: invokestatic c : (Lcom/applovin/exoplayer2/e/i/ac;)I
      //   708: iconst_2
      //   709: if_icmpne -> 753
      //   712: aload_0
      //   713: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   716: invokestatic k : (Lcom/applovin/exoplayer2/e/i/ac;)Z
      //   719: ifne -> 826
      //   722: aload_0
      //   723: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   726: invokestatic h : (Lcom/applovin/exoplayer2/e/i/ac;)Lcom/applovin/exoplayer2/e/j;
      //   729: invokeinterface a : ()V
      //   734: aload_0
      //   735: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   738: iconst_0
      //   739: invokestatic b : (Lcom/applovin/exoplayer2/e/i/ac;I)I
      //   742: pop
      //   743: aload_0
      //   744: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   747: iconst_1
      //   748: invokestatic a : (Lcom/applovin/exoplayer2/e/i/ac;Z)Z
      //   751: pop
      //   752: return
      //   753: aload_0
      //   754: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   757: invokestatic a : (Lcom/applovin/exoplayer2/e/i/ac;)Landroid/util/SparseArray;
      //   760: aload_0
      //   761: getfield e : I
      //   764: invokevirtual remove : (I)V
      //   767: aload_0
      //   768: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   771: astore_1
      //   772: aload_1
      //   773: invokestatic c : (Lcom/applovin/exoplayer2/e/i/ac;)I
      //   776: iconst_1
      //   777: if_icmpne -> 785
      //   780: iconst_0
      //   781: istore_2
      //   782: goto -> 795
      //   785: aload_0
      //   786: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   789: invokestatic d : (Lcom/applovin/exoplayer2/e/i/ac;)I
      //   792: iconst_1
      //   793: isub
      //   794: istore_2
      //   795: aload_1
      //   796: iload_2
      //   797: invokestatic b : (Lcom/applovin/exoplayer2/e/i/ac;I)I
      //   800: pop
      //   801: aload_0
      //   802: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   805: invokestatic d : (Lcom/applovin/exoplayer2/e/i/ac;)I
      //   808: ifne -> 826
      //   811: aload_0
      //   812: getfield a : Lcom/applovin/exoplayer2/e/i/ac;
      //   815: invokestatic h : (Lcom/applovin/exoplayer2/e/i/ac;)Lcom/applovin/exoplayer2/e/j;
      //   818: invokeinterface a : ()V
      //   823: goto -> 743
      //   826: return
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\e\i\ac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */