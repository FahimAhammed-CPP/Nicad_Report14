package com.applovin.exoplayer2.e.g;

import android.util.Pair;
import com.applovin.exoplayer2.ai;
import com.applovin.exoplayer2.b.c;
import com.applovin.exoplayer2.common.base.Function;
import com.applovin.exoplayer2.e.h;
import com.applovin.exoplayer2.e.i;
import com.applovin.exoplayer2.e.j;
import com.applovin.exoplayer2.e.l;
import com.applovin.exoplayer2.e.r;
import com.applovin.exoplayer2.e.u;
import com.applovin.exoplayer2.e.v;
import com.applovin.exoplayer2.e.x;
import com.applovin.exoplayer2.g.f.b;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.v;
import com.applovin.exoplayer2.l.y;
import com.applovin.exoplayer2.v;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

public final class g implements h, v {
  public static final l a = (l)g$.ExternalSyntheticLambda1.INSTANCE;
  
  private final int b;
  
  private final y c;
  
  private final y d;
  
  private final y e;
  
  private final y f;
  
  private final ArrayDeque<a.a> g;
  
  private final i h;
  
  private final List<com.applovin.exoplayer2.g.a.a> i;
  
  private int j;
  
  private int k;
  
  private long l;
  
  private int m;
  
  private y n;
  
  private int o;
  
  private int p;
  
  private int q;
  
  private int r;
  
  private j s;
  
  private a[] t;
  
  private long[][] u;
  
  private int v;
  
  private long w;
  
  private int x;
  
  private b y;
  
  public g() {
    this(0);
  }
  
  public g(int paramInt) {
    this.b = paramInt;
    if ((paramInt & 0x4) != 0) {
      paramInt = 3;
    } else {
      paramInt = 0;
    } 
    this.j = paramInt;
    this.h = new i();
    this.i = new ArrayList<com.applovin.exoplayer2.g.a.a>();
    this.f = new y(16);
    this.g = new ArrayDeque<a.a>();
    this.c = new y(v.a);
    this.d = new y(4);
    this.e = new y();
    this.o = -1;
  }
  
  private static int a(int paramInt) {
    return (paramInt != 1751476579) ? ((paramInt != 1903435808) ? 0 : 1) : 2;
  }
  
  private static int a(n paramn, long paramLong) {
    int m = paramn.a(paramLong);
    int k = m;
    if (m == -1)
      k = paramn.b(paramLong); 
    return k;
  }
  
  private static int a(y paramy) {
    paramy.d(8);
    int k = a(paramy.q());
    if (k != 0)
      return k; 
    paramy.e(4);
    while (paramy.a() > 0) {
      k = a(paramy.q());
      if (k != 0)
        return k; 
    } 
    return 0;
  }
  
  private static long a(n paramn, long paramLong1, long paramLong2) {
    int k = a(paramn, paramLong1);
    return (k == -1) ? paramLong2 : Math.min(paramn.c[k], paramLong2);
  }
  
  private void a(a.a parama) throws ai {
    boolean bool1;
    boolean bool2;
    com.applovin.exoplayer2.g.a a1;
    ArrayList<a> arrayList2 = new ArrayList();
    if (this.x == 1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    r r = new r();
    a.b b1 = parama.d(1969517665);
    if (b1 != null) {
      Pair pair = b.a(b1);
      a1 = (com.applovin.exoplayer2.g.a)pair.first;
      com.applovin.exoplayer2.g.a a3 = (com.applovin.exoplayer2.g.a)pair.second;
      if (a1 != null)
        r.a(a1); 
    } else {
      b1 = null;
      a1 = null;
    } 
    a.a a2 = parama.e(1835365473);
    if (a2 != null) {
      com.applovin.exoplayer2.g.a a3 = b.a(a2);
    } else {
      a2 = null;
    } 
    if ((this.b & 0x1) != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    List<n> list2 = b.a(parama, r, -9223372036854775807L, null, bool2, bool1, (Function)g$.ExternalSyntheticLambda0.INSTANCE);
    j j1 = (j)com.applovin.exoplayer2.l.a.b(this.s);
    int m = list2.size();
    int n = 0;
    int k = -1;
    long l1 = -9223372036854775807L;
    ArrayList<a> arrayList1 = arrayList2;
    List<n> list1 = list2;
    while (n < m) {
      n n1 = list1.get(n);
      if (n1.b != 0) {
        long l2;
        com.applovin.exoplayer2.g.a a3;
        k k1 = n1.a;
        ArrayList<a> arrayList = arrayList1;
        if (k1.e != -9223372036854775807L) {
          l2 = k1.e;
        } else {
          l2 = n1.h;
        } 
        l1 = Math.max(l1, l2);
        a a4 = new a(k1, n1, j1.a(n, k1.b));
        int i1 = n1.e;
        v.a a5 = k1.f.a();
        a5.f(i1 + 30);
        if (k1.b == 2 && l2 > 0L && n1.b > 1)
          a5.a(n1.b / (float)l2 / 1000000.0F); 
        f.a(k1.b, r, a5);
        i1 = k1.b;
        if (this.i.isEmpty()) {
          n1 = null;
        } else {
          a3 = new com.applovin.exoplayer2.g.a(this.i);
        } 
        f.a(i1, a1, (com.applovin.exoplayer2.g.a)a2, a5, new com.applovin.exoplayer2.g.a[] { (com.applovin.exoplayer2.g.a)b1, a3 });
        a4.c.a(a5.a());
        if (k1.b == 2 && k == -1)
          k = arrayList.size(); 
        arrayList.add(a4);
      } 
      n++;
    } 
    this.v = k;
    this.w = l1;
    a[] arrayOfA = arrayList1.<a>toArray(new a[0]);
    this.t = arrayOfA;
    this.u = a(arrayOfA);
    j1.a();
    j1.a(this);
  }
  
  private static long[][] a(a[] paramArrayOfa) {
    long[][] arrayOfLong = new long[paramArrayOfa.length][];
    int[] arrayOfInt = new int[paramArrayOfa.length];
    long[] arrayOfLong1 = new long[paramArrayOfa.length];
    boolean[] arrayOfBoolean = new boolean[paramArrayOfa.length];
    int k;
    for (k = 0; k < paramArrayOfa.length; k++) {
      arrayOfLong[k] = new long[(paramArrayOfa[k]).b.b];
      arrayOfLong1[k] = (paramArrayOfa[k]).b.f[0];
    } 
    long l1 = 0L;
    for (int m = 0; m < paramArrayOfa.length; m++) {
      long l2 = Long.MAX_VALUE;
      int n = -1;
      k = 0;
      while (k < paramArrayOfa.length) {
        long l3 = l2;
        int i1 = n;
        if (!arrayOfBoolean[k]) {
          l3 = l2;
          i1 = n;
          if (arrayOfLong1[k] <= l2) {
            l3 = arrayOfLong1[k];
            i1 = k;
          } 
        } 
        k++;
        l2 = l3;
        n = i1;
      } 
      k = arrayOfInt[n];
      arrayOfLong[n][k] = l1;
      l1 += (paramArrayOfa[n]).b.d[k];
      arrayOfInt[n] = ++k;
      if (k < (arrayOfLong[n]).length) {
        arrayOfLong1[n] = (paramArrayOfa[n]).b.f[k];
        continue;
      } 
      arrayOfBoolean[n] = true;
    } 
    return arrayOfLong;
  }
  
  private void b(long paramLong) throws ai {
    while (!this.g.isEmpty() && ((a.a)this.g.peek()).b == paramLong) {
      a.a a1 = this.g.pop();
      if (a1.a == 1836019574) {
        a(a1);
        this.g.clear();
        this.j = 2;
        continue;
      } 
      if (!this.g.isEmpty())
        ((a.a)this.g.peek()).a(a1); 
    } 
    if (this.j != 2)
      d(); 
  }
  
  private static boolean b(int paramInt) {
    return (paramInt == 1835296868 || paramInt == 1836476516 || paramInt == 1751411826 || paramInt == 1937011556 || paramInt == 1937011827 || paramInt == 1937011571 || paramInt == 1668576371 || paramInt == 1701606260 || paramInt == 1937011555 || paramInt == 1937011578 || paramInt == 1937013298 || paramInt == 1937007471 || paramInt == 1668232756 || paramInt == 1953196132 || paramInt == 1718909296 || paramInt == 1969517665 || paramInt == 1801812339 || paramInt == 1768715124);
  }
  
  private boolean b(i parami) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: getfield m : I
    //   4: ifne -> 69
    //   7: aload_1
    //   8: aload_0
    //   9: getfield f : Lcom/applovin/exoplayer2/l/y;
    //   12: invokevirtual d : ()[B
    //   15: iconst_0
    //   16: bipush #8
    //   18: iconst_1
    //   19: invokeinterface a : ([BIIZ)Z
    //   24: ifne -> 33
    //   27: aload_0
    //   28: invokespecial e : ()V
    //   31: iconst_0
    //   32: ireturn
    //   33: aload_0
    //   34: bipush #8
    //   36: putfield m : I
    //   39: aload_0
    //   40: getfield f : Lcom/applovin/exoplayer2/l/y;
    //   43: iconst_0
    //   44: invokevirtual d : (I)V
    //   47: aload_0
    //   48: aload_0
    //   49: getfield f : Lcom/applovin/exoplayer2/l/y;
    //   52: invokevirtual o : ()J
    //   55: putfield l : J
    //   58: aload_0
    //   59: aload_0
    //   60: getfield f : Lcom/applovin/exoplayer2/l/y;
    //   63: invokevirtual q : ()I
    //   66: putfield k : I
    //   69: aload_0
    //   70: getfield l : J
    //   73: lstore_3
    //   74: lload_3
    //   75: lconst_1
    //   76: lcmp
    //   77: ifne -> 124
    //   80: aload_1
    //   81: aload_0
    //   82: getfield f : Lcom/applovin/exoplayer2/l/y;
    //   85: invokevirtual d : ()[B
    //   88: bipush #8
    //   90: bipush #8
    //   92: invokeinterface b : ([BII)V
    //   97: aload_0
    //   98: aload_0
    //   99: getfield m : I
    //   102: bipush #8
    //   104: iadd
    //   105: putfield m : I
    //   108: aload_0
    //   109: getfield f : Lcom/applovin/exoplayer2/l/y;
    //   112: invokevirtual y : ()J
    //   115: lstore_3
    //   116: aload_0
    //   117: lload_3
    //   118: putfield l : J
    //   121: goto -> 202
    //   124: lload_3
    //   125: lconst_0
    //   126: lcmp
    //   127: ifne -> 202
    //   130: aload_1
    //   131: invokeinterface d : ()J
    //   136: lstore #5
    //   138: lload #5
    //   140: lstore_3
    //   141: lload #5
    //   143: ldc2_w -1
    //   146: lcmp
    //   147: ifne -> 176
    //   150: aload_0
    //   151: getfield g : Ljava/util/ArrayDeque;
    //   154: invokevirtual peek : ()Ljava/lang/Object;
    //   157: checkcast com/applovin/exoplayer2/e/g/a$a
    //   160: astore #8
    //   162: lload #5
    //   164: lstore_3
    //   165: aload #8
    //   167: ifnull -> 176
    //   170: aload #8
    //   172: getfield b : J
    //   175: lstore_3
    //   176: lload_3
    //   177: ldc2_w -1
    //   180: lcmp
    //   181: ifeq -> 202
    //   184: lload_3
    //   185: aload_1
    //   186: invokeinterface c : ()J
    //   191: lsub
    //   192: aload_0
    //   193: getfield m : I
    //   196: i2l
    //   197: ladd
    //   198: lstore_3
    //   199: goto -> 116
    //   202: aload_0
    //   203: getfield l : J
    //   206: aload_0
    //   207: getfield m : I
    //   210: i2l
    //   211: lcmp
    //   212: iflt -> 442
    //   215: aload_0
    //   216: getfield k : I
    //   219: invokestatic c : (I)Z
    //   222: ifeq -> 320
    //   225: aload_1
    //   226: invokeinterface c : ()J
    //   231: lstore #5
    //   233: aload_0
    //   234: getfield l : J
    //   237: lstore_3
    //   238: aload_0
    //   239: getfield m : I
    //   242: istore_2
    //   243: lload #5
    //   245: lload_3
    //   246: ladd
    //   247: iload_2
    //   248: i2l
    //   249: lsub
    //   250: lstore #5
    //   252: lload_3
    //   253: iload_2
    //   254: i2l
    //   255: lcmp
    //   256: ifeq -> 273
    //   259: aload_0
    //   260: getfield k : I
    //   263: ldc 1835365473
    //   265: if_icmpne -> 273
    //   268: aload_0
    //   269: aload_1
    //   270: invokespecial c : (Lcom/applovin/exoplayer2/e/i;)V
    //   273: aload_0
    //   274: getfield g : Ljava/util/ArrayDeque;
    //   277: new com/applovin/exoplayer2/e/g/a$a
    //   280: dup
    //   281: aload_0
    //   282: getfield k : I
    //   285: lload #5
    //   287: invokespecial <init> : (IJ)V
    //   290: invokevirtual push : (Ljava/lang/Object;)V
    //   293: aload_0
    //   294: getfield l : J
    //   297: aload_0
    //   298: getfield m : I
    //   301: i2l
    //   302: lcmp
    //   303: ifne -> 314
    //   306: aload_0
    //   307: lload #5
    //   309: invokespecial b : (J)V
    //   312: iconst_1
    //   313: ireturn
    //   314: aload_0
    //   315: invokespecial d : ()V
    //   318: iconst_1
    //   319: ireturn
    //   320: aload_0
    //   321: getfield k : I
    //   324: invokestatic b : (I)Z
    //   327: ifeq -> 412
    //   330: aload_0
    //   331: getfield m : I
    //   334: bipush #8
    //   336: if_icmpne -> 345
    //   339: iconst_1
    //   340: istore #7
    //   342: goto -> 348
    //   345: iconst_0
    //   346: istore #7
    //   348: iload #7
    //   350: invokestatic b : (Z)V
    //   353: aload_0
    //   354: getfield l : J
    //   357: ldc2_w 2147483647
    //   360: lcmp
    //   361: ifgt -> 370
    //   364: iconst_1
    //   365: istore #7
    //   367: goto -> 373
    //   370: iconst_0
    //   371: istore #7
    //   373: iload #7
    //   375: invokestatic b : (Z)V
    //   378: new com/applovin/exoplayer2/l/y
    //   381: dup
    //   382: aload_0
    //   383: getfield l : J
    //   386: l2i
    //   387: invokespecial <init> : (I)V
    //   390: astore_1
    //   391: aload_0
    //   392: getfield f : Lcom/applovin/exoplayer2/l/y;
    //   395: invokevirtual d : ()[B
    //   398: iconst_0
    //   399: aload_1
    //   400: invokevirtual d : ()[B
    //   403: iconst_0
    //   404: bipush #8
    //   406: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   409: goto -> 430
    //   412: aload_0
    //   413: aload_1
    //   414: invokeinterface c : ()J
    //   419: aload_0
    //   420: getfield m : I
    //   423: i2l
    //   424: lsub
    //   425: invokespecial e : (J)V
    //   428: aconst_null
    //   429: astore_1
    //   430: aload_0
    //   431: aload_1
    //   432: putfield n : Lcom/applovin/exoplayer2/l/y;
    //   435: aload_0
    //   436: iconst_1
    //   437: putfield j : I
    //   440: iconst_1
    //   441: ireturn
    //   442: ldc_w 'Atom size less than header length (unsupported).'
    //   445: invokestatic a : (Ljava/lang/String;)Lcom/applovin/exoplayer2/ai;
    //   448: astore_1
    //   449: goto -> 454
    //   452: aload_1
    //   453: athrow
    //   454: goto -> 452
  }
  
  private boolean b(i parami, u paramu) throws IOException {
    long l1 = this.l - this.m;
    long l2 = parami.c();
    y y1 = this.n;
    if (y1 != null) {
      parami.b(y1.d(), this.m, (int)l1);
      if (this.k == 1718909296) {
        this.x = a(y1);
      } else if (!this.g.isEmpty()) {
        ((a.a)this.g.peek()).a(new a.b(this.k, y1));
      } 
    } else if (l1 < 262144L) {
      parami.b((int)l1);
    } else {
      paramu.a = parami.c() + l1;
      boolean bool1 = true;
      b(l2 + l1);
    } 
    boolean bool = false;
    b(l2 + l1);
  }
  
  private int c(long paramLong) {
    // Byte code:
    //   0: iconst_m1
    //   1: istore #7
    //   3: iconst_m1
    //   4: istore #4
    //   6: iconst_0
    //   7: istore_3
    //   8: ldc2_w 9223372036854775807
    //   11: lstore #19
    //   13: iconst_1
    //   14: istore #10
    //   16: ldc2_w 9223372036854775807
    //   19: lstore #15
    //   21: iconst_1
    //   22: istore #6
    //   24: ldc2_w 9223372036854775807
    //   27: lstore #11
    //   29: iload_3
    //   30: aload_0
    //   31: getfield t : [Lcom/applovin/exoplayer2/e/g/g$a;
    //   34: invokestatic a : (Ljava/lang/Object;)Ljava/lang/Object;
    //   37: checkcast [Lcom/applovin/exoplayer2/e/g/g$a;
    //   40: arraylength
    //   41: if_icmpge -> 281
    //   44: aload_0
    //   45: getfield t : [Lcom/applovin/exoplayer2/e/g/g$a;
    //   48: iload_3
    //   49: aaload
    //   50: astore #25
    //   52: aload #25
    //   54: getfield d : I
    //   57: istore #5
    //   59: iload #5
    //   61: aload #25
    //   63: getfield b : Lcom/applovin/exoplayer2/e/g/n;
    //   66: getfield b : I
    //   69: if_icmpne -> 79
    //   72: lload #19
    //   74: lstore #23
    //   76: goto -> 270
    //   79: aload #25
    //   81: getfield b : Lcom/applovin/exoplayer2/e/g/n;
    //   84: getfield c : [J
    //   87: iload #5
    //   89: laload
    //   90: lstore #13
    //   92: aload_0
    //   93: getfield u : [[J
    //   96: invokestatic a : (Ljava/lang/Object;)Ljava/lang/Object;
    //   99: checkcast [[J
    //   102: iload_3
    //   103: aaload
    //   104: iload #5
    //   106: laload
    //   107: lstore #21
    //   109: lload #13
    //   111: lload_1
    //   112: lsub
    //   113: lstore #23
    //   115: lload #23
    //   117: lconst_0
    //   118: lcmp
    //   119: iflt -> 140
    //   122: lload #23
    //   124: ldc2_w 262144
    //   127: lcmp
    //   128: iflt -> 134
    //   131: goto -> 140
    //   134: iconst_0
    //   135: istore #5
    //   137: goto -> 143
    //   140: iconst_1
    //   141: istore #5
    //   143: iload #5
    //   145: ifne -> 153
    //   148: iload #6
    //   150: ifne -> 200
    //   153: iload #4
    //   155: istore #9
    //   157: lload #15
    //   159: lstore #17
    //   161: iload #6
    //   163: istore #8
    //   165: lload #11
    //   167: lstore #13
    //   169: iload #5
    //   171: iload #6
    //   173: if_icmpne -> 215
    //   176: iload #4
    //   178: istore #9
    //   180: lload #15
    //   182: lstore #17
    //   184: iload #6
    //   186: istore #8
    //   188: lload #11
    //   190: lstore #13
    //   192: lload #23
    //   194: lload #11
    //   196: lcmp
    //   197: ifge -> 215
    //   200: iload #5
    //   202: istore #8
    //   204: lload #23
    //   206: lstore #13
    //   208: iload_3
    //   209: istore #9
    //   211: lload #21
    //   213: lstore #17
    //   215: iload #9
    //   217: istore #4
    //   219: lload #19
    //   221: lstore #23
    //   223: lload #17
    //   225: lstore #15
    //   227: iload #8
    //   229: istore #6
    //   231: lload #13
    //   233: lstore #11
    //   235: lload #21
    //   237: lload #19
    //   239: lcmp
    //   240: ifge -> 270
    //   243: iload_3
    //   244: istore #7
    //   246: lload #13
    //   248: lstore #11
    //   250: iload #8
    //   252: istore #6
    //   254: lload #17
    //   256: lstore #15
    //   258: iload #5
    //   260: istore #10
    //   262: lload #21
    //   264: lstore #23
    //   266: iload #9
    //   268: istore #4
    //   270: iload_3
    //   271: iconst_1
    //   272: iadd
    //   273: istore_3
    //   274: lload #23
    //   276: lstore #19
    //   278: goto -> 29
    //   281: lload #19
    //   283: ldc2_w 9223372036854775807
    //   286: lcmp
    //   287: ifeq -> 307
    //   290: iload #10
    //   292: ifeq -> 307
    //   295: lload #15
    //   297: lload #19
    //   299: ldc2_w 10485760
    //   302: ladd
    //   303: lcmp
    //   304: ifge -> 311
    //   307: iload #4
    //   309: istore #7
    //   311: iload #7
    //   313: ireturn
  }
  
  private int c(i parami, u paramu) throws IOException {
    int k = this.h.a(parami, paramu, this.i);
    if (k == 1 && paramu.a == 0L)
      d(); 
    return k;
  }
  
  private void c(i parami) throws IOException {
    this.e.a(8);
    parami.d(this.e.d(), 0, 8);
    b.a(this.e);
    parami.b(this.e.c());
    parami.a();
  }
  
  private static boolean c(int paramInt) {
    return (paramInt == 1836019574 || paramInt == 1953653099 || paramInt == 1835297121 || paramInt == 1835626086 || paramInt == 1937007212 || paramInt == 1701082227 || paramInt == 1835365473);
  }
  
  private int d(i parami, u paramu) throws IOException {
    int n;
    long l2 = parami.c();
    if (this.o == -1) {
      int i2 = c(l2);
      this.o = i2;
      if (i2 == -1)
        return -1; 
    } 
    a a1 = ((a[])ai.a(this.t))[this.o];
    x x = a1.c;
    int i1 = a1.d;
    long l1 = a1.b.c[i1];
    int m = a1.b.d[i1];
    l2 = l1 - l2 + this.p;
    if (l2 < 0L || l2 >= 262144L) {
      paramu.a = l1;
      return 1;
    } 
    l1 = l2;
    int k = m;
    if (a1.a.g == 1) {
      l1 = l2 + 8L;
      k = m - 8;
    } 
    parami.b((int)l1);
    if (a1.a.j != 0) {
      byte[] arrayOfByte = this.d.d();
      arrayOfByte[0] = 0;
      arrayOfByte[1] = 0;
      arrayOfByte[2] = 0;
      m = a1.a.j;
      int i2 = 4 - a1.a.j;
      while (true) {
        n = k;
        if (this.q < k) {
          n = this.r;
          if (n == 0) {
            parami.b(arrayOfByte, i2, m);
            this.p += m;
            this.d.d(0);
            n = this.d.q();
            if (n >= 0) {
              this.r = n;
              this.c.d(0);
              x.a(this.c, 4);
              this.q += 4;
              k += i2;
              continue;
            } 
            throw ai.b("Invalid NAL length", null);
          } 
          n = x.a((com.applovin.exoplayer2.k.g)parami, n, false);
          this.p += n;
          this.q += n;
          this.r -= n;
          continue;
        } 
        break;
      } 
    } else {
      m = k;
      if ("audio/ac4".equals(a1.a.f.l)) {
        if (this.q == 0) {
          c.a(k, this.e);
          x.a(this.e, 7);
          this.q += 7;
        } 
        m = k + 7;
      } 
      while (true) {
        k = this.q;
        n = m;
        if (k < m) {
          k = x.a((com.applovin.exoplayer2.k.g)parami, m - k, false);
          this.p += k;
          this.q += k;
          this.r -= k;
          continue;
        } 
        break;
      } 
    } 
    x.a(a1.b.f[i1], a1.b.g[i1], n, 0, null);
    a1.d++;
    this.o = -1;
    this.p = 0;
    this.q = 0;
    this.r = 0;
    return 0;
  }
  
  private void d() {
    this.j = 0;
    this.m = 0;
  }
  
  private void d(long paramLong) {
    for (a a1 : this.t) {
      n n = a1.b;
      int m = n.a(paramLong);
      int k = m;
      if (m == -1)
        k = n.b(paramLong); 
      a1.d = k;
    } 
  }
  
  private void e() {
    if (this.x == 2 && (this.b & 0x2) != 0) {
      com.applovin.exoplayer2.g.a a1;
      j j1 = (j)com.applovin.exoplayer2.l.a.b(this.s);
      x x = j1.a(0, 4);
      if (this.y == null) {
        a1 = null;
      } else {
        a1 = new com.applovin.exoplayer2.g.a(new com.applovin.exoplayer2.g.a.a[] { (com.applovin.exoplayer2.g.a.a)this.y });
      } 
      x.a((new v.a()).a(a1).a());
      j1.a();
      j1.a((v)new v.b(-9223372036854775807L));
    } 
  }
  
  private void e(long paramLong) {
    if (this.k == 1836086884) {
      int k = this.m;
      this.y = new b(0L, paramLong, -9223372036854775807L, paramLong + k, this.l - k);
    } 
  }
  
  public int a(i parami, u paramu) throws IOException {
    while (true) {
      int k = this.j;
      if (k != 0) {
        if (k != 1) {
          if (k != 2) {
            if (k == 3)
              return c(parami, paramu); 
            throw new IllegalStateException();
          } 
          return d(parami, paramu);
        } 
        if (b(parami, paramu))
          return 1; 
        continue;
      } 
      if (!b(parami))
        return -1; 
    } 
  }
  
  public v.a a(long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: getfield t : [Lcom/applovin/exoplayer2/e/g/g$a;
    //   4: invokestatic b : (Ljava/lang/Object;)Ljava/lang/Object;
    //   7: checkcast [Lcom/applovin/exoplayer2/e/g/g$a;
    //   10: arraylength
    //   11: ifne -> 25
    //   14: new com/applovin/exoplayer2/e/v$a
    //   17: dup
    //   18: getstatic com/applovin/exoplayer2/e/w.a : Lcom/applovin/exoplayer2/e/w;
    //   21: invokespecial <init> : (Lcom/applovin/exoplayer2/e/w;)V
    //   24: areturn
    //   25: aload_0
    //   26: getfield v : I
    //   29: istore_3
    //   30: iload_3
    //   31: iconst_m1
    //   32: if_icmpeq -> 169
    //   35: aload_0
    //   36: getfield t : [Lcom/applovin/exoplayer2/e/g/g$a;
    //   39: iload_3
    //   40: aaload
    //   41: getfield b : Lcom/applovin/exoplayer2/e/g/n;
    //   44: astore #15
    //   46: aload #15
    //   48: lload_1
    //   49: invokestatic a : (Lcom/applovin/exoplayer2/e/g/n;J)I
    //   52: istore_3
    //   53: iload_3
    //   54: iconst_m1
    //   55: if_icmpne -> 69
    //   58: new com/applovin/exoplayer2/e/v$a
    //   61: dup
    //   62: getstatic com/applovin/exoplayer2/e/w.a : Lcom/applovin/exoplayer2/e/w;
    //   65: invokespecial <init> : (Lcom/applovin/exoplayer2/e/w;)V
    //   68: areturn
    //   69: aload #15
    //   71: getfield f : [J
    //   74: iload_3
    //   75: laload
    //   76: lstore #9
    //   78: aload #15
    //   80: getfield c : [J
    //   83: iload_3
    //   84: laload
    //   85: lstore #11
    //   87: lload #9
    //   89: lload_1
    //   90: lcmp
    //   91: ifge -> 147
    //   94: iload_3
    //   95: aload #15
    //   97: getfield b : I
    //   100: iconst_1
    //   101: isub
    //   102: if_icmpge -> 147
    //   105: aload #15
    //   107: lload_1
    //   108: invokevirtual b : (J)I
    //   111: istore #4
    //   113: iload #4
    //   115: iconst_m1
    //   116: if_icmpeq -> 147
    //   119: iload #4
    //   121: iload_3
    //   122: if_icmpeq -> 147
    //   125: aload #15
    //   127: getfield f : [J
    //   130: iload #4
    //   132: laload
    //   133: lstore_1
    //   134: aload #15
    //   136: getfield c : [J
    //   139: iload #4
    //   141: laload
    //   142: lstore #5
    //   144: goto -> 156
    //   147: ldc2_w -1
    //   150: lstore #5
    //   152: ldc2_w -9223372036854775807
    //   155: lstore_1
    //   156: lload_1
    //   157: lstore #7
    //   159: lload #5
    //   161: lstore_1
    //   162: lload #11
    //   164: lstore #5
    //   166: goto -> 190
    //   169: ldc2_w 9223372036854775807
    //   172: lstore #5
    //   174: ldc2_w -1
    //   177: lstore #11
    //   179: ldc2_w -9223372036854775807
    //   182: lstore #7
    //   184: lload_1
    //   185: lstore #9
    //   187: lload #11
    //   189: lstore_1
    //   190: iconst_0
    //   191: istore_3
    //   192: aload_0
    //   193: getfield t : [Lcom/applovin/exoplayer2/e/g/g$a;
    //   196: astore #15
    //   198: iload_3
    //   199: aload #15
    //   201: arraylength
    //   202: if_icmpge -> 280
    //   205: lload_1
    //   206: lstore #13
    //   208: lload #5
    //   210: lstore #11
    //   212: iload_3
    //   213: aload_0
    //   214: getfield v : I
    //   217: if_icmpeq -> 266
    //   220: aload #15
    //   222: iload_3
    //   223: aaload
    //   224: getfield b : Lcom/applovin/exoplayer2/e/g/n;
    //   227: astore #15
    //   229: aload #15
    //   231: lload #9
    //   233: lload #5
    //   235: invokestatic a : (Lcom/applovin/exoplayer2/e/g/n;JJ)J
    //   238: lstore #11
    //   240: lload_1
    //   241: lstore #5
    //   243: lload #7
    //   245: ldc2_w -9223372036854775807
    //   248: lcmp
    //   249: ifeq -> 262
    //   252: aload #15
    //   254: lload #7
    //   256: lload_1
    //   257: invokestatic a : (Lcom/applovin/exoplayer2/e/g/n;JJ)J
    //   260: lstore #5
    //   262: lload #5
    //   264: lstore #13
    //   266: iload_3
    //   267: iconst_1
    //   268: iadd
    //   269: istore_3
    //   270: lload #13
    //   272: lstore_1
    //   273: lload #11
    //   275: lstore #5
    //   277: goto -> 192
    //   280: new com/applovin/exoplayer2/e/w
    //   283: dup
    //   284: lload #9
    //   286: lload #5
    //   288: invokespecial <init> : (JJ)V
    //   291: astore #15
    //   293: lload #7
    //   295: ldc2_w -9223372036854775807
    //   298: lcmp
    //   299: ifne -> 312
    //   302: new com/applovin/exoplayer2/e/v$a
    //   305: dup
    //   306: aload #15
    //   308: invokespecial <init> : (Lcom/applovin/exoplayer2/e/w;)V
    //   311: areturn
    //   312: new com/applovin/exoplayer2/e/v$a
    //   315: dup
    //   316: aload #15
    //   318: new com/applovin/exoplayer2/e/w
    //   321: dup
    //   322: lload #7
    //   324: lload_1
    //   325: invokespecial <init> : (JJ)V
    //   328: invokespecial <init> : (Lcom/applovin/exoplayer2/e/w;Lcom/applovin/exoplayer2/e/w;)V
    //   331: areturn
  }
  
  public void a(long paramLong1, long paramLong2) {
    this.g.clear();
    this.m = 0;
    this.o = -1;
    this.p = 0;
    this.q = 0;
    this.r = 0;
    if (paramLong1 == 0L) {
      if (this.j != 3) {
        d();
        return;
      } 
      this.h.a();
      this.i.clear();
      return;
    } 
    if (this.t != null)
      d(paramLong2); 
  }
  
  public void a(j paramj) {
    this.s = paramj;
  }
  
  public boolean a() {
    return true;
  }
  
  public boolean a(i parami) throws IOException {
    boolean bool;
    if ((this.b & 0x2) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return j.a(parami, bool);
  }
  
  public long b() {
    return this.w;
  }
  
  public void c() {}
  
  private static final class a {
    public final k a;
    
    public final n b;
    
    public final x c;
    
    public int d;
    
    public a(k param1k, n param1n, x param1x) {
      this.a = param1k;
      this.b = param1n;
      this.c = param1x;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\e\g\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */