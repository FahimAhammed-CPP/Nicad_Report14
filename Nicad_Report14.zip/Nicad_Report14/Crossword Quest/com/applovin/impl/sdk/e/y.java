package com.applovin.impl.sdk.e;

import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.n;
import com.applovin.impl.sdk.network.b;
import com.applovin.impl.sdk.network.c;
import com.applovin.impl.sdk.utils.JsonUtils;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.i;
import org.json.JSONObject;

public abstract class y extends a {
  protected y(String paramString, n paramn) {
    super(paramString, paramn);
  }
  
  protected abstract String a();
  
  protected void a(int paramInt) {
    i.a(paramInt, this.b);
  }
  
  protected abstract void a(JSONObject paramJSONObject);
  
  void a(JSONObject paramJSONObject, b.c<JSONObject> paramc) {
    u<JSONObject> u = new u<JSONObject>(this, c.a(this.b).a(i.a(a(), this.b)).c(i.b(a(), this.b)).a(i.e(this.b)).b("POST").a(paramJSONObject).d(((Boolean)this.b.a(b.eL)).booleanValue()).a(new JSONObject()).a(h()).a(), this.b, paramc) {
        public void a(int param1Int, String param1String, JSONObject param1JSONObject) {
          this.a.a(param1Int, param1String, param1JSONObject);
        }
        
        public void a(JSONObject param1JSONObject, int param1Int) {
          this.a.a(param1JSONObject, param1Int);
        }
      };
    u.a(b.bc);
    u.b(b.bd);
    this.b.V().a((a)u);
  }
  
  protected abstract int h();
  
  protected JSONObject i() {
    JSONObject jSONObject = new JSONObject();
    String str = this.b.n();
    if (((Boolean)this.b.a(b.dz)).booleanValue() && StringUtils.isValidString(str))
      JsonUtils.putString(jSONObject, "cuid", str); 
    if (((Boolean)this.b.a(b.dB)).booleanValue())
      JsonUtils.putString(jSONObject, "compass_random_token", this.b.o()); 
    if (((Boolean)this.b.a(b.dD)).booleanValue())
      JsonUtils.putString(jSONObject, "applovin_random_token", this.b.p()); 
    a(jSONObject);
    return jSONObject;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\impl\sdk\e\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */