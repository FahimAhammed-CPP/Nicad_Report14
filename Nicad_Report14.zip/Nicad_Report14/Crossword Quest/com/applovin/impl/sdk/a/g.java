package com.applovin.impl.sdk.a;

import android.text.TextUtils;
import android.webkit.WebView;
import com.applovin.impl.b.a;
import com.applovin.impl.b.b;
import com.applovin.impl.b.f;
import com.applovin.impl.b.h;
import com.applovin.impl.b.m;
import com.applovin.impl.sdk.AppLovinAdBase;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.v;
import com.iab.omid.library.applovin.adsession.AdSession;
import com.iab.omid.library.applovin.adsession.AdSessionConfiguration;
import com.iab.omid.library.applovin.adsession.AdSessionContext;
import com.iab.omid.library.applovin.adsession.CreativeType;
import com.iab.omid.library.applovin.adsession.ImpressionType;
import com.iab.omid.library.applovin.adsession.Owner;
import com.iab.omid.library.applovin.adsession.VerificationScriptResource;
import com.iab.omid.library.applovin.adsession.media.InteractionType;
import com.iab.omid.library.applovin.adsession.media.MediaEvents;
import com.iab.omid.library.applovin.adsession.media.Position;
import com.iab.omid.library.applovin.adsession.media.VastProperties;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

public class g extends b {
  private final a i;
  
  private final AtomicBoolean j;
  
  private MediaEvents k;
  
  private final VastProperties l;
  
  private final AtomicBoolean m;
  
  private final AtomicBoolean n;
  
  private final AtomicBoolean o;
  
  private final AtomicBoolean p;
  
  public g(a parama) {
    super((AppLovinAdBase)parama);
    VastProperties vastProperties;
    this.j = new AtomicBoolean();
    this.m = new AtomicBoolean();
    this.n = new AtomicBoolean();
    this.o = new AtomicBoolean();
    this.p = new AtomicBoolean();
    this.i = parama;
    float f = (float)parama.i();
    if (parama.i() == -1L) {
      vastProperties = VastProperties.createVastPropertiesForNonSkippableMedia(true, Position.STANDALONE);
    } else {
      vastProperties = VastProperties.createVastPropertiesForSkippableMedia(f, true, Position.STANDALONE);
    } 
    this.l = vastProperties;
  }
  
  protected AdSessionConfiguration a() {
    try {
      return AdSessionConfiguration.createAdSessionConfiguration(CreativeType.VIDEO, ImpressionType.BEGIN_TO_RENDER, Owner.NATIVE, Owner.NATIVE, false);
    } finally {
      Exception exception = null;
      v v = this.c;
      if (v.a())
        this.c.b(this.d, "Failed to create ad session configuration", exception); 
    } 
  }
  
  protected AdSessionContext a(WebView paramWebView) {
    if (h || this.i.aW() != null) {
      v v;
      ArrayList<VerificationScriptResource> arrayList = new ArrayList();
      Iterator<b> iterator = this.i.aW().a().iterator();
      while (true) {
        if (iterator.hasNext()) {
          b b1 = iterator.next();
          List<URL> list = b1.b();
          if (!list.isEmpty()) {
            f f1;
            ArrayList<h> arrayList1 = new ArrayList();
            for (h h : list) {
              if ("omid".equalsIgnoreCase(h.a()))
                arrayList1.add(h); 
            } 
            if (arrayList1.isEmpty()) {
              set = b1.d();
              f1 = f.c;
            } else {
              VerificationScriptResource verificationScriptResource;
              list = new ArrayList();
              for (h h : arrayList1) {
                try {
                  list.add(new URL(h.b()));
                } finally {
                  h = null;
                  v v1 = this.c;
                } 
              } 
              if (!list.isEmpty()) {
                String str1 = set.c();
                String str2 = set.a();
                if (!StringUtils.isValidString(str1) || StringUtils.isValidString(str2)) {
                  for (URL uRL : list) {
                    if (StringUtils.isValidString(str1)) {
                      verificationScriptResource = VerificationScriptResource.createVerificationScriptResourceWithParameters(str2, uRL, str1);
                    } else {
                      verificationScriptResource = VerificationScriptResource.createVerificationScriptResourceWithoutParameters((URL)verificationScriptResource);
                    } 
                    arrayList.add(verificationScriptResource);
                  } 
                  continue;
                } 
              } 
              set = verificationScriptResource.d();
              f1 = f.d;
            } 
            m.a(set, f1, this.b);
            continue;
          } 
        } else {
          break;
        } 
        Set set = set.d();
        f f = f.d;
      } 
      String str = this.b.ao().e();
      if (TextUtils.isEmpty(str)) {
        v = this.c;
        if (v.a())
          this.c.e(this.d, "JavaScript SDK content not loaded successfully"); 
        return null;
      } 
      try {
        return AdSessionContext.createNativeAdSessionContext(this.b.ao().d(), (String)v, arrayList, this.i.getOpenMeasurementContentUrl(), this.i.getOpenMeasurementCustomReferenceData());
      } finally {
        v = null;
        v v1 = this.c;
        if (v.a())
          this.c.b(this.d, "Failed to create ad session context", (Throwable)v); 
      } 
    } 
    throw new AssertionError();
  }
  
  public void a(float paramFloat, boolean paramBoolean) {
    if (this.m.compareAndSet(false, true))
      a("track started", new Runnable(this, paramFloat, paramBoolean) {
            public void run() {
              float f1;
              MediaEvents mediaEvents = g.b(this.c);
              float f2 = this.a;
              if (this.b) {
                f1 = 0.0F;
              } else {
                f1 = 1.0F;
              } 
              mediaEvents.start(f2, f1);
            }
          }); 
  }
  
  protected void a(AdSession paramAdSession) {
    try {
      return;
    } finally {
      paramAdSession = null;
      v v = this.c;
      if (v.a())
        this.c.b(this.d, "Failed to create media events", (Throwable)paramAdSession); 
    } 
  }
  
  public void a(boolean paramBoolean) {
    a("track volume changed", new Runnable(this, paramBoolean) {
          public void run() {
            float f;
            MediaEvents mediaEvents = g.b(this.b);
            if (this.a) {
              f = 0.0F;
            } else {
              f = 1.0F;
            } 
            mediaEvents.volumeChange(f);
          }
        });
  }
  
  public void c() {
    a("track loaded", new Runnable(this) {
          public void run() {
            this.a.g.loaded(g.a(this.a));
          }
        });
  }
  
  public void f() {
    if (this.n.compareAndSet(false, true))
      a("track first quartile", new Runnable(this) {
            public void run() {
              g.b(this.a).firstQuartile();
            }
          }); 
  }
  
  public void g() {
    if (this.o.compareAndSet(false, true))
      a("track midpoint", new Runnable(this) {
            public void run() {
              g.b(this.a).midpoint();
            }
          }); 
  }
  
  public void h() {
    if (this.p.compareAndSet(false, true))
      a("track third quartile", new Runnable(this) {
            public void run() {
              g.b(this.a).thirdQuartile();
            }
          }); 
  }
  
  public void i() {
    a("track completed", new Runnable(this) {
          public void run() {
            g.b(this.a).complete();
          }
        });
  }
  
  public void j() {
    a("track paused", new Runnable(this) {
          public void run() {
            g.b(this.a).pause();
          }
        });
  }
  
  public void k() {
    a("track resumed", new Runnable(this) {
          public void run() {
            g.b(this.a).resume();
          }
        });
  }
  
  public void l() {
    if (this.j.compareAndSet(false, true))
      a("buffer started", new Runnable(this) {
            public void run() {
              g.b(this.a).bufferStart();
            }
          }); 
  }
  
  public void m() {
    if (this.j.compareAndSet(true, false))
      a("buffer finished", new Runnable(this) {
            public void run() {
              g.b(this.a).bufferFinish();
            }
          }); 
  }
  
  public void n() {
    a("track skipped", new Runnable(this) {
          public void run() {
            g.b(this.a).skipped();
          }
        });
  }
  
  public void o() {
    a("track clicked", new Runnable(this) {
          public void run() {
            g.b(this.a).adUserInteraction(InteractionType.CLICK);
          }
        });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\impl\sdk\a\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */