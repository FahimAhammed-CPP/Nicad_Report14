package com.applovin.impl.sdk.nativeAd;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import com.applovin.impl.adview.d;
import com.applovin.impl.sdk.AppLovinAdBase;
import com.applovin.impl.sdk.a.e;
import com.applovin.impl.sdk.array.ArrayDirectDownloadAd;
import com.applovin.impl.sdk.array.ArrayService;
import com.applovin.impl.sdk.n;
import com.applovin.impl.sdk.network.i;
import com.applovin.impl.sdk.utils.JsonUtils;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.utils.h;
import com.applovin.impl.sdk.utils.k;
import com.applovin.impl.sdk.v;
import com.applovin.sdk.AppLovinSdkUtils;
import com.iab.omid.library.applovin.adsession.VerificationScriptResource;
import com.safedk.android.internal.partials.AppLovinNetworkBridge;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONArray;
import org.json.JSONObject;

public class AppLovinNativeAdImpl extends AppLovinAdBase implements AppLovinNativeAd {
  private static final String AD_RESPONSE_TYPE_APPLOVIN = "applovin";
  
  private static final String AD_RESPONSE_TYPE_ORTB = "ortb";
  
  private static final String AD_RESPONSE_TYPE_UNDEFINED = "undefined";
  
  private static final String DEFAULT_APPLOVIN_PRIVACY_URL = "https://www.applovin.com/privacy/";
  
  private final e adEventTracker;
  
  private final String advertiser;
  
  private final String body;
  
  private final String callToAction;
  
  private final Uri clickDestinationBackupUri;
  
  private final Uri clickDestinationUri;
  
  private final a clickHandler;
  
  private final List<String> clickTrackingUrls;
  
  private AppLovinNativeAdEventListener eventListener;
  
  private Uri iconUri;
  
  private final List<i> impressionRequests;
  
  private final AtomicBoolean impressionTracked;
  
  private final String jsTracker;
  
  private Uri mainImageUri;
  
  private AppLovinMediaView mediaView;
  
  private ViewGroup nativeAdView;
  
  private final b onAttachStateChangeHandler;
  
  private AppLovinOptionsView optionsView;
  
  private Uri privacyDestinationUri;
  
  private Uri privacyIconUri;
  
  private final List<View> registeredViews;
  
  private final String tag;
  
  private final String title;
  
  private final com.applovin.impl.b.a vastAd;
  
  private final List<i> viewableMRC100Requests;
  
  private final List<i> viewableMRC50Requests;
  
  private final List<i> viewableVideo50Requests;
  
  private AppLovinNativeAdImpl(Builder paramBuilder) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokestatic access$000 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Lorg/json/JSONObject;
    //   5: aload_1
    //   6: invokestatic access$100 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Lorg/json/JSONObject;
    //   9: aload_1
    //   10: invokestatic access$200 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Lcom/applovin/impl/sdk/n;
    //   13: invokespecial <init> : (Lorg/json/JSONObject;Lorg/json/JSONObject;Lcom/applovin/impl/sdk/n;)V
    //   16: aload_0
    //   17: new java/util/concurrent/atomic/AtomicBoolean
    //   20: dup
    //   21: invokespecial <init> : ()V
    //   24: putfield impressionTracked : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   27: aload_0
    //   28: new java/util/ArrayList
    //   31: dup
    //   32: invokespecial <init> : ()V
    //   35: putfield registeredViews : Ljava/util/List;
    //   38: aload_0
    //   39: new com/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$a
    //   42: dup
    //   43: aload_0
    //   44: invokespecial <init> : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl;)V
    //   47: putfield clickHandler : Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$a;
    //   50: aload_0
    //   51: new com/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$b
    //   54: dup
    //   55: aload_0
    //   56: invokespecial <init> : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl;)V
    //   59: putfield onAttachStateChangeHandler : Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$b;
    //   62: aload_0
    //   63: new com/applovin/impl/sdk/a/e
    //   66: dup
    //   67: aload_0
    //   68: invokespecial <init> : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl;)V
    //   71: putfield adEventTracker : Lcom/applovin/impl/sdk/a/e;
    //   74: aload_0
    //   75: aload_1
    //   76: invokestatic access$300 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Ljava/lang/String;
    //   79: putfield title : Ljava/lang/String;
    //   82: aload_0
    //   83: aload_1
    //   84: invokestatic access$400 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Ljava/lang/String;
    //   87: putfield advertiser : Ljava/lang/String;
    //   90: aload_0
    //   91: aload_1
    //   92: invokestatic access$500 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Ljava/lang/String;
    //   95: putfield body : Ljava/lang/String;
    //   98: aload_0
    //   99: aload_1
    //   100: invokestatic access$600 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Ljava/lang/String;
    //   103: putfield callToAction : Ljava/lang/String;
    //   106: aload_0
    //   107: aload_1
    //   108: invokestatic access$700 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Landroid/net/Uri;
    //   111: putfield iconUri : Landroid/net/Uri;
    //   114: aload_0
    //   115: aload_1
    //   116: invokestatic access$800 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Landroid/net/Uri;
    //   119: putfield mainImageUri : Landroid/net/Uri;
    //   122: aload_0
    //   123: aload_1
    //   124: invokestatic access$900 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Landroid/net/Uri;
    //   127: putfield privacyIconUri : Landroid/net/Uri;
    //   130: aload_0
    //   131: aload_1
    //   132: invokestatic access$1000 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Lcom/applovin/impl/b/a;
    //   135: putfield vastAd : Lcom/applovin/impl/b/a;
    //   138: aload_0
    //   139: aload_1
    //   140: invokestatic access$1100 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Landroid/net/Uri;
    //   143: putfield clickDestinationUri : Landroid/net/Uri;
    //   146: aload_0
    //   147: aload_1
    //   148: invokestatic access$1200 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Landroid/net/Uri;
    //   151: putfield clickDestinationBackupUri : Landroid/net/Uri;
    //   154: aload_0
    //   155: aload_1
    //   156: invokestatic access$1300 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Ljava/util/List;
    //   159: putfield clickTrackingUrls : Ljava/util/List;
    //   162: aload_0
    //   163: aload_1
    //   164: invokestatic access$1400 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Ljava/lang/String;
    //   167: putfield jsTracker : Ljava/lang/String;
    //   170: aload_0
    //   171: aload_1
    //   172: invokestatic access$1500 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Ljava/util/List;
    //   175: putfield impressionRequests : Ljava/util/List;
    //   178: aload_1
    //   179: invokestatic access$1600 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Landroid/net/Uri;
    //   182: ifnull -> 198
    //   185: aload_1
    //   186: invokestatic access$1600 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Landroid/net/Uri;
    //   189: astore_2
    //   190: aload_0
    //   191: aload_2
    //   192: putfield privacyDestinationUri : Landroid/net/Uri;
    //   195: goto -> 227
    //   198: aload_0
    //   199: invokespecial isDspAd : ()Z
    //   202: ifeq -> 218
    //   205: aload_0
    //   206: invokevirtual getSdk : ()Lcom/applovin/impl/sdk/n;
    //   209: invokevirtual N : ()Lcom/applovin/impl/mediation/debugger/ui/testmode/c;
    //   212: invokevirtual a : ()Z
    //   215: ifeq -> 227
    //   218: ldc 'https://www.applovin.com/privacy/'
    //   220: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
    //   223: astore_2
    //   224: goto -> 190
    //   227: aload_0
    //   228: aload_1
    //   229: invokestatic access$1700 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Ljava/util/List;
    //   232: putfield viewableMRC50Requests : Ljava/util/List;
    //   235: aload_0
    //   236: aload_1
    //   237: invokestatic access$1800 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Ljava/util/List;
    //   240: putfield viewableMRC100Requests : Ljava/util/List;
    //   243: aload_0
    //   244: aload_1
    //   245: invokestatic access$1900 : (Lcom/applovin/impl/sdk/nativeAd/AppLovinNativeAdImpl$Builder;)Ljava/util/List;
    //   248: putfield viewableVideo50Requests : Ljava/util/List;
    //   251: new java/lang/StringBuilder
    //   254: dup
    //   255: invokespecial <init> : ()V
    //   258: astore_1
    //   259: aload_1
    //   260: ldc 'AppLovinNativeAd:'
    //   262: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   265: pop
    //   266: aload_1
    //   267: aload_0
    //   268: invokevirtual getAdIdNumber : ()J
    //   271: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   274: pop
    //   275: aload_0
    //   276: aload_1
    //   277: invokevirtual toString : ()Ljava/lang/String;
    //   280: putfield tag : Ljava/lang/String;
    //   283: return
  }
  
  private List<com.applovin.impl.sdk.d.a> getDirectClickTrackingPostbacks() {
    synchronized (this.adObjectLock) {
      String str = getStringFromAdObject("click_tracking_url", null);
      return Utils.getPostbacks("click_tracking_urls", this.adObject, getClCode(), str, this.sdk);
    } 
  }
  
  private boolean isDspAd() {
    return "ortb".equalsIgnoreCase(getType());
  }
  
  private void maybeHandleOnAttachedToWindow(View paramView) {
    if (this.impressionTracked.compareAndSet(false, true)) {
      if (StringUtils.isValidString(this.jsTracker)) {
        d d = new d(null, this.sdk, paramView.getContext());
        AppLovinNetworkBridge.webviewLoadData((WebView)d, this.jsTracker, "text/html", "UTF-8");
        AppLovinSdkUtils.runOnUiThreadDelayed(new Runnable(this, d) {
              public void run() {
                this.a.stopLoading();
              }
            }TimeUnit.SECONDS.toMillis(5L));
      } 
      for (i i : this.impressionRequests)
        this.sdk.aa().dispatchPostbackRequest(i, null); 
      this.adEventTracker.a(paramView);
      this.adEventTracker.d();
    } 
  }
  
  public void destroy() {
    unregisterViewsForInteraction();
    this.eventListener = null;
    this.adEventTracker.e();
  }
  
  public e getAdEventTracker() {
    return this.adEventTracker;
  }
  
  public long getAdIdNumber() {
    return getLongFromAdObject("ad_id", -1L);
  }
  
  public String getAdvertiser() {
    return this.advertiser;
  }
  
  public String getBody() {
    return this.body;
  }
  
  public String getCachePrefix() {
    return getStringFromAdObject("cache_prefix", null);
  }
  
  public String getCallToAction() {
    return this.callToAction;
  }
  
  public a getClickHandler() {
    return this.clickHandler;
  }
  
  public Bundle getDirectDownloadParameters() {
    Bundle bundle = null;
    JSONObject jSONObject = getJsonObjectFromAdObject("ah_parameters", null);
    if (jSONObject != null)
      bundle = JsonUtils.toBundle(jSONObject); 
    return bundle;
  }
  
  public String getDirectDownloadToken() {
    return getStringFromAdObject("ah_dd_token", null);
  }
  
  public Uri getIconUri() {
    return this.iconUri;
  }
  
  public Uri getMainImageUri() {
    return this.mainImageUri;
  }
  
  public AppLovinMediaView getMediaView() {
    return this.mediaView;
  }
  
  public String getOpenMeasurementContentUrl() {
    return getStringFromAdObject("omid_content_url", null);
  }
  
  public String getOpenMeasurementCustomReferenceData() {
    return getStringFromAdObject("omid_custom_ref_data", "");
  }
  
  public List<VerificationScriptResource> getOpenMeasurementVerificationScriptResources() {
    ArrayList<VerificationScriptResource> arrayList = new ArrayList();
    synchronized (this.adObjectLock) {
      JSONArray jSONArray = JsonUtils.getJSONArray(this.adObject, "omid_verification_script_resources", null);
      if (jSONArray != null)
        for (int i = 0;; i++) {
          if (i < jSONArray.length()) {
            JSONObject jSONObject = JsonUtils.getJSONObject(jSONArray, i, null);
            try {
              URL uRL = new URL(JsonUtils.getString(jSONObject, "url", null));
              String str1 = JsonUtils.getString(jSONObject, "vendor_key", null);
              String str2 = JsonUtils.getString(jSONObject, "parameters", null);
            } finally {
              Exception exception = null;
              this.sdk.D();
            } 
          } else {
            return arrayList;
          } 
        }  
      return arrayList;
    } 
  }
  
  public AppLovinOptionsView getOptionsView() {
    return this.optionsView;
  }
  
  public Uri getPrivacyDestinationUri() {
    return this.privacyDestinationUri;
  }
  
  public Uri getPrivacyIconUri() {
    return this.privacyIconUri;
  }
  
  public String getTitle() {
    return this.title;
  }
  
  public String getType() {
    return getStringFromAdObject("type", "undefined");
  }
  
  public com.applovin.impl.b.a getVastAd() {
    return this.vastAd;
  }
  
  public boolean isDirectDownloadEnabled() {
    return StringUtils.isValidString(getDirectDownloadToken());
  }
  
  public boolean isOpenMeasurementEnabled() {
    return getBooleanFromAdObject("omsdk_enabled", Boolean.valueOf(false));
  }
  
  public void registerViewsForInteraction(List<View> paramList, ViewGroup paramViewGroup) {
    this.nativeAdView = paramViewGroup;
    if ((h.c() && this.nativeAdView.isAttachedToWindow()) || (!h.c() && this.nativeAdView.getParent() != null)) {
      maybeHandleOnAttachedToWindow((View)this.nativeAdView);
    } else {
      this.nativeAdView.addOnAttachStateChangeListener(this.onAttachStateChangeHandler);
    } 
    this.sdk.D();
    if (v.a()) {
      v v = this.sdk.D();
      String str = this.tag;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Registered ad view for impressions: ");
      stringBuilder.append(this.nativeAdView);
      v.b(str, stringBuilder.toString());
    } 
    if (this.clickDestinationUri == null && this.clickDestinationBackupUri == null) {
      this.sdk.D();
      if (v.a())
        this.sdk.D().b(this.tag, "Skipping click registration - no click URLs provided"); 
      return;
    } 
    for (View view : paramList) {
      v v;
      String str1;
      StringBuilder stringBuilder;
      String str2;
      if (view.hasOnClickListeners()) {
        this.sdk.D();
        if (v.a()) {
          v = this.sdk.D();
          str1 = this.tag;
          stringBuilder = new StringBuilder();
          stringBuilder.append("View has an onClickListener already - ");
          stringBuilder.append(view);
          v.e(str1, stringBuilder.toString());
        } 
      } 
      if (!view.isClickable()) {
        this.sdk.D();
        if (v.a()) {
          v = this.sdk.D();
          str1 = this.tag;
          stringBuilder = new StringBuilder();
          stringBuilder.append("View is not clickable - ");
          stringBuilder.append(view);
          v.e(str1, stringBuilder.toString());
        } 
      } 
      if (!view.isEnabled()) {
        this.sdk.D();
        if (v.a()) {
          v = this.sdk.D();
          str1 = this.tag;
          stringBuilder = new StringBuilder();
          stringBuilder.append("View is not enabled - ");
          stringBuilder.append(view);
          v.e(str1, stringBuilder.toString());
        } 
      } 
      if (view instanceof android.widget.Button) {
        this.sdk.D();
        if (v.a()) {
          v = this.sdk.D();
          str1 = this.tag;
          stringBuilder = new StringBuilder();
          str2 = "Registering click for button: ";
        } else {
          continue;
        } 
      } else {
        this.sdk.D();
        if (v.a()) {
          v = this.sdk.D();
          str1 = this.tag;
          stringBuilder = new StringBuilder();
          str2 = "Registering click for view: ";
        } else {
          continue;
        } 
      } 
      stringBuilder.append(str2);
      stringBuilder.append(view);
      v.b(str1, stringBuilder.toString());
      continue;
      SYNTHETIC_LOCAL_VARIABLE_6.setOnClickListener(this.clickHandler);
      this.registeredViews.add(SYNTHETIC_LOCAL_VARIABLE_6);
    } 
    this.sdk.D();
    if (v.a()) {
      v v = this.sdk.D();
      String str = this.tag;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Registered views: ");
      stringBuilder.append(this.registeredViews);
      v.b(str, stringBuilder.toString());
    } 
  }
  
  public void setEventListener(AppLovinNativeAdEventListener paramAppLovinNativeAdEventListener) {
    this.eventListener = paramAppLovinNativeAdEventListener;
  }
  
  public void setIconUri(Uri paramUri) {
    this.iconUri = paramUri;
  }
  
  public void setMainImageUri(Uri paramUri) {
    this.mainImageUri = paramUri;
  }
  
  public void setPrivacyIconUri(Uri paramUri) {
    this.privacyIconUri = paramUri;
  }
  
  public void setUpNativeAdViewComponents() {
    this.mediaView = new AppLovinMediaView(this, this.sdk, this.sdk.P());
    if (this.privacyDestinationUri != null)
      this.optionsView = new AppLovinOptionsView(this, this.sdk, this.sdk.P()); 
  }
  
  public boolean shouldInjectOpenMeasurementScriptDuringCaching() {
    return false;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("AppLovinNativeAd{adIdNumber=");
    stringBuilder.append(getAdIdNumber());
    stringBuilder.append(" - ");
    stringBuilder.append(getTitle());
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public void unregisterViewsForInteraction() {
    Iterator<View> iterator = this.registeredViews.iterator();
    while (iterator.hasNext())
      ((View)iterator.next()).setOnClickListener(null); 
    this.sdk.D();
    if (v.a()) {
      v v = this.sdk.D();
      String str = this.tag;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unregistered views: ");
      stringBuilder.append(this.registeredViews);
      v.b(str, stringBuilder.toString());
    } 
    this.registeredViews.clear();
    ViewGroup viewGroup = this.nativeAdView;
    if (viewGroup != null) {
      viewGroup.removeOnAttachStateChangeListener(this.onAttachStateChangeHandler);
      this.nativeAdView = null;
    } 
    AppLovinMediaView appLovinMediaView = this.mediaView;
    if (appLovinMediaView != null)
      appLovinMediaView.destroy(); 
    AppLovinOptionsView appLovinOptionsView = this.optionsView;
    if (appLovinOptionsView != null)
      appLovinOptionsView.destroy(); 
  }
  
  public static class Builder {
    private final JSONObject adObject;
    
    private String advertiser;
    
    private String body;
    
    private String callToAction;
    
    private Uri clickDestinationBackupUri;
    
    private Uri clickDestinationUri;
    
    private List<String> clickTrackingUrls;
    
    private final JSONObject fullResponse;
    
    private Uri iconUri;
    
    private List<i> impressionRequests;
    
    private String jsTracker;
    
    private Uri mainImageUri;
    
    private Uri privacyDestinationUri;
    
    private Uri privacyIconUri;
    
    private final n sdk;
    
    private String title;
    
    private com.applovin.impl.b.a vastAd;
    
    private List<i> viewableMRC100Requests;
    
    private List<i> viewableMRC50Requests;
    
    private List<i> viewableVideo50Requests;
    
    public Builder(JSONObject param1JSONObject1, JSONObject param1JSONObject2, n param1n) {
      this.adObject = param1JSONObject1;
      this.fullResponse = param1JSONObject2;
      this.sdk = param1n;
    }
    
    public AppLovinNativeAdImpl build() {
      return new AppLovinNativeAdImpl(this);
    }
    
    public Builder setAdvertiser(String param1String) {
      this.advertiser = param1String;
      return this;
    }
    
    public Builder setBody(String param1String) {
      this.body = param1String;
      return this;
    }
    
    public Builder setCallToAction(String param1String) {
      this.callToAction = param1String;
      return this;
    }
    
    public Builder setClickDestinationBackupUri(Uri param1Uri) {
      this.clickDestinationBackupUri = param1Uri;
      return this;
    }
    
    public Builder setClickDestinationUri(Uri param1Uri) {
      this.clickDestinationUri = param1Uri;
      return this;
    }
    
    public Builder setClickTrackingUrls(List<String> param1List) {
      this.clickTrackingUrls = param1List;
      return this;
    }
    
    public Builder setIconUri(Uri param1Uri) {
      this.iconUri = param1Uri;
      return this;
    }
    
    public Builder setImpressionRequests(List<i> param1List) {
      this.impressionRequests = param1List;
      return this;
    }
    
    public Builder setJsTracker(String param1String) {
      this.jsTracker = param1String;
      return this;
    }
    
    public Builder setMainImageUri(Uri param1Uri) {
      this.mainImageUri = param1Uri;
      return this;
    }
    
    public Builder setPrivacyDestinationUri(Uri param1Uri) {
      this.privacyDestinationUri = param1Uri;
      return this;
    }
    
    public Builder setPrivacyIconUri(Uri param1Uri) {
      this.privacyIconUri = param1Uri;
      return this;
    }
    
    public Builder setTitle(String param1String) {
      this.title = param1String;
      return this;
    }
    
    public Builder setVastAd(com.applovin.impl.b.a param1a) {
      this.vastAd = param1a;
      return this;
    }
    
    public Builder setViewableMRC100Requests(List<i> param1List) {
      this.viewableMRC100Requests = param1List;
      return this;
    }
    
    public Builder setViewableMRC50Requests(List<i> param1List) {
      this.viewableMRC50Requests = param1List;
      return this;
    }
    
    public Builder setViewableVideo50Requests(List<i> param1List) {
      this.viewableVideo50Requests = param1List;
      return this;
    }
  }
  
  private static class a implements View.OnClickListener {
    private final AppLovinNativeAdImpl a;
    
    public a(AppLovinNativeAdImpl param1AppLovinNativeAdImpl) {
      this.a = param1AppLovinNativeAdImpl;
    }
    
    private void a(AppLovinNativeAdImpl param1AppLovinNativeAdImpl, Context param1Context) {
      String str;
      StringBuilder stringBuilder;
      Uri uri;
      v v;
      if (Utils.openUri(param1Context, param1AppLovinNativeAdImpl.clickDestinationUri, param1AppLovinNativeAdImpl.sdk)) {
        param1AppLovinNativeAdImpl.sdk.D();
        if (v.a()) {
          v = param1AppLovinNativeAdImpl.sdk.D();
          String str1 = param1AppLovinNativeAdImpl.tag;
          stringBuilder = new StringBuilder();
          stringBuilder.append("Opening URL: ");
          uri = param1AppLovinNativeAdImpl.clickDestinationUri;
          str = str1;
        } else {
          return;
        } 
      } else if (Utils.openUri((Context)stringBuilder, ((AppLovinNativeAdImpl)str).clickDestinationBackupUri, ((AppLovinNativeAdImpl)str).sdk)) {
        ((AppLovinNativeAdImpl)str).sdk.D();
        if (v.a()) {
          v = ((AppLovinNativeAdImpl)str).sdk.D();
          String str1 = ((AppLovinNativeAdImpl)str).tag;
          stringBuilder = new StringBuilder();
          stringBuilder.append("Opening backup URL: ");
          uri = ((AppLovinNativeAdImpl)str).clickDestinationBackupUri;
          str = str1;
        } else {
          return;
        } 
      } else {
        return;
      } 
      stringBuilder.append(uri);
      v.b(str, stringBuilder.toString());
    }
    
    public AppLovinNativeAdImpl a() {
      return this.a;
    }
    
    protected boolean a(Object param1Object) {
      return param1Object instanceof a;
    }
    
    public boolean equals(Object param1Object) {
      if (param1Object == this)
        return true; 
      if (!(param1Object instanceof a))
        return false; 
      a a1 = (a)param1Object;
      if (!a1.a(this))
        return false; 
      param1Object = a();
      AppLovinNativeAdImpl appLovinNativeAdImpl = a1.a();
      if (param1Object == null) {
        if (appLovinNativeAdImpl != null)
          return false; 
      } else if (!param1Object.equals(appLovinNativeAdImpl)) {
        return false;
      } 
      return true;
    }
    
    public int hashCode() {
      int i;
      AppLovinNativeAdImpl appLovinNativeAdImpl = a();
      if (appLovinNativeAdImpl == null) {
        i = 43;
      } else {
        i = appLovinNativeAdImpl.hashCode();
      } 
      return 59 + i;
    }
    
    public void onClick(View param1View) {
      this.a.sdk.D();
      if (v.a())
        this.a.sdk.D().b(this.a.tag, "Handle view clicked"); 
      this.a.sdk.v().maybeSubmitPersistentPostbacks(this.a.getDirectClickTrackingPostbacks());
      for (String str : this.a.clickTrackingUrls)
        this.a.sdk.aa().dispatchPostbackAsync(str, null); 
      k.a(this.a.eventListener, this.a);
      if (this.a.isDirectDownloadEnabled()) {
        this.a.sdk.aq().startDirectDownloadActivity((ArrayDirectDownloadAd)this.a, new ArrayService.DirectDownloadListener(this, param1View) {
              public void onAppDetailsDismissed() {}
              
              public void onAppDetailsDisplayed() {}
              
              public void onFailure() {
                AppLovinNativeAdImpl.a a1 = this.b;
                AppLovinNativeAdImpl.a.a(a1, AppLovinNativeAdImpl.a.a(a1), this.a.getContext());
              }
            });
        return;
      } 
      a(this.a, param1View.getContext());
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("AppLovinNativeAdImpl.ClickHandler(ad=");
      stringBuilder.append(a());
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  class null implements ArrayService.DirectDownloadListener {
    null(AppLovinNativeAdImpl this$0, View param1View) {}
    
    public void onAppDetailsDismissed() {}
    
    public void onAppDetailsDisplayed() {}
    
    public void onFailure() {
      AppLovinNativeAdImpl.a a1 = this.b;
      AppLovinNativeAdImpl.a.a(a1, AppLovinNativeAdImpl.a.a(a1), this.a.getContext());
    }
  }
  
  private static class b implements View.OnAttachStateChangeListener {
    private final AppLovinNativeAdImpl a;
    
    public b(AppLovinNativeAdImpl param1AppLovinNativeAdImpl) {
      this.a = param1AppLovinNativeAdImpl;
    }
    
    public AppLovinNativeAdImpl a() {
      return this.a;
    }
    
    protected boolean a(Object param1Object) {
      return param1Object instanceof b;
    }
    
    public boolean equals(Object param1Object) {
      if (param1Object == this)
        return true; 
      if (!(param1Object instanceof b))
        return false; 
      b b1 = (b)param1Object;
      if (!b1.a(this))
        return false; 
      param1Object = a();
      AppLovinNativeAdImpl appLovinNativeAdImpl = b1.a();
      if (param1Object == null) {
        if (appLovinNativeAdImpl != null)
          return false; 
      } else if (!param1Object.equals(appLovinNativeAdImpl)) {
        return false;
      } 
      return true;
    }
    
    public int hashCode() {
      int i;
      AppLovinNativeAdImpl appLovinNativeAdImpl = a();
      if (appLovinNativeAdImpl == null) {
        i = 43;
      } else {
        i = appLovinNativeAdImpl.hashCode();
      } 
      return 59 + i;
    }
    
    public void onViewAttachedToWindow(View param1View) {
      this.a.maybeHandleOnAttachedToWindow(param1View);
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("AppLovinNativeAdImpl.OnAttachStateChangeHandler(ad=");
      stringBuilder.append(a());
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\impl\sdk\nativeAd\AppLovinNativeAdImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */