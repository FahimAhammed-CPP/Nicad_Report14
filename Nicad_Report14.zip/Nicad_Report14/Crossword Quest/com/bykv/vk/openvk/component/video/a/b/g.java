package com.bykv.vk.openvk.component.video.a.b;

import android.util.Log;
import com.bykv.vk.openvk.component.video.a.b.a.a;
import com.bykv.vk.openvk.component.video.a.b.a.b;
import com.bykv.vk.openvk.component.video.a.b.a.c;
import com.bykv.vk.openvk.component.video.a.b.b.a;
import com.bykv.vk.openvk.component.video.a.b.b.c;
import com.bykv.vk.openvk.component.video.a.b.c.a;
import com.bykv.vk.openvk.component.video.a.b.c.b;
import com.bykv.vk.openvk.component.video.a.b.c.c;
import com.bykv.vk.openvk.component.video.a.b.c.d;
import com.bykv.vk.openvk.component.video.a.b.e.a;
import com.bytedance.sdk.component.g.f;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;

class g extends a {
  private final Socket m;
  
  private final c n;
  
  private final d o;
  
  private volatile b p;
  
  private volatile boolean q = true;
  
  g(a parama) {
    super(parama.a, parama.b);
    this.m = parama.c;
    this.n = parama.d;
    this.o = d.c();
  }
  
  private void a(a parama, File paramFile, b paramb, l.a parama1) throws IOException, d, h.a, a, b {
    // Byte code:
    //   0: aload_3
    //   1: invokevirtual a : ()Z
    //   4: ifne -> 37
    //   7: aload_0
    //   8: aload_1
    //   9: aload_3
    //   10: aload #4
    //   12: invokespecial a : (Lcom/bykv/vk/openvk/component/video/a/b/b/a;Lcom/bykv/vk/openvk/component/video/a/b/g$b;Lcom/bykv/vk/openvk/component/video/a/b/l$a;)[B
    //   15: astore #7
    //   17: aload_0
    //   18: invokevirtual e : ()V
    //   21: aload #7
    //   23: ifnonnull -> 27
    //   26: return
    //   27: aload_3
    //   28: aload #7
    //   30: iconst_0
    //   31: aload #7
    //   33: arraylength
    //   34: invokevirtual a : ([BII)V
    //   37: aconst_null
    //   38: astore #8
    //   40: aload_1
    //   41: astore #7
    //   43: aload_1
    //   44: ifnonnull -> 180
    //   47: aload_0
    //   48: getfield b : Lcom/bykv/vk/openvk/component/video/a/b/b/c;
    //   51: aload_0
    //   52: getfield h : Ljava/lang/String;
    //   55: aload_0
    //   56: getfield i : Lcom/bykv/vk/openvk/component/video/a/b/i;
    //   59: getfield c : Lcom/bykv/vk/openvk/component/video/a/b/i$a;
    //   62: getfield a : I
    //   65: invokevirtual a : (Ljava/lang/String;I)Lcom/bykv/vk/openvk/component/video/a/b/b/a;
    //   68: astore_1
    //   69: aload_1
    //   70: astore #7
    //   72: aload_1
    //   73: ifnonnull -> 180
    //   76: getstatic com/bykv/vk/openvk/component/video/a/b/e.c : Z
    //   79: ifeq -> 90
    //   82: ldc 'TAG_PROXY_ProxyTask'
    //   84: ldc 'failed to get video header info from db'
    //   86: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   89: pop
    //   90: aload_0
    //   91: aconst_null
    //   92: aload_3
    //   93: aload #4
    //   95: invokespecial a : (Lcom/bykv/vk/openvk/component/video/a/b/b/a;Lcom/bykv/vk/openvk/component/video/a/b/g$b;Lcom/bykv/vk/openvk/component/video/a/b/l$a;)[B
    //   98: pop
    //   99: aload_0
    //   100: getfield b : Lcom/bykv/vk/openvk/component/video/a/b/b/c;
    //   103: aload_0
    //   104: getfield h : Ljava/lang/String;
    //   107: aload_0
    //   108: getfield i : Lcom/bykv/vk/openvk/component/video/a/b/i;
    //   111: getfield c : Lcom/bykv/vk/openvk/component/video/a/b/i$a;
    //   114: getfield a : I
    //   117: invokevirtual a : (Ljava/lang/String;I)Lcom/bykv/vk/openvk/component/video/a/b/b/a;
    //   120: astore #7
    //   122: aload #7
    //   124: ifnull -> 130
    //   127: goto -> 180
    //   130: new java/lang/StringBuilder
    //   133: dup
    //   134: invokespecial <init> : ()V
    //   137: astore_1
    //   138: aload_1
    //   139: ldc 'failed to get header, rawKey: '
    //   141: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   144: pop
    //   145: aload_1
    //   146: aload_0
    //   147: getfield g : Ljava/lang/String;
    //   150: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   153: pop
    //   154: aload_1
    //   155: ldc ', url: '
    //   157: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   160: pop
    //   161: aload_1
    //   162: aload #4
    //   164: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   167: pop
    //   168: new com/bykv/vk/openvk/component/video/a/b/c/c
    //   171: dup
    //   172: aload_1
    //   173: invokevirtual toString : ()Ljava/lang/String;
    //   176: invokespecial <init> : (Ljava/lang/String;)V
    //   179: athrow
    //   180: aload_2
    //   181: invokevirtual length : ()J
    //   184: aload #7
    //   186: getfield c : I
    //   189: i2l
    //   190: lcmp
    //   191: ifge -> 353
    //   194: aload_0
    //   195: getfield p : Lcom/bykv/vk/openvk/component/video/a/b/b;
    //   198: astore_1
    //   199: aload_1
    //   200: ifnull -> 217
    //   203: aload_1
    //   204: invokevirtual b : ()Z
    //   207: ifne -> 217
    //   210: aload_1
    //   211: invokevirtual d : ()Z
    //   214: ifeq -> 353
    //   217: new com/bykv/vk/openvk/component/video/a/b/b$a
    //   220: dup
    //   221: invokespecial <init> : ()V
    //   224: aload_0
    //   225: getfield a : Lcom/bykv/vk/openvk/component/video/a/b/a/a;
    //   228: invokevirtual a : (Lcom/bykv/vk/openvk/component/video/a/b/a/a;)Lcom/bykv/vk/openvk/component/video/a/b/b$a;
    //   231: aload_0
    //   232: getfield b : Lcom/bykv/vk/openvk/component/video/a/b/b/c;
    //   235: invokevirtual a : (Lcom/bykv/vk/openvk/component/video/a/b/b/c;)Lcom/bykv/vk/openvk/component/video/a/b/b$a;
    //   238: aload_0
    //   239: getfield g : Ljava/lang/String;
    //   242: invokevirtual a : (Ljava/lang/String;)Lcom/bykv/vk/openvk/component/video/a/b/b$a;
    //   245: aload_0
    //   246: getfield h : Ljava/lang/String;
    //   249: invokevirtual b : (Ljava/lang/String;)Lcom/bykv/vk/openvk/component/video/a/b/b$a;
    //   252: new com/bykv/vk/openvk/component/video/a/b/l
    //   255: dup
    //   256: aload #4
    //   258: getfield a : Ljava/lang/String;
    //   261: invokespecial <init> : (Ljava/lang/String;)V
    //   264: invokevirtual a : (Lcom/bykv/vk/openvk/component/video/a/b/l;)Lcom/bykv/vk/openvk/component/video/a/b/b$a;
    //   267: aload_0
    //   268: getfield f : Ljava/util/List;
    //   271: invokevirtual a : (Ljava/util/List;)Lcom/bykv/vk/openvk/component/video/a/b/b$a;
    //   274: aload_0
    //   275: getfield i : Lcom/bykv/vk/openvk/component/video/a/b/i;
    //   278: invokevirtual a : (Lcom/bykv/vk/openvk/component/video/a/b/i;)Lcom/bykv/vk/openvk/component/video/a/b/b$a;
    //   281: new com/bykv/vk/openvk/component/video/a/b/g$1
    //   284: dup
    //   285: aload_0
    //   286: invokespecial <init> : (Lcom/bykv/vk/openvk/component/video/a/b/g;)V
    //   289: invokevirtual a : (Lcom/bykv/vk/openvk/component/video/a/b/b$b;)Lcom/bykv/vk/openvk/component/video/a/b/b$a;
    //   292: invokevirtual a : ()Lcom/bykv/vk/openvk/component/video/a/b/b;
    //   295: astore_1
    //   296: aload_0
    //   297: aload_1
    //   298: putfield p : Lcom/bykv/vk/openvk/component/video/a/b/b;
    //   301: new com/bytedance/sdk/component/g/f
    //   304: dup
    //   305: aload_1
    //   306: aconst_null
    //   307: bipush #10
    //   309: iconst_1
    //   310: invokespecial <init> : (Ljava/lang/Runnable;Ljava/lang/Object;II)V
    //   313: astore #9
    //   315: new com/bykv/vk/openvk/component/video/a/b/g$2
    //   318: dup
    //   319: aload_0
    //   320: ldc 'processCacheNetWorkConcurrent'
    //   322: aload #9
    //   324: invokespecial <init> : (Lcom/bykv/vk/openvk/component/video/a/b/g;Ljava/lang/String;Lcom/bytedance/sdk/component/g/f;)V
    //   327: invokestatic b : (Lcom/bytedance/sdk/component/g/g;)V
    //   330: aload #9
    //   332: astore_1
    //   333: getstatic com/bykv/vk/openvk/component/video/a/b/e.c : Z
    //   336: ifeq -> 355
    //   339: ldc 'TAG_PROXY_ProxyTask'
    //   341: ldc 'fire download in process cache task'
    //   343: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   346: pop
    //   347: aload #9
    //   349: astore_1
    //   350: goto -> 355
    //   353: aconst_null
    //   354: astore_1
    //   355: sipush #8192
    //   358: newarray byte
    //   360: astore #9
    //   362: new com/bykv/vk/openvk/component/video/a/b/h
    //   365: dup
    //   366: aload_2
    //   367: ldc 'r'
    //   369: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   372: astore_2
    //   373: aload_2
    //   374: aload_3
    //   375: invokevirtual b : ()I
    //   378: i2l
    //   379: invokevirtual a : (J)V
    //   382: aload_0
    //   383: getfield i : Lcom/bykv/vk/openvk/component/video/a/b/i;
    //   386: getfield c : Lcom/bykv/vk/openvk/component/video/a/b/i$a;
    //   389: getfield e : I
    //   392: ifle -> 418
    //   395: aload #7
    //   397: getfield c : I
    //   400: aload_0
    //   401: getfield i : Lcom/bykv/vk/openvk/component/video/a/b/i;
    //   404: getfield c : Lcom/bykv/vk/openvk/component/video/a/b/i$a;
    //   407: getfield e : I
    //   410: invokestatic min : (II)I
    //   413: istore #5
    //   415: goto -> 425
    //   418: aload #7
    //   420: getfield c : I
    //   423: istore #5
    //   425: aload_3
    //   426: invokevirtual b : ()I
    //   429: iload #5
    //   431: if_icmpge -> 651
    //   434: aload_0
    //   435: invokevirtual e : ()V
    //   438: aload_2
    //   439: aload #9
    //   441: invokevirtual a : ([B)I
    //   444: istore #6
    //   446: iload #6
    //   448: ifgt -> 635
    //   451: aload_0
    //   452: getfield p : Lcom/bykv/vk/openvk/component/video/a/b/b;
    //   455: astore #7
    //   457: aload #7
    //   459: ifnull -> 495
    //   462: aload #7
    //   464: invokevirtual i : ()Lcom/bykv/vk/openvk/component/video/a/b/c/b;
    //   467: astore #8
    //   469: aload #8
    //   471: ifnonnull -> 492
    //   474: aload #7
    //   476: invokevirtual h : ()Lcom/bykv/vk/openvk/component/video/a/b/h$a;
    //   479: astore #8
    //   481: aload #8
    //   483: ifnonnull -> 489
    //   486: goto -> 495
    //   489: aload #8
    //   491: athrow
    //   492: aload #8
    //   494: athrow
    //   495: aload #7
    //   497: ifnull -> 569
    //   500: aload #7
    //   502: invokevirtual b : ()Z
    //   505: ifne -> 569
    //   508: aload #7
    //   510: invokevirtual d : ()Z
    //   513: ifeq -> 519
    //   516: goto -> 569
    //   519: aload_0
    //   520: invokevirtual e : ()V
    //   523: aload #7
    //   525: getfield m : Ljava/lang/Object;
    //   528: astore #8
    //   530: aload #8
    //   532: monitorenter
    //   533: aload #7
    //   535: getfield m : Ljava/lang/Object;
    //   538: ldc2_w 1000
    //   541: invokevirtual wait : (J)V
    //   544: goto -> 558
    //   547: astore_3
    //   548: goto -> 564
    //   551: astore #7
    //   553: aload #7
    //   555: invokevirtual printStackTrace : ()V
    //   558: aload #8
    //   560: monitorexit
    //   561: goto -> 644
    //   564: aload #8
    //   566: monitorexit
    //   567: aload_3
    //   568: athrow
    //   569: getstatic com/bykv/vk/openvk/component/video/a/b/e.c : Z
    //   572: ifeq -> 584
    //   575: ldc 'TAG_PROXY_ProxyTask'
    //   577: ldc_w 'download task has finished!!!'
    //   580: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   583: pop
    //   584: new java/lang/StringBuilder
    //   587: dup
    //   588: invokespecial <init> : ()V
    //   591: astore_3
    //   592: aload_3
    //   593: ldc_w 'illegal state download task has finished, rawKey: '
    //   596: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   599: pop
    //   600: aload_3
    //   601: aload_0
    //   602: getfield g : Ljava/lang/String;
    //   605: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   608: pop
    //   609: aload_3
    //   610: ldc ', url: '
    //   612: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   615: pop
    //   616: aload_3
    //   617: aload #4
    //   619: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   622: pop
    //   623: new com/bykv/vk/openvk/component/video/a/b/c/c
    //   626: dup
    //   627: aload_3
    //   628: invokevirtual toString : ()Ljava/lang/String;
    //   631: invokespecial <init> : (Ljava/lang/String;)V
    //   634: athrow
    //   635: aload_3
    //   636: aload #9
    //   638: iconst_0
    //   639: iload #6
    //   641: invokevirtual b : ([BII)V
    //   644: aload_0
    //   645: invokevirtual e : ()V
    //   648: goto -> 425
    //   651: getstatic com/bykv/vk/openvk/component/video/a/b/e.c : Z
    //   654: ifeq -> 713
    //   657: new java/lang/StringBuilder
    //   660: dup
    //   661: invokespecial <init> : ()V
    //   664: astore #4
    //   666: aload #4
    //   668: ldc_w 'read cache file complete: '
    //   671: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   674: pop
    //   675: aload #4
    //   677: aload_3
    //   678: invokevirtual b : ()I
    //   681: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   684: pop
    //   685: aload #4
    //   687: ldc_w ', '
    //   690: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   693: pop
    //   694: aload #4
    //   696: iload #5
    //   698: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   701: pop
    //   702: ldc 'TAG_PROXY_ProxyTask'
    //   704: aload #4
    //   706: invokevirtual toString : ()Ljava/lang/String;
    //   709: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   712: pop
    //   713: aload_0
    //   714: invokevirtual c : ()V
    //   717: aload_2
    //   718: invokevirtual a : ()V
    //   721: aload_1
    //   722: ifnull -> 736
    //   725: aload_1
    //   726: invokevirtual get : ()Ljava/lang/Object;
    //   729: pop
    //   730: return
    //   731: astore_1
    //   732: aload_1
    //   733: invokevirtual printStackTrace : ()V
    //   736: return
    //   737: astore #4
    //   739: aload_2
    //   740: astore_3
    //   741: aload #4
    //   743: astore_2
    //   744: goto -> 751
    //   747: astore_2
    //   748: aload #8
    //   750: astore_3
    //   751: aload_3
    //   752: ifnull -> 759
    //   755: aload_3
    //   756: invokevirtual a : ()V
    //   759: aload_1
    //   760: ifnull -> 776
    //   763: aload_1
    //   764: invokevirtual get : ()Ljava/lang/Object;
    //   767: pop
    //   768: goto -> 776
    //   771: astore_1
    //   772: aload_1
    //   773: invokevirtual printStackTrace : ()V
    //   776: goto -> 781
    //   779: aload_2
    //   780: athrow
    //   781: goto -> 779
    // Exception table:
    //   from	to	target	type
    //   362	373	747	finally
    //   373	415	737	finally
    //   418	425	737	finally
    //   425	446	737	finally
    //   451	457	737	finally
    //   462	469	737	finally
    //   474	481	737	finally
    //   489	492	737	finally
    //   492	495	737	finally
    //   500	516	737	finally
    //   519	533	737	finally
    //   533	544	551	java/lang/InterruptedException
    //   533	544	547	finally
    //   553	558	547	finally
    //   558	561	547	finally
    //   564	567	547	finally
    //   567	569	737	finally
    //   569	584	737	finally
    //   584	635	737	finally
    //   635	644	737	finally
    //   644	648	737	finally
    //   651	713	737	finally
    //   713	717	737	finally
    //   725	730	731	finally
    //   763	768	771	finally
  }
  
  private void a(b paramb, l.a parama) throws d, IOException, h.a, a, b {
    if ("HEAD".equalsIgnoreCase(this.i.a.a)) {
      b(paramb, parama);
      return;
    } 
    c(paramb, parama);
  }
  
  private void a(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  private boolean a(b paramb) throws a {
    while (this.j.a()) {
      e();
      l.a a1 = this.j.b();
      try {
        a(paramb, a1);
        return true;
      } catch (c c1) {
        a1.a();
        a(Boolean.valueOf(g()), this.g, (Throwable)c1);
      } catch (IOException iOException) {
        if (iOException instanceof java.net.SocketTimeoutException)
          a1.b(); 
        if (b()) {
          if (e.c) {
            if ("Canceled".equalsIgnoreCase(iOException.getMessage())) {
              Log.w("TAG_PROXY_ProxyTask", "okhttp call canceled");
              continue;
            } 
            Log.e("TAG_PROXY_ProxyTask", Log.getStackTraceString(iOException));
          } 
          continue;
        } 
        a(Boolean.valueOf(g()), this.g, iOException);
      } catch (d d1) {
        if (e.c)
          Log.e("TAG_PROXY_ProxyTask", Log.getStackTraceString((Throwable)d1)); 
        return true;
      } catch (a a2) {
        if (e.c)
          Log.e("TAG_PROXY_ProxyTask", Log.getStackTraceString((Throwable)a2)); 
        this.q = false;
        a(Boolean.valueOf(g()), this.g, (Throwable)a2);
      } catch (b b1) {
        if (e.c)
          Log.e("TAG_PROXY_ProxyTask", Log.getStackTraceString((Throwable)b1)); 
        return false;
      } catch (Exception exception) {
        if (e.c)
          Log.e("TAG_PROXY_ProxyTask", Log.getStackTraceString(exception)); 
      } 
    } 
    return false;
  }
  
  private byte[] a(a parama, b paramb, l.a parama1) throws IOException {
    if (parama != null) {
      if (e.c)
        Log.i("TAG_PROXY_ProxyTask", "get header from db"); 
      return com.bykv.vk.openvk.component.video.a.c.a.a(parama, paramb.b()).getBytes(com.bykv.vk.openvk.component.video.a.c.a.a);
    } 
    a a1 = a(parama1, 0, -1, "HEAD");
    if (a1 == null)
      return null; 
    try {
      a a2;
      String str = com.bykv.vk.openvk.component.video.a.c.a.a(a1, false, false);
      if (str == null) {
        a2 = com.bykv.vk.openvk.component.video.a.c.a.a(a1, this.b, this.h, this.i.c.a);
        if (e.c)
          Log.w("TAG_PROXY_ProxyTask", "get header from network"); 
        return com.bykv.vk.openvk.component.video.a.c.a.a(a2, paramb.b()).getBytes(com.bykv.vk.openvk.component.video.a.c.a.a);
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append(", rawKey: ");
      stringBuilder.append(this.g);
      stringBuilder.append(", url: ");
      stringBuilder.append(a2);
      throw new c(stringBuilder.toString());
    } finally {
      com.bykv.vk.openvk.component.video.a.c.a.a(a1.d());
    } 
  }
  
  private void b(b paramb, l.a parama) throws IOException, d {
    byte[] arrayOfByte = a(this.b.a(this.h, this.i.c.a), paramb, parama);
    if (arrayOfByte == null)
      return; 
    paramb.a(arrayOfByte, 0, arrayOfByte.length);
  }
  
  private void c(b paramb, l.a parama) throws h.a, d, IOException, a, b {
    if (this.q) {
      int i;
      File file = this.a.c(this.h);
      long l1 = file.length();
      a a1 = this.b.a(this.h, this.i.c.a);
      int j = paramb.b();
      long l2 = l1 - j;
      int k = (int)l2;
      if (a1 == null) {
        i = -1;
      } else {
        i = a1.c;
      } 
      if (l1 > paramb.b()) {
        if (e.c) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("cache hit, remainSize: ");
          stringBuilder.append(l2);
          Log.i("TAG_PROXY_ProxyTask", stringBuilder.toString());
        } 
        a(true, k, i, (int)l1, j);
        a(a1, file, paramb, parama);
        return;
      } 
      a(false, k, i, (int)l1, j);
    } else {
      a(false, 0, 0, 0, paramb.b());
    } 
    d(paramb, parama);
  }
  
  private void d(b paramb, l.a parama) throws d, IOException, a, b {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial i : ()V
    //   4: invokestatic elapsedRealtime : ()J
    //   7: lstore #8
    //   9: aload_1
    //   10: invokevirtual b : ()I
    //   13: istore #4
    //   15: aload_0
    //   16: aload_2
    //   17: iload #4
    //   19: aload_0
    //   20: getfield i : Lcom/bykv/vk/openvk/component/video/a/b/i;
    //   23: getfield c : Lcom/bykv/vk/openvk/component/video/a/b/i$a;
    //   26: getfield e : I
    //   29: ldc_w 'GET'
    //   32: invokevirtual a : (Lcom/bykv/vk/openvk/component/video/a/b/l$a;IILjava/lang/String;)Lcom/bykv/vk/openvk/component/video/a/b/e/a;
    //   35: astore #14
    //   37: aload #14
    //   39: ifnonnull -> 43
    //   42: return
    //   43: aconst_null
    //   44: astore #11
    //   46: aconst_null
    //   47: astore #13
    //   49: iconst_0
    //   50: istore_3
    //   51: aload #14
    //   53: iconst_0
    //   54: iconst_1
    //   55: invokestatic a : (Lcom/bykv/vk/openvk/component/video/a/b/e/a;ZZ)Ljava/lang/String;
    //   58: astore #12
    //   60: aload #12
    //   62: ifnonnull -> 946
    //   65: aload_0
    //   66: getfield b : Lcom/bykv/vk/openvk/component/video/a/b/b/c;
    //   69: aload_0
    //   70: getfield h : Ljava/lang/String;
    //   73: aload_0
    //   74: invokevirtual f : ()I
    //   77: invokevirtual a : (Ljava/lang/String;I)Lcom/bykv/vk/openvk/component/video/a/b/b/a;
    //   80: astore #12
    //   82: aload #14
    //   84: invokestatic a : (Lcom/bykv/vk/openvk/component/video/a/b/e/a;)I
    //   87: istore #5
    //   89: aload #12
    //   91: ifnull -> 280
    //   94: aload #12
    //   96: getfield c : I
    //   99: iload #5
    //   101: if_icmpeq -> 280
    //   104: getstatic com/bykv/vk/openvk/component/video/a/b/e.c : Z
    //   107: ifeq -> 178
    //   110: new java/lang/StringBuilder
    //   113: dup
    //   114: invokespecial <init> : ()V
    //   117: astore_1
    //   118: aload_1
    //   119: ldc_w 'Content-Length not match, old: '
    //   122: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   125: pop
    //   126: aload_1
    //   127: aload #12
    //   129: getfield c : I
    //   132: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   135: pop
    //   136: aload_1
    //   137: ldc_w ', '
    //   140: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   143: pop
    //   144: aload_1
    //   145: iload #5
    //   147: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   150: pop
    //   151: aload_1
    //   152: ldc_w ', key: '
    //   155: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   158: pop
    //   159: aload_1
    //   160: aload_0
    //   161: getfield h : Ljava/lang/String;
    //   164: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   167: pop
    //   168: ldc 'TAG_PROXY_ProxyTask'
    //   170: aload_1
    //   171: invokevirtual toString : ()Ljava/lang/String;
    //   174: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   177: pop
    //   178: new java/lang/StringBuilder
    //   181: dup
    //   182: invokespecial <init> : ()V
    //   185: astore_1
    //   186: aload_1
    //   187: ldc_w 'Content-Length not match, old length: '
    //   190: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   193: pop
    //   194: aload_1
    //   195: aload #12
    //   197: getfield c : I
    //   200: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   203: pop
    //   204: aload_1
    //   205: ldc_w ', new length: '
    //   208: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   211: pop
    //   212: aload_1
    //   213: iload #5
    //   215: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   218: pop
    //   219: aload_1
    //   220: ldc_w ', rawKey: '
    //   223: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   226: pop
    //   227: aload_1
    //   228: aload_0
    //   229: getfield g : Ljava/lang/String;
    //   232: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   235: pop
    //   236: aload_1
    //   237: ldc_w ', currentUrl: '
    //   240: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   243: pop
    //   244: aload_1
    //   245: aload_2
    //   246: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   249: pop
    //   250: aload_1
    //   251: ldc_w ', previousInfo: '
    //   254: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   257: pop
    //   258: aload_1
    //   259: aload #12
    //   261: getfield e : Ljava/lang/String;
    //   264: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   267: pop
    //   268: new com/bykv/vk/openvk/component/video/a/b/c/b
    //   271: dup
    //   272: aload_1
    //   273: invokevirtual toString : ()Ljava/lang/String;
    //   276: invokespecial <init> : (Ljava/lang/String;)V
    //   279: athrow
    //   280: aload_1
    //   281: invokevirtual a : ()Z
    //   284: ifne -> 315
    //   287: aload #14
    //   289: iload #4
    //   291: invokestatic a : (Lcom/bykv/vk/openvk/component/video/a/b/e/a;I)Ljava/lang/String;
    //   294: astore_2
    //   295: aload_0
    //   296: invokevirtual e : ()V
    //   299: aload_2
    //   300: getstatic com/bykv/vk/openvk/component/video/a/c/a.a : Ljava/nio/charset/Charset;
    //   303: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   306: astore_2
    //   307: aload_1
    //   308: aload_2
    //   309: iconst_0
    //   310: aload_2
    //   311: arraylength
    //   312: invokevirtual a : ([BII)V
    //   315: aload_0
    //   316: invokevirtual e : ()V
    //   319: aload_0
    //   320: getfield a : Lcom/bykv/vk/openvk/component/video/a/b/a/a;
    //   323: aload_0
    //   324: getfield h : Ljava/lang/String;
    //   327: invokevirtual d : (Ljava/lang/String;)Ljava/io/File;
    //   330: astore #15
    //   332: aload_0
    //   333: getfield q : Z
    //   336: istore #10
    //   338: iload #10
    //   340: ifeq -> 533
    //   343: aload #15
    //   345: ifnull -> 533
    //   348: aload #15
    //   350: invokevirtual length : ()J
    //   353: aload_1
    //   354: invokevirtual b : ()I
    //   357: i2l
    //   358: lcmp
    //   359: iflt -> 533
    //   362: aload #14
    //   364: aload_0
    //   365: getfield b : Lcom/bykv/vk/openvk/component/video/a/b/b/c;
    //   368: aload_0
    //   369: getfield h : Ljava/lang/String;
    //   372: aload_0
    //   373: getfield i : Lcom/bykv/vk/openvk/component/video/a/b/i;
    //   376: getfield c : Lcom/bykv/vk/openvk/component/video/a/b/i$a;
    //   379: getfield a : I
    //   382: invokestatic a : (Lcom/bykv/vk/openvk/component/video/a/b/e/a;Lcom/bykv/vk/openvk/component/video/a/b/b/c;Ljava/lang/String;I)Lcom/bykv/vk/openvk/component/video/a/b/b/a;
    //   385: pop
    //   386: new com/bykv/vk/openvk/component/video/a/b/h
    //   389: dup
    //   390: aload #15
    //   392: ldc_w 'rwd'
    //   395: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   398: astore #12
    //   400: aload #12
    //   402: astore_2
    //   403: aload #12
    //   405: aload_1
    //   406: invokevirtual b : ()I
    //   409: i2l
    //   410: invokevirtual a : (J)V
    //   413: goto -> 436
    //   416: astore #11
    //   418: aload #12
    //   420: astore_2
    //   421: goto -> 428
    //   424: astore #11
    //   426: aconst_null
    //   427: astore_2
    //   428: aload #11
    //   430: invokevirtual printStackTrace : ()V
    //   433: aconst_null
    //   434: astore #12
    //   436: aload #12
    //   438: astore #11
    //   440: aload #12
    //   442: astore_2
    //   443: getstatic com/bykv/vk/openvk/component/video/a/b/e.c : Z
    //   446: ifeq -> 595
    //   449: aload #12
    //   451: astore_2
    //   452: new java/lang/StringBuilder
    //   455: dup
    //   456: invokespecial <init> : ()V
    //   459: astore #11
    //   461: aload #12
    //   463: astore_2
    //   464: aload #11
    //   466: ldc_w 'can write to cache file in network task, cache file size: '
    //   469: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   472: pop
    //   473: aload #12
    //   475: astore_2
    //   476: aload #11
    //   478: aload #15
    //   480: invokevirtual length : ()J
    //   483: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   486: pop
    //   487: aload #12
    //   489: astore_2
    //   490: aload #11
    //   492: ldc_w ', from: '
    //   495: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   498: pop
    //   499: aload #12
    //   501: astore_2
    //   502: aload #11
    //   504: aload_1
    //   505: invokevirtual b : ()I
    //   508: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   511: pop
    //   512: aload #12
    //   514: astore_2
    //   515: ldc 'TAG_PROXY_ProxyTask'
    //   517: aload #11
    //   519: invokevirtual toString : ()Ljava/lang/String;
    //   522: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   525: pop
    //   526: aload #12
    //   528: astore #11
    //   530: goto -> 595
    //   533: getstatic com/bykv/vk/openvk/component/video/a/b/e.c : Z
    //   536: ifeq -> 592
    //   539: new java/lang/StringBuilder
    //   542: dup
    //   543: invokespecial <init> : ()V
    //   546: astore_2
    //   547: aload_2
    //   548: ldc_w 'can't write to cache file in network task, cache file size: '
    //   551: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   554: pop
    //   555: aload_2
    //   556: aload #15
    //   558: invokevirtual length : ()J
    //   561: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   564: pop
    //   565: aload_2
    //   566: ldc_w ', from: '
    //   569: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   572: pop
    //   573: aload_2
    //   574: aload_1
    //   575: invokevirtual b : ()I
    //   578: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   581: pop
    //   582: ldc 'TAG_PROXY_ProxyTask'
    //   584: aload_2
    //   585: invokevirtual toString : ()Ljava/lang/String;
    //   588: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   591: pop
    //   592: aconst_null
    //   593: astore #11
    //   595: aload #11
    //   597: astore_2
    //   598: aload_0
    //   599: getfield b : Lcom/bykv/vk/openvk/component/video/a/b/b/c;
    //   602: aload_0
    //   603: getfield h : Ljava/lang/String;
    //   606: aload_0
    //   607: invokevirtual f : ()I
    //   610: invokevirtual a : (Ljava/lang/String;I)Lcom/bykv/vk/openvk/component/video/a/b/b/a;
    //   613: astore #12
    //   615: aload #12
    //   617: ifnonnull -> 626
    //   620: iconst_0
    //   621: istore #6
    //   623: goto -> 636
    //   626: aload #11
    //   628: astore_2
    //   629: aload #12
    //   631: getfield c : I
    //   634: istore #6
    //   636: aload #11
    //   638: astore_2
    //   639: sipush #8192
    //   642: newarray byte
    //   644: astore #15
    //   646: aload #11
    //   648: astore_2
    //   649: aload #14
    //   651: invokevirtual d : ()Ljava/io/InputStream;
    //   654: astore #16
    //   656: iconst_0
    //   657: istore #4
    //   659: aload #11
    //   661: astore_2
    //   662: iload #4
    //   664: istore_3
    //   665: aload #16
    //   667: aload #15
    //   669: invokevirtual read : ([B)I
    //   672: istore #7
    //   674: iload #7
    //   676: iflt -> 858
    //   679: aload #11
    //   681: astore_2
    //   682: iload #4
    //   684: istore_3
    //   685: aload_0
    //   686: invokevirtual e : ()V
    //   689: aload #11
    //   691: astore #12
    //   693: iload #4
    //   695: istore #5
    //   697: iload #7
    //   699: ifle -> 837
    //   702: aload #11
    //   704: astore_2
    //   705: iload #4
    //   707: istore_3
    //   708: aload_1
    //   709: aload #15
    //   711: iconst_0
    //   712: iload #7
    //   714: invokevirtual b : ([BII)V
    //   717: iload #4
    //   719: iload #7
    //   721: iadd
    //   722: istore #5
    //   724: aload #11
    //   726: astore #12
    //   728: aload #11
    //   730: ifnull -> 821
    //   733: aload #11
    //   735: aload #15
    //   737: iconst_0
    //   738: iload #7
    //   740: invokevirtual a : ([BII)V
    //   743: aload #11
    //   745: astore #12
    //   747: goto -> 821
    //   750: astore #12
    //   752: aload #11
    //   754: astore_2
    //   755: iload #5
    //   757: istore_3
    //   758: aload #11
    //   760: invokevirtual a : ()V
    //   763: getstatic com/bykv/vk/openvk/component/video/a/b/e.c : Z
    //   766: ifeq -> 805
    //   769: new java/lang/StringBuilder
    //   772: dup
    //   773: invokespecial <init> : ()V
    //   776: astore_2
    //   777: aload_2
    //   778: ldc_w 'append to cache file error in network task!!! '
    //   781: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   784: pop
    //   785: aload_2
    //   786: aload #12
    //   788: invokestatic getStackTraceString : (Ljava/lang/Throwable;)Ljava/lang/String;
    //   791: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   794: pop
    //   795: ldc 'TAG_PROXY_ProxyTask'
    //   797: aload_2
    //   798: invokevirtual toString : ()Ljava/lang/String;
    //   801: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   804: pop
    //   805: aconst_null
    //   806: astore #12
    //   808: goto -> 821
    //   811: astore_1
    //   812: aload #13
    //   814: astore_2
    //   815: iload #5
    //   817: istore_3
    //   818: goto -> 939
    //   821: aload #12
    //   823: astore_2
    //   824: iload #5
    //   826: istore_3
    //   827: aload_0
    //   828: iload #6
    //   830: aload_1
    //   831: invokevirtual b : ()I
    //   834: invokevirtual a : (II)V
    //   837: aload #12
    //   839: astore_2
    //   840: iload #5
    //   842: istore_3
    //   843: aload_0
    //   844: invokevirtual e : ()V
    //   847: aload #12
    //   849: astore #11
    //   851: iload #5
    //   853: istore #4
    //   855: goto -> 659
    //   858: aload #11
    //   860: astore_2
    //   861: iload #4
    //   863: istore_3
    //   864: getstatic com/bykv/vk/openvk/component/video/a/b/e.c : Z
    //   867: ifeq -> 885
    //   870: aload #11
    //   872: astore_2
    //   873: iload #4
    //   875: istore_3
    //   876: ldc 'TAG_PROXY_ProxyTask'
    //   878: ldc_w 'read from net complete!'
    //   881: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   884: pop
    //   885: aload #11
    //   887: astore_2
    //   888: iload #4
    //   890: istore_3
    //   891: aload_0
    //   892: invokevirtual c : ()V
    //   895: aload #14
    //   897: invokevirtual d : ()Ljava/io/InputStream;
    //   900: invokestatic a : (Ljava/io/Closeable;)V
    //   903: aload #11
    //   905: ifnull -> 913
    //   908: aload #11
    //   910: invokevirtual a : ()V
    //   913: aload_0
    //   914: getfield c : Ljava/util/concurrent/atomic/AtomicInteger;
    //   917: iload #4
    //   919: invokevirtual addAndGet : (I)I
    //   922: pop
    //   923: aload_0
    //   924: getfield d : Ljava/util/concurrent/atomic/AtomicLong;
    //   927: invokestatic elapsedRealtime : ()J
    //   930: lload #8
    //   932: lsub
    //   933: invokevirtual addAndGet : (J)J
    //   936: pop2
    //   937: return
    //   938: astore_1
    //   939: goto -> 1007
    //   942: astore_1
    //   943: goto -> 1007
    //   946: new java/lang/StringBuilder
    //   949: dup
    //   950: invokespecial <init> : ()V
    //   953: astore_1
    //   954: aload_1
    //   955: aload #12
    //   957: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   960: pop
    //   961: aload_1
    //   962: ldc_w ', rawKey: '
    //   965: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   968: pop
    //   969: aload_1
    //   970: aload_0
    //   971: getfield g : Ljava/lang/String;
    //   974: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   977: pop
    //   978: aload_1
    //   979: ldc ', url: '
    //   981: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   984: pop
    //   985: aload_1
    //   986: aload_2
    //   987: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   990: pop
    //   991: new com/bykv/vk/openvk/component/video/a/b/c/c
    //   994: dup
    //   995: aload_1
    //   996: invokevirtual toString : ()Ljava/lang/String;
    //   999: invokespecial <init> : (Ljava/lang/String;)V
    //   1002: athrow
    //   1003: astore_1
    //   1004: aload #11
    //   1006: astore_2
    //   1007: aload #14
    //   1009: invokevirtual d : ()Ljava/io/InputStream;
    //   1012: invokestatic a : (Ljava/io/Closeable;)V
    //   1015: aload_2
    //   1016: ifnull -> 1023
    //   1019: aload_2
    //   1020: invokevirtual a : ()V
    //   1023: aload_0
    //   1024: getfield c : Ljava/util/concurrent/atomic/AtomicInteger;
    //   1027: iload_3
    //   1028: invokevirtual addAndGet : (I)I
    //   1031: pop
    //   1032: aload_0
    //   1033: getfield d : Ljava/util/concurrent/atomic/AtomicLong;
    //   1036: invokestatic elapsedRealtime : ()J
    //   1039: lload #8
    //   1041: lsub
    //   1042: invokevirtual addAndGet : (J)J
    //   1045: pop2
    //   1046: goto -> 1051
    //   1049: aload_1
    //   1050: athrow
    //   1051: goto -> 1049
    // Exception table:
    //   from	to	target	type
    //   51	60	1003	finally
    //   65	89	1003	finally
    //   94	178	1003	finally
    //   178	280	1003	finally
    //   280	315	1003	finally
    //   315	338	1003	finally
    //   348	386	1003	finally
    //   386	400	424	com/bykv/vk/openvk/component/video/a/b/h$a
    //   386	400	1003	finally
    //   403	413	416	com/bykv/vk/openvk/component/video/a/b/h$a
    //   403	413	942	finally
    //   428	433	942	finally
    //   443	449	942	finally
    //   452	461	942	finally
    //   464	473	942	finally
    //   476	487	942	finally
    //   490	499	942	finally
    //   502	512	942	finally
    //   515	526	942	finally
    //   533	592	1003	finally
    //   598	615	942	finally
    //   629	636	942	finally
    //   639	646	942	finally
    //   649	656	942	finally
    //   665	674	938	finally
    //   685	689	938	finally
    //   708	717	938	finally
    //   733	743	750	finally
    //   758	763	938	finally
    //   763	805	811	finally
    //   827	837	938	finally
    //   843	847	938	finally
    //   864	870	938	finally
    //   876	885	938	finally
    //   891	895	938	finally
    //   946	1003	1003	finally
  }
  
  private b h() {
    try {
      c c1;
      this.i = i.a(this.m.getInputStream());
      OutputStream outputStream = this.m.getOutputStream();
      if (this.i.c.a == 1) {
        b b1 = e.a;
      } else {
        c1 = e.b;
      } 
      if (c1 == null) {
        if (e.c) {
          Log.e("TAG_PROXY_ProxyTask", "cache is null");
          return null;
        } 
      } else {
        this.a = (a)c1;
        this.g = this.i.c.b;
        this.h = this.i.c.c;
        this.j = new l(this.i.c.g);
        this.f = this.i.b;
        if (e.c) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("request from MediaPlayer:    ");
          stringBuilder.append(this.i.toString());
          Log.i("TAG_PROXY_ProxyTask", stringBuilder.toString());
        } 
        return new b(outputStream, this.i.c.d);
      } 
    } catch (IOException iOException) {
      Boolean bool;
      com.bykv.vk.openvk.component.video.a.c.a.a(this.m);
      if (e.c)
        Log.e("TAG_PROXY_ProxyTask", Log.getStackTraceString(iOException)); 
      if (this.a == null) {
        bool = null;
      } else {
        bool = Boolean.valueOf(g());
      } 
      a(bool, this.g, iOException);
      return null;
    } catch (d d1) {
      Boolean bool;
      com.bykv.vk.openvk.component.video.a.c.a.a(this.m);
      if (e.c)
        Log.e("TAG_PROXY_ProxyTask", Log.getStackTraceString((Throwable)d1)); 
      if (this.a == null) {
        bool = null;
      } else {
        bool = Boolean.valueOf(g());
      } 
      a(bool, this.g, (Throwable)d1);
      return null;
    } 
    return null;
  }
  
  private void i() {
    b b1 = this.p;
    this.p = null;
    if (b1 != null)
      b1.a(); 
  }
  
  public void a() {
    super.a();
    i();
  }
  
  public void run() {
    b b1 = h();
    if (b1 == null)
      return; 
    c c2 = this.n;
    if (c2 != null)
      c2.a(this); 
    this.a.a(this.h);
    if (e.h != 0) {
      a a1 = this.b.a(this.h, this.i.c.a);
      if (a1 == null || this.a.c(this.h).length() < a1.c)
        this.o.a(g(), this.h); 
    } 
    try {
      a(b1);
    } catch (a a1) {
    
    } finally {
      b1 = null;
    } 
    this.o.a(g(), null);
    a();
    com.bykv.vk.openvk.component.video.a.c.a.a(this.m);
    c c1 = this.n;
    if (c1 != null)
      c1.b(this); 
  }
  
  static final class a {
    a a;
    
    c b;
    
    Socket c;
    
    g.c d;
    
    a a(c param1c) {
      if (param1c != null) {
        this.b = param1c;
        return this;
      } 
      throw new IllegalArgumentException("db == null");
    }
    
    a a(g.c param1c) {
      this.d = param1c;
      return this;
    }
    
    a a(Socket param1Socket) {
      if (param1Socket != null) {
        this.c = param1Socket;
        return this;
      } 
      throw new IllegalArgumentException("socket == null");
    }
    
    g a() {
      if (this.b != null && this.c != null)
        return new g(this); 
      throw new IllegalArgumentException();
    }
  }
  
  private static class b {
    private final OutputStream a;
    
    private int b;
    
    private boolean c;
    
    b(OutputStream param1OutputStream, int param1Int) {
      this.a = param1OutputStream;
      this.b = param1Int;
    }
    
    void a(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws d {
      if (!this.c)
        try {
          this.a.write(param1ArrayOfbyte, param1Int1, param1Int2);
          this.c = true;
          return;
        } catch (IOException iOException) {
          throw new d(iOException);
        }  
    }
    
    boolean a() {
      return this.c;
    }
    
    int b() {
      return this.b;
    }
    
    void b(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws d {
      try {
        this.a.write(param1ArrayOfbyte, param1Int1, param1Int2);
        this.b += param1Int2;
        return;
      } catch (IOException iOException) {
        throw new d(iOException);
      } 
    }
  }
  
  public static interface c {
    void a(g param1g);
    
    void b(g param1g);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bykv\vk\openvk\component\video\a\b\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */