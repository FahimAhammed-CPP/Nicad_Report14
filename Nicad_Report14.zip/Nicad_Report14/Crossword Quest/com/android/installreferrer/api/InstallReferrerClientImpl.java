package com.android.installreferrer.api;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import com.android.installreferrer.commons.InstallReferrerCommons;
import com.google.android.finsky.externalreferrer.IGetInstallReferrerService;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;

class InstallReferrerClientImpl extends InstallReferrerClient {
  private static final int PLAY_STORE_MIN_APP_VER = 80837300;
  
  private static final String SERVICE_ACTION_NAME = "com.google.android.finsky.BIND_GET_INSTALL_REFERRER_SERVICE";
  
  private static final String SERVICE_NAME = "com.google.android.finsky.externalreferrer.GetInstallReferrerService";
  
  private static final String SERVICE_PACKAGE_NAME = "com.android.vending";
  
  private static final String TAG = "InstallReferrerClient";
  
  private int clientState = 0;
  
  private final Context mApplicationContext;
  
  private IGetInstallReferrerService service;
  
  private ServiceConnection serviceConnection;
  
  public InstallReferrerClientImpl(Context paramContext) {
    this.mApplicationContext = paramContext.getApplicationContext();
  }
  
  private boolean isPlayStoreCompatible() {
    PackageManager packageManager = this.mApplicationContext.getPackageManager();
    try {
      int i = (packageManager.getPackageInfo("com.android.vending", 128)).versionCode;
      return (i >= 80837300);
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      return false;
    } 
  }
  
  public void endConnection() {
    this.clientState = 3;
    if (this.serviceConnection != null) {
      InstallReferrerCommons.logVerbose("InstallReferrerClient", "Unbinding from service.");
      this.mApplicationContext.unbindService(this.serviceConnection);
      this.serviceConnection = null;
    } 
    this.service = null;
  }
  
  public ReferrerDetails getInstallReferrer() throws RemoteException {
    if (isReady()) {
      Bundle bundle = new Bundle();
      bundle.putString("package_name", this.mApplicationContext.getPackageName());
      try {
        return new ReferrerDetails(this.service.c(bundle));
      } catch (RemoteException remoteException) {
        InstallReferrerCommons.logWarn("InstallReferrerClient", "RemoteException getting install referrer information");
        this.clientState = 0;
        throw remoteException;
      } 
    } 
    throw new IllegalStateException("Service not connected. Please start a connection before using the service.");
  }
  
  public boolean isReady() {
    return (this.clientState == 2 && this.service != null && this.serviceConnection != null);
  }
  
  public void startConnection(InstallReferrerStateListener paramInstallReferrerStateListener) {
    if (isReady()) {
      InstallReferrerCommons.logVerbose("InstallReferrerClient", "Service connection is valid. No need to re-initialize.");
      paramInstallReferrerStateListener.onInstallReferrerSetupFinished(0);
      return;
    } 
    int i = this.clientState;
    if (i == 1) {
      InstallReferrerCommons.logWarn("InstallReferrerClient", "Client is already in the process of connecting to the service.");
      paramInstallReferrerStateListener.onInstallReferrerSetupFinished(3);
      return;
    } 
    if (i == 3) {
      InstallReferrerCommons.logWarn("InstallReferrerClient", "Client was already closed and can't be reused. Please create another instance.");
      paramInstallReferrerStateListener.onInstallReferrerSetupFinished(3);
      return;
    } 
    InstallReferrerCommons.logVerbose("InstallReferrerClient", "Starting install referrer service setup.");
    Intent intent = new Intent("com.google.android.finsky.BIND_GET_INSTALL_REFERRER_SERVICE");
    intent.setComponent(new ComponentName("com.android.vending", "com.google.android.finsky.externalreferrer.GetInstallReferrerService"));
    List<ResolveInfo> list = this.mApplicationContext.getPackageManager().queryIntentServices(intent, 0);
    if (list != null && !list.isEmpty()) {
      ResolveInfo resolveInfo = list.get(0);
      if (resolveInfo.serviceInfo != null) {
        String str1 = resolveInfo.serviceInfo.packageName;
        String str2 = resolveInfo.serviceInfo.name;
        if ("com.android.vending".equals(str1) && str2 != null && isPlayStoreCompatible()) {
          intent = new Intent(intent);
          InstallReferrerServiceConnection installReferrerServiceConnection = new InstallReferrerServiceConnection(paramInstallReferrerStateListener);
          this.serviceConnection = installReferrerServiceConnection;
          try {
            boolean bool = this.mApplicationContext.bindService(intent, installReferrerServiceConnection, 1);
            if (bool) {
              InstallReferrerCommons.logVerbose("InstallReferrerClient", "Service was bonded successfully.");
              return;
            } 
            InstallReferrerCommons.logWarn("InstallReferrerClient", "Connection to service is blocked.");
            this.clientState = 0;
            paramInstallReferrerStateListener.onInstallReferrerSetupFinished(1);
            return;
          } catch (SecurityException securityException) {
            InstallReferrerCommons.logWarn("InstallReferrerClient", "No permission to connect to service.");
            this.clientState = 0;
            paramInstallReferrerStateListener.onInstallReferrerSetupFinished(4);
            return;
          } 
        } 
        InstallReferrerCommons.logWarn("InstallReferrerClient", "Play Store missing or incompatible. Version 8.3.73 or later required.");
        this.clientState = 0;
        paramInstallReferrerStateListener.onInstallReferrerSetupFinished(2);
        return;
      } 
    } 
    this.clientState = 0;
    InstallReferrerCommons.logVerbose("InstallReferrerClient", "Install Referrer service unavailable on device.");
    paramInstallReferrerStateListener.onInstallReferrerSetupFinished(2);
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface ClientState {
    public static final int CLOSED = 3;
    
    public static final int CONNECTED = 2;
    
    public static final int CONNECTING = 1;
    
    public static final int DISCONNECTED = 0;
  }
  
  private final class InstallReferrerServiceConnection implements ServiceConnection {
    private final InstallReferrerStateListener mListener;
    
    private InstallReferrerServiceConnection(InstallReferrerStateListener param1InstallReferrerStateListener) {
      if (param1InstallReferrerStateListener != null) {
        this.mListener = param1InstallReferrerStateListener;
        return;
      } 
      throw new RuntimeException("Please specify a listener to know when setup is done.");
    }
    
    public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
      InstallReferrerCommons.logVerbose("InstallReferrerClient", "Install Referrer service connected.");
      InstallReferrerClientImpl.access$102(InstallReferrerClientImpl.this, IGetInstallReferrerService.Stub.b(param1IBinder));
      InstallReferrerClientImpl.access$202(InstallReferrerClientImpl.this, 2);
      this.mListener.onInstallReferrerSetupFinished(0);
    }
    
    public void onServiceDisconnected(ComponentName param1ComponentName) {
      InstallReferrerCommons.logWarn("InstallReferrerClient", "Install Referrer service disconnected.");
      InstallReferrerClientImpl.access$102(InstallReferrerClientImpl.this, null);
      InstallReferrerClientImpl.access$202(InstallReferrerClientImpl.this, 0);
      this.mListener.onInstallReferrerServiceDisconnected();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\android\installreferrer\api\InstallReferrerClientImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */