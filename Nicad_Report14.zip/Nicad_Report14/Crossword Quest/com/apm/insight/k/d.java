package com.apm.insight.k;

import android.content.Context;
import com.apm.insight.CrashType;
import com.apm.insight.h.b;
import com.apm.insight.i;
import com.apm.insight.l.i;
import com.apm.insight.l.o;
import com.apm.insight.l.q;
import com.apm.insight.l.r;
import com.apm.insight.runtime.p;
import com.apm.insight.runtime.r;
import java.io.File;
import org.json.JSONException;
import org.json.JSONObject;

public class d {
  private static volatile d a;
  
  private volatile Context b;
  
  private d(Context paramContext) {
    this.b = paramContext;
  }
  
  public static d a() {
    if (a == null)
      a = new d(i.g()); 
    return a;
  }
  
  public void a(JSONObject paramJSONObject) {
    if (paramJSONObject != null)
      if (paramJSONObject.length() <= 0)
        return;  
  }
  
  public void a(JSONObject paramJSONObject, long paramLong, boolean paramBoolean) {
    if (paramJSONObject != null) {
      if (paramJSONObject.length() <= 0)
        return; 
      try {
        String str = e.c();
        File file1 = o.a(this.b);
        CrashType crashType = CrashType.ANR;
        int i = 0;
        File file2 = new File(file1, i.a(paramLong, crashType, false, false));
        i.a(file2, file2.getName(), str, paramJSONObject, e.b());
        return;
      } finally {
        paramJSONObject = null;
      } 
    } 
  }
  
  public boolean a(long paramLong, JSONObject paramJSONObject) {
    boolean bool = false;
    if (paramJSONObject != null) {
      if (paramJSONObject.length() <= 0)
        return false; 
      try {
        String str = e.c();
        File file = new File(o.a(this.b), o.a(i.e()));
        i.a(file, file.getName(), str, paramJSONObject, e.a());
        paramJSONObject.put("upload_scene", "direct");
        r.a(paramJSONObject);
        return bool;
      } finally {
        paramJSONObject = null;
      } 
    } 
    return false;
  }
  
  public boolean a(JSONObject paramJSONObject, File paramFile1, File paramFile2) {
    try {
      return e.a(str, paramJSONObject.toString(), new File[] { paramFile1, paramFile2, r.a(System.currentTimeMillis()), new File(b.a()) }).a();
    } finally {
      paramJSONObject = null;
      q.b((Throwable)paramJSONObject);
    } 
  }
  
  public void b(JSONObject paramJSONObject) {
    if (paramJSONObject != null) {
      if (paramJSONObject.length() == 0)
        return; 
      p.b().a(new Runnable(this, paramJSONObject) {
            public void run() {
              String str = e.c();
              try {
                this.a.put("upload_scene", "direct");
              } catch (JSONException jSONException) {
                jSONException.printStackTrace();
              } 
              e.b(str, this.a.toString());
            }
          });
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\apm\insight\k\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */